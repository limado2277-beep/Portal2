// Copia de la aplicación para poder abrirla sin conexión. Los datos no se guardan acá:
// los guarda compat.js en el aparato y se borran al salir.
const V = 'portal-v20', API = 'portal-api';
const SHELL = ['/', '/index.html', '/boot.js', '/compat.js', '/app.js', '/styles.css'];
self.addEventListener('install', e => { e.waitUntil(caches.open(V).then(c => Promise.all(SHELL.map(u => c.add(u).catch(() => {})))).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== V && k !== API).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const req = e.request; if (req.method !== 'GET') return;
  const url = new URL(req.url); if (url.origin !== location.origin) return;
  const p = url.pathname;
  if (p === '/api/config' || p === '/api/me') {
    e.respondWith(fetch(req).then(r => { if (r.ok) { const c = r.clone(); caches.open(API).then(x => x.put(req, c)); } return r; }).catch(() => caches.match(req).then(r => r || Promise.reject(new Error('sin conexión')))));
    return;
  }
  if (p.startsWith('/api/') || p.startsWith('/uploads/') || p === '/healthz') return;
  e.respondWith(fetch(req).then(r => { if (r.ok) { const c = r.clone(); caches.open(V).then(x => x.put(req, c)); } return r; }).catch(() => caches.match(req).then(r => r || (req.mode === 'navigate' ? caches.match('/index.html') : Promise.reject(new Error('sin conexión'))))));
});
