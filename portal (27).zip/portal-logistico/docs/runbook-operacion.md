# Runbook de operación

## Puesta en marcha
1. `cp .env.example .env` y completá `COMPANY_NAME`, `BASE_URL` (https), `ADMIN_EMAIL`, `DATA_DIR` (disco persistente) y, si querés, SMTP, `INTEGRATION_KEY`, `WEBHOOK_URL`/`WEBHOOK_SECRET`.
2. `npm start` (Node 22.13 o superior). Detrás de HTTPS (Caddy/nginx o el panel de tu hosting).
3. Entrá como administración, cambiá la clave y activá la verificación en dos pasos.

## Instalación desde cero (probada)
Con la carpeta del zip y Node 22.13+: `cp .env.example .env`, completar, `npm start`, entrar con el administrador, `npm test` (73 pruebas) y `npm run test:dr`. Esto se verificó en una carpeta vacía descomprimiendo el zip. Docker y Caddy no se pudieron ejecutar donde se armó el proyecto.
Opcional: `ROUTING_URL` (mapas reales con OSRM) y `BACKUP_DIR` (copias en otro disco).

## Copias de seguridad
- Con Docker, el servicio `backup` hace una copia diaria; con `npm run clientes` el supervisor hace una por cliente. Sin eso, programá `npm run backup` con cron. Manual: `npm run backup`. Se conservan `BACKUP_KEEP` copias.
- **Guardá una copia fuera del servidor** (otro disco o nube) una vez por semana.

## Restaurar (probado: `npm run test:dr`)
1. Parar el servicio.
2. `node scripts/restore.js RUTA/portal-AAAA-MM-DD.db CARPETA_DATOS`
   - Verifica la integridad antes de tocar nada, guarda la base vieja como `.anterior` y restaura los archivos subidos.
3. Arrancar y comprobar: ingreso, una entrega reciente y el stock.
4. Cada trimestre ensayá la restauración en una carpeta aparte con `npm run test:dr` (copia, destruye una base de prueba, restaura y compara usuarios, entregas, fotos y claves).
5. Si dice "no es una base válida", usá la copia anterior.

## Incidentes
| Síntoma | Qué hacer |
|---|---|
| Choferes sin conexión | Siguen trabajando; los cambios se envían al volver la señal. Revisá el servicio y el dominio. |
| Alguien perdió el segundo factor | Administración lo desactiva para ese usuario y lo vuelve a activar. |
| Sospecha de clave filtrada | Cambiar la clave (cierra todas las sesiones), rotar `INTEGRATION_KEY`/`WEBHOOK_SECRET`, revisar la auditoría. |
| Mapas dicen "no se pudo consultar" | El ruteo es opcional: se sigue con la estimación. Revisá que `ROUTING_URL` responda desde el servidor. |
| Cambios de un chofer "perdidos" | Aparecen en la lista roja del banner del chofer (permisos o dato rechazado); revisá y volvé a cargarlos. |
| Lentitud | `npm run loadtest` en una copia para medir; ver README (límites y migración a PostgreSQL). |

## Actualizaciones
Actualizá Node y el sistema operativo todos los meses. Antes de cambiar el código: copia manual y `npm test`.
