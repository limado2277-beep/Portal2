
(function(){
'use strict';
/* ---------- utilidades ---------- */
var esc=function(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});};
var pad=function(n){return String(n).padStart(2,'0');};
/* Ubicaciones: pasillo:rack:ubicación:altura (ej. 01:01:01:00 = pasillo 01, rack 01, ubicación 01, altura 00 = el piso; 01:01:01:03 = tres pisos arriba). Al leer se aceptan - . / como separador; se guarda siempre con ":". */
var locParse=function(c){var m=String(c==null?'':c).trim().match(/^(\d{1,3})\s*[:\-.\/]\s*(\d{1,3})\s*[:\-.\/]\s*(\d{1,3})\s*[:\-.\/]\s*(\d{1,3})$/);return m?{p:+m[1],r:+m[2],u:+m[3],a:+m[4]}:null;};
var locFmt=function(p,r,u,a){return pad(p)+':'+pad(r)+':'+pad(u)+':'+pad(a);};
var locNorm=function(c){var o=locParse(c);return o?locFmt(o.p,o.r,o.u,o.a):String(c==null?'':c).trim();};
var locCell=function(v){if(v instanceof Date)return '(hora de Excel)';return locNorm(v);};
var locTxt=function(c){var o=locParse(c);return o?'Pasillo '+pad(o.p)+' · Rack '+pad(o.r)+' · Ubicación '+pad(o.u)+' · '+(o.a===0?'Piso (altura 00)':'Altura '+pad(o.a)):String(c==null?'':c);};
var ymd=function(d){return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());};
var addDays=function(n){var d=new Date();d.setDate(d.getDate()+n);return ymd(d);};
var HOY=addDays(0);
var at=function(off,h,m){var d=new Date();d.setDate(d.getDate()+off);d.setHours(h,m,0,0);return d.toISOString();};
var fmtFecha=function(s){
  if(s===HOY)return 'Hoy'; if(s===addDays(1))return 'Mañana'; if(s===addDays(-1))return 'Ayer';
  var p=s.split('-').map(Number); return new Date(p[0],p[1]-1,p[2]).toLocaleDateString('es-AR',{weekday:'short',day:'numeric',month:'short'});};
var fmtHora=function(iso){return new Date(iso).toLocaleTimeString('es-AR',{hour:'2-digit',minute:'2-digit'});};
var fmtARS=function(n){return Number(n||0).toLocaleString('es-AR',{style:'currency',currency:'ARS',maximumFractionDigits:0});};
var EST={programada:['Programada',''],en_camino:['En camino','signal'],entregada:['Entregada','ok'],no_entregada:['No entregada','bad']};
var FACT={pendiente:'Sin facturar',emitida:'Emitida',pagada:'Pagada'};
var ICON={
  truck:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 6h11v10H2zM13 9h5l4 4v3h-9"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/></svg>',
  nav:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 11l18-8-8 18-2-8z"/></svg>',
  bell:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9a6 6 0 0112 0c0 6 2 7 2 7H4s2-1 2-7zM10 20a2 2 0 004 0"/></svg>',
  check:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5 9-10"/></svg>',
  alert:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l10 18H2zM12 10v5M12 18h.01"/></svg>'
};
var ventana=function(e){return e.desde+' a '+e.hasta+' h';};
var hav=function(a,b){var R=6371,t=function(x){return x*Math.PI/180;},dl=t(b.lat-a.lat),dn=t(b.lng-a.lng);
  var h=Math.pow(Math.sin(dl/2),2)+Math.cos(t(a.lat))*Math.cos(t(b.lat))*Math.pow(Math.sin(dn/2),2);return 2*R*Math.asin(Math.sqrt(h));};
var FACTOR=1.3;
var pathKm=function(start,stops){var k=0,p=start;stops.forEach(function(s){k+=hav(p,s);p=s;});return k*FACTOR;};
function optimize(start,stops){
  var rest=stops.slice(),out=[],p=start;
  while(rest.length){var bi=0,bd=1e12;rest.forEach(function(s,i){var d=hav(p,s);if(d<bd){bd=d;bi=i;}});p=rest.splice(bi,1)[0];out.push(p);}
  var improved=true,guard=0;
  while(improved&&guard++<50){improved=false;
    for(var i=0;i<out.length-1;i++)for(var j=i+1;j<out.length;j++){
      var cand=out.slice(0,i).concat(out.slice(i,j+1).reverse(),out.slice(j+1));
      if(pathKm(start,cand)<pathKm(start,out)-1e-9){out=cand;improved=true;}}}
  return out;}
var hasXY=function(e){return typeof e.lat==='number'&&typeof e.lng==='number';};
var wazeUrl=function(e){return hasXY(e)?'https://waze.com/ul?ll='+e.lat+','+e.lng+'&navigate=yes&zoom=17':'https://waze.com/ul?q='+encodeURIComponent(e.direccion||'')+'&navigate=yes';};

/* ---------- datos de demostración (ficticios) ---------- */
var VIAJES_DEMO=[{"id": "G-0001", "guia": "G-0001", "fecha": "2026-05-29", "proveedor": "Trans SRL", "ruta": "Buenos Aires - Rosario", "vehiculo": "Camion", "km": 300, "ton": 10.8, "tarifaKm": 1840, "costoKm": 1815, "peaje": 17600}, {"id": "G-0002", "guia": "G-0002", "fecha": "2026-06-02", "proveedor": "Logistica Norte", "ruta": "Buenos Aires - Cordoba", "vehiculo": "Camioneta", "km": 700, "ton": 3.7, "tarifaKm": 950, "costoKm": 1035, "peaje": 35200}, {"id": "G-0003", "guia": "G-0003", "fecha": "2026-06-06", "proveedor": "Cargo Express", "ruta": "Buenos Aires - Mendoza", "vehiculo": "Semirremolque", "km": 1050, "ton": 26.3, "tarifaKm": 2420, "costoKm": 2800, "peaje": 44000}, {"id": "G-0004", "guia": "G-0004", "fecha": "2026-06-10", "proveedor": "Trans SRL", "ruta": "Buenos Aires - Bahia Blanca", "vehiculo": "Camion", "km": 620, "ton": 11.5, "tarifaKm": 1840, "costoKm": 1785, "peaje": 26400}, {"id": "G-0005", "guia": "G-0005", "fecha": "2026-06-14", "proveedor": "Logistica Norte", "ruta": "Buenos Aires - Mar del Plata", "vehiculo": "Camioneta", "km": 400, "ton": 3.9, "tarifaKm": 950, "costoKm": 1040, "peaje": 17600}, {"id": "G-0006", "guia": "G-0006", "fecha": "2026-06-18", "proveedor": "Cargo Express", "ruta": "Buenos Aires - Neuquen", "vehiculo": "Semirremolque", "km": 1150, "ton": 25.2, "tarifaKm": 2420, "costoKm": 2470, "peaje": 44000}, {"id": "G-0007", "guia": "G-0007", "fecha": "2026-06-22", "proveedor": "Trans SRL", "ruta": "Buenos Aires - Salta", "vehiculo": "Camion", "km": 1600, "ton": 11, "tarifaKm": 1840, "costoKm": 2170, "peaje": 52800}, {"id": "G-0008", "guia": "G-0008", "fecha": "2026-06-26", "proveedor": "Logistica Norte", "ruta": "Buenos Aires - Posadas", "vehiculo": "Camioneta", "km": 1030, "ton": 3.8, "tarifaKm": 950, "costoKm": 900, "peaje": 35200}, {"id": "G-0009", "guia": "G-0009", "fecha": "2026-06-30", "proveedor": "Cargo Express", "ruta": "Buenos Aires - Resistencia", "vehiculo": "Semirremolque", "km": 1000, "ton": 26.9, "tarifaKm": 2420, "costoKm": 2565, "peaje": 35200}, {"id": "G-0010", "guia": "G-0010", "fecha": "2026-07-04", "proveedor": "Trans SRL", "ruta": "Buenos Aires - Comodoro Rivadavia", "vehiculo": "Camion", "km": 1780, "ton": 11.8, "tarifaKm": 1840, "costoKm": 2040, "peaje": 35200}, {"id": "G-0011", "guia": "G-0011", "fecha": "2026-07-08", "proveedor": "Logistica Norte", "ruta": "Buenos Aires - Rosario", "vehiculo": "Camioneta", "km": 300, "ton": 3.6, "tarifaKm": 950, "costoKm": 980, "peaje": 17600}, {"id": "G-0012", "guia": "G-0012", "fecha": "2026-07-12", "proveedor": "Cargo Express", "ruta": "Buenos Aires - Cordoba", "vehiculo": "Semirremolque", "km": 700, "ton": 25.8, "tarifaKm": 2420, "costoKm": 2930, "peaje": 35200}, {"id": "G-0013", "guia": "G-0013", "fecha": "2026-07-16", "proveedor": "Trans SRL", "ruta": "Buenos Aires - Mendoza", "vehiculo": "Camion", "km": 1050, "ton": 11.3, "tarifaKm": 1840, "costoKm": 1805, "peaje": 44000}, {"id": "G-0014", "guia": "G-0014", "fecha": "2026-07-20", "proveedor": "Logistica Norte", "ruta": "Buenos Aires - Bahia Blanca", "vehiculo": "Camioneta", "km": 620, "ton": 3.8, "tarifaKm": 950, "costoKm": 1025, "peaje": 26400}, {"id": "G-0015", "guia": "G-0015", "fecha": "2026-07-24", "proveedor": "Cargo Express", "ruta": "Buenos Aires - Mar del Plata", "vehiculo": "Semirremolque", "km": 400, "ton": 27.4, "tarifaKm": 2420, "costoKm": 2470, "peaje": 17600}, {"id": "G-0016", "guia": "G-0016", "fecha": "2026-07-28", "proveedor": "Trans SRL", "ruta": "Buenos Aires - Neuquen", "vehiculo": "Camion", "km": 1150, "ton": 10.8, "tarifaKm": 1840, "costoKm": 1925, "peaje": 44000}, {"id": "G-0017", "guia": "G-0017", "fecha": "2026-08-01", "proveedor": "Logistica Norte", "ruta": "Buenos Aires - Salta", "vehiculo": "Camioneta", "km": 1600, "ton": 3.7, "tarifaKm": 950, "costoKm": 925, "peaje": 52800}, {"id": "G-0018", "guia": "G-0018", "fecha": "2026-08-05", "proveedor": "Cargo Express", "ruta": "Buenos Aires - Posadas", "vehiculo": "Semirremolque", "km": 1030, "ton": 26.3, "tarifaKm": 2420, "costoKm": 2745, "peaje": 35200}, {"id": "G-0019", "guia": "G-0019", "fecha": "2026-08-09", "proveedor": "Trans SRL", "ruta": "Buenos Aires - Resistencia", "vehiculo": "Camion", "km": 1000, "ton": 11.5, "tarifaKm": 1840, "costoKm": 1970, "peaje": 35200}, {"id": "G-0020", "guia": "G-0020", "fecha": "2026-08-13", "proveedor": "Logistica Norte", "ruta": "Buenos Aires - Comodoro Rivadavia", "vehiculo": "Camioneta", "km": 1780, "ton": 3.9, "tarifaKm": 950, "costoKm": 965, "peaje": 35200}];
var WMS_DEMO={"skus":[{"id":"P001","codigo":"P001","producto":"Producto 1","categoria":"Envases","um":"UN","min":50,"max":300,"ubic":"01:01:01:00","deposito":"Deposito A","peso":0.4},{"id":"P002","codigo":"P002","producto":"Producto 2","categoria":"Materias Primas","um":"UN","min":60,"max":320,"ubic":"02:01:01:00","deposito":"Deposito B","peso":8},{"id":"P003","codigo":"P003","producto":"Producto 3","categoria":"Insumos","um":"UN","min":90,"max":450,"ubic":"01:01:01:01","deposito":"Deposito A","peso":2.5},{"id":"P004","codigo":"P004","producto":"Producto 4","categoria":"Productos Terminados","um":"UN","min":40,"max":250,"ubic":"03:01:01:00","deposito":"Deposito C","peso":6},{"id":"P005","codigo":"P005","producto":"Producto 5","categoria":"Envases","um":"UN","min":70,"max":350,"ubic":"02:01:01:01","deposito":"Deposito B","peso":0.4},{"id":"P006","codigo":"P006","producto":"Producto 6","categoria":"Materias Primas","um":"UN","min":55,"max":280,"ubic":"01:01:01:02","deposito":"Deposito A","peso":8},{"id":"P007","codigo":"P007","producto":"Producto 7","categoria":"Insumos","um":"UN","min":45,"max":230,"ubic":"03:01:01:01","deposito":"Deposito C","peso":2.5},{"id":"P008","codigo":"P008","producto":"Producto 8","categoria":"Productos Terminados","um":"UN","min":90,"max":420,"ubic":"02:01:01:02","deposito":"Deposito B","peso":6},{"id":"P009","codigo":"P009","producto":"Producto 9","categoria":"Insumos","um":"UN","min":45,"max":230,"ubic":"01:01:01:03","deposito":"Deposito A","peso":2.5},{"id":"P010","codigo":"P010","producto":"Producto 10","categoria":"Envases","um":"UN","min":60,"max":300,"ubic":"03:01:01:02","deposito":"Deposito C","peso":0.4},{"id":"P011","codigo":"P011","producto":"Producto 11","categoria":"Envases","um":"UN","min":55,"max":280,"ubic":"02:01:01:03","deposito":"Deposito B","peso":0.4},{"id":"CH01","codigo":"CH01","producto":"Producto 12","categoria":"Envases","um":"UN","min":15,"max":100,"ubic":"02:02:01:00","deposito":"Deposito B","peso":0.4}],"ubic":[{"id":"01:01:01:00","codigo":"01:01:01:00","descripcion":"Pasillo 1, Rack 1, Ubicación 1, Altura 00 (piso)","deposito":"Deposito A","cap":150},{"id":"01:01:01:01","codigo":"01:01:01:01","descripcion":"Pasillo 1, Rack 1, Ubicación 1, Altura 01","deposito":"Deposito A","cap":150},{"id":"01:01:01:02","codigo":"01:01:01:02","descripcion":"Pasillo 1, Rack 1, Ubicación 1, Altura 02","deposito":"Deposito A","cap":150},{"id":"01:01:01:03","codigo":"01:01:01:03","descripcion":"Pasillo 1, Rack 1, Ubicación 1, Altura 03","deposito":"Deposito A","cap":150},{"id":"01:02:01:00","codigo":"01:02:01:00","descripcion":"Pasillo 1, Rack 2, Ubicación 1, Altura 00 (piso)","deposito":"Deposito A","cap":150},{"id":"01:02:01:01","codigo":"01:02:01:01","descripcion":"Pasillo 1, Rack 2, Ubicación 1, Altura 01","deposito":"Deposito A","cap":150},{"id":"01:02:01:02","codigo":"01:02:01:02","descripcion":"Pasillo 1, Rack 2, Ubicación 1, Altura 02","deposito":"Deposito A","cap":150},{"id":"01:02:01:03","codigo":"01:02:01:03","descripcion":"Pasillo 1, Rack 2, Ubicación 1, Altura 03","deposito":"Deposito A","cap":150},{"id":"01:03:01:00","codigo":"01:03:01:00","descripcion":"Pasillo 1, Rack 3, Ubicación 1, Altura 00 (piso)","deposito":"Deposito A","cap":150},{"id":"01:03:01:01","codigo":"01:03:01:01","descripcion":"Pasillo 1, Rack 3, Ubicación 1, Altura 01","deposito":"Deposito A","cap":150},{"id":"01:03:01:02","codigo":"01:03:01:02","descripcion":"Pasillo 1, Rack 3, Ubicación 1, Altura 02","deposito":"Deposito A","cap":150},{"id":"01:03:01:03","codigo":"01:03:01:03","descripcion":"Pasillo 1, Rack 3, Ubicación 1, Altura 03","deposito":"Deposito A","cap":150},{"id":"02:01:01:00","codigo":"02:01:01:00","descripcion":"Pasillo 2, Rack 1, Ubicación 1, Altura 00 (piso)","deposito":"Deposito B","cap":150},{"id":"02:01:01:01","codigo":"02:01:01:01","descripcion":"Pasillo 2, Rack 1, Ubicación 1, Altura 01","deposito":"Deposito B","cap":150},{"id":"02:01:01:02","codigo":"02:01:01:02","descripcion":"Pasillo 2, Rack 1, Ubicación 1, Altura 02","deposito":"Deposito B","cap":150},{"id":"02:01:01:03","codigo":"02:01:01:03","descripcion":"Pasillo 2, Rack 1, Ubicación 1, Altura 03","deposito":"Deposito B","cap":150},{"id":"02:02:01:00","codigo":"02:02:01:00","descripcion":"Pasillo 2, Rack 2, Ubicación 1, Altura 00 (piso)","deposito":"Deposito B","cap":150},{"id":"02:02:01:01","codigo":"02:02:01:01","descripcion":"Pasillo 2, Rack 2, Ubicación 1, Altura 01","deposito":"Deposito B","cap":150},{"id":"02:02:01:02","codigo":"02:02:01:02","descripcion":"Pasillo 2, Rack 2, Ubicación 1, Altura 02","deposito":"Deposito B","cap":150},{"id":"02:02:01:03","codigo":"02:02:01:03","descripcion":"Pasillo 2, Rack 2, Ubicación 1, Altura 03","deposito":"Deposito B","cap":150},{"id":"02:03:01:00","codigo":"02:03:01:00","descripcion":"Pasillo 2, Rack 3, Ubicación 1, Altura 00 (piso)","deposito":"Deposito B","cap":150},{"id":"02:03:01:01","codigo":"02:03:01:01","descripcion":"Pasillo 2, Rack 3, Ubicación 1, Altura 01","deposito":"Deposito B","cap":150},{"id":"02:03:01:02","codigo":"02:03:01:02","descripcion":"Pasillo 2, Rack 3, Ubicación 1, Altura 02","deposito":"Deposito B","cap":150},{"id":"02:03:01:03","codigo":"02:03:01:03","descripcion":"Pasillo 2, Rack 3, Ubicación 1, Altura 03","deposito":"Deposito B","cap":150},{"id":"03:01:01:00","codigo":"03:01:01:00","descripcion":"Pasillo 3, Rack 1, Ubicación 1, Altura 00 (piso)","deposito":"Deposito C","cap":150},{"id":"03:01:01:01","codigo":"03:01:01:01","descripcion":"Pasillo 3, Rack 1, Ubicación 1, Altura 01","deposito":"Deposito C","cap":150},{"id":"03:01:01:02","codigo":"03:01:01:02","descripcion":"Pasillo 3, Rack 1, Ubicación 1, Altura 02","deposito":"Deposito C","cap":150},{"id":"03:01:01:03","codigo":"03:01:01:03","descripcion":"Pasillo 3, Rack 1, Ubicación 1, Altura 03","deposito":"Deposito C","cap":150},{"id":"03:02:01:00","codigo":"03:02:01:00","descripcion":"Pasillo 3, Rack 2, Ubicación 1, Altura 00 (piso)","deposito":"Deposito C","cap":150},{"id":"03:02:01:01","codigo":"03:02:01:01","descripcion":"Pasillo 3, Rack 2, Ubicación 1, Altura 01","deposito":"Deposito C","cap":150},{"id":"03:02:01:02","codigo":"03:02:01:02","descripcion":"Pasillo 3, Rack 2, Ubicación 1, Altura 02","deposito":"Deposito C","cap":150},{"id":"03:02:01:03","codigo":"03:02:01:03","descripcion":"Pasillo 3, Rack 2, Ubicación 1, Altura 03","deposito":"Deposito C","cap":150},{"id":"03:03:01:00","codigo":"03:03:01:00","descripcion":"Pasillo 3, Rack 3, Ubicación 1, Altura 00 (piso)","deposito":"Deposito C","cap":150},{"id":"03:03:01:01","codigo":"03:03:01:01","descripcion":"Pasillo 3, Rack 3, Ubicación 1, Altura 01","deposito":"Deposito C","cap":150},{"id":"03:03:01:02","codigo":"03:03:01:02","descripcion":"Pasillo 3, Rack 3, Ubicación 1, Altura 02","deposito":"Deposito C","cap":150},{"id":"03:03:01:03","codigo":"03:03:01:03","descripcion":"Pasillo 3, Rack 3, Ubicación 1, Altura 03","deposito":"Deposito C","cap":150},{"id":"01:01:02:00","codigo":"01:01:02:00","descripcion":"Pasillo 1, Rack 1, Ubicación 2, Altura 00 (piso)","deposito":"Deposito A","cap":150},{"id":"01:01:02:01","codigo":"01:01:02:01","descripcion":"Pasillo 1, Rack 1, Ubicación 2, Altura 01","deposito":"Deposito A","cap":150},{"id":"01:01:02:02","codigo":"01:01:02:02","descripcion":"Pasillo 1, Rack 1, Ubicación 2, Altura 02","deposito":"Deposito A","cap":150},{"id":"01:01:02:03","codigo":"01:01:02:03","descripcion":"Pasillo 1, Rack 1, Ubicación 2, Altura 03","deposito":"Deposito A","cap":150},{"id":"01:02:02:00","codigo":"01:02:02:00","descripcion":"Pasillo 1, Rack 2, Ubicación 2, Altura 00 (piso)","deposito":"Deposito A","cap":150},{"id":"01:02:02:01","codigo":"01:02:02:01","descripcion":"Pasillo 1, Rack 2, Ubicación 2, Altura 01","deposito":"Deposito A","cap":150},{"id":"01:02:02:02","codigo":"01:02:02:02","descripcion":"Pasillo 1, Rack 2, Ubicación 2, Altura 02","deposito":"Deposito A","cap":150},{"id":"01:02:02:03","codigo":"01:02:02:03","descripcion":"Pasillo 1, Rack 2, Ubicación 2, Altura 03","deposito":"Deposito A","cap":150},{"id":"01:03:02:00","codigo":"01:03:02:00","descripcion":"Pasillo 1, Rack 3, Ubicación 2, Altura 00 (piso)","deposito":"Deposito A","cap":150},{"id":"01:03:02:01","codigo":"01:03:02:01","descripcion":"Pasillo 1, Rack 3, Ubicación 2, Altura 01","deposito":"Deposito A","cap":150},{"id":"01:03:02:02","codigo":"01:03:02:02","descripcion":"Pasillo 1, Rack 3, Ubicación 2, Altura 02","deposito":"Deposito A","cap":150},{"id":"01:03:02:03","codigo":"01:03:02:03","descripcion":"Pasillo 1, Rack 3, Ubicación 2, Altura 03","deposito":"Deposito A","cap":150},{"id":"02:01:02:00","codigo":"02:01:02:00","descripcion":"Pasillo 2, Rack 1, Ubicación 2, Altura 00 (piso)","deposito":"Deposito B","cap":150},{"id":"02:01:02:01","codigo":"02:01:02:01","descripcion":"Pasillo 2, Rack 1, Ubicación 2, Altura 01","deposito":"Deposito B","cap":150},{"id":"02:01:02:02","codigo":"02:01:02:02","descripcion":"Pasillo 2, Rack 1, Ubicación 2, Altura 02","deposito":"Deposito B","cap":150},{"id":"02:01:02:03","codigo":"02:01:02:03","descripcion":"Pasillo 2, Rack 1, Ubicación 2, Altura 03","deposito":"Deposito B","cap":150},{"id":"02:02:02:00","codigo":"02:02:02:00","descripcion":"Pasillo 2, Rack 2, Ubicación 2, Altura 00 (piso)","deposito":"Deposito B","cap":150},{"id":"02:02:02:01","codigo":"02:02:02:01","descripcion":"Pasillo 2, Rack 2, Ubicación 2, Altura 01","deposito":"Deposito B","cap":150},{"id":"02:02:02:02","codigo":"02:02:02:02","descripcion":"Pasillo 2, Rack 2, Ubicación 2, Altura 02","deposito":"Deposito B","cap":150},{"id":"02:02:02:03","codigo":"02:02:02:03","descripcion":"Pasillo 2, Rack 2, Ubicación 2, Altura 03","deposito":"Deposito B","cap":150},{"id":"02:03:02:00","codigo":"02:03:02:00","descripcion":"Pasillo 2, Rack 3, Ubicación 2, Altura 00 (piso)","deposito":"Deposito B","cap":150},{"id":"02:03:02:01","codigo":"02:03:02:01","descripcion":"Pasillo 2, Rack 3, Ubicación 2, Altura 01","deposito":"Deposito B","cap":150},{"id":"02:03:02:02","codigo":"02:03:02:02","descripcion":"Pasillo 2, Rack 3, Ubicación 2, Altura 02","deposito":"Deposito B","cap":150},{"id":"02:03:02:03","codigo":"02:03:02:03","descripcion":"Pasillo 2, Rack 3, Ubicación 2, Altura 03","deposito":"Deposito B","cap":150},{"id":"03:01:02:00","codigo":"03:01:02:00","descripcion":"Pasillo 3, Rack 1, Ubicación 2, Altura 00 (piso)","deposito":"Deposito C","cap":150},{"id":"03:01:02:01","codigo":"03:01:02:01","descripcion":"Pasillo 3, Rack 1, Ubicación 2, Altura 01","deposito":"Deposito C","cap":150},{"id":"03:01:02:02","codigo":"03:01:02:02","descripcion":"Pasillo 3, Rack 1, Ubicación 2, Altura 02","deposito":"Deposito C","cap":150},{"id":"03:01:02:03","codigo":"03:01:02:03","descripcion":"Pasillo 3, Rack 1, Ubicación 2, Altura 03","deposito":"Deposito C","cap":150},{"id":"03:02:02:00","codigo":"03:02:02:00","descripcion":"Pasillo 3, Rack 2, Ubicación 2, Altura 00 (piso)","deposito":"Deposito C","cap":150},{"id":"03:02:02:01","codigo":"03:02:02:01","descripcion":"Pasillo 3, Rack 2, Ubicación 2, Altura 01","deposito":"Deposito C","cap":150},{"id":"03:02:02:02","codigo":"03:02:02:02","descripcion":"Pasillo 3, Rack 2, Ubicación 2, Altura 02","deposito":"Deposito C","cap":150},{"id":"03:02:02:03","codigo":"03:02:02:03","descripcion":"Pasillo 3, Rack 2, Ubicación 2, Altura 03","deposito":"Deposito C","cap":150},{"id":"03:03:02:00","codigo":"03:03:02:00","descripcion":"Pasillo 3, Rack 3, Ubicación 2, Altura 00 (piso)","deposito":"Deposito C","cap":150},{"id":"03:03:02:01","codigo":"03:03:02:01","descripcion":"Pasillo 3, Rack 3, Ubicación 2, Altura 01","deposito":"Deposito C","cap":150},{"id":"03:03:02:02","codigo":"03:03:02:02","descripcion":"Pasillo 3, Rack 3, Ubicación 2, Altura 02","deposito":"Deposito C","cap":150},{"id":"03:03:02:03","codigo":"03:03:02:03","descripcion":"Pasillo 3, Rack 3, Ubicación 2, Altura 03","deposito":"Deposito C","cap":150}],"kardex":[{"id":"K000005","fecha":"2026-06-01","tipo":"IN","sku":"P001","ubicacion":"01:01:01:00","in":71,"out":0,"operador":"Sistema (ajuste inicial)"},{"id":"K000006","fecha":"2026-06-01","tipo":"IN","sku":"P002","ubicacion":"02:01:01:00","in":75,"out":0,"operador":"Sistema (ajuste inicial)"},{"id":"K000007","fecha":"2026-06-01","tipo":"IN","sku":"P003","ubicacion":"01:01:01:01","in":171,"out":0,"operador":"Sistema (ajuste inicial)"},{"id":"K000008","fecha":"2026-06-01","tipo":"IN","sku":"P004","ubicacion":"03:01:01:00","in":79,"out":0,"operador":"Sistema (ajuste inicial)"},{"id":"K000009","fecha":"2026-06-01","tipo":"IN","sku":"P005","ubicacion":"02:01:01:01","in":116,"out":0,"operador":"Sistema (ajuste inicial)"},{"id":"K000010","fecha":"2026-06-01","tipo":"IN","sku":"P006","ubicacion":"01:01:01:02","in":100,"out":0,"operador":"Sistema (ajuste inicial)"},{"id":"K000011","fecha":"2026-06-01","tipo":"IN","sku":"P007","ubicacion":"03:01:01:01","in":100,"out":0,"operador":"Sistema (ajuste inicial)"},{"id":"K000012","fecha":"2026-06-01","tipo":"IN","sku":"P008","ubicacion":"02:01:01:02","in":167,"out":0,"operador":"Sistema (ajuste inicial)"},{"id":"K000013","fecha":"2026-06-01","tipo":"IN","sku":"P009","ubicacion":"01:01:01:03","in":85,"out":0,"operador":"Sistema (ajuste inicial)"},{"id":"K000014","fecha":"2026-06-01","tipo":"IN","sku":"P010","ubicacion":"03:01:01:02","in":115,"out":0,"operador":"Sistema (ajuste inicial)"},{"id":"K000015","fecha":"2026-06-01","tipo":"IN","sku":"P011","ubicacion":"02:01:01:03","in":116,"out":0,"operador":"Sistema (ajuste inicial)"},{"id":"K000016","fecha":"2026-06-01","tipo":"IN","sku":"CH01","ubicacion":"02:02:01:00","in":20,"out":0,"operador":"Sistema (ajuste inicial)"},{"id":"K000017","fecha":"2026-07-30","tipo":"OUT","sku":"P001","ubicacion":"01:01:01:00","in":0,"out":1,"operador":"Juan"},{"id":"K000018","fecha":"2026-07-31","tipo":"OUT","sku":"P002","ubicacion":"02:01:01:00","in":0,"out":3,"operador":"Pedro"},{"id":"K000019","fecha":"2026-08-01","tipo":"OUT","sku":"P003","ubicacion":"01:01:01:01","in":0,"out":1,"operador":"Ana"},{"id":"K000020","fecha":"2026-08-02","tipo":"IN","sku":"P004","ubicacion":"03:01:01:00","in":4,"out":0,"operador":"Luis"},{"id":"K000021","fecha":"2026-08-03","tipo":"OUT","sku":"P005","ubicacion":"02:01:01:01","in":0,"out":2,"operador":"Juan"},{"id":"K000022","fecha":"2026-08-04","tipo":"OUT","sku":"P001","ubicacion":"01:01:01:00","in":0,"out":1,"operador":"Pedro"},{"id":"K000023","fecha":"2026-08-05","tipo":"OUT","sku":"P002","ubicacion":"02:01:01:00","in":0,"out":3,"operador":"Ana"},{"id":"K000024","fecha":"2026-08-06","tipo":"OUT","sku":"P003","ubicacion":"01:01:01:01","in":0,"out":1,"operador":"Luis"},{"id":"K000025","fecha":"2026-08-07","tipo":"IN","sku":"P004","ubicacion":"03:01:01:00","in":4,"out":0,"operador":"Juan"},{"id":"K000026","fecha":"2026-08-08","tipo":"OUT","sku":"P005","ubicacion":"02:01:01:01","in":0,"out":2,"operador":"Pedro"},{"id":"K000027","fecha":"2026-08-09","tipo":"OUT","sku":"P005","ubicacion":"02:01:01:01","in":0,"out":1,"operador":"Ana"},{"id":"K000028","fecha":"2026-08-10","tipo":"OUT","sku":"P006","ubicacion":"01:01:01:02","in":0,"out":3,"operador":"Luis"},{"id":"K000029","fecha":"2026-08-11","tipo":"OUT","sku":"P007","ubicacion":"03:01:01:01","in":0,"out":1,"operador":"Juan"},{"id":"K000030","fecha":"2026-08-12","tipo":"IN","sku":"P008","ubicacion":"02:01:01:02","in":4,"out":0,"operador":"Pedro"},{"id":"K000031","fecha":"2026-08-13","tipo":"OUT","sku":"P009","ubicacion":"01:01:01:03","in":0,"out":2,"operador":"Ana"},{"id":"K000032","fecha":"2026-07-30","tipo":"OUT","sku":"P010","ubicacion":"03:01:01:02","in":0,"out":3,"operador":"Luis"},{"id":"K000033","fecha":"2026-07-31","tipo":"OUT","sku":"P010","ubicacion":"03:01:01:02","in":0,"out":1,"operador":"Juan"},{"id":"K000034","fecha":"2026-08-01","tipo":"IN","sku":"CH01","ubicacion":"02:02:01:00","in":25,"out":0,"operador":"Pedro"},{"id":"K000035","fecha":"2026-08-02","tipo":"IN","sku":"P001","ubicacion":"01:01:01:00","in":10,"out":0,"operador":"Ana"},{"id":"K000036","fecha":"2026-08-03","tipo":"IN","sku":"P002","ubicacion":"02:01:01:00","in":60,"out":0,"operador":"Luis"},{"id":"K000037","fecha":"2026-08-04","tipo":"IN","sku":"CH01","ubicacion":"02:02:01:00","in":25,"out":0,"operador":"Juan"},{"id":"K000038","fecha":"2026-08-05","tipo":"IN","sku":"P001","ubicacion":"01:01:01:00","in":10,"out":0,"operador":"Pedro"},{"id":"K000039","fecha":"2026-08-06","tipo":"IN","sku":"P001","ubicacion":"01:01:01:00","in":10,"out":0,"operador":"Ana"},{"id":"K000040","fecha":"2026-08-07","tipo":"OUT","sku":"P005","ubicacion":"02:01:01:01","in":0,"out":2,"operador":"Luis"},{"id":"K000041","fecha":"2026-08-08","tipo":"OUT","sku":"P005","ubicacion":"02:01:01:01","in":0,"out":1,"operador":"Juan"},{"id":"K000042","fecha":"2026-08-09","tipo":"OUT","sku":"P006","ubicacion":"01:01:01:02","in":0,"out":3,"operador":"Pedro"},{"id":"K000043","fecha":"2026-08-10","tipo":"OUT","sku":"P001","ubicacion":"01:01:01:00","in":0,"out":1,"operador":"Ana"},{"id":"K000044","fecha":"2026-08-11","tipo":"OUT","sku":"P002","ubicacion":"02:01:01:00","in":0,"out":3,"operador":"Luis"},{"id":"K000045","fecha":"2026-08-12","tipo":"OUT","sku":"P003","ubicacion":"01:01:01:01","in":0,"out":1,"operador":"Juan"},{"id":"K000046","fecha":"2026-08-13","tipo":"IN","sku":"P004","ubicacion":"03:01:01:00","in":4,"out":0,"operador":"Pedro"},{"id":"K000047","fecha":"2026-07-30","tipo":"OUT","sku":"P005","ubicacion":"02:01:01:01","in":0,"out":2,"operador":"Ana"},{"id":"K000048","fecha":"2026-07-31","tipo":"OUT","sku":"P001","ubicacion":"01:01:01:00","in":0,"out":1,"operador":"Luis"},{"id":"K000049","fecha":"2026-08-01","tipo":"OUT","sku":"P002","ubicacion":"02:01:01:00","in":0,"out":3,"operador":"Juan"},{"id":"K000050","fecha":"2026-08-02","tipo":"OUT","sku":"P003","ubicacion":"01:01:01:01","in":0,"out":1,"operador":"Pedro"},{"id":"K000051","fecha":"2026-08-03","tipo":"IN","sku":"P004","ubicacion":"03:01:01:00","in":4,"out":0,"operador":"Ana"},{"id":"K000052","fecha":"2026-08-04","tipo":"OUT","sku":"P005","ubicacion":"02:01:01:01","in":0,"out":2,"operador":"Luis"},{"id":"K000053","fecha":"2026-08-05","tipo":"OUT","sku":"P005","ubicacion":"02:01:01:01","in":0,"out":1,"operador":"Juan"},{"id":"K000054","fecha":"2026-08-06","tipo":"OUT","sku":"P006","ubicacion":"01:01:01:02","in":0,"out":3,"operador":"Pedro"},{"id":"K000055","fecha":"2026-08-07","tipo":"OUT","sku":"P007","ubicacion":"03:01:01:01","in":0,"out":1,"operador":"Ana"},{"id":"K000056","fecha":"2026-08-08","tipo":"IN","sku":"P008","ubicacion":"02:01:01:02","in":4,"out":0,"operador":"Luis"},{"id":"K000057","fecha":"2026-08-09","tipo":"OUT","sku":"P009","ubicacion":"01:01:01:03","in":0,"out":2,"operador":"Juan"},{"id":"K000058","fecha":"2026-08-10","tipo":"OUT","sku":"P010","ubicacion":"03:01:01:02","in":0,"out":3,"operador":"Pedro"},{"id":"K000059","fecha":"2026-08-11","tipo":"OUT","sku":"P010","ubicacion":"03:01:01:02","in":0,"out":1,"operador":"Ana"},{"id":"K000060","fecha":"2026-08-12","tipo":"IN","sku":"CH01","ubicacion":"02:02:01:00","in":25,"out":0,"operador":"Luis"},{"id":"K000061","fecha":"2026-08-13","tipo":"IN","sku":"P001","ubicacion":"01:01:01:00","in":10,"out":0,"operador":"Juan"},{"id":"K000062","fecha":"2026-08-13","tipo":"TRANSFERENCIA","sku":"P003","ubicacion":"01:01:01:01","in":0,"out":40,"operador":"Ana"},{"id":"K000063","fecha":"2026-08-13","tipo":"TRANSFERENCIA","sku":"P003","ubicacion":"01:01:01:00","in":40,"out":0,"operador":"Ana"}]};
var DEPOT_DEMO={nombre:'Depósito central, Avellaneda',lat:-34.6627,lng:-58.3650};
function historyDemo(){
  var seed=7,rnd=function(){seed=(seed*16807)%2147483647;return seed/2147483647;};
  var cl=[['c1','Ferretería Del Plata','Av. Mitre 1890, Wilde',-34.6989,-58.3156],['c2','Pinturería Los Aromos','Hipólito Yrigoyen 4120, Lanús',-34.7064,-58.3922],['c3','Corralón Santa Lucía','Av. Espora 2250, Burzaco',-34.8317,-58.3896],['c4','Obras y Revestimientos','Cerrito 640, Quilmes',-34.7206,-58.2526],['c5','Casa Hogar Adrogué','Esteban Adrogué 1130, Adrogué',-34.8,-58.39]];
  var drv=[['d1','Marcos Peralta'],['d2','Diego Ruiz']],out=[],n=4000;
  var mot=['Cliente ausente','Dirección incorrecta','Mercadería rechazada','No hay quien reciba'];
  for(var off=-7;off<=-2;off++){drv.forEach(function(d){
    var k=4+Math.floor(rnd()*3);
    for(var i=0;i<k;i++){
      var c=cl[Math.floor(rnd()*cl.length)];n++;
      var ok=rnd()<0.9,h=9+i*2,late=rnd()<0.2,tsH=late?h+3:h+1,mi=Math.floor(rnd()*60);
      var ts=at(off,tsH,mi),por=d[1];
      var e={id:'d-h'+n,guia:'G-'+n,clienteId:c[0],cliente:c[1],direccion:c[2],lat:c[3],lng:c[4],fecha:addDays(off),desde:pad(h-1)+':00',hasta:pad(h+2)+':00',choferId:d[0],chofer:d[1],orden:i+1,estado:ok?'entregada':'no_entregada',bultos:2+Math.floor(rnd()*14),
        remito:{numero:'R-0003-'+String(7000+n-4000).padStart(8,'0')},factura:null,observaciones:[],
        historial:[{estado:'programada',ts:at(off-2,15,0),por:'Administración'},{estado:'en_camino',ts:at(off,h-1,30),por:por},{estado:ok?'entregada':'no_entregada',ts:ts,por:por}]};
      if(ok&&rnd()<0.85)e.factura={numero:'A-0003-'+String(n).padStart(8,'0'),importe:Math.round((50000+rnd()*400000)/100)*100,estado:rnd()<0.6?'pagada':'emitida',vence:addDays(off+(rnd()<0.5?5:20))};
      if(!ok)e.observaciones=[{ts:ts,por:por,texto:'No entregada: '+mot[Math.floor(rnd()*mot.length)]+'.'}];
      out.push(e);
    }});}
  return out;
}
function demoEntregas(){return baseDemo().concat(historyDemo());}
function baseDemo(){
  var H=function(est,ts,por){return {estado:est,ts:ts,por:por};};
  var M='Marcos Peralta',D='Diego Ruiz';
  return [
   {id:'d-4818',guia:'G-4818',clienteId:'c1',cliente:'Ferretería Del Plata',direccion:'Av. Mitre 1890, Wilde',lat:-34.6989,lng:-58.3156,fecha:HOY,desde:'08:00',hasta:'11:00',choferId:'d1',chofer:M,orden:1,estado:'entregada',bultos:6,
    remito:{numero:'R-0003-00007712'},factura:{numero:'A-0003-00001204',importe:184500,estado:'emitida',vence:addDays(14)},
    observaciones:[{ts:at(0,9,41),por:M,texto:'Recibió el encargado. Sin novedades.'}],
    historial:[H('programada',at(-1,16,0),'Administración'),H('en_camino',at(0,8,20),M),H('entregada',at(0,9,41),M)]},
   {id:'d-4821',guia:'G-4821',clienteId:'c2',cliente:'Pinturería Los Aromos',direccion:'Hipólito Yrigoyen 4120, Lanús',lat:-34.7064,lng:-58.3922,fecha:HOY,desde:'10:00',hasta:'13:00',choferId:'d1',chofer:M,orden:2,estado:'en_camino',bultos:12,
    remito:{numero:'R-0003-00007719'},factura:{numero:'A-0003-00001206',importe:236800,estado:'emitida',vence:addDays(20)},
    observaciones:[{ts:at(0,10,12),por:M,texto:'Salí del depósito. Llego en unos 25 minutos.'}],
    historial:[H('programada',at(-2,15,30),'Administración'),H('en_camino',at(0,10,12),M)]},
   {id:'d-4822',guia:'G-4822',clienteId:'c3',cliente:'Corralón Santa Lucía',direccion:'Av. Espora 2250, Burzaco',lat:-34.8317,lng:-58.3896,fecha:HOY,desde:'11:00',hasta:'14:00',choferId:'d1',chofer:M,orden:3,estado:'programada',bultos:20,
    remito:{numero:'R-0003-00007721'},factura:null,
    observaciones:[{ts:at(-1,17,5),por:'Administración',texto:'El cliente pide descargar por el portón lateral.'}],
    historial:[H('programada',at(-1,17,0),'Administración')]},
   {id:'d-4823',guia:'G-4823',clienteId:'c4',cliente:'Obras y Revestimientos',direccion:'Cerrito 640, Quilmes',lat:-34.7206,lng:-58.2526,fecha:HOY,desde:'12:00',hasta:'15:00',choferId:'d1',chofer:M,orden:4,estado:'programada',bultos:9,
    remito:{numero:'R-0003-00007722'},factura:{numero:'A-0003-00001208',importe:412300,estado:'emitida',vence:addDays(30)},observaciones:[],
    historial:[H('programada',at(-1,17,10),'Administración')]},
   {id:'d-4824',guia:'G-4824',clienteId:'c5',cliente:'Casa Hogar Adrogué',direccion:'Esteban Adrogué 1130, Adrogué',lat:-34.8,lng:-58.39,fecha:HOY,desde:'14:00',hasta:'17:00',choferId:'d1',chofer:M,orden:5,estado:'programada',bultos:4,
    remito:{numero:'R-0003-00007723'},factura:null,observaciones:[],historial:[H('programada',at(-1,17,12),'Administración')]},
   {id:'d-4836',guia:'G-4836',clienteId:'c2',cliente:'Pinturería Los Aromos',direccion:'Hipólito Yrigoyen 4120, Lanús',lat:-34.7064,lng:-58.3922,fecha:addDays(1),desde:'09:00',hasta:'12:00',choferId:'d2',chofer:D,orden:1,estado:'programada',bultos:8,
    remito:{numero:'R-0003-00007730'},factura:{numero:'',importe:0,estado:'pendiente',vence:''},observaciones:[],historial:[H('programada',at(0,8,0),'Administración')]},
   {id:'d-4790',guia:'G-4790',clienteId:'c2',cliente:'Pinturería Los Aromos',direccion:'Hipólito Yrigoyen 4120, Lanús',lat:-34.7064,lng:-58.3922,fecha:addDays(-1),desde:'09:00',hasta:'12:00',choferId:'d2',chofer:D,orden:1,estado:'entregada',bultos:10,
    remito:{numero:'R-0003-00007690'},factura:{numero:'A-0003-00001190',importe:98300,estado:'pagada',vence:addDays(-1)},
    observaciones:[{ts:at(-1,10,48),por:D,texto:'Recibió Marcela. Se dejó el remito firmado.'}],
    historial:[H('programada',at(-4,12,0),'Administración'),H('en_camino',at(-1,9,50),D),H('entregada',at(-1,10,48),D)]},
   {id:'d-4801',guia:'G-4801',clienteId:'c2',cliente:'Pinturería Los Aromos',direccion:'Hipólito Yrigoyen 4120, Lanús',lat:-34.7064,lng:-58.3922,fecha:addDays(-6),desde:'14:00',hasta:'17:00',choferId:'d2',chofer:D,orden:1,estado:'entregada',bultos:15,
    remito:{numero:'R-0003-00007655'},factura:{numero:'A-0003-00001171',importe:151200,estado:'emitida',vence:addDays(-1)},observaciones:[],
    historial:[H('programada',at(-9,12,0),'Administración'),H('entregada',at(-6,15,22),D)]}
  ];
}
/* ---------- equipos, check lists y fichas: plantillas y datos de ejemplo ---------- */
var TIPOS={autoelevador:['Autoelevador','autoelevador'],apilador:['Apilador / zorra eléctrica','autoelevador'],camion:['Camión','camion'],utilitario:['Utilitario / camioneta','camion']};
/* Plantillas genéricas de uso habitual. Cada empresa debe ajustarlas al manual del fabricante y a su normativa de higiene y seguridad. [id, grupo, texto, crítico] */
var CHK={
 autoelevador:{lect:'Horas de uso',items:[
  ['hor','Horquillas y mástil','Horquillas sin fisuras ni deformaciones, y trabadas',1],
  ['mas','Horquillas y mástil','Mástil y cadenas sin juego, lubricadas',1],
  ['cil','Horquillas y mástil','Cilindros hidráulicos sin pérdidas',0],
  ['fre','Conducción','Freno de servicio y de estacionamiento',1],
  ['dir','Conducción','Dirección sin juego excesivo',1],
  ['neu','Conducción','Ruedas y neumáticos en buen estado',0],
  ['boc','Seguridad','Bocina y alarma de retroceso',1],
  ['luz','Seguridad','Luces y baliza',0],
  ['cin','Seguridad','Cinturón de seguridad',1],
  ['tec','Seguridad','Techo protector del operador en buen estado',1],
  ['pla','Seguridad','Placa de capacidad legible',1],
  ['ext','Seguridad','Extintor cargado y vigente',0],
  ['ene','Energía y fluidos','Batería y cables / GLP sin pérdidas / combustible',1],
  ['flu','Energía y fluidos','Niveles de aceite y refrigerante, sin pérdidas',0],
  ['lim','Estado general','Cabina y piso limpios, sin golpes nuevos',0]]},
 camion:{lect:'Kilometraje',items:[
  ['neu','Neumáticos y frenos','Neumáticos: presión, desgaste y rueda de auxilio',1],
  ['fre','Neumáticos y frenos','Frenos y freno de mano',1],
  ['dir','Neumáticos y frenos','Dirección y suspensión sin ruidos ni juego',1],
  ['luz','Luces y visibilidad','Luces altas, bajas, giro, freno y retroceso',1],
  ['esp','Luces y visibilidad','Espejos, parabrisas y limpiaparabrisas',0],
  ['boc','Luces y visibilidad','Bocina',0],
  ['ace','Motor y fluidos','Nivel de aceite, refrigerante y líquido de frenos',0],
  ['fug','Motor y fluidos','Sin pérdidas de combustible ni aceite',1],
  ['com','Motor y fluidos','Combustible suficiente para la ruta',0],
  ['doc','Documentación y seguridad','Documentación a bordo (cédula, seguro, RTO, licencia)',1],
  ['mat','Documentación y seguridad','Matafuego vigente, balizas triangulares y botiquín',0],
  ['cin','Documentación y seguridad','Cinturón de seguridad',1],
  ['caj','Carga','Caja o furgón: puertas, trabas y piso en buen estado',0],
  ['sul','Carga','Cinchas y elementos de sujeción de carga',0],
  ['lim','Estado general','Cabina y caja limpias, sin golpes nuevos',0]]}
};
var tplDe=function(tipo){var k=(TIPOS[tipo]||TIPOS.camion)[1],pl=(typeof D==='function'&&typeof S==='object'&&S&&S.data?(D().plantillas||[]):[]).find(function(x){return x.id===k;});return pl&&pl.items&&pl.items.length?{lect:CHK[k].lect,items:pl.items,fuente:pl.fuente||''}:CHK[k];};
var dleft=function(v){if(!v)return null;return Math.round((new Date(v+'T00:00:00')-new Date(HOY+'T00:00:00'))/864e5);};
function chkResultado(tpl,items){var r='ok';tpl.items.forEach(function(it){var v=items[it[0]];if(v==='mal'){if(it[3])r='fuera';else if(r==='ok')r='obs';}else if(v==='obs'&&r==='ok')r='obs';});return r;}
function chkArma(eq,por,porId,ts,items,lect,nota){
  var fallas=[];tplDe(eq.tipo).items.forEach(function(it){var v=items[it[0]];if(v&&v!=='ok')fallas.push({id:it[0],texto:it[2],v:v,crit:!!it[3]});});
  return {equipoId:eq.id,equipoNombre:eq.nombre,tipo:eq.tipo,ts:ts,fecha:ymd(new Date(ts)),por:por||'',porId:porId||'',lect:lect,nota:nota||'',items:items,resultado:chkResultado(tplDe(eq.tipo),items),fallas:fallas};}
function EQUIPOS_DEMO(){return [
 {id:'e1',tipo:'autoelevador',nombre:'Autoelevador 1',ident:'AE-01',marca:'Toyota 8FGU25',anio:2019,cap:2500,energia:'GLP',asignado:'',docs:[{nombre:'Mantenimiento',vence:addDays(40)},{nombre:'Inspección técnica',vence:addDays(120)}]},
 {id:'e2',tipo:'autoelevador',nombre:'Autoelevador 2',ident:'AE-02',marca:'Hyster H50',anio:2016,cap:2300,energia:'Diésel',asignado:'',docs:[{nombre:'Mantenimiento',vence:addDays(-5)},{nombre:'Inspección técnica',vence:addDays(60)}]},
 {id:'e3',tipo:'apilador',nombre:'Apilador eléctrico',ident:'AP-01',marca:'Still EGV',anio:2021,cap:1200,energia:'Eléctrico',asignado:'',docs:[{nombre:'Mantenimiento',vence:addDays(90)}]},
 {id:'e4',tipo:'camion',nombre:'Camión 1',ident:'AB 123 CD',marca:'Mercedes-Benz Atego',anio:2020,cap:8000,energia:'Diésel',asignado:'d1',docs:[{nombre:'RTO',vence:addDays(25)},{nombre:'Seguro',vence:addDays(200)}]},
 {id:'e5',tipo:'camion',nombre:'Camión 2',ident:'AC 456 EF',marca:'Iveco Tector',anio:2018,cap:9000,energia:'Diésel',asignado:'d2',docs:[{nombre:'RTO',vence:addDays(150)},{nombre:'Seguro',vence:addDays(15)}]},
 {id:'e6',tipo:'utilitario',nombre:'Utilitario 1',ident:'AA 789 GH',marca:'Renault Kangoo',anio:2022,cap:650,energia:'Nafta',asignado:'',docs:[{nombre:'RTO',vence:addDays(300)},{nombre:'Seguro',vence:addDays(90)}]}];}
function CHECKS_DEMO(){
  var eqs=EQUIPOS_DEMO(),out=[],n=0;
  var mk=function(id,off,h,m,por,porId,over,lect,nota){
    var eq=eqs.find(function(e){return e.id===id;}),items={};tplDe(eq.tipo).items.forEach(function(it){items[it[0]]='ok';});
    Object.keys(over||{}).forEach(function(k){items[k]=over[k];});
    var c=chkArma(eq,por,porId,at(off,h,m),items,lect,nota);c.id='c-demo'+(++n);out.push(c);};
  mk('e1',-3,7,5,'Julián Sosa','o1',{},4150,'');mk('e1',-2,7,8,'Carla Medina','o2',{},4165,'');mk('e1',-1,7,2,'Julián Sosa','o1',{},4188,'');mk('e1',0,7,10,'Julián Sosa','o1',{},4210,'');
  mk('e2',-2,7,15,'Carla Medina','o2',{},6850,'');mk('e2',-1,7,20,'Carla Medina','o2',{mas:'mal',luz:'obs'},6890,'Cadena del mástil con juego. Se avisó a mantenimiento. La baliza parpadea.');
  mk('e3',-2,7,30,'Julián Sosa','o1',{},932,'');mk('e3',-1,7,31,'Julián Sosa','o1',{},940,'');
  mk('e4',-2,6,50,'Marcos Peralta','d1',{},118210,'');mk('e4',-1,6,45,'Marcos Peralta','d1',{},118330,'');mk('e4',0,7,30,'Marcos Peralta','d1',{luz:'obs'},118420,'Luz de giro trasera derecha intermitente.');
  mk('e5',-2,7,0,'Diego Ruiz','d2',{},84010,'');mk('e5',-1,6,58,'Diego Ruiz','d2',{},84155,'');
  return out;}
var PERFILES_DEMO=[
  {id:'c1',rol:'cliente',nombre:'Ferretería Del Plata',telefono:'11 5555-0301',contacto:'Sergio',notas:'Recibe el encargado de 8 a 12 h.'},{id:'c2',rol:'cliente',nombre:'Pinturería Los Aromos',telefono:'011 5555-0302',contacto:'Marcela'},
  {id:'c3',rol:'cliente',nombre:'Corralón Santa Lucía'},{id:'c4',rol:'cliente',nombre:'Obras y Revestimientos'},
  {id:'c5',rol:'cliente',nombre:'Casa Hogar Adrogué'},
  {id:'d1',rol:'chofer',nombre:'Marcos Peralta',telefono:'11 5555-0101',contacto:'Laura (pareja) 11 5555-0199',turno:'Mañana',licCat:'D2',licVence:addDays(210),hab:[{nombre:'Psicofísico',vence:addDays(20)},{nombre:'Manejo defensivo',vence:addDays(300)}],notas:'Conoce bien la zona sur.'},
  {id:'d2',rol:'chofer',nombre:'Diego Ruiz',telefono:'11 5555-0102',contacto:'',turno:'Mañana',licCat:'D1',licVence:addDays(-12),hab:[{nombre:'Psicofísico',vence:addDays(90)}],notas:''},
  {id:'o1',rol:'deposito',nombre:'Julián Sosa',telefono:'11 5555-0201',contacto:'',turno:'Mañana',licCat:'',licVence:'',hab:[{nombre:'Curso de autoelevadorista',vence:addDays(150)}],notas:''},
  {id:'o2',rol:'deposito',nombre:'Carla Medina',telefono:'11 5555-0202',contacto:'',turno:'Tarde',licCat:'',licVence:'',hab:[{nombre:'Curso de autoelevadorista',vence:addDays(10)}],notas:''}];

/* ---------- estado ---------- */
var S={
  mode:'demo',            // demo | live
  hasDb:false, isAdmin:false, me:{id:null,name:''}, perfil:null, perfilListo:false,
  demoRol:'cliente', demoDia:'hoy', fuel:{consumo:14,precio:1300}, cfg:{kgPos:1000,d1:30,d2:60,corte:''},
  data:{demo:{entregas:demoEntregas(),perfiles:PERFILES_DEMO,depot:DEPOT_DEMO,viajes:JSON.parse(JSON.stringify(VIAJES_DEMO)),wms:JSON.parse(JSON.stringify(WMS_DEMO)),equipos:EQUIPOS_DEMO(),checks:CHECKS_DEMO()},
        live:{entregas:[],equipos:[],checks:[],viajes:[],wms:{skus:[],ubic:[],kardex:[]},perfiles:[],depot:{nombre:'Depósito',lat:-34.6627,lng:-58.3650}}},
  names:{}, ui:{formOpen:false,edit:null,dia:'hoy',chofer:'',motivo:null,delConfirm:null,hits:[],pick:null,optChofer:'',optDia:'hoy',confirmDel:null,tab:'op',sim:null,wloc:'',wfind:'',wver:'',wsub:'stock',wvista:'stock',wfil:'',m:{tipo:'IN',sku:'',ubi:''},abcDias:'5',abcStart:'',periodo:'7',mapChofer:'',mapDia:'hoy',eqsub:'equipos',eqFil:'',eqf:null,fic:null,chk:null,miEq:'',chkOpen:null},
  note:'',trafico:{nombre:'Tráfico',telefono:''}
};
var user=null,db=null,assets=null,unsubs=[];
var D=function(){return S.data[S.mode];};
var rolActual=function(){return S.mode==='demo'?S.demoRol:(S.isAdmin?'admin':(S.perfil?S.perfil.rol:null));};
var miId=function(){return S.mode==='demo'?(S.demoRol==='cliente'?'c2':S.demoRol==='chofer'?'d1':S.demoRol==='deposito'?'o1':null):S.me.id;};
var miPerfil=function(){return S.mode==='demo'?(D().perfiles.find(function(p){return p.id===miId();})||null):S.perfil;};
var diaStr=function(k){return k==='hoy'?HOY:k==='manana'?addDays(1):k==='ayer'?addDays(-1):'';};

/* ---------- toasts ---------- */
function toast(t){var host=document.getElementById('toasts');var el=document.createElement('div');el.className='toast';el.textContent=t;host.appendChild(el);setTimeout(function(){el.remove();},5200);}

/* ---------- persistencia (demo en memoria / vivo en db) ---------- */
function clean(o){return JSON.parse(JSON.stringify(o));}
function upsertLocal(list,e){var i=list.findIndex(function(x){return x.id===e.id;});if(i>=0)list[i]=e;else list.push(e);}
async function persist(e){
  e=clean(e);
  if(S.mode==='demo'){upsertLocal(S.data.demo.entregas,e);render();return;}
  await db.doc('entregas/'+e.id).set(e);
  if(e.clienteId)await db.doc('portal/'+e.clienteId+'/entregas/'+e.id).set(e);
}
async function removeEntrega(e){
  if(S.mode==='demo'){S.data.demo.entregas=S.data.demo.entregas.filter(function(x){return x.id!==e.id;});render();return;}
  await db.doc('entregas/'+e.id).delete();
  if(e.clienteId)await db.doc('portal/'+e.clienteId+'/entregas/'+e.id).delete();
}
function actor(){return S.mode==='demo'?(S.demoRol==='chofer'?'Marcos Peralta':S.demoRol==='deposito'?'Julián Sosa':'Administración'):(S.perfil&&S.perfil.nombre)||(S.isAdmin?'Administración':'Usuario');}
async function setEstado(id,estado,motivo,pod,extra){
  var e=clean(D().entregas.find(function(x){return x.id===id;}));if(!e)return;
  if(pod){e.pod=pod;if(pod.devuelve&&pod.devuelve.length)e.devuelve=pod.devuelve;}
  if(extra&&extra.devuelve&&extra.devuelve.length)e.devuelve=extra.devuelve;
  e.estado=estado;e.historial=(e.historial||[]).concat([{estado:estado,ts:new Date().toISOString(),por:actor()}]);
  if(motivo)e.observaciones=(e.observaciones||[]).concat([{ts:new Date().toISOString(),por:actor(),texto:'No entregada: '+motivo+'.'}]);
  if(motivo&&extra&&(extra.nota||(extra.fotos&&extra.fotos.length)||extra.pend)){var ob={ts:new Date().toISOString(),por:actor(),texto:extra.nota||'Foto adjunta'};if(extra.fotos&&extra.fotos.length)ob.fotos=extra.fotos;if(extra.pend)ob.fotoPendiente=true;e.observaciones=e.observaciones.concat([ob]);}
  try{await persist(e);toast(estado==='en_camino'?'Marcada en camino':estado==='entregada'?'Entrega confirmada':'Entrega registrada como no realizada');}
  catch(err){toast('No se pudo guardar. Probá de nuevo.');}
}
async function addObs(id,texto,fotos,pend){
  texto=(texto||'').trim();fotos=fotos||[];if(!texto&&!fotos.length&&!pend)return;
  var e=clean(D().entregas.find(function(x){return x.id===id;}));if(!e)return;
  var ob={ts:new Date().toISOString(),por:actor(),texto:texto||'Foto adjunta'};if(fotos.length)ob.fotos=fotos;if(pend)ob.fotoPendiente=true;
  e.observaciones=(e.observaciones||[]).concat([ob]);
  try{await persist(e);toast('Observación guardada');}catch(err){toast('No se pudo guardar la observación.');}
}

/* ---------- suscripciones en vivo ---------- */
function resetSubs(){unsubs.forEach(function(u){try{u();}catch(_){}});unsubs=[];}
async function resolveNames(ids){
  if(!user||!ids.length)return;
  try{var ps=await user.profiles(ids);ids.forEach(function(i){if(ps[i]&&ps[i].name)S.names[i]=ps[i].name;});render();}catch(_){}
}
function startLive(){
  resetSubs();var rol=S.isAdmin?'admin':(S.perfil&&S.perfil.rol);var live=S.data.live,prev={};
  var onErr=function(e){toast('No se pudieron leer los datos ('+(e&&e.code||'error')+').');};
  var onEnt=function(snap){
    var list=snap.docs.map(function(d){return Object.assign({id:d.id},d.data());});
    if(rol==='cliente'){list.forEach(function(e){var p=prev[e.id];if(p&&p!==e.estado)toast('Tu entrega '+e.guia+' ahora está: '+EST[e.estado][0]+'.');prev[e.id]=e.estado;});}
    live.entregas=list;render();};
  if(rol==='admin'){
    unsubs.push(db.collection('entregas').onSnapshot(onEnt,onErr));
    ['skus','ubic','kardex','conteos','picks','devoluciones'].forEach(function(k){unsubs.push(db.collection('wms/'+k+'/items').onSnapshot(function(s){live.wms[k]=s.docs.map(function(d){return Object.assign({id:d.id},d.data());});render();},onErr));});
    unsubs.push(db.collection('viajes').onSnapshot(function(s){live.viajes=s.docs.map(function(d){return Object.assign({id:d.id},d.data());});render();},onErr));
    unsubs.push(db.doc('config/almacen').onSnapshot(function(s){if(s.exists)S.cfg=Object.assign({},S.cfg,s.data());render();},onErr));
    unsubs.push(db.doc('config/combustible').onSnapshot(function(s){if(s.exists)S.fuel=s.data();render();},onErr));
    unsubs.push(db.collection('perfiles').onSnapshot(function(s){live.perfiles=s.docs.map(function(d){return Object.assign({id:d.id},d.data());});resolveNames(live.perfiles.map(function(p){return p.id;}));render();},onErr));
    unsubs.push(db.doc('config/deposito').onSnapshot(function(s){if(s.exists)live.depot=s.data();render();},onErr));
  }else if(rol==='chofer'){
    unsubs.push(db.collection('entregas').where('choferId','==',S.me.id).onSnapshot(onEnt,onErr));
    unsubs.push(db.doc('config/deposito').onSnapshot(function(s){if(s.exists)live.depot=s.data();render();},onErr));
  }else if(rol==='cliente'){
    unsubs.push(db.collection('portal/'+S.me.id+'/entregas').onSnapshot(onEnt,onErr));
  }
  if(rol==='admin'||rol==='chofer'||rol==='cliente')unsubs.push(db.doc('config/trafico').onSnapshot(function(s){if(s.exists)S.trafico=s.data();render();},onErr));
  if(rol==='admin'||rol==='chofer'||rol==='deposito'){
    unsubs.push(db.collection('equipos').onSnapshot(function(s){live.equipos=s.docs.map(function(d){return Object.assign({id:d.id},d.data());});render();},onErr));
    unsubs.push(db.collection('checks').orderBy('ts','desc').limit(400).onSnapshot(function(s){live.checks=s.docs.map(function(d){return Object.assign({id:d.id},d.data());});render();},onErr));
  }
  extLive(rol,onErr);
}

/* ---------- vistas ---------- */
function chipEstado(e){var m=EST[e.estado]||['—',''];return '<span class="chip '+m[1]+'">'+m[0]+'</span>';}
function facturaVencida(e){return e.factura&&e.factura.estado==='emitida'&&e.factura.vence&&e.factura.vence<=HOY&&e.factura.vence!=='';}
function pasos(e){
  var order=['programada','en_camino','entregada'],idx=e.estado==='no_entregada'?1:order.indexOf(e.estado),lab=['Programada','En camino',e.estado==='no_entregada'?'No entregada':'Entregada'];
  return '<div class="steps" aria-label="Estado de la entrega">'+lab.map(function(l,i){
    var cls=i<idx||(i===2&&e.estado==='entregada')?'on':(i===idx?'cur':'');
    if(e.estado==='entregada'&&i<=2)cls='on';
    return '<span class="step '+cls+'"><i></i>'+esc(l)+'</span>';}).join('')+'</div>';}
function docs(e){
  var r=e.remito&&e.remito.numero?'<div class="doc"><span class="k">Remito</span><span class="v">'+esc(e.remito.numero)+'</span>'+(e.remito.url?'<a class="small" href="'+esc(e.remito.url)+'" target="_blank" rel="noopener">Ver PDF</a>':pdfBtn(e,'remito'))+'</div>':'<div class="doc"><span class="k">Remito</span><span class="v muted">Aún no emitido</span></div>';
  var f=e.factura&&e.factura.numero?'<div class="doc"><span class="k">Factura · '+esc(FACT[e.factura.estado]||'')+'</span><span class="v">'+esc(e.factura.numero)+' · '+fmtARS(e.factura.importe)+'</span>'+(e.factura.vence?'<span class="small '+(facturaVencida(e)?'':'muted')+'" style="'+(facturaVencida(e)?'color:var(--bad);font-weight:600':'')+'">'+(e.factura.estado==='pagada'?'Pagada':'Vence '+esc(e.factura.vence))+'</span>':'')+(e.factura.url?'<a class="small" href="'+esc(e.factura.url)+'" target="_blank" rel="noopener">Ver PDF</a>':pdfBtn(e,'factura'))+'</div>':'<div class="doc"><span class="k">Factura</span><span class="v muted">Pendiente de emisión</span></div>';
  return '<div class="grid2">'+r+f+'</div>'+podHtml(e);}
function obsList(e){var o=e.observaciones||[];if(!o.length)return '';
  return '<div class="obs">'+o.map(function(x){return '<div>'+esc(x.texto)+'<small>'+esc(x.por)+' · '+esc(fmtHora(x.ts))+'</small>'+fotosHtml(x.fotos)+(x.fotoPendiente?'<small>Foto pendiente de subir</small>':'')+'</div>';}).join('')+'</div>';}

/* cliente */
function viewCliente(){
  var all=D().entregas.filter(function(e){return S.mode==='demo'?e.clienteId==='c2':true;});
  var pend=all.filter(function(e){return e.estado==='programada'||e.estado==='en_camino';}).sort(function(a,b){return (a.fecha+a.desde).localeCompare(b.fecha+b.desde);});
  var hist=all.filter(function(e){return pend.indexOf(e)<0;}).sort(function(a,b){return b.fecha.localeCompare(a.fecha);});
  var camino=pend.filter(function(e){return e.estado==='en_camino';});
  var venc=all.filter(facturaVencida);
  var ban='';
  if(camino.length){var e=camino[0];ban+='<div class="banner signal" role="status">'+ICON.truck+'<div><strong>Tu pedido '+esc(e.guia)+' está en camino</strong>Ventana de entrega: '+esc(ventana(e))+(e.chofer?' · Chofer: '+esc(e.chofer):'')+'.</div></div>';}
  else if(pend.length){var n=pend[0];ban+='<div class="banner info" role="status">'+ICON.bell+'<div><strong>Tenés '+pend.length+(pend.length===1?' entrega pendiente':' entregas pendientes')+'</strong>Próxima: '+esc(fmtFecha(n.fecha))+', '+esc(ventana(n))+' ('+esc(n.guia)+').</div></div>';}
  else ban+='<div class="banner ok" role="status">'+ICON.check+'<div><strong>No tenés entregas pendientes</strong>Cuando se programe una nueva te avisamos acá.</div></div>';
  if(venc.length)ban+='<div class="banner bad" role="status">'+ICON.alert+'<div><strong>'+venc.length+(venc.length===1?' factura vencida':' facturas vencidas')+' · total '+fmtARS(venc.reduce(function(t,e){return t+(e.factura.importe||0);},0))+'</strong>'+venc.slice(0,5).map(function(e){return esc(e.factura.numero)+' ('+fmtARS(e.factura.importe)+')';}).join(' · ')+(venc.length>5?' · y '+(venc.length-5)+' más':'')+'</div></div>';
  var card=function(e){return '<article class="card'+(e.estado==='en_camino'?' next':'')+(e.estado==='entregada'?' done':'')+'">'+
    '<div class="row sp"><div class="row"><span class="guia">'+esc(e.guia)+'</span>'+chipEstado(e)+'</div><strong>'+esc(fmtFecha(e.fecha))+' · '+esc(ventana(e))+'</strong></div>'+
    '<div>'+esc(e.direccion)+' <span class="muted small">· '+(e.bultos||1)+' bulto'+((e.bultos||1)>1?'s':'')+'</span></div>'+pasos(e)+docs(e)+obsList(e)+((e.estado==='programada'||e.estado==='en_camino')&&traf().telefono?'<div class="row"><span class="small muted">¿Necesitás consultar algo?</span>'+trafBtns('Hola, consulto por mi entrega '+e.guia+' ('+fmtFecha(e.fecha)+', '+ventana(e)+').',true)+'</div>':'')+'</article>';};
  return ban+
    '<h2>Mis entregas</h2>'+
    (pend.length?pend.map(card).join(''):'')+
    (hist.length?'<h3>Historial</h3>'+hist.map(card).join(''):'')+
    (!all.length?'<div class="empty">Todavía no hay entregas asociadas a tu cuenta.</div>':'');
}

/* chofer */
function viewChofer(){
  var yo=miId(),dia=diaStr(S.ui.dia==='manana'?'manana':'hoy');
  var mine=D().entregas.filter(function(e){return e.choferId===yo&&e.fecha===dia;}).sort(function(a,b){return (a.orden||0)-(b.orden||0);});
  var done=mine.filter(function(e){return e.estado==='entregada'||e.estado==='no_entregada';}).length;
  var pend=mine.filter(function(e){return e.estado==='programada'||e.estado==='en_camino';});
  var next=pend.find(function(e){return e.estado==='en_camino';})||pend[0];
  var dep=D().depot,lastDone=mine.filter(function(e){return e.estado==='entregada'&&hasXY(e);}).slice(-1)[0];
  var km=pathKm(lastDone||dep,pend.filter(hasXY));
  var head='<div class="row sp"><h2>Hoja de ruta</h2><div class="seg lt" role="group" aria-label="Día"><button data-act="dia" data-v="hoy" aria-pressed="'+(S.ui.dia!=='manana')+'">Hoy</button><button data-act="dia" data-v="manana" aria-pressed="'+(S.ui.dia==='manana')+'">Mañana</button></div></div>'+
    '<div class="tiles"><div class="tile"><b>'+done+' / '+mine.length+'</b><span>Entregadas</span></div><div class="tile"><b>'+pend.length+'</b><span>Pendientes</span></div><div class="tile"><b>~'+km.toFixed(0)+' km</b><span>Restantes (estimado)</span></div></div>';
  var cards=mine.map(function(e,i){
    var fin=e.estado==='entregada'||e.estado==='no_entregada',isNext=next&&next.id===e.id;
    var acts='';
    if(!fin){
      acts+='<div class="row"><a class="btn sig" href="'+esc(wazeUrl(e))+'" target="_blank" rel="noopener">'+ICON.nav+'Navegar con Waze</a>';
      if(e.estado==='programada')acts+='<button class="btn" data-act="estado" data-id="'+esc(e.id)+'" data-v="en_camino">'+ICON.truck+'Salí hacia acá</button>';
      acts+='<button class="btn ok" data-act="x-pod" data-id="'+esc(e.id)+'">'+ICON.check+'Entregado</button>';
      acts+='<button class="btn bad" data-act="motivo" data-id="'+esc(e.id)+'">No se pudo entregar</button></div>';
      if(S.ui.motivo===e.id)acts+='<div class="row"><label style="flex:1;min-width:200px">Motivo<select id="mot-'+esc(e.id)+'"><option>Cliente ausente</option><option>Dirección incorrecta</option><option>Mercadería rechazada</option><option>No hay quien reciba</option><option>Otro</option></select></label></div><div class="row"><label style="flex:1;min-width:200px">Observaciones (opcional)<textarea id="mnota-'+esc(e.id)+'" placeholder="Ej.: nadie atendió, se llamó dos veces"></textarea></label></div>'+devBlock('no-'+e.id,e)+ftBlock('no:'+e.id)+'<div class="row"><button class="btn bad" data-act="noent" data-id="'+esc(e.id)+'">Confirmar que no se entregó</button></div>';
      if(traf().telefono)acts+='<div class="row">'+trafBtns('Hola, soy '+actor()+'. Entrega '+e.guia+' ('+e.cliente+'): ',true)+'</div>';
      if(S.ui.obsOpen===e.id||ftList('obs:'+e.id).length)acts+='<div class="row"><label style="flex:1;min-width:200px">Observación<textarea id="obs-'+esc(e.id)+'" placeholder="Ej.: recibió el encargado, entrada por portón lateral"></textarea></label></div>'+ftBlock('obs:'+e.id)+'<div class="row"><button class="btn sm" data-act="obs" data-id="'+esc(e.id)+'">Guardar observación</button><button class="btn sm" data-act="x16-obs" data-id="'+esc(e.id)+'">Cerrar</button></div>';else acts+='<div class="row"><button class="btn sm" data-act="x16-obs" data-id="'+esc(e.id)+'">+ Observación o foto</button></div>';
    }
    return '<article class="card'+(isNext?' next':'')+(fin?' done':'')+'"><div class="row"><span class="stopn">'+(i+1)+'</span><div style="min-width:0;flex:1"><div class="row"><strong>'+esc(e.cliente)+'</strong>'+chipEstado(e)+'</div><div class="small muted">'+esc(e.direccion)+'</div></div></div>'+
      '<div class="row small"><span class="guia">'+esc(e.guia)+'</span><span>Ventana '+esc(ventana(e))+'</span><span>'+(e.bultos||1)+' bulto'+((e.bultos||1)>1?'s':'')+'</span>'+(e.remito&&e.remito.numero?'<span class="mono">'+esc(e.remito.numero)+'</span>':'')+'</div>'+
      obsList(e)+podHtml(e)+acts+panelPod(e)+'</article>';}).join('');
  var sticky=next?'<div class="sticky-next"><div class="in"><div class="t"><div class="small" style="opacity:.75">Siguiente parada</div><strong>'+esc(next.cliente)+'</strong> <span class="small" style="opacity:.8">'+esc(next.direccion)+'</span></div><a class="btn sig" href="'+esc(wazeUrl(next))+'" target="_blank" rel="noopener">'+ICON.nav+'Waze</a></div></div>':'';
  return alertasPropias()+panelVehiculo()+panelUrgencia()+panelGasto()+head+(mine.length?cards:'<div class="empty">No tenés paradas asignadas para este día.</div>')+'<div id="sticky-slot">'+sticky+'</div>';
}

/* administración */
var pct1=function(x){return (x>0?'+':'')+nf(x*100,1)+'%';};
function vCalc(v){var pres=v.tarifaKm*v.km+v.peaje,real=v.costoKm*v.km+v.peaje;return Object.assign({},v,{pres:pres,real:real,dev:pres?(real-pres)/pres:0,cpk:v.km?real/v.km:0,cpt:v.ton?real/v.ton:0});}
function chipDev(d){var c=d>0.10?'bad':d>0.05?'warn':d<-0.02?'ok':'';return '<span class="chip '+c+'">'+pct1(d)+'</span>';}
function chartRutas(rows){
  var max=Math.max.apply(null,rows.map(function(r){return Math.max(r.pres,r.real);}))||1,W=600,L=150,rh=36,H=rows.length*rh+8,g='';
  rows.forEach(function(r,i){var y=i*rh+6,sc=(W-L-70)/max,nm=r.ruta.replace(/^Buenos Aires - /,'');
    g+='<text x="'+(L-8)+'" y="'+(y+17)+'" text-anchor="end">'+esc(nm)+'</text>'+
      '<rect x="'+L+'" y="'+y+'" width="'+(r.pres*sc).toFixed(1)+'" height="11" rx="2" style="fill:var(--neutral-bg);stroke:var(--line)"><title>Presupuestado '+esc(fmtARS(r.pres))+'</title></rect>'+
      '<rect x="'+L+'" y="'+(y+14)+'" width="'+(r.real*sc).toFixed(1)+'" height="11" rx="2" style="fill:var(--'+(r.real>r.pres*1.05?'bad':'ok')+')"><title>Real '+esc(fmtARS(r.real))+'</title></rect>'+
      '<text x="'+(L+Math.max(r.pres,r.real)*sc+6).toFixed(1)+'" y="'+(y+22)+'">'+esc(fm(r.real))+'</text>';});
  return '<svg class="chart" viewBox="0 0 '+W+' '+H+'" width="100%" role="img" aria-label="Costo presupuestado y real por ruta">'+g+'</svg><div class="legend"><span><i style="background:var(--neutral-bg);border:1px solid var(--line)"></i>Presupuestado</span><span><i style="background:var(--ok)"></i>Real (dentro de +5%)</span><span><i style="background:var(--bad)"></i>Real (más de +5% sobre lo pactado)</span></div>';}
function viewViajes(){
  var list=(D().viajes||[]).map(vCalc).sort(function(a,b){return b.fecha.localeCompare(a.fecha);});
  var head='<div class="row sp"><h2>Viajes de larga distancia</h2><label class="btn pri" style="cursor:pointer">Importar planilla (Excel o CSV)<input id="v-file" type="file" accept=".xlsx,.xls,.csv,.txt" hidden></label></div>';
  if(!list.length)return head+'<div class="empty">Todavía no hay viajes. Cargá el primero con "Nuevo viaje", subí una planilla (bajá la plantilla CSV) o importá la hoja "TMS 2 Registro de Viajes" de tu Excel.</div>';
  var T=function(f){return list.reduce(function(t,x){return t+x[f];},0);},km=T('km'),ton=T('ton'),pres=T('pres'),real=T('real'),dev=pres?(real-pres)/pres:0,fuera=list.filter(function(x){return x.dev>0.05;});
  var byR={},byP={};
  list.forEach(function(x){var r=byR[x.ruta]=byR[x.ruta]||{ruta:x.ruta,pres:0,real:0};r.pres+=x.pres;r.real+=x.real;
    var p=byP[x.proveedor]=byP[x.proveedor]||{n:x.proveedor,v:0,km:0,pres:0,real:0};p.v++;p.km+=x.km;p.pres+=x.pres;p.real+=x.real;});
  var rutas=Object.keys(byR).map(function(k){return byR[k];}).sort(function(a,b){return b.real-a.real;}),provs=Object.keys(byP).map(function(k){return byP[k];}).sort(function(a,b){return b.real-a.real;});
  var th='style="text-align:left;color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.06em"';
  return head+'<div class="kpis">'+
    KPI(list.length,'Viajes',nf(km)+' km · '+nf(ton,1)+' t')+
    KPI(fm(real),'Costo real',fm(pres)+' presupuestado')+
    KPI(pct1(dev),'Desvío total',dev>0.05?'sobre lo pactado':'dentro de lo esperado',dev>0.05?'bad':'ok')+
    KPI(fuera.length,'Viajes fuera de presupuesto','más de +5%',fuera.length?'bad':'ok')+
    KPI(fmtARS(real/km),'Costo por km','promedio ponderado')+
    KPI(fm(real/ton),'Costo por tonelada','promedio ponderado')+'</div>'+
    '<div class="panel"><h3>Costo por ruta</h3>'+chartRutas(rutas)+'</div>'+
    '<div class="panel"><h3>Proveedores</h3><div class="tablewrap"><table style="width:100%;border-collapse:collapse;font-size:14px;min-width:520px"><thead><tr '+th+'><th style="padding:6px">Proveedor</th><th>Viajes</th><th>Km</th><th>Costo real</th><th>Desvío</th><th>$ / km</th></tr></thead><tbody>'+
      provs.map(function(p){var d=p.pres?(p.real-p.pres)/p.pres:0;return '<tr style="border-top:1px solid var(--line)"><td style="padding:8px 6px"><strong>'+esc(p.n)+'</strong></td><td>'+p.v+'</td><td>'+nf(p.km)+'</td><td>'+fmtARS(p.real)+'</td><td>'+chipDev(d)+'</td><td>'+fmtARS(p.real/p.km)+'</td></tr>';}).join('')+'</tbody></table></div></div>'+
    '<div class="panel"><h3>Detalle de viajes</h3><div class="tablewrap"><table style="width:100%;border-collapse:collapse;font-size:14px;min-width:760px"><thead><tr '+th+'><th style="padding:6px">Guía</th><th>Fecha</th><th>Ruta</th><th>Proveedor</th><th>Km</th><th>Ton</th><th>Real</th><th>Desvío</th><th>$ / ton</th></tr></thead><tbody>'+
      list.map(function(x){return '<tr style="border-top:1px solid var(--line)"><td style="padding:8px 6px"><span class="guia">'+esc(x.guia)+'</span></td><td>'+esc(fmtFecha(x.fecha))+'</td><td>'+esc(x.ruta.replace(/^Buenos Aires - /,'BA → '))+'</td><td>'+esc(x.proveedor)+'<div class="small muted">'+esc(x.vehiculo)+'</div></td><td>'+nf(x.km)+'</td><td>'+nf(x.ton,1)+'</td><td>'+fmtARS(x.real)+'</td><td>'+chipDev(x.dev)+'</td><td>'+fmtARS(x.cpt)+'</td></tr>';}).join('')+'</tbody></table></div></div>'+
    '<div class="small muted">Presupuestado = tarifa pactada por km × km + peaje. Real = costo real por km × km + peaje. Mismos cálculos que las hojas TMS de tu Excel.</div>';
}
function loadXLSX(){return window.XLSX?Promise.resolve():new Promise(function(res,rej){var s=document.createElement('script');s.src='https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js';s.onload=res;s.onerror=rej;document.head.appendChild(s);});}
function parseViajes(buf){
  var wb=XLSX.read(buf,{type:'array',cellDates:true}),nm=function(re){var n=wb.SheetNames.filter(function(x){return re.test(x);})[0];return n?XLSX.utils.sheet_to_json(wb.Sheets[n],{header:1,raw:true,defval:null}):null;};
  var r2=nm(/registro de viajes/i),r1=nm(/maestro rutas/i);if(!r2)return null;
  var num=function(x){x=typeof x==='number'?x:parseFloat(String(x==null?'':x).replace(',','.'));return isNaN(x)?0:x;};
  var rutas={},tar={};
  (r1||[]).slice(5,15).forEach(function(r){if(r&&r[0])rutas[r[0]]={km:num(r[1]),peaje:num(r[2])};});
  (r1||[]).slice(5,15).forEach(function(r){if(r&&r[5])tar[r[5]]=num(r[8]);});
  var out=[],skip=0;
  r2.slice(4).forEach(function(r){
    if(!r||!r[0])return;var guia=String(r[0]).trim();if(!/^[A-Za-z0-9][A-Za-z0-9-]*$/.test(guia))return;
    var f=r[1],fecha='';if(f instanceof Date)fecha=new Date(f.getTime()+12*3600e3).toISOString().slice(0,10);else if(typeof f==='number')fecha=new Date(Math.round((f-25569)*864e5)).toISOString().slice(0,10);else fecha=String(f||'').slice(0,10);
    var rt=rutas[r[3]]||{km:0,peaje:0},km=num(r[5])||rt.km,ton=num(r[6]),clave=r[7]||(r[2]+'-'+r[4]),tk=num(r[8])||tar[clave]||0,ck=num(r[10]),pj=num(r[11])||rt.peaje;
    if(!km||!ck||!tk||!fecha){skip++;return;}
    out.push({id:guia,guia:guia,fecha:fecha,proveedor:String(r[2]||''),ruta:String(r[3]||''),vehiculo:String(r[4]||''),km:km,ton:ton,tarifaKm:tk,costoKm:ck,peaje:pj});});
  return {rows:out,skipped:skip};}
async function importViajes(file){
  try{
    toast('Leyendo el Excel…');await loadXLSX();
    var res=parseViajes(await file.arrayBuffer());
    if(!res){toast('No encontré la hoja "TMS 2 Registro de Viajes".');return;}
    if(!res.rows.length){toast('No hay viajes completos para importar.');return;}
    if(S.mode==='demo'){var m={};S.data.demo.viajes.concat(res.rows).forEach(function(v){m[v.id]=v;});S.data.demo.viajes=Object.keys(m).map(function(k){return m[k];});render();}
    else{for(var i=0;i<res.rows.length;i+=10)await Promise.all(res.rows.slice(i,i+10).map(function(v){return db.doc('viajes/'+v.id).set(clean(v));}));}
    toast(res.rows.length+' viajes importados'+(res.skipped?' ('+res.skipped+' incompletos omitidos)':'')+'.');
  }catch(e){toast('No se pudo importar el archivo.');}
}
/* ================= WMS ================= */
var W=function(){return D().wms;};
function wStock(){var m={},tot={},w=W();
  w.kardex.forEach(function(x){var k=x.ubicacion+'|'+x.sku,q=(x.in||0)-(x.out||0);m[k]=(m[k]||0)+q;tot[x.sku]=(tot[x.sku]||0)+q;});
  return {m:m,tot:tot};}
function wAlert(disp,min){return disp<=0?'REORDEN':disp<=0.2*min?'AJUSTADO':'OK';}
var chipW=function(a){return '<span class="chip '+(a==='REORDEN'?'bad':a==='AJUSTADO'?'warn':'ok')+'">'+a+'</span>';};
function wPut(kind,o){o=clean(o);
  if(kind==='kardex'){if(!o.ts)o.ts=isoNow();if(!o.operador)o.operador=actor();}
  if(S.mode==='demo'){upsertLocal(S.data.demo.wms[kind],o);render();return Promise.resolve();}
  return db.doc('wms/'+kind+'/items/'+o.id).set(o);}
function wDel(kind,id){
  if(S.mode==='demo'){S.data.demo.wms[kind]=S.data.demo.wms[kind].filter(function(x){return x.id!==id;});render();return Promise.resolve();}
  return db.doc('wms/'+kind+'/items/'+id).delete();}
function wSub(){return '<div class="seg lt" role="group" aria-label="Depósito">'+[['stock','Stock'],['plano','Plano'],['efic','Peso y orden'],['mov','Movimiento'],['kardex','Kardex'],['abc','ABC-XYZ'],['lotes','Lotes y FEFO'],['conteos','Conteos'],['picking','Picking'],['devol','Logística inversa'],['maestros','Productos y ubicaciones']].map(function(t){return '<button data-act="wsub" data-v="'+t[0]+'" aria-pressed="'+(S.ui.wsub===t[0])+'">'+t[1]+'</button>';}).join('')+'</div>';}
function viewWms(){
  var w=W(),h='<div class="row sp"><h2>Depósito</h2><div class="row"><label class="btn" style="cursor:pointer">Importar Excel<input id="w-file" type="file" accept=".xlsx,.xls,.csv,.txt" hidden></label>'+(S.mode==='live'&&!w.skus.length?'<button class="btn" data-act="wcargar">Cargar datos de ejemplo</button>':'')+'</div></div>'+wSub();
  if(!w.skus.length&&S.ui.wsub!=='maestros')return h+'<div class="empty">Todavía no hay productos. Agregá el primero a mano o importá tu Excel (hojas WMS 1, 2 y 3).<div style="margin-top:10px"><button class="btn pri" data-act="wsub" data-v="maestros">Agregar productos</button></div></div>';
  var v=S.ui.wsub;
  return h+(v==='devol'?xDevol():v==='lotes'?xLotes():v==='conteos'?xConteos():v==='picking'?xPicking():v==='efic'?wEfic():v==='plano'?wPlano():v==='mov'?wMov():v==='kardex'?wKardex():v==='abc'?wAbc():v==='maestros'?wMaestros():wStockView()+xStockVenc());}
function wStockView(){
  var w=W(),st=wStock(),capT=w.ubic.reduce(function(t,u){return t+(u.cap||0);},0),uni=Object.keys(st.tot).reduce(function(t,k){return t+st.tot[k];},0);
  var occ=Object.keys(st.m).filter(function(k){return st.m[k]>0;}).length;
  var rows=w.skus.map(function(s){var t=st.tot[s.codigo]||0,disp=t-s.min;return {s:s,t:t,disp:disp,a:wAlert(disp,s.min)};});
  var rj=rows.filter(function(r){return r.a==='REORDEN';}),am=rows.filter(function(r){return r.a==='AJUSTADO';});
  var ban=rj.length?'<div class="banner bad" role="status">'+ICON.alert+'<div><strong>'+rj.length+(rj.length===1?' SKU para reordenar':' SKUs para reordenar')+'</strong>'+rj.slice().sort(function(a,b){return a.t-b.t;}).slice(0,8).map(function(r){var ps=window.skuPos23?window.skuPos23(r.s.codigo,4):'';return '<span style="display:block;margin-top:4px">'+esc(r.s.codigo+' '+r.s.producto)+' <span class="small">— '+(ps?'📍 '+esc(ps)+' · mín. '+nf(r.s.min||0):'sin stock · mín. '+nf(r.s.min||0))+'</span></span>';}).join('')+(rj.length>8?'<span class="small" style="display:block;margin-top:6px">…y '+nf(rj.length-8)+' más. Se muestran los 8 con menos stock; el resto está en la pestaña Stock.</span>':'')+'</div></div>':'';
  ban+=am.length?'<div class="banner warn" role="status">'+ICON.alert+'<div><strong>'+am.length+(am.length===1?' SKU ajustado':' SKUs ajustados')+'</strong>'+am.map(function(r){return esc(r.s.codigo+' '+r.s.producto);}).join(' · ')+'</div></div>':'';
  if(!ban)ban='<div class="banner ok" role="status">'+ICON.check+'<div><strong>Todos los SKUs con stock sobre el mínimo</strong></div></div>';
  var th='style="text-align:left;color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.06em"';
  var uIx={},sIx={};w.ubic.forEach(function(x){uIx[x.codigo]=x;});w.skus.forEach(function(x){sIx[x.codigo]=x;});
  var ub=Object.keys(st.m).filter(function(k){return st.m[k]!==0;}).sort().map(function(k){var p=k.split('|'),u=uIx[p[0]],sk=sIx[p[1]],cap=u?u.cap:0,pc2=cap?Math.round(st.m[k]/cap*100):0;
    return '<tr style="border-top:1px solid var(--line)"><td style="padding:8px 6px" class="mono">'+esc(p[0])+'</td><td><span class="guia">'+esc(p[1])+'</span> '+esc(sk?sk.producto:'')+'</td><td>'+nf(st.m[k])+'</td><td>'+(cap?'<div class="row" style="flex-wrap:nowrap"><div class="bar" style="flex:1"><i style="width:'+Math.min(100,pc2)+'%;background:var(--'+(pc2>100?'bad':pc2>85?'warn':'ok')+')"></i></div><span>'+pc2+'%</span></div>':'<span class="muted">—</span>')+'</td></tr>';}).join('');
  return '<div class="kpis">'+KPI(w.skus.length,'SKUs',w.ubic.length+' ubicaciones')+KPI(nf(uni),'Unidades en stock','cuadra con el kardex','ok')+KPI(capT?Math.round(uni/capT*100)+'%':'—','Ocupación','de '+nf(capT)+' u de capacidad')+KPI(rj.length,'Para reordenar','stock ≤ mínimo',rj.length?'bad':'ok')+KPI(am.length,'Ajustados','menos de 20% sobre el mínimo',am.length?'warn':'ok')+'</div>'+ban+
   '<div class="panel"><h3>Stock por SKU</h3><div class="tablewrap"><table style="width:100%;border-collapse:collapse;font-size:14px;min-width:640px"><thead><tr '+th+'><th style="padding:6px">SKU</th><th>Producto</th><th>Categoría</th><th>Stock</th><th>Mín</th><th>Máx</th><th>Disponible</th><th>Alerta</th></tr></thead><tbody>'+
    rows.map(function(r){return '<tr style="border-top:1px solid var(--line)"><td style="padding:8px 6px"><span class="guia">'+esc(r.s.codigo)+'</span></td><td>'+esc(r.s.producto)+'</td><td class="muted">'+esc(r.s.categoria)+'</td><td><strong>'+nf(r.t)+'</strong> '+esc(r.s.um||'')+'</td><td>'+nf(r.s.min)+'</td><td>'+nf(r.s.max)+'</td><td>'+nf(r.disp)+'</td><td>'+chipW(r.a)+(r.t>r.s.max?' <span class="chip warn">Sobre máx.</span>':'')+'</td></tr>';}).join('')+'</tbody></table></div></div>'+
   '<div class="panel"><h3>Stock por ubicación</h3><div class="tablewrap"><table style="width:100%;border-collapse:collapse;font-size:14px;min-width:520px"><thead><tr '+th+'><th style="padding:6px">Ubicación</th><th>SKU</th><th>Stock</th><th>Ocupación</th></tr></thead><tbody>'+(ub||'<tr><td colspan="4" class="muted" style="padding:14px">Sin stock.</td></tr>')+'</tbody></table></div></div>';}
var SEMT={ok:'Verde',warn:'Amarillo',bad:'Rojo'};
function semLegend(){var v=S.ui.wvista==='lot'?['Vence en más de 60 días o sin vencimiento','Vence en 31 a 60 días','Vence en 30 días o menos, o vencido']:S.ui.wvista==='peso'?['Hasta 80% del máximo','80% a 100%','Supera el máximo']:['Hasta '+S.cfg.d1+' días sin salida',S.cfg.d1+' a '+S.cfg.d2+' días','Más de '+S.cfg.d2+' días (obsoleto)'];
  return '<div class="legend"><span><i style="background:var(--ok-bg);border:1px solid var(--ok)"></i>'+v[0]+'</span><span><i style="background:var(--warn-bg);border:1px solid var(--warn)"></i>'+v[1]+'</span><span><i style="background:var(--bad-bg);border:1px solid var(--bad)"></i>'+v[2]+'</span></div>';}
var semChip=function(l,t){return '<span class="chip '+l+'">'+t+'</span>';};
function wPeso(){
  var w=W(),st=wStock(),cfg=S.cfg,pk={};w.skus.forEach(function(k){pk[k.codigo]=k.peso||0;});
  var pos={},max={},rack={};
  Object.keys(st.m).forEach(function(k){if(st.m[k]>0){var pp=k.split('|');pos[pp[0]]=(pos[pp[0]]||0)+st.m[k]*(pk[pp[1]]||0);}});
  w.ubic.forEach(function(u){var m=locParse(u.codigo)||{p:0,r:0},rk=m.p+':'+m.r;max[u.codigo]=u.capKg>0?u.capKg:cfg.kgPos;var r=rack[rk]=rack[rk]||{key:rk,p:m.p,r:m.r,kg:0,max:0,n:0};r.kg+=pos[u.codigo]||0;r.max+=max[u.codigo];r.n++;});
  var lv=function(kg,mx){var q=mx?kg/mx:0;return q>1?'bad':q>=0.8?'warn':'ok';};
  return {pos:pos,max:max,rack:rack,pk:pk,lev:function(loc){return lv(pos[loc]||0,max[loc]||cfg.kgPos);},levR:lv,total:Object.keys(pos).reduce(function(t,k){return t+pos[k];},0)};}
function wDias(){
  var w=W(),cfg=S.cfg,corte=new Date((cfg.corte||HOY)+'T12:00:00'),last={};
  w.kardex.forEach(function(x){var o=last[x.sku]=last[x.sku]||{out:'',inn:''};if(x.tipo==='OUT'&&x.out>0&&x.fecha>o.out)o.out=x.fecha;if(x.in>0&&x.fecha>o.inn)o.inn=x.fecha;});
  var dias={};w.skus.forEach(function(k){var o=last[k.codigo],ref=o?(o.out||o.inn):'';dias[k.codigo]=ref?Math.floor((corte-new Date(ref+'T12:00:00'))/864e5):null;});
  return {dias:dias,corte:cfg.corte||HOY,lev:function(sku){var d=dias[sku];return d==null||d>cfg.d2?'bad':d>cfg.d1?'warn':'ok';}};}
function locExtra(sel,has,PW,DS){
  var kg=PW.pos[sel]||0,mx=PW.max[sel],lv=PW.lev(sel),m=locParse(sel)||{p:0,r:0},rk=PW.rack[m.p+':'+m.r];
  var ob=has.map(function(h){var d=DS.dias[h.sku];return esc(h.sku)+': '+(d==null?'sin movimientos':d+' días sin salida')+' '+semChip(DS.lev(h.sku),SEMT[DS.lev(h.sku)]);}).join('<br>');
  return '<div class="grid2"><div class="doc"><span class="k">Peso en la posición</span><span class="v">'+nf(kg)+' de '+nf(mx)+' kg '+semChip(lv,SEMT[lv])+'</span></div>'+
    '<div class="doc"><span class="k">Peso del rack completo</span><span class="v">'+(rk?nf(rk.kg)+' de '+nf(rk.max)+' kg '+semChip(PW.levR(rk.kg,rk.max),SEMT[PW.levR(rk.kg,rk.max)]):'—')+'</span></div>'+
    '<div class="doc" style="grid-column:1/-1"><span class="k">Antigüedad del stock</span><span class="v">'+(ob||'Sin stock')+'</span></div></div>';}
function wEfic(){
  var w=W(),st=wStock(),PW=wPeso(),DS=wDias(),cfg=S.cfg,P=SIMD,lay=simLayout(P),dem=simDemand(),pa=simPlace(lay,'actual'),pb=simPlace(lay,'slotting');
  var dist=function(c){var l=lay.map[c];return l?l.x+l.y:0;},act=0,opt=0;
  w.skus.forEach(function(k){var d=dem[k.codigo]||0;act+=d*dist(pa[k.codigo]);opt+=d*dist(pb[k.codigo]);});
  var eff=act>0?Math.min(1,opt/act):null;
  var rows=w.skus.map(function(k){var t=st.tot[k.codigo]||0;return {k:k,t:t,kg:t*(k.peso||0),d:dem[k.codigo]||0,dias:DS.dias[k.codigo],lev:DS.lev(k.codigo)};});
  var totD=rows.reduce(function(a,r){return a+r.d;},0),sorted=rows.slice().sort(function(a,b){return b.d-a.d;});
  rows.forEach(function(r){r.rk=1+rows.filter(function(o){return o.d>r.d;}).length;});
  rows.forEach(function(r){var ac=rows.filter(function(o){return o.rk<=r.rk;}).reduce(function(t,o){return t+(totD?o.d/totD:0);},0);r.abc=ac<=0.8?'A':ac<=0.95?'B':'C';});
  var third=lay.list.slice().sort(function(a,b){return (a.x+a.y)-(b.x+b.y);}).slice(0,Math.ceil(lay.list.length/3)).map(function(l){return l.code;});
  var aRows=rows.filter(function(r){return r.abc==='A'&&r.t>0;}),aIn=aRows.filter(function(r){return third.indexOf(pa[r.k.codigo])>=0;}).length;
  var obs=rows.filter(function(r){return r.t>0&&r.lev==='bad';}),obsU=obs.reduce(function(a,r){return a+r.t;},0),obsKg=obs.reduce(function(a,r){return a+r.kg;},0),warn=rows.filter(function(r){return r.t>0&&r.lev==='warn';});
  var racks=Object.keys(PW.rack).map(function(k){return PW.rack[k];}).sort(function(a,b){return a.p-b.p||a.r-b.r;}),racksBad=racks.filter(function(r){return PW.levR(r.kg,r.max)==='bad';}),posBad=w.ubic.filter(function(u){return PW.lev(u.codigo)==='bad'&&(PW.pos[u.codigo]||0)>0;});
  var sinPeso=w.skus.filter(function(k){return !(k.peso>0);});
  var th='style="text-align:left;color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.06em"';
  var inp=function(id,l,v,st2,ty){return '<label>'+l+'<input id="cf-'+id+'" type="'+(ty||'number')+'" min="0" step="'+(st2||1)+'" value="'+esc(v)+'"></label>';};
  var ban=sinPeso.length?'<div class="banner warn" role="status">'+ICON.alert+'<div><strong>Faltan pesos de '+sinPeso.length+' SKUs</strong>Cargá el peso por unidad en Maestros (o agregá una columna "Peso (kg)" en la hoja WMS 1). Sin eso el peso por rack queda subestimado.</div></div>':'';
  return '<div class="kpis">'+
    KPI(nf(PW.total)+' kg','Peso almacenado',racks.length+' racks')+
    KPI(racksBad.length,'Racks sobre el máximo','peso mayor al soportado',racksBad.length?'bad':'ok')+
    KPI(posBad.length,'Posiciones sobre el máximo','con stock',posBad.length?'bad':'ok')+
    KPI(eff==null?'—':Math.round(eff*100)+'%','Eficiencia del orden',eff==null?'sin salidas para medir':'cuánto se acerca a lo ideal',eff==null?'':eff>=0.85?'ok':eff>=0.65?'warn':'bad')+
    KPI(aRows.length?aIn+' de '+aRows.length:'—','SKUs A cerca de la puerta','en el tercio más cercano')+
    KPI(obs.length,'SKUs obsoletos',nf(obsU)+' u · '+nf(obsKg)+' kg',obs.length?'bad':'ok')+'</div>'+ban+
    (obs.length?'<div class="banner bad" role="status">'+ICON.alert+'<div><strong>'+obs.length+(obs.length===1?' SKU sin salida':' SKUs sin salida')+' hace más de '+cfg.d2+' días</strong>'+obs.map(function(r){return esc(r.k.codigo+' '+r.k.producto)+(r.dias==null?'':' ('+r.dias+' d)');}).join(' · ')+'</div></div>':'<div class="banner ok" role="status">'+ICON.check+'<div><strong>No hay stock obsoleto con los límites actuales</strong></div></div>')+
    '<div class="panel"><h3>Peso por rack</h3><div class="tablewrap"><table style="width:100%;border-collapse:collapse;font-size:14px;min-width:520px"><thead><tr '+th+'><th style="padding:6px">Rack</th><th>Peso</th><th>Máximo soportado</th><th>Carga</th><th></th></tr></thead><tbody>'+
    racks.map(function(r){var q=r.max?r.kg/r.max:0,l=PW.levR(r.kg,r.max);return '<tr style="border-top:1px solid var(--line)"><td style="padding:8px 6px"><strong>Pasillo '+r.p+' · Rack '+r.r+'</strong></td><td>'+nf(r.kg)+' kg</td><td>'+nf(r.max)+' kg</td><td><div class="row" style="flex-wrap:nowrap"><div class="bar" style="flex:1"><i style="width:'+Math.min(100,q*100).toFixed(0)+'%;background:var(--'+(l==='ok'?'ok':l==='warn'?'warn':'bad')+')"></i></div><span>'+nf(q*100)+'%</span></div></td><td>'+semChip(l,SEMT[l])+'</td></tr>';}).join('')+'</tbody></table></div></div>'+
    '<div class="panel"><h3>Orden y antigüedad por SKU</h3><div class="tablewrap"><table style="width:100%;border-collapse:collapse;font-size:14px;min-width:720px"><thead><tr '+th+'><th style="padding:6px">SKU</th><th>Stock</th><th>Peso</th><th>Clase</th><th>Ubicación actual</th><th>Ubicación sugerida</th><th>Sin salida</th><th></th></tr></thead><tbody>'+
    sorted.map(function(r){var c=r.k.codigo,mv=r.d>0&&pa[c]&&pb[c]&&pa[c]!==pb[c]&&dist(pb[c])<dist(pa[c]);return '<tr style="border-top:1px solid var(--line)"><td style="padding:8px 6px"><span class="guia">'+esc(c)+'</span> '+esc(r.k.producto)+'</td><td>'+nf(r.t)+'</td><td>'+(r.k.peso>0?nf(r.kg)+' kg':'<span class="muted">—</span>')+'</td><td><span class="chip '+(r.abc==='A'?'ok':r.abc==='B'?'warn':'')+'">'+r.abc+'</span></td><td class="mono">'+esc(pa[c]||'—')+'</td><td class="mono">'+(mv?'<strong>'+esc(pb[c])+'</strong>':'<span class="muted">sin cambio</span>')+'</td><td>'+(r.dias==null?'—':r.dias+' d')+'</td><td>'+(r.t>0?semChip(r.lev,SEMT[r.lev]):'')+'</td></tr>';}).join('')+'</tbody></table></div>'+
    '<div class="small muted">Eficiencia del orden = distancia ideal ÷ distancia actual, ponderada por salidas: 100% significa que los SKUs que más salen ya están lo más cerca posible de la puerta. La ubicación sugerida pone los de mayor salida más cerca.</div></div>'+
    '<div class="panel"><h3>Límites del semáforo</h3><div class="grid2">'+inp('kg','Peso máximo por posición (kg)',cfg.kgPos,10)+inp('d1','Amarillo desde (días sin salida)',cfg.d1,1)+inp('d2','Rojo desde (días sin salida)',cfg.d2,1)+inp('cor','Fecha de corte (vacío = hoy)',cfg.corte,1,'date')+'</div><div class="small muted">Los días sin salida se cuentan desde la última salida (OUT) del SKU; si nunca salió, desde su última entrada. Se calculan contra '+esc(DS.corte)+'. El peso máximo por posición se puede cambiar por ubicación en Maestros.</div></div>';}
function wPlano(){
  var OP=rolActual()==='deposito',PW=wPeso(),DS=wDias(),VV=!OP&&S.ui.wvista==='valor'&&rolActual()==='admin',VP=VV?x9pos():null;
  var w=W(),st=wStock(),sel=S.ui.wloc,fs=S.ui.wfind,byLoc={},nq=1,maxP=1,maxR=1,cells={};
  w.ubic.forEach(function(u){var m=locParse(u.codigo);if(m){cells[u.codigo]={code:u.codigo,p:m.p,r:m.r,u:m.u,q:m.a,cap:u.cap||0,desc:u.descripcion};nq=Math.max(nq,m.a+1);maxP=Math.max(maxP,m.p);maxR=Math.max(maxR,m.r);}});
  var prs=[];Object.keys(cells).forEach(function(k){var kk=pad(cells[k].r)+':'+pad(cells[k].u);if(prs.indexOf(kk)<0)prs.push(kk);});prs.sort();Object.keys(cells).forEach(function(k){cells[k].ri=prs.indexOf(pad(cells[k].r)+':'+pad(cells[k].u));});maxR=Math.max(1,prs.length);
  Object.keys(st.m).forEach(function(k){var pp=k.split('|');if(st.m[k]>0)(byLoc[pp[0]]=byLoc[pp[0]]||[]).push({sku:pp[1],q:st.m[k]});});
  var CW=5.4,CH=2.2,GX=6.5,GY=2.4,RG=0.8;
  var bandQ=[],bandOff=[],totRows=0;Object.keys(cells).forEach(function(k){var c=cells[k];(bandQ[c.ri]=bandQ[c.ri]||[]);if(bandQ[c.ri].indexOf(c.q)<0)bandQ[c.ri].push(c.q);});
  for(var bi=0;bi<maxR;bi++){bandQ[bi]=(bandQ[bi]||[]).sort(function(a,b){return b-a;});bandOff[bi]=totRows;totRows+=bandQ[bi].length;}
  var X=function(c){return (c.p-1)*GX;},Y=function(c){return 3+(bandOff[c.ri]+bandQ[c.ri].indexOf(c.q))*GY+c.ri*RG;};
  var skName=function(c){var k=w.skus.filter(function(z){return z.codigo===c;})[0];return k?k.producto:'';};
  var g='<text x="0" y="1.2" style="font-size:1px;font-weight:600">Puerta / despacho</text><line x1="0" x2="'+(maxP*GX-1.1)+'" y1="1.8" y2="1.8" style="stroke:var(--head)" stroke-width="0.25"/>';
  for(var pp2=1;pp2<=maxP;pp2++)g+='<text x="'+((pp2-1)*GX+CW/2)+'" y="2.7" text-anchor="middle" style="font-size:0.95px;font-weight:700">Pasillo '+pp2+'</text>';
  Object.keys(cells).forEach(function(k){var c=cells[k],has=byLoc[k]||[],hit=fs&&has.some(function(h){return h.sku===fs;}),on=sel===k;
    var V=OP?'stock':S.ui.wvista,lev=null,fill,txt,dot=null;if(OP&&has.length){var l1=PW.lev(k),l2=has.map(function(h){return DS.lev(h.sku);}).concat([l1]);dot=l2.indexOf('bad')>=0?'bad':l2.indexOf('warn')>=0?'warn':null;}
    if(V==='peso'&&has.length)lev=PW.lev(k);
    if(V==='lot'&&has.length)lev=extLotLev(k);
    if(V==='obs'&&has.length)lev=has.map(function(h){return DS.lev(h.sku);}).sort(function(a,b){return ['ok','warn','bad'].indexOf(b)-['ok','warn','bad'].indexOf(a);})[0];
    fill=on?'var(--accent)':hit?'var(--signal)':VV&&has.length?x9fill(VP,k):lev?'var(--'+lev+'-bg)':has.length?(V==='stock'?'var(--signal-bg)':'var(--neutral-bg)'):'var(--surface2)';txt=on?'var(--accent-ink)':hit?'#fff':VV&&has.length&&VP.al(k)>0.55?'#06202b':'var(--ink)';
    var lab=has.length?(VV?vfmt(VP.pos[k]||0)+(VP.sc[k]?' *':''):V==='peso'?nf(PW.pos[k]||0)+' kg':V==='lot'?extLotLab(k):V==='obs'?has.map(function(h){var dd=DS.dias[h.sku];return h.sku+' · '+(dd==null?'—':dd+' d');}).join(' '):has.map(function(h){return h.sku;}).join(' ')):'libre';
    g+='<g data-act="wloc" data-id="'+esc(k)+'" tabindex="0" role="button" aria-label="Pasillo '+c.p+' rack '+c.r+' ubicación '+c.u+' altura '+pad(c.q)+(has.length?' '+esc(lab):' libre')+'" style="cursor:pointer"><rect x="'+X(c)+'" y="'+Y(c)+'" width="'+CW+'" height="'+CH+'" rx="0.3" style="fill:'+fill+';stroke:'+(hit||on?'var(--ink)':'var(--line)')+'" stroke-width="'+(hit||on?0.18:0.08)+'"/><text x="'+(X(c)+0.4)+'" y="'+(Y(c)+0.95)+'" style="font-size:0.85px;font-weight:700;fill:'+txt+'">R'+c.r+' · P'+c.q+'</text><text x="'+(X(c)+0.4)+'" y="'+(Y(c)+1.9)+'" style="font-size:0.85px;fill:'+txt+'">'+esc(lab)+'</text>'+(dot?'<circle cx="'+(X(c)+CW-0.6)+'" cy="'+(Y(c)+0.6)+'" r="0.42" style="fill:var(--'+dot+');stroke:var(--ink)" stroke-width="0.08"/>':'')+'</g>';});
  var H=3+totRows*GY+maxR*RG;
  var plano='<div class="panel"><div class="row sp"><h3>'+(x9only?'Valor del depósito':'Plano del depósito')+'</h3>'+(x9only||OP?'':'<label>Ver<select id="wv-vista"><option value="stock"'+(S.ui.wvista==='stock'?' selected':'')+'>Contenido</option><option value="peso"'+(S.ui.wvista==='peso'?' selected':'')+'>Peso (semáforo)</option><option value="obs"'+(S.ui.wvista==='obs'?' selected':'')+'>Antigüedad del stock (semáforo)</option><option value="lot"'+(S.ui.wvista==='lot'?' selected':'')+'>Lotes y vencimientos (semáforo)</option>'+(rolActual()==='admin'?'<option value="valor"'+(S.ui.wvista==='valor'?' selected':'')+'>Valor del stock ($)</option>':'')+'</select></label>')+'<label style="min-width:230px">¿Dónde está?<select id="wf-sku"><option value="">Elegir un SKU…</option>'+w.skus.map(function(k){return '<option value="'+esc(k.codigo)+'"'+(fs===k.codigo?' selected':'')+'>'+esc(k.codigo+' · '+k.producto)+'</option>';}).join('')+'</select></label></div>'+
    '<div class="small muted">Tocá una posición para ver exactamente dónde está en el rack'+(OP?', cuánto pesa y hace cuánto no sale. Un punto <strong>naranja</strong> marca peso cerca del máximo o stock con poca salida; un punto <strong>rojo</strong>, peso excedido o stock obsoleto.':'.')+'</div>'+
    '<svg class="chart" viewBox="-0.5 0 '+(maxP*GX)+' '+H+'" width="100%" style="display:block;max-width:'+Math.max(240,Math.round((maxP*GX+0.5)*11))+'px" role="group" aria-label="Plano del depósito">'+g+'</svg>'+
    (VV?x9legend(VP):(S.ui.wvista!=='stock'?semLegend():'')+'<div class="legend"><span><i style="background:var(--signal-bg);border:1px solid var(--line)"></i>Con stock</span><span><i style="background:var(--surface2);border:1px solid var(--line)"></i>Libre</span><span><i style="background:var(--signal)"></i>Resultado de la búsqueda</span><span><i style="background:var(--accent)"></i>Seleccionada</span></div>')+
    (fs?'<div class="small"><strong>'+esc(fs)+'</strong> está en: '+(Object.keys(byLoc).filter(function(k){return byLoc[k].some(function(h){return h.sku===fs;});}).map(function(k){var q=byLoc[k].filter(function(h){return h.sku===fs;})[0].q;return '<button class="btn sm" data-act="wloc" data-id="'+esc(k)+'">'+esc(k)+' ('+nf(q)+')</button>';}).join(' ')||'ninguna ubicación con stock')+'</div>':'')+'</div>';
  var det='';
  if(sel&&cells[sel]){
    var c=cells[sel],has=byLoc[sel]||[],tot=has.reduce(function(t,h){return t+h.q;},0),oc=c.cap?Math.round(tot/c.cap*100):0;
    var rs=Object.keys(cells).map(function(k){return cells[k];}).filter(function(z){return z.p===c.p&&z.r===c.r;}),rmax=Math.max.apply(null,rs.map(function(z){return z.u;})),by={};rs.forEach(function(z){by[z.u+'|'+z.q]=z;});
    var x0=30,cw=Math.min(64,(396-x0)/rmax),chh=34,Hf=8+nq*chh+20,rack='<rect x="'+(x0-2)+'" y="4" width="'+(cw*rmax+4)+'" height="'+(nq*chh+8)+'" rx="4" style="fill:none;stroke:var(--head)" stroke-width="2"/>';
    for(var a2=nq-1;a2>=0;a2--){var yy=8+(nq-1-a2)*chh;rack+='<text x="'+(x0-6)+'" y="'+(yy+chh/2+4)+'" text-anchor="end" style="font-size:11px;fill:var(--muted)">'+pad(a2)+'</text>';
      for(var r2=1;r2<=rmax;r2++){var z=by[r2+'|'+a2];if(!z)continue;var hh=byLoc[z.code]||[],isSel=z.code===sel,xx=x0+(r2-1)*cw;
        rack+='<g data-act="wloc" data-id="'+esc(z.code)+'" style="cursor:pointer"><rect x="'+(xx+1)+'" y="'+yy+'" width="'+(cw-2)+'" height="'+(chh-3)+'" rx="3" style="fill:'+(isSel?'var(--accent)':VV&&hh.length?x9fill(VP,z.code):hh.length?'var(--signal-bg)':'var(--surface2)')+';stroke:var(--line)"/>'+
          '<text x="'+(xx+cw/2)+'" y="'+(yy+chh/2+3)+'" text-anchor="middle" style="font-size:10px;fill:'+(isSel?'var(--accent-ink)':'var(--ink)')+'">'+esc(VV?(hh.length?vfmt(VP.pos[z.code]||0):''):hh.length?hh[0].sku+(hh.length>1?'+':''):'')+'</text></g>';}}
    for(var r3=1;r3<=rmax;r3++)rack+='<text x="'+(x0+(r3-0.5)*cw)+'" y="'+(Hf-4)+'" text-anchor="middle" style="font-size:11px;fill:var(--muted)">U'+pad(r3)+'</text>';
    var moves=w.kardex.filter(function(x){return x.ubicacion===sel;}).sort(function(a,b){return b.fecha.localeCompare(a.fecha)||b.id.localeCompare(a.id);}).slice(0,3);
    var ver=(S.ui.wver||'').trim(),vb='';
    if(ver)vb=locNorm(ver)===locNorm(sel)?'<div class="banner ok" role="status">'+ICON.check+'<div><strong>Correcto</strong>La posición coincide.</div></div>':'<div class="banner bad" role="alert">'+ICON.alert+'<div><strong>No coincide</strong>Leíste '+esc(ver)+' y la posición esperada es <span class="mono">'+esc(sel)+'</span>.</div></div>';
    det='<div class="panel" id="loc-det"><div class="row sp"><div><div class="small muted">Posición seleccionada</div><div style="font-family:var(--f-display);font-size:28px;font-weight:700;line-height:1">'+esc(sel)+'</div></div><button class="btn sm" data-act="wloc" data-id="">Cerrar</button></div>'+
      '<div style="font-size:18px"><strong>'+esc(locTxt(sel))+'</strong></div>'+
      '<svg class="chart" viewBox="0 0 400 '+Hf+'" width="100%" role="img" aria-label="Vista de frente del pasillo con la posición marcada">'+rack+'</svg>'+
      '<div class="small muted">Vista de frente del rack '+pad(c.r)+' del pasillo '+pad(c.p)+': cada columna es una ubicación (U01, U02…) y cada fila una altura; 00 es el piso. Código de esta posición: <span class="mono">'+esc(sel)+'</span> (pasillo:rack:ubicación:altura).</div>'+
      '<div class="grid2"><div class="doc"><span class="k">Contiene</span><span class="v">'+(has.length?has.map(function(h){return esc(h.sku)+' · '+esc(skName(h.sku))+' · '+nf(h.q)+' u'+(VV?' · '+x9v(h.sku,h.q):'');}).join('<br>'):'Libre')+'</span></div><div class="doc"><span class="k">Ocupación</span><span class="v">'+(c.cap?nf(tot)+' de '+nf(c.cap)+' u ('+oc+'%)':'Sin capacidad cargada')+'</span></div>'+(VV?x9doc(VP,sel):'')+'</div>'+
      lotesPos(sel)+locExtra(sel,has,PW,DS)+'<label>Confirmar lectura: escribí o escaneá el código de la etiqueta<input id="w-ver" autocomplete="off" placeholder="01:02:01:02" value="'+esc(S.ui.wver||'')+'"></label>'+vb+
      (moves.length?'<div><div class="small muted">Últimos movimientos en esta posición</div>'+moves.map(function(x){return '<div class="leg"><span>'+esc(x.fecha)+(x.ts?' '+esc(fmtHora(x.ts)):'')+' · '+esc(x.tipo)+' · '+esc(x.sku)+'<div class="small muted">Por '+esc(x.operador||'sin registrar')+'</div></span><span>'+(x.in?'+'+nf(x.in):'−'+nf(x.out))+'</span></div>';}).join('')+'</div>':'')+'</div>';}
  return plano+det;}
function wMov(){
  var w=W(),m=S.ui.m,st=wStock(),tr=m.tipo==='TRANSFERENCIA';
  var opS=w.skus.map(function(s){return '<option value="'+esc(s.codigo)+'"'+(m.sku===s.codigo?' selected':'')+'>'+esc(s.codigo+' · '+s.producto)+'</option>';}).join('');
  var opU=function(sel){return w.ubic.map(function(u){return '<option value="'+esc(u.codigo)+'"'+(sel===u.codigo?' selected':'')+'>'+esc(u.codigo)+'</option>';}).join('');};
  var opUo=function(m){if(m.tipo==='IN')return '<option value="">Elegir…</option>'+opU(m.ubi);
    if(!m.sku)return '<option value="">Elegí primero el SKU</option>';
    var l=(window.skuPosL23?window.skuPosL23(m.sku):[]);
    if(!l.length)return '<option value="">Este SKU no tiene stock en ninguna posición</option>';
    return '<option value="">Elegir… ('+l.length+(l.length===1?' posición':' posiciones')+' con stock)</option>'+l.map(function(y){return '<option value="'+esc(y[0])+'"'+(m.ubi===y[0]?' selected':'')+'>'+esc(y[0])+' ('+nf(y[1])+' u)</option>';}).join('');};
  var cur=m.sku&&m.ubi?(st.m[m.ubi+'|'+m.sku]||0):null;
  var lotes=m.sku&&m.ubi?wLotes().filter(function(l){return l.sku===m.sku&&l.ubi===m.ubi&&l.q>0;}).sort(fefo):[],sinLote=cur===null?0:cur-lotes.reduce(function(t,l){return t+l.q;},0);
  var lotF=m.tipo==='IN'?'<label>Lote (opcional)<input id="m-lot" maxlength="30" placeholder="Ej.: L2611"></label><label>Vencimiento (opcional)<input id="m-vto" type="date"></label>':'<label>Lote<select id="m-lot">'+lotes.map(function(l){return '<option value="'+esc(l.lote)+'">'+esc(l.lote+' · '+nf(l.q)+' u'+(l.vence?' · vence '+l.vence:''))+'</option>';}).join('')+(sinLote>0||!lotes.length?'<option value="">Sin lote'+(sinLote>0&&lotes.length?' · '+nf(sinLote)+' u':'')+'</option>':'')+'</select></label>';
  return '<form class="panel" id="form-mov" autocomplete="off"><h3>Registrar movimiento</h3><p class="small muted" style="margin:0">El stock nunca se edita: cada movimiento se suma al kardex. Una transferencia genera la salida y la entrada automáticamente.</p><div class="grid2">'+
   '<label>Tipo<select id="m-tipo"><option value="IN"'+(m.tipo==='IN'?' selected':'')+'>Entrada (IN)</option><option value="OUT"'+(m.tipo==='OUT'?' selected':'')+'>Salida (OUT)</option><option value="TRANSFERENCIA"'+(tr?' selected':'')+'>Transferencia</option></select></label>'+
   '<label>Fecha<input id="m-fec" type="date" required value="'+HOY+'"></label>'+
   '<label>SKU<select id="m-sku" required><option value="">Elegir…</option>'+opS+'</select></label>'+
   '<label>'+(tr?'Ubicación origen':'Ubicación')+'<select id="m-ubi" required>'+opUo(m)+'</select></label>'+
   (tr?'<label>Ubicación destino<select id="m-des" required><option value="">Elegir…</option>'+opU('')+'</select></label>':'')+
   '<label>Cantidad<input id="m-can" type="number" min="1" step="1" required></label>'+lotF+
   '<label>Operador<input id="m-ope" value="'+esc(actor())+'"></label></div>'+
   (cur!==null?'<div class="small muted">Stock actual en '+esc(m.ubi)+': <strong>'+nf(cur)+'</strong></div>':'')+
   '<div class="row"><button class="btn pri" type="submit">Registrar</button></div></form>';}
function wKardex(){
  var w=W(),f=S.ui.wfil,list=w.kardex.filter(function(x){return !f||x.sku===f;}).sort(function(a,b){return b.fecha.localeCompare(a.fecha)||b.id.localeCompare(a.id);}).slice(0,60);
  var th='style="text-align:left;color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.06em"';
  return '<div class="panel"><div class="row sp"><h3>Kardex</h3><label style="min-width:220px">SKU<select id="k-fil"><option value="">Todos</option>'+w.skus.map(function(s){return '<option value="'+esc(s.codigo)+'"'+(f===s.codigo?' selected':'')+'>'+esc(s.codigo+' · '+s.producto)+'</option>';}).join('')+'</select></label></div>'+
   '<div class="small muted">Últimos '+list.length+' movimientos de '+w.kardex.length+'.</div><div class="tablewrap"><table style="width:100%;border-collapse:collapse;font-size:14px;min-width:600px"><thead><tr '+th+'><th style="padding:6px">Fecha</th><th>Tipo</th><th>SKU</th><th>Ubicación</th><th>Entra</th><th>Sale</th><th>Operador</th></tr></thead><tbody>'+
   list.map(function(x){return '<tr style="border-top:1px solid var(--line)"><td style="padding:8px 6px">'+esc(x.fecha)+(x.ts?'<div class="small muted">'+esc(fmtHora(x.ts))+'</div>':'')+'</td><td><span class="chip '+(x.tipo==='IN'?'ok':x.tipo==='OUT'?'signal':'')+'">'+esc(x.tipo)+'</span></td><td><span class="guia">'+esc(x.sku)+'</span></td><td class="mono">'+esc(x.ubicacion)+'</td><td>'+(x.in?nf(x.in):'')+'</td><td>'+(x.out?nf(x.out):'')+'</td><td class="muted">'+esc(x.operador||'sin registrar')+'</td></tr>';}).join('')+'</tbody></table></div></div>';}
function wAbc(){
  var w=W(),dias=parseInt(S.ui.abcDias,10)||5,dates=w.kardex.map(function(x){return x.fecha;}).sort(),maxD=dates[dates.length-1]||HOY;
  var start=S.ui.abcStart||(function(){var d=new Date(maxD+'T12:00:00');d.setDate(d.getDate()-(3*dias-1));return ymd(d);})();
  var addD=function(s,n){var d=new Date(s+'T12:00:00');d.setDate(d.getDate()+n);return ymd(d);};
  var outs=w.kardex.filter(function(x){return x.tipo==='OUT';});
  var rows=w.skus.map(function(s){var mine=outs.filter(function(x){return x.sku===s.codigo;}),tot=mine.reduce(function(t,x){return t+(x.out||0);},0);
    var per=[0,1,2].map(function(i){var a=addD(start,i*dias),b=addD(start,(i+1)*dias);return mine.filter(function(x){return x.fecha>=a&&x.fecha<b;}).reduce(function(t,x){return t+(x.out||0);},0);});
    var avg=(per[0]+per[1]+per[2])/3,sd=Math.sqrt(per.reduce(function(t,x){return t+Math.pow(x-avg,2);},0)/3),cv=avg?sd/avg:0;
    return {s:s,tot:tot,per:per,cv:cv,xyz:avg===0?'Sin mov.':cv<=0.2?'X':cv<=0.5?'Y':'Z'};});
  var T=rows.reduce(function(t,r){return t+r.tot;},0);
  rows.forEach(function(r){r.pct=T?r.tot/T:0;r.rank=1+rows.filter(function(o){return o.tot>r.tot;}).length;});
  rows.forEach(function(r){r.acum=rows.filter(function(o){return o.rank<=r.rank;}).reduce(function(t,o){return t+o.pct;},0);r.abc=r.acum<=0.8?'A':r.acum<=0.95?'B':'C';});
  rows.sort(function(a,b){return a.rank-b.rank||a.s.codigo.localeCompare(b.s.codigo);});
  var cell=function(a,x){var n=rows.filter(function(r){return r.abc===a&&r.xyz===x;}).length;return '<td style="text-align:center;padding:10px;background:'+(n?'var(--ok-bg)':'transparent')+'"><strong style="font-size:20px">'+n+'</strong></td>';};
  var th='style="text-align:left;color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.06em"';
  return '<div class="panel"><h3>Matriz ABC-XYZ</h3><p class="small muted" style="margin:0">ABC: cuánto aporta cada SKU a las salidas (A hasta 80% acumulado, B hasta 95%). XYZ: qué tan estable es la demanda en 3 períodos (X: variación ≤ 20%, Y: ≤ 50%, Z: más). Las transferencias no cuentan como consumo.</p>'+
   '<div class="grid2"><label>Inicio del período 1<input id="abc-ini" type="date" value="'+esc(start)+'"></label><label>Días por período<input id="abc-dia" type="number" min="1" value="'+dias+'"></label></div>'+
   '<table style="width:100%;border-collapse:collapse;font-size:14px;max-width:420px"><thead><tr><th></th><th>X</th><th>Y</th><th>Z</th><th>Sin mov.</th></tr></thead><tbody>'+['A','B','C'].map(function(a){return '<tr style="border-top:1px solid var(--line)"><th style="padding:8px">'+a+'</th>'+['X','Y','Z','Sin mov.'].map(function(x){return cell(a,x);}).join('')+'</tr>';}).join('')+'</tbody></table></div>'+
   '<div class="panel"><div class="tablewrap"><table style="width:100%;border-collapse:collapse;font-size:14px;min-width:640px"><thead><tr '+th+'><th style="padding:6px">SKU</th><th>Producto</th><th>Salidas</th><th>% total</th><th>Acum.</th><th>ABC</th><th>P1 / P2 / P3</th><th>CV</th><th>XYZ</th></tr></thead><tbody>'+
   rows.map(function(r){return '<tr style="border-top:1px solid var(--line)"><td style="padding:8px 6px"><span class="guia">'+esc(r.s.codigo)+'</span></td><td>'+esc(r.s.producto)+'</td><td>'+nf(r.tot)+'</td><td>'+nf(r.pct*100,1)+'%</td><td>'+nf(r.acum*100,1)+'%</td><td><span class="chip '+(r.abc==='A'?'ok':r.abc==='B'?'warn':'')+'">'+r.abc+'</span></td><td class="mono">'+r.per.join(' / ')+'</td><td>'+nf(r.cv,2)+'</td><td><strong>'+esc(r.xyz)+'</strong></td></tr>';}).join('')+'</tbody></table></div></div>';}
function wMaestros(){
  var w=W(),th='style="text-align:left;color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.06em"';
  var delB=function(a,id){return S.ui.confirmDel===a+id?'<button class="btn sm bad" data-act="wdel" data-k="'+a+'" data-id="'+esc(id)+'">Confirmar</button>':'<button class="btn sm" data-act="wpedir" data-k="'+a+'" data-id="'+esc(id)+'">Quitar</button>';};
  return '<form class="panel" id="form-sku" autocomplete="off"><h3>Agregar o actualizar SKU</h3><div class="grid2">'+
   '<label>Código<input id="s-cod" required></label><label>Producto<input id="s-pro" required></label><label>Categoría<input id="s-cat"></label><label>U.M.<input id="s-um" value="UN"></label><label>Stock mínimo<input id="s-min" type="number" min="0" value="0"></label><label>Stock máximo<input id="s-max" type="number" min="0" value="0"></label><label>Ubicación principal<input id="s-ubi" list="dl-ubi" placeholder="01:01:01:00"></label><label>Depósito<input id="s-dep"></label><label>Peso por unidad (kg)<input id="s-pes" type="number" min="0" step="0.01" value="0"></label><label>Proveedor<input id="s-prov"></label><label>Plazo del proveedor (días)<input id="s-lead" type="number" min="0"></label><label>Costo por unidad ($)<input id="s-costo" type="number" min="0" step="any"></label><label>Volumen por unidad (m³)<input id="s-vol" type="number" min="0" step="any"></label><label>Stock inicial (unidades)<input id="s-ini" type="number" min="0" step="1" placeholder="0"></label></div><datalist id="dl-ubi">'+w.ubic.map(function(u){return '<option value="'+esc(u.codigo)+'">';}).join('')+'</datalist><p class="small muted">Para cargar stock ahora, completá «Stock inicial» y elegí la ubicación principal (tiene que existir en Ubicaciones). Si dejás el stock en 0, el producto queda creado sin stock y lo ingresás después por Recepción o Movimiento. Si el código ya existe, se actualizan sus datos y se conservan los que dejes vacíos.</p><div class="row"><button class="btn pri" type="submit">Guardar SKU</button></div></form>'+
   '<div class="panel"><h3>SKUs ('+w.skus.length+')</h3><div class="tablewrap"><table style="width:100%;border-collapse:collapse;font-size:14px;min-width:560px"><thead><tr '+th+'><th style="padding:6px">Código</th><th>Producto</th><th>Categoría</th><th>Mín</th><th>Máx</th><th>Kg/u</th><th></th></tr></thead><tbody>'+w.skus.map(function(s){return '<tr style="border-top:1px solid var(--line)"><td style="padding:8px 6px"><span class="guia">'+esc(s.codigo)+'</span></td><td>'+esc(s.producto)+'</td><td class="muted">'+esc(s.categoria)+'</td><td>'+nf(s.min)+'</td><td>'+nf(s.max)+'</td><td>'+(s.peso?nf(s.peso,2):'<span class="muted">—</span>')+'</td><td>'+delB('skus',s.id)+'</td></tr>';}).join('')+'</tbody></table></div></div>'+
   '<form class="panel" id="form-ubi" autocomplete="off"><h3>Agregar o actualizar ubicación</h3><div class="grid2"><label>Código (pasillo:rack:ubicación:altura)<input id="u-cod" placeholder="01:01:01:00" required inputmode="numeric"><span class="small muted">Ej.: 01:01:01:00 = pasillo 01, rack 01, ubicación 01, altura 00 (el piso). Con pisos: 01:01:01:03 = tres alturas arriba.</span></label><label>Descripción<input id="u-des"></label><label>Depósito<input id="u-dep"></label><label>Capacidad (unidades)<input id="u-cap" type="number" min="0" value="150"></label><label>Peso máximo (kg, vacío = el general)<input id="u-kg" type="number" min="0"></label></div><div class="row"><button class="btn pri" type="submit">Guardar ubicación</button></div></form>'+
   '<form class="panel" id="form-gen" autocomplete="off"><h3>Generar posiciones en lote</h3><p class="small muted" style="margin:0">Crea de una vez todas las posiciones de tu depósito. Ejemplo: 3 pasillos, 4 racks por pasillo, 5 ubicaciones por rack y 4 alturas (00 es el piso) = 240 posiciones. Las que ya existen no se tocan.</p><div class="grid2"><label>Pasillos<input id="g-pas" type="number" min="1" max="99" value="1"></label><label>Racks por pasillo<input id="g-rack" type="number" min="1" max="99" value="1"></label><label>Ubicaciones por rack<input id="g-ubi" type="number" min="1" max="99" value="1"></label><label>Alturas (incluye el piso)<input id="g-alt" type="number" min="1" max="20" value="1"></label><label>Capacidad por posición (unidades)<input id="g-cap" type="number" min="0" value="0"></label><label>Capacidad por posición (kg)<input id="g-kg" type="number" min="0" value="0"></label><label>Depósito<input id="g-dep"></label></div><div class="row"><button class="btn pri" type="submit">Generar posiciones</button></div></form>'+
   '<div class="panel"><h3>Ubicaciones ('+w.ubic.length+')</h3><div class="tablewrap"><table style="width:100%;border-collapse:collapse;font-size:14px;min-width:480px"><thead><tr '+th+'><th style="padding:6px">Código</th><th>Descripción</th><th>Depósito</th><th>Capacidad</th><th></th></tr></thead><tbody>'+w.ubic.map(function(u){return '<tr style="border-top:1px solid var(--line)"><td style="padding:8px 6px" class="mono">'+esc(u.codigo)+'</td><td>'+esc(u.descripcion)+'</td><td>'+esc(u.deposito)+'</td><td>'+nf(u.cap)+'</td><td>'+delB('ubic',u.id)+'</td></tr>';}).join('')+'</tbody></table></div></div>';}
function parseWms(buf){
  var wb=XLSX.read(buf,{type:'array',cellDates:true}),nm=function(re){var n=wb.SheetNames.filter(function(x){return re.test(x);})[0];return n?XLSX.utils.sheet_to_json(wb.Sheets[n],{header:1,raw:true,defval:null}):null;};
  var num=function(x){x=typeof x==='number'?x:parseFloat(String(x==null?'':x).replace(',','.'));return isNaN(x)?0:x;};
  var r1=nm(/maestro sku/i),r2=nm(/maestro ubicaciones/i),r3=nm(/kardex/i),out={skus:[],ubic:[],kardex:[]};
  (r1||[]).slice(4).forEach(function(r){if(r&&r[0]&&r[1]){var c=String(r[0]).trim();out.skus.push({id:c,codigo:c,producto:String(r[1]),categoria:String(r[2]||''),um:String(r[3]||'UN'),min:num(r[4]),max:num(r[5]),ubic:locCell(r[6]),deposito:String(r[7]||''),peso:num(r[8])});}});
  (r2||[]).slice(4).forEach(function(r){if(r&&r[0]){var c=locCell(r[0]);var ub={id:c,codigo:c,descripcion:String(r[4]||''),deposito:String(r[5]||''),cap:num(r[6])};if(num(r[7]))ub.capKg=num(r[7]);out.ubic.push(ub);}});
  (r3||[]).slice(4).forEach(function(r,i){if(!r||!r[1]||!r[2])return;var f=r[0],fecha=f instanceof Date?new Date(f.getTime()+12*3600e3).toISOString().slice(0,10):typeof f==='number'?new Date(Math.round((f-25569)*864e5)).toISOString().slice(0,10):String(f||'').slice(0,10);
    if(!fecha)return;out.kardex.push({id:'K'+String(i+5).padStart(6,'0'),fecha:fecha,tipo:String(r[1]).toUpperCase(),sku:String(r[2]).trim(),ubicacion:locCell(r[4]),'in':num(r[5]),out:num(r[6]),operador:String(r[7]||'')});});
  return (r1||r3)?out:null;}
async function wBulk(kinds,data){
  var jobs=[];kinds.forEach(function(k){data[k].forEach(function(o){jobs.push([k,o]);});});
  if(S.mode==='demo'){kinds.forEach(function(k){var m={};S.data.demo.wms[k].concat(data[k]).forEach(function(o){m[o.id]=o;});S.data.demo.wms[k]=Object.keys(m).map(function(i){return m[i];});});render();return jobs.length;}
  if(jobs.length>60){var by={};jobs.forEach(function(j){(by[j[0]]=by[j[0]]||[]).push({id:j[1].id,data:clean(j[1])});});
    for(var k in by){for(var i=0;i<by[k].length;i+=400){var rr=await fetch('/api/docs/bulk',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({coll:'wms/'+k+'/items',docs:by[k].slice(i,i+400)})});if(!rr.ok){var jj=await rr.json().catch(function(){return {};});throw new Error(jj.error||'No se pudo guardar');}}}
    return jobs.length;}
  for(var i=0;i<jobs.length;i+=10)await Promise.all(jobs.slice(i,i+10).map(function(j){return db.doc('wms/'+j[0]+'/items/'+j[1].id).set(clean(j[1]));}));
  return jobs.length;}
async function importWms(file){
  try{toast('Leyendo el Excel…');await loadXLSX();var d=parseWms(await file.arrayBuffer());
    if(!d||(!d.skus.length&&!d.kardex.length)){toast('No encontré las hojas WMS 1, 2 o 3.');return;}
    var malU=[];d.ubic.forEach(function(u){if(!locParse(u.codigo))malU.push(u.codigo);});d.skus.forEach(function(k){if(k.ubic&&!locParse(k.ubic))malU.push(k.ubic);});d.kardex.forEach(function(k){if(k.ubicacion&&!locParse(k.ubicacion))malU.push(k.ubicacion);});
    if(malU.length){var uq=malU.filter(function(v,i,a){return a.indexOf(v)===i;});toast('No se importó nada: hay ubicaciones sin el formato pasillo:rack:ubicación:altura (ej. 01:01:01:00): '+uq.slice(0,4).join(', ')+(uq.length>4?'…':'')+'. Si Excel las convirtió en horas, formateá la columna como Texto y cargalo de nuevo.');return;}
    var sig=function(x){return [x.fecha,x.tipo,x.sku,x.ubicacion,x['in'],x.out,x.operador].join('|');},have={},total=d.kardex.length;
    W().kardex.forEach(function(x){var k=sig(x);have[k]=(have[k]||0)+1;});
    d.kardex=d.kardex.filter(function(x){var k=sig(x);if(have[k]>0){have[k]--;return false;}return true;}).map(function(x,i){return Object.assign({},x,{id:'K'+Date.now().toString(36)+i.toString(36)+Math.random().toString(36).slice(2,6)});});
    var n=await wBulk(['skus','ubic','kardex'],d);toast(d.skus.length+' SKUs y '+d.ubic.length+' ubicaciones actualizados; '+d.kardex.length+' movimientos nuevos'+(total>d.kardex.length?' ('+(total-d.kardex.length)+' ya existían)':'')+'.');
  }catch(e){toast('No se pudo importar el archivo.');}}
/* ================= SIMULACIÓN DE PICKING ================= */
var SIMD={pick:2,vel:1.2,tl:25,tov:90,lam:20,lin:4,tur:8,spd:300,esc:'actual',aw:4,bl:3};
var simAnim={raf:0,t:0,last:0,rec:null,on:false};
function simStop(){simAnim.on=false;if(simAnim.raf)cancelAnimationFrame(simAnim.raf);simAnim.raf=0;}
function simRng(a){return function(){a|=0;a=a+0x6D2B79F5|0;var t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
function simLayout(P){
  var list=[],nq=1,nu=1;
  W().ubic.forEach(function(u){var m=locParse(u.codigo);if(m){list.push({code:u.codigo,p:m.p,r:m.r,u:m.u,q:m.a});nq=Math.max(nq,m.a+1);nu=Math.max(nu,m.u);}});
  list.forEach(function(l){l.x=l.p*P.aw;l.y=3+(l.r-1)*P.bl+((l.u-1)+(l.q+0.5)/nq)*P.bl/nu;});
  var map={};list.forEach(function(l){map[l.code]=l;});return {list:list,map:map,nq:nq};}
function simDemand(){var d={};W().kardex.forEach(function(x){if(x.tipo==='OUT')d[x.sku]=(d[x.sku]||0)+(x.out||0);});return d;}
function simPlace(lay,mode){
  var st=wStock(),dem=simDemand(),place={},skus=W().skus.map(function(k){return k.codigo;});
  if(mode==='actual'){var bestBy={},skM={};Object.keys(st.m).forEach(function(k){var pp=k.split('|'),q=st.m[k];if(q>0&&lay.map[pp[0]]){var bb=bestBy[pp[1]];if(!bb||q>bb.q)bestBy[pp[1]]={u:pp[0],q:q};}});W().skus.forEach(function(z){skM[z.codigo]=z;});
    skus.forEach(function(c){var best=bestBy[c]?bestBy[c].u:null;if(!best){var sk=skM[c];if(sk&&lay.map[sk.ubic])best=sk.ubic;}if(best)place[c]=best;});}
  else{var order=skus.slice().sort(function(a,b){return (dem[b]||0)-(dem[a]||0);}),locs=lay.list.slice().sort(function(a,b){return (a.x+a.y)-(b.x+b.y);});
    order.forEach(function(c,i){if(locs[i])place[c]=locs[i].code;});}
  return place;}
function simRoute(items,P){
  var fr=[{t:0,x:0,y:0}],cx=0,cy=0,t=0,dist=0,push=function(x,y){var d=Math.abs(x-cx)+Math.abs(y-cy);dist+=d;t+=d/P.vel;cx=x;cy=y;fr.push({t:t,x:x,y:y});};
  var go=function(x,y){if(cx!==x){if(cy!==0)push(cx,0);push(x,0);}push(x,y);};
  var xs=[];items.forEach(function(i){if(xs.indexOf(i.x)<0)xs.push(i.x);});xs.sort(function(a,b){return a-b;});
  xs.forEach(function(x){items.filter(function(i){return i.x===x;}).sort(function(a,b){return a.y-b.y;}).forEach(function(i){go(i.x,i.y);t+=P.tl;fr.push({t:t,x:cx,y:cy});});});
  go(0,0);t+=P.tov;fr.push({t:t,x:0,y:0});
  return {frames:fr,dur:t,dist:dist};}
function simRun(lay,place,P,seed,rec){
  var rng=simRng(seed),dem=simDemand(),sk=Object.keys(place).filter(function(c){return (dem[c]||0)>0;});
  if(!sk.length)sk=Object.keys(place);
  var wts=sk.map(function(c){return dem[c]||1;}),tw=wts.reduce(function(a,b){return a+b;},0);
  var draw=function(){var r=rng()*tw,i=0;for(;i<sk.length-1;i++){r-=wts[i];if(r<=0)break;}return sk[i];};
  var lamS=P.lam/3600,T=P.tur*3600,t=0,orders=[],free=[],i;
  for(i=0;i<P.pick;i++)free.push(0);
  var perPicker=[];for(i=0;i<P.pick;i++)perPicker.push([]);
  while(true){t+=-Math.log(1-rng())/lamS;if(t>T)break;
    var k=1+Math.floor(rng()*(2*P.lin-1)),got=[],tries=0;
    while(got.length<Math.min(k,sk.length)&&tries++<30){var c=draw();if(got.indexOf(c)<0)got.push(c);}
    var items=got.map(function(c){var l=lay.map[place[c]];return {x:l.x,y:l.y,sku:c};});
    var pk=0;for(i=1;i<free.length;i++)if(free[i]<free[pk])pk=i;
    var rt=simRoute(items,P),start=Math.max(t,free[pk]),end=start+rt.dur;free[pk]=end;
    var o={arr:t,start:start,end:end,wait:start-t,serv:rt.dur,dist:rt.dist,pk:pk,lines:got.length};
    if(rec){o.frames=rt.frames;perPicker[pk].push(o);}orders.push(o);}
  var n=orders.length||1,sum=function(f){return orders.reduce(function(a,o){return a+o[f];},0);};
  var late=orders.filter(function(o){return o.end>T;}).length;
  return {orders:orders,perPicker:perPicker,n:orders.length,wait:sum('wait')/n/60,serv:sum('serv')/n/60,cyc:(sum('wait')+sum('serv'))/n/60,km:sum('dist')/1000,util:Math.min(9.99,sum('serv')/(P.pick*T)),late:late,lph:orders.reduce(function(a,o){return a+o.lines;},0)/P.tur/P.pick};}
function simAvg(lay,place,P,reps){var a={n:0,wait:0,serv:0,cyc:0,km:0,util:0,late:0,lph:0},r,k;
  for(r=1;r<=reps;r++){var x=simRun(lay,place,P,r,false);for(k in a)a[k]+=x[k];}for(k in a)a[k]/=reps;return a;}
function viewSim(){
  if(!S.ui.sim)S.ui.sim=Object.assign({},SIMD);var P=S.ui.sim,h='<div class="row sp"><h2>Simulación de picking</h2></div>';
  var lay=simLayout(P);
  if(!lay.list.length||!W().skus.length)return h+'<div class="empty">Cargá primero SKUs, ubicaciones y movimientos en la pestaña Depósito.</div>';
  var pa=simPlace(lay,'actual'),pb=simPlace(lay,'slotting'),A=simAvg(lay,pa,P,20),B=simAvg(lay,pb,P,20);
  var dl=function(a,b,unit,dec,lowGood){var d=b-a,pc2=a?d/a*100:0,good=lowGood?d<0:d>0;return '<span class="chip '+(Math.abs(pc2)<1?'':good?'ok':'bad')+'">'+(d>0?'+':'')+nf(pc2,0)+'%</span>';};
  var row=function(l,a,b,dec,unit,low){return '<tr style="border-top:1px solid var(--line)"><td style="padding:8px 6px">'+l+'</td><td>'+nf(a,dec)+unit+'</td><td>'+nf(b,dec)+unit+'</td><td>'+dl(a,b,unit,dec,low)+'</td></tr>';};
  var th='style="text-align:left;color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.06em"';
  var kpi='<div class="panel"><h3>Resultado del turno ('+nf(P.tur)+' h, promedio de 20 simulaciones)</h3><div class="tablewrap"><table style="width:100%;border-collapse:collapse;font-size:14px;min-width:460px"><thead><tr '+th+'><th style="padding:6px">Indicador</th><th>Ubicación actual</th><th>Reubicando por rotación</th><th>Cambio</th></tr></thead><tbody>'+
    row('Pedidos preparados',A.n,B.n,0,'',false)+row('Tiempo de espera del pedido',A.wait,B.wait,1,' min',true)+row('Tiempo de preparación',A.serv,B.serv,1,' min',true)+row('Tiempo total (espera + preparación)',A.cyc,B.cyc,1,' min',true)+row('Distancia caminada en el turno',A.km,B.km,1,' km',true)+row('Utilización de operarios',A.util*100,B.util*100,0,'%',true)+row('Pedidos sin terminar al cierre',A.late,B.late,1,'',true)+
    '</tbody></table></div><div class="small muted">"Reubicando" pone los SKUs de mayor salida en las posiciones más cercanas a la puerta. Es el mismo conjunto de pedidos en ambos casos, así que la diferencia viene solo del layout.</div></div>';
  var escn=P.esc==='slotting'?'slotting':'actual',place=escn==='slotting'?pb:pa,dem=simDemand(),maxD=Math.max.apply(null,Object.keys(dem).map(function(k){return dem[k];}).concat([1]));
  var byLoc={};Object.keys(place).forEach(function(c){byLoc[place[c]]=c;});
  var maxP=Math.max.apply(null,lay.list.map(function(l){return l.p;})),maxY=Math.max.apply(null,lay.list.map(function(l){return l.y;}))+2,g='';
  g+='<line x1="-1" x2="'+((maxP+1)*P.aw)+'" y1="0" y2="0" style="stroke:var(--line)" stroke-width="0.3"/><text x="-1.5" y="-0.8" style="font-size:0.9px">Puerta y despacho</text>';
  for(var pp=1;pp<=maxP;pp++)g+='<line x1="'+pp*P.aw+'" x2="'+pp*P.aw+'" y1="0" y2="'+(maxY-1)+'" style="stroke:var(--line)" stroke-dasharray="0.4 0.4" stroke-width="0.15"/>';
  var hl=(P.hl||'');
  lay.list.forEach(function(l){var c=byLoc[l.code],op=c?0.15+0.85*Math.min(1,(dem[c]||0)/maxD):0,w=P.aw*0.4,hh=P.bl/lay.nq*0.9;
    g+='<rect x="'+(l.x-w-0.2)+'" y="'+(l.y-hh/2)+'" width="'+w+'" height="'+hh+'" rx="0.15" style="fill:'+(c?'var(--signal)':'var(--neutral-bg)')+';fill-opacity:'+(c?op:1)+';stroke:var(--line)" stroke-width="0.08"><title>'+esc2(l.code+(c?' · '+c+' · salidas '+(dem[c]||0):' · vacía'))+'</title></rect>'+(c?'<text x="'+(l.x-w/2-0.2)+'" y="'+(l.y+0.22)+'" text-anchor="middle" style="font-size:0.62px;fill:var(--ink)">'+esc2(c)+'</text>':'');});
  function esc2(x){return esc(x);}
  for(var q=0;q<P.pick;q++)g+='<circle id="pk-'+q+'" cx="0" cy="0" r="0.7" style="fill:var(--accent);stroke:var(--surface)" stroke-width="0.15"><title>Operario '+(q+1)+'</title></circle>';
  var vb=(-2.5)+' -3 '+((maxP+1)*P.aw+3)+' '+(maxY+4);
  var plano='<div class="panel"><div class="row sp"><h3>Plano y animación</h3><div class="row"><label>Escenario<select id="sm-esc"><option value="actual"'+(escn==='actual'?' selected':'')+'>Ubicación actual</option><option value="slotting"'+(escn==='slotting'?' selected':'')+'>Reubicando por rotación</option></select></label><label>Velocidad<select id="sm-spd"><option value="60"'+(P.spd==60?' selected':'')+'>×60</option><option value="300"'+(P.spd==300?' selected':'')+'>×300</option><option value="900"'+(P.spd==900?' selected':'')+'>×900</option></select></label></div></div>'+
    '<svg class="chart" id="sim-svg" viewBox="'+vb+'" width="100%" role="img" aria-label="Plano del depósito con operarios en movimiento" style="max-height:520px">'+g+'</svg>'+
    '<div class="row sp"><div class="row"><button class="btn pri" data-act="simplay">'+(simAnim.on?'Detener':'Reproducir turno')+'</button><span id="sim-clock" class="mono">'+simClock(simAnim.t)+'</span></div><div class="legend"><span><i style="background:var(--signal)"></i>SKU (más intenso = más salidas)</span><span><i style="background:var(--accent);border-radius:50%"></i>Operario</span></div></div><div class="small muted">Cada operario sale de la puerta, recorre los pasillos donde tiene líneas y vuelve. Las cajas muestran el SKU que hoy ocupa cada posición.</div></div>';
  var sw='',pts=[1,2,3,4,5],ya=[],yb=[],i2;
  pts.forEach(function(np){var PP=Object.assign({},P,{pick:np});ya.push(simAvg(lay,pa,PP,10).cyc);yb.push(simAvg(lay,pb,PP,10).cyc);});
  var mx=Math.max.apply(null,ya.concat(yb).concat([1])),cap=Math.max(5,1.6*Math.max.apply(null,ya.slice(1).concat(yb.slice(1)))),Wd=600,Hh=200,pl=36,pb2=26,pt=10,X=function(i){return pl+i*(Wd-pl-20)/4;},Y=function(v){return Hh-pb2-Math.min(v,cap)/cap*(Hh-pb2-pt);};
  var gg='';for(i2=0;i2<=4;i2++)gg+='<text x="'+X(i2)+'" y="'+(Hh-8)+'" text-anchor="middle">'+(i2+1)+'</text>';
  [0,0.5,1].forEach(function(f){var v=cap*f;gg+='<line x1="'+pl+'" x2="'+(Wd-20)+'" y1="'+Y(v)+'" y2="'+Y(v)+'" style="stroke:var(--line)"/><text x="'+(pl-6)+'" y="'+(Y(v)+4)+'" text-anchor="end">'+nf(v,0)+'</text>';});
  var pl2=function(arr,col,dash){return '<polyline fill="none" style="stroke:var(--'+col+')" stroke-width="2.5" '+(dash?'stroke-dasharray="6 4"':'')+' points="'+arr.map(function(v,i){return X(i)+','+Y(v);}).join(' ')+'"/>'+arr.map(function(v,i){return '<circle cx="'+X(i)+'" cy="'+Y(v)+'" r="3.5" style="fill:var(--'+col+')"><title>'+(i+1)+' operarios: '+nf(v,1)+' min</title></circle>';}).join('');};
  sw='<div class="panel"><h3>¿Cuántos operarios hacen falta?</h3><svg class="chart" viewBox="0 0 '+Wd+' '+Hh+'" width="100%" role="img" aria-label="Tiempo total por pedido según cantidad de operarios">'+gg+pl2(ya,'muted',false)+pl2(yb,'ok',true)+'</svg><div class="legend"><span><i style="background:var(--muted)"></i>Ubicación actual</span><span><i style="background:var(--ok)"></i>Reubicando por rotación</span><span>Eje vertical: minutos entre que llega el pedido y queda listo (lo que pasa del borde superior está fuera de escala: el equipo no da abasto). Eje horizontal: operarios.</span></div></div>';
  var inp=function(id,l,v,step){return '<label>'+l+'<input id="sm-'+id+'" type="number" min="0.1" step="'+step+'" value="'+v+'"></label>';};
  var par='<div class="panel"><h3>Supuestos</h3><p class="small muted" style="margin:0">Estos valores son de ejemplo. Reemplazalos con mediciones reales de tu depósito (cronometrá un picking) o los resultados no valen para decidir nada.</p><div class="grid2">'+
    inp('pick','Operarios',P.pick,1)+inp('vel','Velocidad de caminata (m/s)',P.vel,0.1)+inp('tl','Segundos por línea (buscar y sacar)',P.tl,1)+inp('tov','Segundos por pedido (preparar y dejar)',P.tov,5)+inp('lam','Pedidos que llegan por hora',P.lam,1)+inp('lin','Líneas por pedido (promedio)',P.lin,1)+inp('tur','Horas del turno',P.tur,1)+inp('aw','Distancia entre pasillos (m)',P.aw,0.5)+inp('bl','Largo de cada rack (m)',P.bl,0.5)+'</div>'+
    '<div class="small muted">Los pedidos se generan al azar con la misma proporción de salidas que tiene tu kardex: los SKUs que más salen se piden más seguido. La distancia usa el recorrido típico de ida y vuelta por cada pasillo.</div></div>';
  return h+kpi+plano+sw+par;}
function simClock(t){var m=Math.floor(t/60);return 'Turno '+pad(Math.floor(m/60))+':'+pad(m%60);}
function simPlay(){
  if(simAnim.on){simStop();render();return;}
  var P=S.ui.sim,lay=simLayout(P),pl=simPlace(lay,P.esc==='slotting'?'slotting':'actual');
  simAnim.rec=simRun(lay,pl,P,1,true);simAnim.t=0;simAnim.last=0;simAnim.on=true;
  var endT=P.tur*3600+600,sp=function(){return S.ui.sim.spd;};
  var step=function(ts){
    if(!simAnim.on)return;if(S.ui.tab!=='sim'){simStop();return;}
    if(!simAnim.last)simAnim.last=ts;simAnim.t+=(ts-simAnim.last)/1000*sp();simAnim.last=ts;
    var rec=simAnim.rec,t=simAnim.t,q;
    for(q=0;q<rec.perPicker.length;q++){var el=document.getElementById('pk-'+q);if(!el)continue;var x=0,y=0,list=rec.perPicker[q];
      for(var i=0;i<list.length;i++){var o=list[i];if(t>=o.start&&t<=o.end){var lt=t-o.start,f=o.frames,j=1;while(j<f.length-1&&f[j].t<lt)j++;var a=f[j-1],b=f[j],k=b.t>a.t?(lt-a.t)/(b.t-a.t):1;x=a.x+(b.x-a.x)*Math.min(1,Math.max(0,k));y=a.y+(b.y-a.y)*Math.min(1,Math.max(0,k));break;}}
      el.setAttribute('cx',x);el.setAttribute('cy',y);}
    var ck=document.getElementById('sim-clock');if(ck)ck.textContent=simClock(t)+' · en cola: '+rec.orders.filter(function(o){return o.arr<=t&&o.start>t;}).length;
    if(t>=endT){simStop();render();return;}
    simAnim.raf=requestAnimationFrame(step);};
  render();simAnim.raf=requestAnimationFrame(step);}
function adminTabs(){return '<div class="seg lt" role="group" aria-label="Sección">'+[['op','Operación'],['dash','Dashboard'],['viajes','Viajes'],['wms','Depósito'],['eq','Equipos y personal'],['gest','Gestión'],['sim','Simulación']].map(function(t){return '<button data-act="tab" data-v="'+t[0]+'" aria-pressed="'+(S.ui.tab===t[0])+'">'+t[1]+'</button>';}).join('')+'</div>';}
function onTime(e){
  var h=(e.historial||[]).filter(function(x){return x.estado==='entregada';}).slice(-1)[0];if(!h)return false;
  var d=new Date(h.ts),ds=ymd(d);
  return ds<e.fecha||(ds===e.fecha&&(pad(d.getHours())+':'+pad(d.getMinutes()))<=e.hasta);}
var pc=function(a,b){return b?Math.round(a/b*100)+'%':'—';};
var nf=function(n,d){return Number(n).toLocaleString('es-AR',{maximumFractionDigits:d==null?0:d});};
var fm=function(n){return n>=1e6?'$ '+nf(n/1e6,1)+' M':n>=1e4?'$ '+nf(n/1e3)+' mil':fmtARS(n);};
var KPI=function(v,l,s,c){return '<div class="kpi"><span class="l">'+l+'</span><b'+(c?' style="color:var(--'+c+')"':'')+'>'+v+'</b><span class="s">'+(s||'&nbsp;')+'</span></div>';};
function chartDias(list,from,n){
  var days=[],i;for(i=0;i<n;i++)days.push(addDays(-(n-1)+i));
  var rows=days.map(function(d){var x=list.filter(function(e){return e.fecha===d;});return {d:d,e:x.filter(function(e){return e.estado==='entregada';}).length,n:x.filter(function(e){return e.estado==='no_entregada';}).length,p:x.filter(function(e){return e.estado==='programada'||e.estado==='en_camino';}).length};});
  var max=Math.max(1,Math.max.apply(null,rows.map(function(r){return r.e+r.n+r.p;})));
  var W=600,H=190,pl=26,pb=22,pt=8,bw=Math.min(40,(W-pl)/n*0.6),step=(W-pl)/n,sc=(H-pb-pt)/max,g='';
  for(i=0;i<=max;i+=Math.max(1,Math.ceil(max/4))){var y=H-pb-i*sc;g+='<line x1="'+pl+'" x2="'+W+'" y1="'+y+'" y2="'+y+'" style="stroke:var(--line)"/><text x="'+(pl-6)+'" y="'+(y+4)+'" text-anchor="end">'+i+'</text>';}
  var every=Math.ceil(n/10);
  rows.forEach(function(r,k){var x=pl+k*step+(step-bw)/2,y=H-pb,hs=[[r.e,'ok'],[r.n,'bad'],[r.p,'neutral-bg']];
    hs.forEach(function(q){if(!q[0])return;var h=q[0]*sc;y-=h;g+='<rect x="'+x+'" y="'+y+'" width="'+bw+'" height="'+h+'" rx="2" style="fill:var(--'+q[1]+')"><title>'+esc(fmtFecha(r.d))+': '+q[0]+'</title></rect>';});
    if(k%every===0||k===n-1){var dd=r.d.split('-');g+='<text x="'+(x+bw/2)+'" y="'+(H-6)+'" text-anchor="middle">'+dd[2]+'/'+dd[1]+'</text>';}});
  return '<svg class="chart" viewBox="0 0 '+W+' '+H+'" width="100%" role="img" aria-label="Entregas por día">'+g+'</svg><div class="legend"><span><i style="background:var(--ok)"></i>Entregadas</span><span><i style="background:var(--bad)"></i>No entregadas</span><span><i style="background:var(--neutral-bg);border:1px solid var(--line)"></i>Pendientes</span></div>';}
function mapaRuta(){
  var choferes=D().perfiles.filter(function(p){return p.rol==='chofer';}),ch=S.ui.mapChofer||(choferes[0]&&choferes[0].id)||'',dia=diaStr(S.ui.mapDia)||HOY,dep=D().depot;
  var sel='<div class="row"><label>Chofer<select id="m-cho">'+choferes.map(function(c){return '<option value="'+esc(c.id)+'"'+(ch===c.id?' selected':'')+'>'+esc(c.nombre)+'</option>';}).join('')+'</select></label><label>Día<select id="m-dia"><option value="ayer"'+(S.ui.mapDia==='ayer'?' selected':'')+'>Ayer</option><option value="hoy"'+(S.ui.mapDia!=='ayer'&&S.ui.mapDia!=='manana'?' selected':'')+'>Hoy</option><option value="manana"'+(S.ui.mapDia==='manana'?' selected':'')+'>Mañana</option></select></label></div>';
  var st=D().entregas.filter(function(e){return e.choferId===ch&&e.fecha===dia&&hasXY(e);}).sort(function(a,b){return (a.orden||0)-(b.orden||0);});
  if(!st.length)return sel+'<div class="empty">Sin paradas con coordenadas para ese chofer y día.</div>';
  var opt=optimize(dep,st),all=[dep].concat(st),W=600,H=300,p=28;
  var la=all.map(function(x){return x.lat;}),ln=all.map(function(x){return x.lng;}),minLa=Math.min.apply(null,la),maxLa=Math.max.apply(null,la),minLn=Math.min.apply(null,ln),maxLn=Math.max.apply(null,ln),k=Math.cos(minLa*Math.PI/180);
  var w=Math.max((maxLn-minLn)*k,1e-4),h=Math.max(maxLa-minLa,1e-4),sc=Math.min((W-2*p)/w,(H-2*p)/h),ox=(W-w*sc)/2,oy=(H-h*sc)/2;
  var X=function(x){return ox+(x.lng-minLn)*k*sc;},Y=function(x){return oy+(maxLa-x.lat)*sc;};
  var line=function(arr){return arr.map(function(x){return X(x).toFixed(1)+','+Y(x).toFixed(1);}).join(' ');};
  var cur=pathKm(dep,st),best=pathKm(dep,opt),g='<rect width="'+W+'" height="'+H+'" rx="8" style="fill:var(--surface2)"/>';
  g+='<polyline points="'+line([dep].concat(st))+'" fill="none" style="stroke:var(--muted)" stroke-width="2.5"/>';
  if(best<cur-0.3)g+='<polyline points="'+line([dep].concat(opt))+'" fill="none" style="stroke:var(--ok)" stroke-width="2.5" stroke-dasharray="7 5"/>';
  g+='<rect x="'+(X(dep)-8)+'" y="'+(Y(dep)-8)+'" width="16" height="16" rx="3" style="fill:var(--head)"/><text x="'+X(dep)+'" y="'+(Y(dep)+24)+'" text-anchor="middle" dy="-16">Depósito</text>';
  var col={entregada:'ok',en_camino:'signal',no_entregada:'bad',programada:'head'};
  st.forEach(function(e,i){g+='<circle cx="'+X(e)+'" cy="'+Y(e)+'" r="13" style="fill:var(--'+col[e.estado]+')"><title>'+esc(e.cliente+' · '+EST[e.estado][0])+'</title></circle><text x="'+X(e)+'" y="'+(Y(e)+4)+'" text-anchor="middle" style="fill:#fff;font-weight:700;font-size:12px">'+(i+1)+'</text>';});
  return sel+'<svg class="chart" viewBox="0 0 '+W+' '+H+'" width="100%" role="img" aria-label="Mapa esquemático de la ruta">'+g+'</svg>'+
    '<div class="legend"><span><i style="background:var(--muted)"></i>Orden actual · ~'+cur.toFixed(0)+' km</span>'+(best<cur-0.3?'<span><i style="background:var(--ok)"></i>Orden sugerido · ~'+best.toFixed(0)+' km (−'+(cur-best).toFixed(0)+' km)</span>':'<span>Orden ya eficiente</span>')+'</div><div class="small muted">Mapa esquemático: ubica las paradas por coordenadas, sin calles. Sirve para ver el recorrido y los cruces.</div>';}
function viewDash(){
  var n=parseInt(S.ui.periodo,10)||7,from=addDays(-(n-1)),dep=D().depot,fu=S.fuel;
  var list=D().entregas.filter(function(e){return e.fecha>=from&&e.fecha<=HOY;});
  var ent=list.filter(function(e){return e.estado==='entregada';}),noe=list.filter(function(e){return e.estado==='no_entregada';}),cerr=ent.length+noe.length,ot=ent.filter(onTime).length;
  var groups={},drv={};
  list.forEach(function(e){if(!e.choferId)return;var k=e.choferId+'|'+e.fecha;(groups[k]=groups[k]||[]).push(e);
    var d=drv[e.choferId]=drv[e.choferId]||{n:e.chofer||e.choferId,ent:0,noe:0,ok:0,tot:0,act:0,rutas:0};
    d.tot++;if(e.estado==='entregada'){d.ent++;if(onTime(e))d.ok++;}if(e.estado==='no_entregada')d.noe++;});
  var kmA=0,kmO=0;
  Object.keys(groups).forEach(function(k){var st=groups[k].slice().sort(function(a,b){return (a.orden||0)-(b.orden||0);}).filter(hasXY),a=pathKm(dep,st),o=Math.min(a,pathKm(dep,optimize(dep,st)));kmA+=a;kmO+=o;var d=drv[k.split('|')[0]];d.act+=a;d.rutas++;});
  var lit=kmA*fu.consumo/100,costo=lit*fu.precio,aho=kmA-kmO,ahoC=aho*fu.consumo/100*fu.precio;
  var todas=D().entregas,pend=todas.filter(function(e){return e.factura&&e.factura.estado==='emitida';}),venc=todas.filter(facturaVencida);
  var sum=function(a){return a.reduce(function(t,e){return t+(e.factura.importe||0);},0);};
  var mot={};noe.forEach(function(e){(e.observaciones||[]).forEach(function(o){var m=String(o.texto).match(/^No entregada: (.*)\.$/);if(m)mot[m[1]]=(mot[m[1]]||0)+1;});});
  var motK=Object.keys(mot).sort(function(a,b){return mot[b]-mot[a];}),motMax=motK.length?mot[motK[0]]:1;
  var drvs=Object.keys(drv).map(function(k){return drv[k];}).sort(function(a,b){return b.ent-a.ent;});
  var out='<div class="row sp"><h2>Dashboard</h2><label style="min-width:160px">Período<select id="p-per"><option value="1"'+(n===1?' selected':'')+'>Hoy</option><option value="7"'+(n===7?' selected':'')+'>Últimos 7 días</option><option value="30"'+(n===30?' selected':'')+'>Últimos 30 días</option></select></label></div>';
  if(!list.length)return out+'<div class="empty">No hay entregas en este período.</div>';
  out+='<div class="kpis">'+
    KPI(list.length,'Entregas',ent.length+' hechas · '+(list.length-cerr)+' pendientes')+
    KPI(pc(ent.length,cerr),'Efectividad',noe.length+' no entregadas','ok')+
    KPI(pc(ot,ent.length),'A tiempo','dentro de la ventana pactada')+
    KPI(nf(kmA)+' km','Recorrido estimado',Object.keys(groups).length+' rutas')+
    KPI(nf(aho)+' km','Ahorro con ruta eficiente',pc(aho,kmA)+' menos km','ok')+
    KPI(nf(lit)+' L','Combustible estimado','a '+nf(fu.consumo,1)+' L/100 km')+
    KPI(fm(costo),'Costo de combustible',cerr?fmtARS(costo/Math.max(1,list.length))+' por entrega':'')+
    KPI(fm(ahoC),'Ahorro posible','por reordenar las rutas','ok')+
    KPI(fm(sum(venc)),'Facturas vencidas',venc.length+' facturas',venc.length?'bad':'')+
    KPI(fm(sum(pend)),'Por cobrar',pend.length+' facturas emitidas')+
  '</div>';
  out+='<div class="panel"><h3>Entregas por día</h3>'+chartDias(list,from,n)+'</div>';
  out+='<div class="panel"><h3>Recorrido de un chofer</h3>'+mapaRuta()+'</div>';
  out+='<div class="panel"><h3>Choferes</h3><div class="tablewrap"><table style="width:100%;border-collapse:collapse;font-size:14px;min-width:560px"><thead><tr style="text-align:left;color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.06em"><th style="padding:6px">Chofer</th><th>Rutas</th><th>Entregas</th><th>Efectividad</th><th>A tiempo</th><th>Km est.</th><th>Km / entrega</th></tr></thead><tbody>'+
    drvs.map(function(d){var cc=d.ent+d.noe,ef=cc?d.ent/cc*100:0;return '<tr style="border-top:1px solid var(--line)"><td style="padding:8px 6px"><strong>'+esc(d.n)+'</strong></td><td>'+d.rutas+'</td><td>'+d.ent+' / '+d.tot+'</td><td><div class="row" style="flex-wrap:nowrap"><div class="bar" style="flex:1"><i style="width:'+ef.toFixed(0)+'%"></i></div><span>'+pc(d.ent,cc)+'</span></div></td><td>'+pc(d.ok,d.ent)+'</td><td>'+nf(d.act)+'</td><td>'+(d.tot?nf(d.act/d.tot,1):'—')+'</td></tr>';}).join('')+
    '</tbody></table></div></div>';
  if(motK.length)out+='<div class="panel"><h3>Por qué no se entregó</h3>'+motK.map(function(m){return '<div class="row" style="flex-wrap:nowrap"><span style="width:180px;flex:none">'+esc(m)+'</span><div class="bar" style="flex:1"><i style="width:'+(mot[m]/motMax*100)+'%;background:var(--bad)"></i></div><strong>'+mot[m]+'</strong></div>';}).join('')+'</div>';
  out+='<div class="panel"><h3>Combustible</h3><p class="small muted" style="margin:0">Por ahora es una estimación: kilómetros de las rutas × consumo × precio. Ajustá los valores a tu flota. El siguiente paso es medirlo de verdad: carga de litros y odómetro por chofer y viaje, para ver consumo real por vehículo, costo por entrega y desvíos.</p><div class="grid2"><label>Consumo (litros cada 100 km)<input id="fu-con" type="number" min="1" step="0.5" value="'+esc(fu.consumo)+'"></label><label>Precio por litro (ARS)<input id="fu-pre" type="number" min="1" step="10" value="'+esc(fu.precio)+'"></label></div></div>';
  return out;
}
function diaList(dia){var f=diaStr(dia);return D().entregas.filter(function(e){return !f||e.fecha===f;});}
function viewEq(){var st=S.ui.eqsub||'equipos';return '<div class="seg lt" role="group" aria-label="Equipos y personal">'+[['equipos','Equipos'],['historial','Check lists'],['personal','Fichas']].map(function(t){return '<button data-act="eqsub" data-v="'+t[0]+'" aria-pressed="'+(st===t[0])+'">'+t[1]+'</button>';}).join('')+'</div>'+(st==='historial'?viewHistorial():st==='personal'?viewPersonal():viewEquipos());}
function viewAdmin(){return adminTabs()+eqBanner()+(S.ui.tab==='eq'?viewEq():S.ui.tab==='dash'?viewDash():S.ui.tab==='viajes'?viewViajes():S.ui.tab==='wms'?viewWms():S.ui.tab==='gest'?viewGest():S.ui.tab==='sim'?viewSim():viewOps());}
function viewOps(){
  var dia=S.ui.dia,chof=S.ui.chofer,perf=D().perfiles;
  var list=diaList(dia).filter(function(e){return !chof||e.choferId===chof;}).sort(function(a,b){return (a.fecha+(a.choferId||'')+String(1000+(a.orden||0))).localeCompare(b.fecha+(b.choferId||'')+String(1000+(b.orden||0)));});
  var cnt=function(s){return list.filter(function(e){return e.estado===s;}).length;};
  var choferes=perf.filter(function(p){return p.rol==='chofer';});
  var cerr27=list.filter(function(e){return e.estado==='entregada'||e.estado==='no_entregada';}).length,listV=S.ui.verHechas?list:list.filter(function(e){return e.estado!=='entregada'&&e.estado!=='no_entregada';});
  var out='<div class="row sp"><h2>Administración</h2><button class="btn pri" data-act="nuevo">Nueva entrega</button></div>'+
   '<div class="tiles"><div class="tile"><b>'+list.length+'</b><span>Entregas</span></div><div class="tile"><b>'+cnt('programada')+'</b><span>Programadas</span></div><div class="tile"><b style="color:var(--signal)">'+cnt('en_camino')+'</b><span>En camino</span></div><div class="tile"><b style="color:var(--ok)">'+cnt('entregada')+'</b><span>Entregadas</span></div><div class="tile"><b style="color:var(--bad)">'+cnt('no_entregada')+'</b><span>No entregadas</span></div></div>';
  if(S.mode==='live'&&!D().entregas.length&&!S.ui.formOpen)out+='<div class="banner info">'+ICON.bell+'<div><strong>Todavía no hay entregas cargadas</strong>Cargá primero a tus clientes y choferes en "Usuarios", y después la primera entrega. '+(esInvitado()?'':'Si querés ver cómo queda, abrí la demostración.<div style="margin-top:8px"><button class="btn sm" data-act="modo" data-v="demo">Ver demostración con datos de ejemplo</button></div>')+'</div></div>';
  if(S.ui.formOpen)out+=formEntrega();
  out+='<div class="panel"><div class="row">'+
    '<label>Día<select id="f-dia" data-act="fdia"><option value="ayer"'+(dia==='ayer'?' selected':'')+'>Ayer</option><option value="hoy"'+(dia==='hoy'?' selected':'')+'>Hoy</option><option value="manana"'+(dia==='manana'?' selected':'')+'>Mañana</option><option value="todos"'+(dia==='todos'?' selected':'')+'>Todos</option></select></label>'+
    '<label>Chofer<select id="f-chof" data-act="fchof"><option value="">Todos</option>'+choferes.map(function(c){return '<option value="'+esc(c.id)+'"'+(chof===c.id?' selected':'')+'>'+esc(c.nombre)+'</option>';}).join('')+'</select></label></div>'+
    (cerr27?'<div class="row sp" style="margin:6px 0"><span class="small muted">'+(S.ui.verHechas?'Mostrando todas':'Mostrando '+listV.length+' pendientes')+' · '+cerr27+' ya cerradas</span><button class="btn sm" data-act="x27-hechas">'+(S.ui.verHechas?'Ocultar cerradas':'Ver cerradas')+'</button></div>':'')+'<div class="tablewrap"><table style="width:100%;border-collapse:collapse;font-size:14px;min-width:720px"><thead><tr style="text-align:left;color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.06em"><th style="padding:6px">Guía</th><th>Cliente</th><th>Fecha y ventana</th><th>Chofer</th><th>Estado</th><th>Factura</th><th></th></tr></thead><tbody>'+
    (listV.length?listV.map(function(e){return '<tr style="border-top:1px solid var(--line)"><td style="padding:8px 6px"><span class="guia">'+esc(e.guia)+'</span></td><td><strong>'+esc(e.cliente)+'</strong><div class="small muted">'+esc(e.direccion)+'</div></td><td>'+esc(fmtFecha(e.fecha))+'<div class="small muted">'+esc(ventana(e))+'</div></td><td>'+esc(e.chofer||'Sin asignar')+(e.orden?'<div class="small muted">Parada '+e.orden+'</div>':'')+'</td><td>'+chipEstado(e)+'</td><td>'+(e.factura&&e.factura.numero?esc(FACT[e.factura.estado]||'')+'<div>'+pdfBtn(e,'factura')+'</div>':'<span class="muted">—</span>')+(facturaVencida(e)?' <span class="chip bad">Vencida</span>':'')+'</td><td style="white-space:nowrap">'+waBtn(e)+'<button class="btn sm" data-act="editar" data-id="'+esc(e.id)+'">Editar</button> '+(S.ui.confirmDel===e.id?'<button class="btn sm bad" data-act="borrar" data-id="'+esc(e.id)+'">Confirmar</button>':'<button class="btn sm" data-act="pedirBorrar" data-id="'+esc(e.id)+'">Eliminar</button>')+'</td></tr>';}).join(''):'<tr><td colspan="7" style="padding:18px;text-align:center" class="muted">No hay entregas para este filtro.</td></tr>')+
    '</tbody></table></div></div>';
  out+=panelPods()+panelTrafico()+panelOptimizar(choferes)+panelVentanas()+panelFlota();
  if(S.mode==='live')out+=panelUsuarios();
  return out;
}
function formEntrega(){
  var e=S.ui.edit||{},clientes=D().perfiles.filter(function(p){return p.rol==='cliente';}),choferes=D().perfiles.filter(function(p){return p.rol==='chofer';});
  var opt=function(list,sel){return list.map(function(p){return '<option value="'+esc(p.id)+'"'+(sel===p.id?' selected':'')+'>'+esc(p.nombre)+'</option>';}).join('');};
  var r=e.remito||{},f=e.factura||{};
  var maxN=D().entregas.reduce(function(m,x){var n=parseInt(String(x.guia||'').replace(/\D/g,''),10);return isNaN(n)?m:Math.max(m,n);},4800);
  return '<form class="panel" id="form-ent" autocomplete="off"><h3>'+(e.id?'Editar entrega':'Nueva entrega')+'</h3><div class="grid2">'+
   '<label>Guía<input id="x-guia" required value="'+esc(e.guia||'G-'+(maxN+1))+'"></label>'+
   '<label>Cliente<select id="x-cli" required '+(e.id?'disabled':'')+'><option value="">Elegir…</option>'+opt(clientes,e.clienteId)+'</select></label>'+
   '<label>Chofer<select id="x-cho"><option value="">Sin asignar</option>'+opt(choferes,e.choferId)+'</select></label>'+
   '<label>Fecha pactada<input id="x-fec" type="date" required value="'+esc(e.fecha||HOY)+'"></label>'+
   '<label>Desde<input id="x-des" type="time" required value="'+esc(e.desde||'09:00')+'"></label>'+
   '<label>Hasta<input id="x-has" type="time" required value="'+esc(e.hasta||'12:00')+'"></label>'+
   '<label style="grid-column:1/-1">Dirección de entrega<input id="x-dir" required value="'+esc(e.direccion||'')+'"></label>'+
   '<label>Coordenadas (pegá lat, lng desde un mapa)<input id="x-xy" placeholder="-34.7064, -58.3922" value="'+(hasXY(e)?esc(e.lat+', '+e.lng):'')+'"></label>'+
   '<label>Bultos<input id="x-bul" type="number" min="1" value="'+esc(e.bultos||1)+'"></label>'+'<label>Peso total (kg)<input id="x-peso" type="number" min="0" step="any" value="'+esc(e.pesoKg||'')+'"></label>'+
   '<label>N.º de remito<input id="x-rem" value="'+esc(r.numero||'')+'"></label>'+
   '<label>N.º de factura<input id="x-fac" value="'+esc(f.numero||'')+'"></label>'+
   '<label>Importe factura (ARS)<input id="x-imp" type="number" min="0" value="'+esc(f.importe||'')+'"></label>'+
   '<label>Estado de factura<select id="x-fes"><option value="pendiente"'+(f.estado==='pendiente'?' selected':'')+'>Sin facturar</option><option value="emitida"'+(f.estado==='emitida'?' selected':'')+'>Emitida</option><option value="pagada"'+(f.estado==='pagada'?' selected':'')+'>Pagada</option></select></label>'+
   '<label>Vencimiento factura<input id="x-ven" type="date" value="'+esc(f.vence||'')+'"></label>'+
   (assets&&S.mode==='live'?'<label>PDF del remito<input id="x-prem" type="file" accept="application/pdf"></label><label>PDF de la factura<input id="x-pfac" type="file" accept="application/pdf"></label>':'')+
   '</div><div class="row"><button class="btn pri" type="submit">Guardar entrega</button><button class="btn" type="button" data-act="cancelar">Cancelar</button></div></form>';
}
function panelOptimizar(choferes){
  var ch=S.ui.optChofer||(choferes[0]&&choferes[0].id)||'',dia=diaStr(S.ui.optDia==='manana'?'manana':'hoy');
  var sel='<div class="row"><label>Chofer<select id="o-cho" data-act="ocho">'+choferes.map(function(c){return '<option value="'+esc(c.id)+'"'+(ch===c.id?' selected':'')+'>'+esc(c.nombre)+'</option>';}).join('')+'</select></label>'+
    '<label>Día<select id="o-dia" data-act="odia"><option value="hoy"'+(S.ui.optDia!=='manana'?' selected':'')+'>Hoy</option><option value="manana"'+(S.ui.optDia==='manana'?' selected':'')+'>Mañana</option></select></label></div>';
  var route=D().entregas.filter(function(e){return e.choferId===ch&&e.fecha===dia;}).sort(function(a,b){return (a.orden||0)-(b.orden||0);});
  var dep=D().depot;
  var locked=[];for(var i=0;i<route.length;i++){var s=route[i];if(s.estado==='entregada'||s.estado==='no_entregada'||s.estado==='en_camino')locked.push(s);else break;}
  var free=route.filter(function(e){return locked.indexOf(e)<0;}),freeXY=free.filter(hasXY),freeNo=free.filter(function(e){return !hasXY(e);});
  var lastLocked=locked.filter(hasXY).slice(-1)[0],start=lastLocked||dep;
  var best=optimize(start,freeXY),nuevo=best.concat(freeNo);
  var kmAct=pathKm(start,freeXY),kmOpt=pathKm(start,best),ahorro=kmAct-kmOpt,pct=kmAct>0?ahorro/kmAct*100:0;
  var changed=nuevo.some(function(e,i){return free[i]&&free[i].id!==e.id;});
  var body=!route.length?'<div class="empty">Ese chofer no tiene paradas para ese día.</div>':
    '<div class="grid2"><div class="tile"><b>'+kmAct.toFixed(0)+' km</b><span>Orden actual (estimado)</span></div><div class="tile"><b style="color:var(--ok)">'+kmOpt.toFixed(0)+' km</b><span>Orden sugerido</span></div><div class="tile"><b>'+(ahorro>0.5?'−'+ahorro.toFixed(0)+' km':'0 km')+'</b><span>'+(ahorro>0.5?'Ahorro '+pct.toFixed(0)+'%':'Ya está ordenada')+'</span></div></div>'+
    '<div>'+locked.map(function(e,i){return '<div class="leg"><span>'+(i+1)+'. '+esc(e.cliente)+'</span><span class="muted small">'+esc(EST[e.estado][0])+' · fija</span></div>';}).join('')+
      nuevo.map(function(e,i){return '<div class="leg"><span><strong>'+(locked.length+i+1)+'.</strong> '+esc(e.cliente)+' <span class="muted small">'+esc(e.direccion)+'</span></span><span class="muted small">'+esc(ventana(e))+'</span></div>';}).join('')+'</div>'+
    '<div class="row"><button class="btn pri" data-act="aplicarOrden" '+(changed?'':'disabled')+'>Aplicar orden sugerido</button><span class="small muted">Distancias en línea recta × 1,3 (factor urbano). No considera ventanas horarias ni tránsito en vivo.</span></div>';
  return '<div class="panel"><h3>Ruta eficiente</h3><p class="small muted" style="margin:0">Waze abre una parada por vez, así que ordenamos las paradas primero y el chofer navega a la siguiente con un toque. Las entregas ya hechas o en camino quedan fijas.</p>'+sel+body+
    (S.mode==='live'?'<div class="row"><label style="flex:1;min-width:200px">Depósito (lat, lng)<input id="dep-xy" value="'+esc(dep.lat+', '+dep.lng)+'"></label><button class="btn sm" data-act="guardarDeposito">Guardar depósito</button></div>':'<div class="small muted">Punto de partida: '+esc(dep.nombre)+'.</div>')+'</div>';
}
function panelUsuarios(){
  var all=S.users||[],rs=S.ui.resetId,fil=S.ui.ufil||'',uq=String(S.ui.uq||'').trim().toLowerCase(),lim=S.ui.ulim||25;
  var us0=all.filter(function(u){return (!fil||u.role===fil)&&(!uq||(String(u.name||'')+' '+String(u.email||'')).toLowerCase().indexOf(uq)>=0);}),us=us0.slice(0,lim);
  var cn=function(r){return all.filter(function(u){return !r||u.role===r;}).length;};
  var bar28='<div class="seg lt" role="group" aria-label="Tipo de usuario" style="margin:8px 0">'+[['','👥 Todos'],['cliente','🤝 Clientes'],['chofer','🚐 Choferes'],['deposito','🏭 Operarios'],['admin','🧑‍💼 Administración']].map(function(t){return '<button data-act="x28-ufil" data-v="'+t[0]+'" aria-pressed="'+(fil===t[0])+'">'+t[1]+' ('+cn(t[0])+')</button>';}).join('')+'</div>'+
    '<label style="margin-bottom:8px">Buscar por nombre o correo<input id="x28-uq" type="search" placeholder="Escribí para buscar…" value="'+esc(S.ui.uq||'')+'"></label>'+
    '<div class="small muted" style="margin-bottom:4px">Mostrando '+us.length+' de '+us0.length+(us0.length!==all.length?' (filtrado de '+all.length+')':'')+'</div>';
  return '<div class="panel"><h3>Usuarios</h3><p class="small muted" style="margin:0">Cada persona entra con su correo y contraseña. Creá una cuenta por cliente, chofer y operario de depósito: el cliente solo ve sus propias entregas, el chofer solo las que tiene asignadas y el operario solo equipos y check lists.</p>'+
   bar28+'<div>'+(us.length?us.map(function(u){return '<div class="leg" style="flex-wrap:wrap"><span><strong>'+esc(u.name)+'</strong> <span class="chip '+(u.role==='chofer'||u.role==='deposito'?'signal':'')+'">'+esc(u.role==='admin'?'administración':u.role)+'</span> <span class="muted small">'+esc(u.email)+'</span></span><span class="row"><button class="btn sm" data-act="uclave" data-id="'+esc(u.id)+'">Nueva clave</button>'+(u.id===S.me.id?'':'<button class="btn sm bad" data-act="uquitar" data-id="'+esc(u.id)+'">'+(S.ui.confirmDel==='u'+u.id?'Confirmar':'Quitar')+'</button>')+'</span>'+
      (rs===u.id?'<div class="row" style="width:100%"><label style="flex:1;min-width:200px">Nueva contraseña (mínimo 10 caracteres)<input id="u-newpass" type="text" autocomplete="off"></label><button class="btn pri sm" data-act="uguardar" data-id="'+esc(u.id)+'">Guardar</button></div>':'')+'</div>';}).join(''):'<div class="empty">'+(all.length?'Ningún usuario coincide con el filtro.':'Todavía no hay usuarios.')+'</div>')+(us0.length>us.length?'<button class="btn" style="width:100%;margin-top:8px" data-act="x28-umas">Ver más ('+(us0.length-us.length)+' restantes)</button>':'')+'</div>'+
   '<form id="form-user" autocomplete="off"><h3 style="margin:6px 0">Crear usuario</h3><div class="grid2"><label>Nombre (empresa o chofer)<input id="n-nom" required maxlength="120"></label><label>Correo<input id="n-mail" type="email" required></label><label>Rol<select id="n-rol"><option value="cliente">Cliente</option><option value="chofer">Chofer</option><option value="deposito">Depósito (operario)</option><option value="admin">Administración</option></select></label><label>Contraseña inicial (mínimo 10 caracteres)<input id="n-pas" type="text" minlength="10" required autocomplete="off"></label></div><div class="row"><button class="btn pri" type="submit">Crear usuario</button></div></form>'+auditPanel()+'</div>';
}
var AUD={ingreso:'Ingresó',ingreso_fallido:'Ingreso fallido',usuario_creado:'Usuario creado',usuario_borrado:'Usuario borrado',usuario_activado:'Usuario activado',usuario_desactivado:'Usuario desactivado',clave_cambiada:'Clave cambiada',cambio_rol:'Cambio de rol',borrado:'Borrado',correo_enviado:'Correo enviado',correo_fallido:'Correo fallido'};
function auditPanel(){
  if(!S.audit)return '<div class="row"><button class="btn sm" data-act="auditver">Ver registro de actividad</button></div>';
  return '<h3 style="margin:6px 0">Registro de actividad</h3><div class="tablewrap"><table style="width:100%;border-collapse:collapse;font-size:13px;min-width:560px"><thead><tr style="text-align:left;color:var(--muted)"><th>Cuándo</th><th>Quién</th><th>Qué</th><th>Detalle</th></tr></thead><tbody>'+S.audit.slice(0,100).map(function(x){return '<tr style="border-top:1px solid var(--line)"><td>'+esc(fmtFecha(String(x.ts).slice(0,10)))+' '+esc(fmtHora(x.ts))+'</td><td>'+esc(x.user_name||'—')+'</td><td>'+esc(AUD[x.action]||x.action)+'</td><td class="muted">'+esc(x.detail||'')+'</td></tr>';}).join('')+'</tbody></table></div><div class="row"><button class="btn sm" data-act="auditver">Actualizar</button><button class="btn sm" data-act="auditocultar">Ocultar</button></div>';}
function loadUsers(){return fetch('/api/users',{credentials:'same-origin'}).then(function(r){return r.ok?r.json():[];}).then(function(u){S.users=u;render();}).catch(function(){});}
function apiJson(method,url,body){return fetch(url,{method:method,credentials:'same-origin',headers:{'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body)}).then(function(r){return r.json().catch(function(){return {};}).then(function(j){if(!r.ok)throw new Error(j.error||('Error '+r.status));return j;});});}
/* ---------- equipos, check lists y personal ---------- */
var fechaHora=function(ts){var d=new Date(ts);return fmtFecha(ymd(d))+' '+fmtHora(ts);};
var dmy=function(v){return String(v||'').split('-').reverse().join('/');};
function vencChip(v,nom){
  if(!v)return '';var n=dleft(v),c=n<0?'bad':n<=30?'warn':'ok';
  var t=n<0?'vencido hace '+(-n)+' d':n===0?'vence hoy':n<=30?'vence en '+n+' d':'hasta '+dmy(v);
  return '<span class="chip '+c+'">'+esc(nom)+': '+esc(t)+'</span>';}
function ultimoCheck(id){var best=null;(D().checks||[]).forEach(function(c){if(c.equipoId===id&&(!best||c.ts>best.ts))best=c;});return best;}
function estadoEq(eq){
  var l=ultimoCheck(eq.id);
  if(!l)return {k:'sin',hoy:false,l:null,chip:'<span class="chip">Sin check list</span>'};
  var hoy=l.fecha===HOY,k=l.resultado;
  var chip=k==='fuera'?'<span class="chip bad">Fuera de servicio</span>':k==='obs'?'<span class="chip warn">Con observaciones</span>':hoy?'<span class="chip ok">En condiciones</span>':'<span class="chip">Sin check hoy</span>';
  return {k:k,hoy:hoy,l:l,chip:chip};}
var docsVenc=function(list){return (list||[]).filter(function(d){var n=dleft(d.vence);return n!=null&&n<0;});};
var docsPorVencer=function(list){return (list||[]).filter(function(d){var n=dleft(d.vence);return n!=null&&n>=0&&n<=30;});};
function persVenc(p){var l=(p.hab||[]).slice();if(p.licVence)l.push({nombre:'Licencia',vence:p.licVence});return l;}
function eqCard(eq,admin){
  var st=estadoEq(eq),l=st.l,tpl=tplDe(eq.tipo),asi=eq.asignado?D().perfiles.find(function(p){return p.id===eq.asignado;}):null;
  var det=[eq.marca,eq.anio,eq.cap?nf(eq.cap)+' kg':'',eq.energia].filter(Boolean).join(' · ');
  var fal=l&&l.fallas&&l.fallas.length?'<div class="obs">'+l.fallas.map(function(f){return '<div>'+(f.crit?'<strong>Crítico · </strong>':'')+esc(f.texto)+' <span class="muted">('+(f.v==='mal'?'mal':'con observación')+')</span></div>';}).join('')+(l.nota?'<div>'+esc(l.nota)+'<small>'+esc(l.por)+' · '+esc(fechaHora(l.ts))+'</small></div>':'')+'</div>':'';
  var acts='<div class="row"><button class="btn pri sm" data-act="chkabrir" data-id="'+esc(eq.id)+'">Hacer check list</button>';
  if(admin){acts+='<button class="btn sm" data-act="eqedit" data-id="'+esc(eq.id)+'">Editar</button>';
    acts+=S.ui.confirmDel==='eq'+eq.id?'<button class="btn sm bad" data-act="eqdel" data-id="'+esc(eq.id)+'">Confirmar: quitar equipo</button><button class="btn sm" data-act="cancelar">No</button>':'<button class="btn sm bad" data-act="eqpedir" data-id="'+esc(eq.id)+'">Quitar</button>';}
  acts+='</div>';
  return '<article class="card"><div class="row sp"><div style="min-width:0"><strong>'+esc(eq.nombre)+'</strong> <span class="muted small">'+esc(TIPOS[eq.tipo]?TIPOS[eq.tipo][0]:eq.tipo)+(eq.ident?' · '+esc(eq.ident):'')+'</span></div>'+st.chip+'</div>'+
    (det?'<div class="small muted">'+esc(det)+(asi?' · Asignado a '+esc(asi.nombre):'')+'</div>':'')+
    (l?'<div class="small">Último check: '+esc(fechaHora(l.ts))+' · '+esc(l.por)+(l.lect!==''&&l.lect!=null?' · '+esc(tpl.lect)+': '+nf(l.lect):'')+'</div>':'<div class="small muted">Todavía no se hizo ningún check list.</div>')+
    fal+((eq.docs||[]).length?'<div class="chips">'+eq.docs.map(function(d){return vencChip(d.vence,d.nombre);}).join('')+'</div>':'')+acts+'</article>';}
function viewCheck(){
  var c=S.ui.chk;if(!c)return '';
  var eq=(D().equipos||[]).find(function(e){return e.id===c.eq;});if(!eq)return '';
  var tpl=tplDe(eq.tipo),answered=tpl.items.filter(function(it){return c.items[it[0]];}).length,all=answered===tpl.items.length;
  var grupos=[],porG={};tpl.items.forEach(function(it){if(!porG[it[1]]){porG[it[1]]=[];grupos.push(it[1]);}porG[it[1]].push(it);});
  var body=grupos.map(function(g){return '<h3 style="font-size:17px;margin-top:6px">'+esc(g)+'</h3>'+porG[g].map(function(it){
    return '<div class="chk-it"><div class="chk-t">'+esc(it[2])+(it[3]?' <span class="chip bad">Crítico</span>':'')+'</div><div class="chkseg" role="group" aria-label="'+esc(it[2])+'">'+
      [['ok','Bien'],['obs','Observación'],['mal','Mal']].map(function(o){return '<button type="button" data-act="chkset" data-id="'+it[0]+'" data-v="'+o[0]+'" aria-pressed="'+(c.items[it[0]]===o[0])+'">'+o[1]+'</button>';}).join('')+'</div></div>';}).join('');}).join('');
  var res=all?chkResultado(tpl,c.items):null;
  var ban=res==='fuera'?'<div class="banner bad" role="status">'+ICON.alert+'<div><strong>Falla crítica</strong>El equipo quedará marcado como fuera de servicio y administración lo verá en su panel. No lo uses hasta que se corrija y se haga un nuevo check list.</div></div>':
    res==='obs'?'<div class="banner warn" role="status">'+ICON.alert+'<div><strong>Con observaciones</strong>Se puede usar, pero quedan registradas para que mantenimiento las revise.</div></div>':
    res==='ok'?'<div class="banner ok" role="status">'+ICON.check+'<div><strong>Todo en condiciones</strong></div></div>':'';
  return '<section class="panel" id="chk-form" aria-label="Check list"><div class="row sp"><h3>Check list · '+esc(eq.nombre)+'</h3><span class="small muted">'+answered+' de '+tpl.items.length+' respondidos</span></div>'+
    '<div class="row"><button class="btn sm" type="button" data-act="chkall">Marcar lo que falta como "Bien"</button></div>'+body+
    '<div class="grid2"><label>'+esc(tpl.lect)+' (opcional)<input id="chk-lect" inputmode="decimal" placeholder="Ej.: 4210"></label></div>'+
    '<label>Detalle de lo que observaste (obligatorio si hay observaciones o fallas)<textarea id="chk-nota" placeholder="Ej.: pierde aceite en el cilindro izquierdo"></textarea></label>'+ban+
    '<div class="row"><button class="btn pri" type="button" data-act="chkenviar"'+(all?'':' disabled')+'>Enviar check list</button><button class="btn" type="button" data-act="chkcerrar">Cancelar</button></div></section>';}
async function chkEnviar(){
  var c=S.ui.chk;if(!c)return;var eq=(D().equipos||[]).find(function(e){return e.id===c.eq;});if(!eq)return;
  var tpl=tplDe(eq.tipo),g=function(i){return document.getElementById(i);};
  var miss=tpl.items.filter(function(it){return !c.items[it[0]];}).length;if(miss){toast('Faltan '+miss+' puntos por responder.');return;}
  var nota=(g('chk-nota').value||'').trim(),lectS=(g('chk-lect').value||'').trim().replace(',','.'),lect=lectS===''?'':parseFloat(lectS);
  if(lectS!==''&&isNaN(lect)){toast('La lectura debe ser un número.');return;}
  var res=chkResultado(tpl,c.items);if(res!=='ok'&&!nota){toast('Contá qué observaste en el campo de detalle.');return;}
  var doc=chkArma(eq,actor(),miId(),new Date().toISOString(),c.items,lect,nota);
  try{
    if(S.mode==='demo'){doc.id='c-'+Date.now();S.data.demo.checks.push(doc);}
    else{doc.id=db.collection('checks').doc().id;await db.doc('checks/'+doc.id).set(clean(doc));}
    try{await otDesdeCheck(eq,doc);}catch(_){}
    S.ui.chk=null;toast(res==='fuera'?'Check list guardado: equipo fuera de servicio.':res==='obs'?'Check list guardado con observaciones.':'Check list guardado. Todo en condiciones.');render();
  }catch(_){toast('No se pudo guardar el check list. Probá de nuevo.');}
}
function eqKpis(){
  var eqs=D().equipos||[],st=eqs.map(estadoEq);
  var hoy=st.filter(function(x){return x.hoy;}).length,fuera=st.filter(function(x){return x.k==='fuera';}).length,obs=st.filter(function(x){return x.k==='obs';}).length;
  var venc=eqs.reduce(function(n,e){return n+docsVenc(e.docs).length;},0);
  return {n:eqs.length,hoy:hoy,fuera:fuera,obs:obs,venc:venc};}
function eqBanner(){
  var eqs=D().equipos||[],out='';
  var fuera=eqs.filter(function(e){return estadoEq(e).k==='fuera';});
  if(fuera.length)out+='<div class="banner bad" role="status">'+ICON.alert+'<div><strong>'+fuera.length+' equipo'+(fuera.length>1?'s':'')+' fuera de servicio</strong>'+esc(fuera.map(function(e){return e.nombre;}).join(', '))+'. <button class="btn sm" data-act="tab" data-v="eq">Ver equipos</button></div></div>';
  var vencP=D().perfiles.filter(function(p){return (p.rol==='chofer'||p.rol==='deposito')&&docsVenc(persVenc(p)).length;});
  var vencE=eqs.filter(function(e){return docsVenc(e.docs).length;});
  if(vencP.length||vencE.length)out+='<div class="banner warn" role="status">'+ICON.alert+'<div><strong>Vencimientos para revisar</strong>'+esc(vencE.map(function(e){return e.nombre;}).concat(vencP.map(function(p){return p.nombre;})).join(', '))+' tienen documentación vencida.</div></div>';
  return out;}
function viewEquipos(){
  var k=eqKpis(),fil=S.ui.eqFil,eqs=(D().equipos||[]).filter(function(e){return !fil||e.tipo===fil;});
  eqs=eqs.slice().sort(function(a,b){var o={fuera:0,obs:1,sin:2,ok:3},x=estadoEq(a),y=estadoEq(b);return (o[x.k]-o[y.k])||a.nombre.localeCompare(b.nombre);});
  return '<div class="row sp"><h2>Equipos</h2><button class="btn pri" data-act="eqnuevo">Nuevo equipo</button></div>'+
    '<div class="tiles"><div class="tile"><b>'+k.n+'</b><span>Equipos</span></div><div class="tile"><b>'+k.hoy+' / '+k.n+'</b><span>Con check hoy</span></div><div class="tile"><b style="color:var(--bad)">'+k.fuera+'</b><span>Fuera de servicio</span></div><div class="tile"><b style="color:var(--warn)">'+k.obs+'</b><span>Con observaciones</span></div><div class="tile"><b style="color:'+(k.venc?'var(--bad)':'inherit')+'">'+k.venc+'</b><span>Documentos vencidos</span></div></div>'+
    '<div class="row"><label style="min-width:200px">Mostrar<select id="eq-fil"><option value="">Todos los tipos</option>'+Object.keys(TIPOS).map(function(t){return '<option value="'+t+'"'+(fil===t?' selected':'')+'>'+esc(TIPOS[t][0])+'</option>';}).join('')+'</select></label></div>'+
    viewCheck()+viewEqForm()+
    (eqs.length?eqs.map(function(e){return eqCard(e,true);}).join(''):'<div class="empty">Todavía no cargaste equipos. Agregá autoelevadores, camiones y utilitarios con "Nuevo equipo".</div>')+
    '<p class="small muted">Las listas de control son una base de uso habitual. Ajustalas al manual de cada fabricante y a la normativa de higiene y seguridad que te corresponda.</p>';}
function viewEqForm(){
  var f=S.ui.eqf;if(!f)return '';
  var chof=D().perfiles.filter(function(p){return p.rol==='chofer';}),docs=(f.docs||[]).slice(),i;while(docs.length<4)docs.push({nombre:'',vence:''});
  var enes=['GLP','Diésel','Nafta','Eléctrico','Gas natural'];
  return '<form id="form-eq" class="panel"><h3>'+(f.id?'Editar equipo':'Nuevo equipo')+'</h3><div class="grid2">'+
    '<label>Tipo<select id="eq-tipo">'+Object.keys(TIPOS).map(function(t){return '<option value="'+t+'"'+(f.tipo===t?' selected':'')+'>'+esc(TIPOS[t][0])+'</option>';}).join('')+'</select></label>'+
    '<label>Nombre<input id="eq-nom" required value="'+esc(f.nombre||'')+'" placeholder="Autoelevador 3"></label>'+
    '<label>Patente o n.º de serie<input id="eq-ide" value="'+esc(f.ident||'')+'"></label>'+
    '<label>Marca y modelo<input id="eq-mar" value="'+esc(f.marca||'')+'"></label>'+
    '<label>Año<input id="eq-ani" type="number" min="1980" max="2100" value="'+esc(f.anio||'')+'"></label>'+
    '<label>Capacidad o carga útil (kg)<input id="eq-cap" type="number" min="0" value="'+esc(f.cap||'')+'"></label>'+
    '<label>Energía<select id="eq-ene">'+enes.map(function(x){return '<option'+(f.energia===x?' selected':'')+'>'+x+'</option>';}).join('')+'</select></label>'+
    '<label>Chofer asignado (opcional)<select id="eq-asi"><option value="">Sin asignar</option>'+chof.map(function(p){return '<option value="'+esc(p.id)+'"'+(f.asignado===p.id?' selected':'')+'>'+esc(p.nombre)+'</option>';}).join('')+'</select></label></div>'+
    '<h3 style="font-size:17px">Vencimientos</h3><datalist id="dl-docs"><option value="RTO / VTV"><option value="Seguro"><option value="Cédula verde"><option value="Mantenimiento / service"><option value="Inspección técnica"><option value="Extintor"></datalist>'+
    docs.map(function(d,j){return '<div class="grid2"><label>Documento<input id="eq-dn'+j+'" list="dl-docs" value="'+esc(d.nombre||'')+'"></label><label>Vence<input id="eq-dv'+j+'" type="date" value="'+esc(d.vence||'')+'"></label></div>';}).join('')+
    '<div class="row"><button class="btn pri" type="submit">Guardar equipo</button><button class="btn" type="button" data-act="eqcancel">Cancelar</button></div></form>';}
async function saveEquipo(){
  var g=function(i){return document.getElementById(i);},old=S.ui.eqf||{},nom=g('eq-nom').value.trim();if(!nom){toast('Poné un nombre al equipo.');return;}
  var docs=[];for(var j=0;j<4;j++){var n=(g('eq-dn'+j).value||'').trim(),v=g('eq-dv'+j).value;if(n&&v)docs.push({nombre:n,vence:v});}
  var e={id:old.id||(S.mode==='demo'?'e-'+Date.now():db.collection('equipos').doc().id),tipo:g('eq-tipo').value,nombre:nom,ident:g('eq-ide').value.trim(),marca:g('eq-mar').value.trim(),anio:parseInt(g('eq-ani').value,10)||'',cap:parseFloat(g('eq-cap').value)||'',energia:g('eq-ene').value,asignado:g('eq-asi').value,docs:docs};
  try{if(S.mode==='demo')upsertLocal(S.data.demo.equipos,e);else await db.doc('equipos/'+e.id).set(clean(e));S.ui.eqf=null;toast('Equipo guardado');render();}catch(_){toast('No se pudo guardar el equipo.');}}
function viewHistorial(){
  var cs=(D().checks||[]).slice().sort(function(a,b){return b.ts.localeCompare(a.ts);}).slice(0,60);
  var k=eqKpis(),pend=(D().equipos||[]).filter(function(e){return !estadoEq(e).hoy;});
  return '<h2>Historial de check lists</h2>'+
    '<div class="tiles"><div class="tile"><b>'+pc(k.hoy,k.n)+'</b><span>Cumplimiento hoy</span></div><div class="tile"><b>'+cs.length+'</b><span>Últimos registros</span></div><div class="tile"><b style="color:var(--bad)">'+cs.filter(function(c){return c.resultado==='fuera';}).length+'</b><span>Con falla crítica</span></div></div>'+
    (pend.length?'<div class="banner info">'+ICON.bell+'<div><strong>Sin check list hoy</strong>'+esc(pend.map(function(e){return e.nombre;}).join(', '))+'.</div></div>':'')+
    (cs.length?'<div class="panel">'+cs.map(function(c){
      var chip=c.resultado==='fuera'?'<span class="chip bad">Falla crítica</span>':c.resultado==='obs'?'<span class="chip warn">Observaciones</span>':'<span class="chip ok">Todo bien</span>',open=S.ui.chkOpen===c.id;
      return '<div class="leg" style="display:block"><div class="row sp"><span><strong>'+esc(c.equipoNombre)+'</strong> <span class="muted small">'+esc(fechaHora(c.ts))+' · '+esc(c.por)+'</span></span><span class="row">'+chip+(c.fallas&&c.fallas.length||c.nota?'<button class="btn sm" data-act="chkdet" data-id="'+esc(c.id)+'">'+(open?'Ocultar':'Ver detalle')+'</button>':'')+'</span></div>'+
        (open?'<div class="obs" style="margin-top:6px">'+(c.fallas||[]).map(function(f){return '<div>'+(f.crit?'<strong>Crítico · </strong>':'')+esc(f.texto)+' <span class="muted">('+(f.v==='mal'?'mal':'con observación')+')</span></div>';}).join('')+(c.nota?'<div>'+esc(c.nota)+'</div>':'')+'</div>':'')+'</div>';}).join('')+'</div>':'<div class="empty">Todavía no hay check lists registrados.</div>');}
function viewPersonal(){
  var all=D().perfiles.filter(function(p){return p.rol==='chofer'||p.rol==='deposito'||p.rol==='cliente';}).sort(function(a,b){return a.rol.localeCompare(b.rol)||a.nombre.localeCompare(b.nombre);});
  var pf=S.ui.pfil||'',pq=String(S.ui.pq||'').trim().toLowerCase(),pl=S.ui.plim||25;
  var list0=all.filter(function(p){return (!pf||p.rol===pf)&&(!pq||(String(p.nombre||'')+' '+String(p.telefono||'')+' '+String(p.area||'')+' '+String(p.zona||'')).toLowerCase().indexOf(pq)>=0);}),list=list0.slice(0,pl);
  var pc=function(r){return all.filter(function(p){return !r||p.rol===r;}).length;};
  var pbar='<div class="seg lt" role="group" aria-label="Tipo de ficha" style="margin:8px 0">'+[['','👥 Todos'],['cliente','🤝 Clientes'],['chofer','🚐 Choferes'],['deposito','🏭 Operarios']].map(function(t){return '<button data-act="x29-pfil" data-v="'+t[0]+'" aria-pressed="'+(pf===t[0])+'">'+t[1]+' ('+pc(t[0])+')</button>';}).join('')+'</div>'+
    '<label style="margin-bottom:6px">Buscar por nombre, teléfono o zona<input id="x29-pq" type="search" placeholder="Escribí para buscar…" value="'+esc(S.ui.pq||'')+'"></label>'+
    '<div class="small muted" style="margin-bottom:4px">Mostrando '+list.length+' de '+list0.length+(list0.length!==all.length?' (filtrado de '+all.length+')':'')+'</div>';
  return '<h2>Fichas</h2><p class="small muted" style="margin:0">Choferes, personal de depósito y clientes. Para sumar a alguien, creá su usuario en Operación › Usuarios y después completá su ficha acá. Con el teléfono de un cliente cargado, aparece el botón de WhatsApp en sus entregas.</p>'+viewFicForm()+pbar+
    (list.length?list.map(function(p){
      var venc=persVenc(p),eqs=(D().equipos||[]).filter(function(e){return e.asignado===p.id;});
      return '<article class="card"><div class="row sp"><div><strong>'+esc(p.nombre)+'</strong> <span class="chip '+(p.rol==='chofer'?'signal':'')+'">'+({chofer:'Chofer',deposito:'Depósito',cliente:'Cliente'}[p.rol]||p.rol)+'</span></div><button class="btn sm" data-act="ficedit" data-id="'+esc(p.id)+'">Editar ficha</button></div>'+
        '<div class="small muted">'+[p.area?'<strong>'+esc(p.area)+'</strong>':'',p.turno?'Turno '+esc(p.turno):'',p.telefono?'Tel. <a href="tel:'+esc(String(p.telefono).replace(/[^0-9+]/g,''))+'">'+esc(p.telefono)+'</a>'+(waUrl(p.telefono)?' · <a href="'+esc(waUrl(p.telefono))+'" target="_blank" rel="noopener">WhatsApp</a>':''):'',p.licCat?'Licencia '+esc(p.licCat):'',eqs.length?'Vehículo: '+esc(eqs.map(function(e){return e.nombre;}).join(', ')):''].filter(Boolean).join(' · ')+'</div>'+
        (p.contacto?'<div class="small">Contacto de emergencia: '+esc(p.contacto)+'</div>':'')+
        (venc.length?'<div class="chips">'+venc.map(function(d){return vencChip(d.vence,d.nombre);}).join('')+'</div>':'<div class="small muted">Sin vencimientos cargados.</div>')+
        (p.notas?'<div class="obs"><div>'+esc(p.notas)+'</div></div>':'')+'</article>';}).join('')+(list0.length>list.length?'<button class="btn" style="width:100%" data-act="x29-pmas">Ver más ('+(list0.length-list.length)+' restantes)</button>':''):'<div class="empty">'+(all.length?'Ninguna ficha coincide con el filtro.':'Todavía no hay choferes ni personal de depósito con perfil.')+'</div>');}
function viewFicForm(){
  var p=S.ui.fic;if(!p)return '';if(p.rol==='cliente')return viewFicCliente(p);var hab=(p.hab||[]).slice();while(hab.length<3)hab.push({nombre:'',vence:''});
  return '<form id="form-fic" class="panel"><h3>Ficha de '+esc(p.nombre)+'</h3><div class="grid2">'+
    '<label>Nombre en el portal<input id="fi-nom" required value="'+esc(p.nombre||'')+'"></label>'+
    '<label>Función<select id="fi-rol"><option value="chofer"'+(p.rol==='chofer'?' selected':'')+'>Chofer</option><option value="deposito"'+(p.rol==='deposito'?' selected':'')+'>Depósito (operario)</option></select></label>'+
    '<label>Teléfono<input id="fi-tel" inputmode="tel" value="'+esc(p.telefono||'')+'"></label>'+
    '<label>Contacto de emergencia<input id="fi-con" value="'+esc(p.contacto||'')+'" placeholder="Nombre y teléfono"></label>'+
    '<label>Turno<select id="fi-tur">'+['','Mañana','Tarde','Noche','Rotativo'].map(function(t){return '<option'+(p.turno===t?' selected':'')+'>'+t+'</option>';}).join('')+'</select></label>'+
    '<label>Categoría de licencia<input id="fi-lic" value="'+esc(p.licCat||'')+'" placeholder="Ej.: D2"></label>'+
    '<label>Vence la licencia<input id="fi-lve" type="date" value="'+esc(p.licVence||'')+'"></label></div>'+
    '<datalist id="dl-hab"><option value="Psicofísico"><option value="Curso de autoelevadorista"><option value="Manejo defensivo"><option value="Cargas peligrosas"><option value="Primeros auxilios"></datalist>'+
    hab.map(function(d,j){return '<div class="grid2"><label>Habilitación o curso<input id="fi-hn'+j+'" list="dl-hab" value="'+esc(d.nombre||'')+'"></label><label>Vence<input id="fi-hv'+j+'" type="date" value="'+esc(d.vence||'')+'"></label></div>';}).join('')+
    '<label>Notas<textarea id="fi-not">'+esc(p.notas||'')+'</textarea></label>'+
    '<div class="row"><button class="btn pri" type="submit">Guardar ficha</button><button class="btn" type="button" data-act="ficcancel">Cancelar</button></div></form>';}
async function saveFicha(){
  var g=function(i){return document.getElementById(i)||{value:''};},old=S.ui.fic;if(!old)return;var nom=g('fi-nom').value.trim();if(!nom){toast('Poné el nombre.');return;}
  var hab=[];for(var j=0;j<3;j++){var n=(g('fi-hn'+j).value||'').trim(),v=g('fi-hv'+j).value;if(n&&v)hab.push({nombre:n,vence:v});}
  var p=Object.assign({},old,{nombre:nom,rol:g('fi-rol').value||old.rol,telefono:g('fi-tel').value.trim(),contacto:g('fi-con').value.trim(),turno:g('fi-tur').value,licCat:g('fi-lic').value.trim(),licVence:g('fi-lve').value,hab:hab,notas:g('fi-not').value.trim()});
  var id=p.id;delete p.id;
  try{if(S.mode==='demo'){var i=S.data.demo.perfiles.findIndex(function(x){return x.id===id;});if(i>=0)S.data.demo.perfiles[i]=Object.assign({id:id},p);}else await db.doc('perfiles/'+id).set(clean(p));
    S.ui.fic=null;toast('Ficha guardada');render();}catch(_){toast('No se pudo guardar la ficha.');}}
function alertasPropias(){
  var p=miPerfil(),out='';if(!p)return '';var v=persVenc(p),mal=docsVenc(v),por=docsPorVencer(v);
  if(mal.length)out+='<div class="banner bad" role="status">'+ICON.alert+'<div><strong>Tenés documentación vencida</strong>'+esc(mal.map(function(d){return d.nombre;}).join(', '))+'. Avisale a administración.</div></div>';
  else if(por.length)out+='<div class="banner warn" role="status">'+ICON.alert+'<div><strong>Documentación por vencer</strong>'+esc(por.map(function(d){return d.nombre+' ('+dmy(d.vence)+')';}).join(', '))+'.</div></div>';
  return out;}
function panelVehiculo(){
  var me=miId(),cam=(D().equipos||[]).filter(function(e){return TIPOS[e.tipo]&&TIPOS[e.tipo][1]==='camion';});if(!cam.length)return '';
  var sel=S.ui.miEq||(cam.find(function(e){return e.asignado===me;})||cam[0]).id,eq=cam.find(function(e){return e.id===sel;})||cam[0],st=estadoEq(eq);
  var ban=st.k==='fuera'?'<div class="banner bad" role="status">'+ICON.alert+'<div><strong>Vehículo fuera de servicio</strong>No salgas hasta que se corrija la falla y se haga un nuevo check list.</div></div>':!st.hoy?'<div class="banner warn" role="status">'+ICON.alert+'<div><strong>Falta el check list de hoy</strong>Hacelo antes de salir.</div></div>':'';
  return '<section class="panel"><div class="row sp"><h3>Mi vehículo</h3>'+st.chip+'</div>'+
    '<label>Vehículo<select id="ch-eq">'+cam.map(function(e){return '<option value="'+esc(e.id)+'"'+(e.id===eq.id?' selected':'')+'>'+esc(e.nombre+(e.ident?' · '+e.ident:''))+'</option>';}).join('')+'</select></label>'+ban+
    (S.ui.chk&&S.ui.chk.eq===eq.id?viewCheck():'<div class="row"><button class="btn pri" data-act="chkabrir" data-id="'+esc(eq.id)+'">Check list de salida</button></div>')+
    (eq.docs&&eq.docs.length?'<div class="chips">'+eq.docs.map(function(d){return vencChip(d.vence,d.nombre);}).join('')+'</div>':'')+'</section>';}
function viewDeposito(){
  var eqs=(D().equipos||[]).filter(function(e){return TIPOS[e.tipo]&&TIPOS[e.tipo][1]==='autoelevador';});
  return '<h2>Equipos del depósito</h2>'+alertasPropias()+viewCheck()+
    (eqs.length?eqs.map(function(e){return eqCard(e,false);}).join(''):'<div class="empty">Todavía no hay equipos cargados. Pedile a administración que los agregue.</div>');}
async function eqClick(a,id,v){
  if(a==='eqsub'){S.ui.eqsub=v;S.ui.eqf=null;S.ui.fic=null;S.ui.chk=null;render();}
  else if(a==='eqnuevo'){S.ui.eqf=null;render();S.ui.eqf={tipo:'autoelevador',docs:[]};render();var f=document.getElementById('form-eq');if(f)f.scrollIntoView({behavior:'smooth',block:'nearest'});}
  else if(a==='eqedit'){var e=(D().equipos||[]).find(function(x){return x.id===id;});if(e){S.ui.eqf=null;render();S.ui.eqf=clean(e);render();var f2=document.getElementById('form-eq');if(f2)f2.scrollIntoView({behavior:'smooth',block:'nearest'});}}
  else if(a==='eqcancel'){S.ui.eqf=null;render();}
  else if(a==='eqpedir'){S.ui.confirmDel='eq'+id;render();}
  else if(a==='eqdel'){S.ui.confirmDel=null;try{if(S.mode==='demo')S.data.demo.equipos=S.data.demo.equipos.filter(function(x){return x.id!==id;});else await db.doc('equipos/'+id).delete();toast('Equipo quitado');render();}catch(_){toast('No se pudo quitar el equipo.');}}
  else if(a==='chkabrir'){S.ui.chk=null;render();S.ui.chk={eq:id,items:{}};render();var f3=document.getElementById('chk-form');if(f3)f3.scrollIntoView({behavior:'smooth',block:'start'});}
  else if(a==='chkset'){if(S.ui.chk){S.ui.chk.items[id]=v;render();}}
  else if(a==='chkall'){var c=S.ui.chk;if(c){var eq=(D().equipos||[]).find(function(x){return x.id===c.eq;});if(eq){tplDe(eq.tipo).items.forEach(function(it){if(!c.items[it[0]])c.items[it[0]]='ok';});render();}}}
  else if(a==='chkcerrar'){S.ui.chk=null;render();}
  else if(a==='chkenviar'){await chkEnviar();}
  else if(a==='chkdet'){S.ui.chkOpen=S.ui.chkOpen===id?null:id;render();}
  else if(a==='ficedit'){var p=D().perfiles.find(function(x){return x.id===id;});if(p){S.ui.fic=null;render();S.ui.fic=clean(p);render();var f4=document.getElementById('form-fic');if(f4)f4.scrollIntoView({behavior:'smooth',block:'nearest'});}}
  else if(a==='ficsintel'){var pc=D().perfiles.find(function(x){return x.id===id;});if(pc){S.ui.tab='eq';S.ui.eqsub='personal';S.ui.fic=null;render();S.ui.fic=clean(pc);render();window.scrollTo(0,0);}else toast('No se encontró la ficha del cliente.');}
  else if(a==='ficcancel'){S.ui.fic=null;render();}
}

/* ---------- WhatsApp: abre el chat con el mensaje armado (sin API, lo envía una persona) ---------- */
function waNum(t){var d=String(t||'').replace(/\D/g,'').replace(/^0+/,'');if(!d)return '';if(d.indexOf('54')===0)return d.indexOf('549')===0?d:'549'+d.slice(2);return '549'+d;}
function waMsg(e){
  var emp=(window.APP_CONFIG&&window.APP_CONFIG.name)||'Portal de entregas';
  var t=e.estado==='en_camino'?'tu pedido '+e.guia+' está en camino. Ventana de entrega: '+ventana(e)+'.':e.estado==='entregada'?'entregamos tu pedido '+e.guia+'. Podés ver el remito y la factura en el portal.':e.estado==='no_entregada'?'no pudimos entregar el pedido '+e.guia+'. Escribinos para coordinar una nueva entrega.':'tenés una entrega programada ('+e.guia+') para '+fmtFecha(e.fecha)+', entre '+ventana(e)+'.';
  return 'Hola, te escribimos de '+emp+': '+t;}
function waUrl(tel,txt){var n=waNum(tel);return n?'https://wa.me/'+n+(txt?'?text='+encodeURIComponent(txt):''):'';}
function waBtn(e){
  var p=D().perfiles.find(function(x){return x.id===e.clienteId;}),u=p&&waUrl(p.telefono,waMsg(e));
  return u?'<a class="btn sm" href="'+esc(u)+'" target="_blank" rel="noopener">WhatsApp</a> ':'<button class="btn sm" data-act="ficsintel" data-id="'+esc(e.clienteId||'')+'" title="Cargá el teléfono del cliente en su ficha">Cargar WhatsApp</button> ';}
function viewFicCliente(p){
  return '<form id="form-fic" class="panel"><h3>Ficha de '+esc(p.nombre)+'</h3><div class="grid2">'+
    '<label>Nombre en el portal<input id="fi-nom" required value="'+esc(p.nombre||'')+'"></label>'+
    '<label>Teléfono para WhatsApp (con código de área, sin el 15)<input id="fi-tel" inputmode="tel" value="'+esc(p.telefono||'')+'" placeholder="11 5555-1234"></label>'+
    '<label>Persona de contacto<input id="fi-con" value="'+esc(p.contacto||'')+'"></label></div>'+
    '<label>Notas (horarios, acceso, observaciones)<textarea id="fi-not">'+esc(p.notas||'')+'</textarea></label>'+
    '<div class="row"><button class="btn pri" type="submit">Guardar ficha</button><button class="btn" type="button" data-act="ficcancel">Cancelar</button></div></form>';}

/* ---------- contacto de tráfico: único punto de contacto ante urgencias y consultas ---------- */
function traf(){return S.mode==='demo'?(S.trafDemo||{nombre:'Tráfico',telefono:'11 5555-0100'}):(S.trafico||{});}
function trafBtns(msg,small){
  var t=traf();if(!t.telefono)return '';var u=waUrl(t.telefono,msg),n=String(t.telefono).replace(/[^0-9+]/g,''),nom=t.nombre||'Tráfico';
  return '<span class="row" style="gap:8px">'+(n?'<a class="btn'+(small?' sm':'')+'" href="tel:'+esc(n)+'">Llamar a '+esc(nom)+'</a>':'')+(u?'<a class="btn'+(small?' sm':'')+'" href="'+esc(u)+'" target="_blank" rel="noopener">WhatsApp a '+esc(nom)+'</a>':'')+'</span>';}
function panelTrafico(){
  var t=traf();
  return '<div class="panel"><h3>Contacto de tráfico</h3><p class="small muted" style="margin:0">Es el número al que los choferes llaman o escriben ante una urgencia, y al que los clientes consultan por sus entregas. Los choferes no ven teléfonos de clientes: todo pasa por tráfico.</p>'+
    '<div class="grid2"><label>Nombre<input id="tr-nom" value="'+esc(t.nombre||'Tráfico')+'"></label><label>Teléfono (con código de área, sin el 15)<input id="tr-tel" inputmode="tel" value="'+esc(t.telefono||'')+'" placeholder="11 5555-1234"></label></div>'+
    '<div class="row"><button class="btn pri" data-act="trsave">Guardar contacto</button></div></div>';}
function panelUrgencia(){
  if(!traf().telefono)return '';
  return '<section class="panel"><h3>¿Urgencia o problema?</h3><div class="small muted">Comunicate con tráfico. No contactes al cliente por tu cuenta.</div>'+trafBtns('Hola, soy '+actor()+' (chofer). Tengo una urgencia.')+'</section>';}

/* ---------- render ---------- */
function statusBanner(){
  var n=window.PORTAL_STATUS||{},out='';
  if(S.mode!=='live')return '';
  if(n.offline)out+='<div class="banner warn" role="status" style="margin-top:16px">'+ICON.alert+'<div><strong>Sin conexión</strong>Podés seguir trabajando: tus cambios se guardan en este aparato y se envían solos cuando vuelva la señal.'+(n.pending?' Pendientes de enviar: '+n.pending+'.':'')+'</div></div>';
  else if(n.pending)out+='<div class="banner info" role="status" style="margin-top:16px">'+ICON.bell+'<div><strong>Enviando cambios</strong>Quedan '+n.pending+' por enviar.</div></div>';
  if(n.lastError&&n.pending&&!n.offline)out+='<div class="banner warn" role="status" style="margin-top:16px">'+ICON.alert+'<div><strong>El servidor no respondió bien</strong>Reintentamos solos. <button class="btn sm" data-act="x-reintentar">Reintentar ahora</button></div></div>';
  else if(n.pending&&n.offline)out+='<div class="small muted" style="margin-top:6px"><button class="btn sm" data-act="x-reintentar">Reintentar ahora</button></div>';
  if(n.dropped)out+='<div class="banner bad" role="status" style="margin-top:16px">'+ICON.alert+'<div><strong>'+n.dropped+' cambio'+(n.dropped>1?'s':'')+' no se pudo'+(n.dropped>1?'ieron':'')+' guardar</strong>El servidor lo rechazó (por ejemplo, ya no tenés permiso). Avisale a administración. '+(n.lost||[]).slice(-3).map(function(l){return esc(l.path)+' ('+esc(l.msg)+')';}).join(' · ')+' <button class="btn sm" data-act="x-lostok">Entendido</button></div></div>';
  if(n.conflicts)out+='<div class="banner info" role="status" style="margin-top:16px">'+ICON.bell+'<div><strong>Se unieron cambios hechos sin conexión</strong>'+(n.notes||[]).slice(-3).map(function(l){return esc(l.msg);}).join(' ')+' <button class="btn sm" data-act="x-lostok">Entendido</button></div></div>';
  return out;
}
function esInvitado(){return S.mode==='live'&&/^invitado$/i.test((S.me&&S.me.name)||'');}
function headerHtml(){
  var rol=rolActual(),pillTxt=S.mode==='demo'?'Demostración':'En vivo';
  var rolTabs='';
  if(S.mode==='demo')rolTabs='<div class="seg" role="group" aria-label="Ver como">'+[['cliente','Cliente'],['chofer','Chofer'],['deposito','Depósito'],['admin','Administración']].map(function(r){return '<button data-act="demorol" data-v="'+r[0]+'" aria-pressed="'+(S.demoRol===r[0])+'">'+r[1]+'</button>';}).join('')+'</div>';
  var who=S.mode==='live'?'<span class="who">'+esc(S.me.name||'')+(rol&&!esInvitado()?' · '+esc(rol==='admin'?'administración':rol):'')+'</span>':'';
  var swap=S.hasDb&&S.isAdmin&&!esInvitado()?'<div class="seg"><button data-act="modo" data-v="'+(S.mode==='demo'?'live':'demo')+'" aria-pressed="false">'+(S.mode==='demo'?'Ir al portal en vivo':'Ver demostración')+'</button></div>':'';
  return '<header class="top"><div class="top-in"><a class="brand" href="/" data-act="x12-inicio" title="Ir al inicio" aria-label="Ir al inicio">'+ICON.truck+esc((window.APP_CONFIG&&window.APP_CONFIG.name)||'Portal')+'</a><span class="pill '+(S.mode==='demo'?'demo':'')+'">'+pillTxt+'</span>'+who+rolTabs+swap+(S.mode==='live'?'<div class="seg"><button data-act="salir" aria-pressed="false">Salir</button></div>':'')+'</div></header>';
}
function mainHtml(){
  if(S.mode==='demo'){return S.demoRol==='cliente'?viewCliente():S.demoRol==='chofer'?viewChofer():S.demoRol==='deposito'?viewDeposito():viewAdmin();}
  var rol=rolActual();
  if(!S.perfilListo)return '<div class="empty">Verificando tu cuenta…</div>';
  if(rol==='admin')return viewAdmin();
  if(rol==='cliente')return viewCliente();
  if(rol==='chofer')return viewChofer();
  if(rol==='deposito')return viewDeposito();
  return '<div class="banner warn">'+ICON.alert+'<div><strong>Tu cuenta todavía no tiene un perfil asignado</strong>Pedile a quien administra el portal que te asigne como cliente, chofer o personal de depósito. Mientras tanto podés ver una demostración con datos de ejemplo.<div style="margin-top:8px"><button class="btn sm" data-act="modo" data-v="demo">Ver demostración</button></div></div></div>';
}
function render(){
  if(S.drawing){S.pendingRender=true;return;}
  var app=document.getElementById('app');
  var keep={},act=document.activeElement,actId=act&&act.id,selS=null;
  app.querySelectorAll('input,select,textarea').forEach(function(el){if(el.id&&el.type!=='file')keep[el.id]=el.type==='checkbox'?el.checked:el.value;});
  if(act&&act.selectionStart!=null)selS=[act.selectionStart,act.selectionEnd];
  var scrollY=window.scrollY;
  app.innerHTML=headerHtml()+'<div class="wrap">'+statusBanner()+(S.note?'<div class="banner info" style="margin-top:16px">'+ICON.bell+'<div>'+esc(S.note)+'</div></div>':'')+'<main>'+mainHtml()+'</main></div>';
  Object.keys(keep).forEach(function(id){var el=document.getElementById(id);if(el&&el.type!=='file'){if(el.type==='checkbox')el.checked=keep[id];else el.value=keep[id];}});
  if(actId){var f=document.getElementById(actId);if(f){f.focus();if(selS&&f.setSelectionRange){try{f.setSelectionRange(selS[0],selS[1]);}catch(_){}}}}
  window.scrollTo(0,scrollY);
  if(typeof extAfterRender==='function')extAfterRender();
}

/* ---------- EXT: prueba de entrega, importación, indicadores, costos, mantenimiento, depósito operativo ---------- */
S.ext={per:'30',sub:'ind',pod:null,sig:'',foto:null,fotoUrl:'',geo:null,noGeo:false,imp:null,pickDraft:[],vrp:{spd:30,svc:10},lt:{sku:'',can:''},gasto:false,otClose:null,conOpen:null,cnUbi:''};
S.consentDemo=false;S.consent=null;
var TH='style="text-align:left;color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.06em"';
var gv=function(i){var el=document.getElementById(i);return el?el.value:'';};
var gnum=function(i){var n=parseFloat(String(gv(i)).replace(',','.'));return isNaN(n)?NaN:n;};
var isoNow=function(){return new Date().toISOString();};
var uid=function(p){return p+Date.now().toString(36)+Math.random().toString(36).slice(2,6);};
var tbl=function(head,rows,min){return '<div class="tablewrap"><table style="width:100%;border-collapse:collapse;font-size:14px;min-width:'+(min||560)+'px"><thead><tr '+TH+'>'+head.map(function(h,i){return '<th'+(i===0?' style="padding:6px"':'')+'>'+h+'</th>';}).join('')+'</tr></thead><tbody>'+rows.map(function(r){return '<tr style="border-top:1px solid var(--line)">'+r.map(function(c,i){return '<td'+(i===0?' style="padding:8px 6px"':'')+'>'+c+'</td>';}).join('')+'</tr>';}).join('')+'</tbody></table></div>';};
var toMin=function(hhmm){var p=String(hhmm||'').split(':');return (parseInt(p[0],10)||0)*60+(parseInt(p[1],10)||0);};
var hhmm=function(m){m=Math.round(m);return pad(Math.floor(m/60)%24)+':'+pad(m%60);};
var WC=function(k){return (W()[k])||[];};
var XL=function(k){var d=D();return d[k]||(d[k]=[]);};

/* ----- datos de demostración (ficticios) ----- */
(function(){
  var seed=11,rnd=function(){seed=(seed*16807)%2147483647;return seed/2147483647;};
  var g=[];[['e4',84000],['e5',121500]].forEach(function(p){var odo=p[1],c=0;
    for(var off=-27;off<=-1;off+=3){var km=250+Math.round(rnd()*120),l=Math.round(km*(0.30+rnd()*0.05)*10)/10;odo+=km;c++;
      g.push({id:'g-d'+p[0]+c,fecha:addDays(off),tipo:'combustible',equipoId:p[0],equipo:p[0]==='e4'?'Camión 1':'Camión 2',importe:Math.round(l*1300),litros:l,odo:odo,porId:p[0]==='e4'?'d1':'d2',por:p[0]==='e4'?'Marcos Peralta':'Diego Ruiz',nota:''});
      if(c%3===0)g.push({id:'g-p'+p[0]+c,fecha:addDays(off),tipo:'peaje',equipoId:p[0],equipo:p[0]==='e4'?'Camión 1':'Camión 2',importe:6200,litros:0,odo:0,porId:p[0]==='e4'?'d1':'d2',por:'',nota:''});}});
  S.data.demo.gastos=g;S.data.demo.ordenes=[];S.data.demo.plantillas=[];S.data.demo.consents=[];
  S.data.live.gastos=[];S.data.live.ordenes=[];S.data.live.plantillas=[];S.data.live.consents=[];
  var w=S.data.demo.wms;w.conteos=[];w.picks=[];S.data.live.wms.conteos=[];S.data.live.wms.picks=[];
  [['KL01','P001','01:01:01:00',30,'L2601',25],['KL02','P003','01:01:01:01',40,'L2602',50],['KL03','P005','02:01:01:01',60,'L2603',200],['KL04','P005','02:01:01:01',10,'L2599',-3]].forEach(function(x){
    w.kardex.push({id:x[0],fecha:HOY,tipo:'IN',sku:x[1],ubicacion:x[2],'in':x[3],out:0,lote:x[4],vence:addDays(x[5]),operador:'Demostración'});});
  var sig='data:image/svg+xml;utf8,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="160" height="70" viewBox="0 0 160 70"><rect width="160" height="70" fill="#fff"/><path d="M12 48 C30 10 40 10 48 40 S70 60 84 30 S110 20 148 44" fill="none" stroke="#222" stroke-width="2.4" stroke-linecap="round"/></svg>');
  S.data.demo.entregas.forEach(function(e){
    if(e.pesoKg==null)e.pesoKg=(e.bultos||1)*110;
    var n=parseInt(String(e.guia).replace(/\D/g,''),10)||0,h=(e.historial||[]).filter(function(x){return x.estado==='entregada';}).slice(-1)[0];
    if(e.estado==='entregada'&&h&&(e.id==='d-4818'||e.id==='d-4790'||n%9===0)){
      var parcial=e.id==='d-4790'||(n%9===0&&n%2===0);
      e.pod={receptor:e.id==='d-4790'?'Marcela':'Encargado',completa:!parcial,nota:parcial?'Faltó 1 bulto, queda para reposición.':'',ts:h.ts,firma:sig,foto:'',por:h.por,lat:e.lat+0.0004,lng:e.lng-0.0003,distM:55};}
  });
})();

/* ----- prueba de entrega + consentimiento ----- */
var hasConsent=function(){return S.mode==='demo'?S.consentDemo:!!(S.consent&&S.consent.ok);};
/* ----- fotos en observaciones (sacar con la cámara o elegir de la galería) ----- */
S.ext.fts=S.ext.fts||{};
var FT_MAX=4;
function ftList(c){S.ext.fts=S.ext.fts||{};return S.ext.fts[c]||(S.ext.fts[c]=[]);}
function ftBlock(c){var l=ftList(c);
  return '<div class="fotos"><div class="row"><label class="btn" style="cursor:pointer">Sacar foto<input type="file" id="fts-cam-'+esc(c)+'" data-ctx="'+esc(c)+'" accept="image/*" capture="environment" hidden></label><label class="btn" style="cursor:pointer">Elegir de la galería<input type="file" id="fts-gal-'+esc(c)+'" data-ctx="'+esc(c)+'" accept="image/*" multiple hidden></label><span class="small muted">'+(l.length?l.length+' de '+FT_MAX+' fotos':'Sin fotos (opcional)')+'</span></div>'+
   (l.length?'<div class="row">'+l.map(function(f,i){return '<span style="position:relative;display:inline-block"><img class="foto" alt="Foto '+(i+1)+'" src="'+esc(f.url)+'" style="width:72px;height:72px;object-fit:cover;border-radius:8px"><button type="button" class="btn sm" data-act="x14-fdel" data-ctx="'+esc(c)+'" data-i="'+i+'" aria-label="Quitar foto '+(i+1)+'" style="position:absolute;top:-6px;right:-6px;padding:0 8px">×</button></span>';}).join('')+'</div>':'')+'</div>';}
async function ftSubir(c){var l=ftList(c),urls=[],pend=0;
  for(var i=0;i<l.length;i++){var f=l[i];
    if(S.mode==='demo')urls.push(f.url);
    else if(assets){try{var u=await assets.upload(f.blob);urls.push(u.url);}catch(_){pend++;}}
    else pend++;}
  return {urls:urls,pend:pend};}
function fotosHtml(a){return (a&&a.length)?'<div class="row">'+a.map(function(u,i){return '<a href="'+esc(u)+'" target="_blank" rel="noopener"><img class="foto" alt="Foto '+(i+1)+'" src="'+esc(u)+'"></a>';}).join('')+'</div>':'';}
document.addEventListener('change',async function(ev){var t=ev.target;if(!t||!t.dataset||!t.dataset.ctx||!/^fts-/.test(t.id||''))return;
  var fl=[].slice.call(t.files||[]);t.value='';var l=ftList(t.dataset.ctx),sobran=false;
  for(var i=0;i<fl.length;i++){if(l.length>=FT_MAX){sobran=true;break;}try{var b=await resizeFoto(fl[i]);l.push({blob:b,url:URL.createObjectURL(b)});}catch(_){toast('No se pudo leer una de las fotos.');}}
  if(sobran)toast('Máximo '+FT_MAX+' fotos por vez.');
  render();});
document.addEventListener('click',function(ev){var b=ev.target.closest&&ev.target.closest('[data-act="x14-fdel"]');if(!b)return;ev.preventDefault();
  var l=ftList(b.dataset.ctx),i=parseInt(b.dataset.i,10);if(l[i]){if(S.mode!=='demo')try{URL.revokeObjectURL(l[i].url);}catch(_){}l.splice(i,1);}render();});
function podHtml(e){var p=e.pod;if(!p)return '';
  return '<div class="pod"><div class="row"><strong>Prueba de entrega</strong>'+(p.completa===false?'<span class="chip warn">Parcial o con daños</span>':'<span class="chip ok">Completa</span>')+'</div>'+
   '<div class="small">Recibió: <strong>'+esc(p.receptor||'—')+'</strong> · '+esc(fmtHora(p.ts))+(p.distM!=null?' · a '+(p.distM>=1000?nf(p.distM/1000,1)+' km':nf(p.distM)+' m')+' de la dirección':'')+'</div>'+(p.nota?'<div class="small muted">'+esc(p.nota)+'</div>':'')+
   '<div class="row">'+(p.firma?'<img class="sig" alt="Firma de quien recibió" src="'+esc(p.firma)+'">':'')+'</div>'+fotosHtml(p.fotos&&p.fotos.length?p.fotos:(p.foto?[p.foto]:[]))+(p.fotoPendiente?'<div class="small muted">Foto pendiente de subir</div>':'')+'</div>';}
function panelPod(e){
  if(S.ext.pod!==e.id)return '';
  var cons=hasConsent();
  if(!cons&&!S.ext.noGeo)return '<div class="panel"><h3>Antes de usar la ubicación</h3><p class="small">Para dejar prueba de que la entrega se hizo en la dirección, esta aplicación puede registrar la ubicación de tu teléfono <strong>solo en el momento en que confirmás una entrega</strong>. No hay seguimiento continuo. La ve la administración de la empresa. Podés retirar tu consentimiento cuando quieras pidiéndolo a administración.</p><div class="row"><button class="btn ok" data-act="x-consent">Acepto</button><button class="btn" data-act="x-nogeo">Continuar sin registrar ubicación</button><button class="btn" data-act="x-podno">Cancelar</button></div></div>';
  var g=S.ext.geo,dist=g&&hasXY(e)?Math.round(hav(g,e)*1000):null;
  return '<div class="panel pod-form"><h3>Confirmar entrega · '+esc(e.guia)+'</h3>'+
   '<label>Quién recibió<input id="pod-rec" placeholder="Nombre y apellido" autocomplete="off"></label>'+
   '<label style="flex-direction:row;display:flex;gap:8px;align-items:center"><input type="checkbox" id="pod-ok" checked style="width:auto"> Entrega completa y sin daños</label>'+
   '<label>Observaciones (obligatorio si no está completa)<textarea id="pod-nota" placeholder="Ej.: faltó 1 bulto, caja golpeada"></textarea></label>'+
   devBlock('pod',e)+'<div><div class="small muted">Firma de quien recibió</div><canvas id="sigpad" class="sigpad" width="320" height="140" aria-label="Espacio para firmar con el dedo"></canvas><div class="row"><button class="btn sm" data-act="x-sigclear">Borrar firma</button></div></div>'+
   '<div class="small muted">Fotos de la entrega o del problema (sacala con la cámara o elegila de la galería)</div>'+ftBlock('pod')+
   (cons?'<div class="row"><button class="btn" data-act="x-geo">Registrar mi ubicación</button><span class="small">'+(g?'Ubicación tomada'+(dist!=null?' · a '+dist+' m de la dirección':''):'Sin ubicación')+'</span></div>':'')+
   '<div class="row"><button class="btn ok" data-act="x-podok" data-id="'+esc(e.id)+'">Confirmar entrega</button><button class="btn" data-act="x-podno">Cancelar</button></div></div>';}
function devBlock(key,e){var its=e.items||[],id='dvl-'+key,rows='';
  for(var k=0;k<3;k++)rows+='<div class="row" style="flex-wrap:wrap;margin-top:6px"><input id="'+id+'-p'+k+'" '+(its.length?'list="'+id+'-dl" ':'')+'maxlength="80" autocomplete="off" placeholder="Producto o código" style="flex:2;min-width:150px"><input id="'+id+'-q'+k+'" type="number" inputmode="numeric" min="1" placeholder="Unidades" style="width:96px"><select id="'+id+'-s'+k+'" aria-label="Estado"><option value="ok">Buen estado</option><option value="mal">Dañada o rota</option></select></div>';
  return '<details class="panel" style="margin:8px 0"><summary><strong>¿Vuelve mercadería al depósito?</strong> (si la hay)</summary><div class="small muted" style="margin-top:6px">Anotá qué productos devuelve el cliente, cuántas unidades y si están en buen estado. El depósito lo revisa al recibirlo.</div>'+rows+(its.length?'<datalist id="'+id+'-dl">'+its.map(function(o){return '<option value="'+esc(o.sku+(o.producto?' · '+o.producto:''))+'"></option>';}).join('')+'</datalist>':'')+'<div class="small muted" style="margin-top:6px">Si hay más de tres productos, anotá el resto en las observaciones.</div></details>';}
function readDev(key,e){var its=(e&&e.items)||[],out=[],id='dvl-'+key;
  for(var k=0;k<3;k++){var t=gv(id+'-p'+k).trim(),q=parseInt(gv(id+'-q'+k),10);if(!(q>0))continue;var code=t.split(' · ')[0].trim().toUpperCase(),it=its.find(function(o){return String(o.sku).toUpperCase()===code||(o.producto&&o.producto.toLowerCase()===t.toLowerCase());});
    out.push({sku:it?it.sku:'',desc:t||'Sin detallar',qty:q,estado:gv(id+'-s'+k)==='mal'?'mal':'ok'});}
  return out;}
function extAfterRender(){
  var c=document.getElementById('sigpad');if(!c)return;
  var x=c.getContext('2d');x.lineWidth=2.4;x.lineCap='round';x.strokeStyle='#111';
  if(S.ext.sig){var im=new Image();im.onload=function(){x.drawImage(im,0,0,c.width,c.height);};im.src=S.ext.sig;}
  var down=false,last=null,moved=false;
  var pt=function(ev){var r=c.getBoundingClientRect();return {x:(ev.clientX-r.left)*c.width/r.width,y:(ev.clientY-r.top)*c.height/r.height};};
  c.addEventListener('pointerdown',function(ev){down=true;S.drawing=true;last=pt(ev);try{c.setPointerCapture(ev.pointerId);}catch(_){}ev.preventDefault();});
  c.addEventListener('pointermove',function(ev){if(!down)return;var p=pt(ev);x.beginPath();x.moveTo(last.x,last.y);x.lineTo(p.x,p.y);x.stroke();last=p;moved=true;ev.preventDefault();});
  var up=function(){if(!down)return;down=false;S.drawing=false;
    if(moved){var t=document.createElement('canvas');t.width=c.width;t.height=c.height;var tc=t.getContext('2d');tc.fillStyle='#fff';tc.fillRect(0,0,t.width,t.height);tc.drawImage(c,0,0);S.ext.sig=t.toDataURL('image/png');}
    if(S.pendingRender){S.pendingRender=false;render();}};
  c.addEventListener('pointerup',up);c.addEventListener('pointercancel',up);
}
function resizeFoto(file){return new Promise(function(res,rej){var im=new Image(),u=URL.createObjectURL(file);im.onload=function(){var m=1024,k=Math.min(1,m/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);c.getContext('2d').drawImage(im,0,0,c.width,c.height);URL.revokeObjectURL(u);c.toBlob(function(b){b?res(b):rej(new Error('foto'));},'image/jpeg',0.8);};im.onerror=function(){rej(new Error('foto'));};im.src=u;});}
function tomarGeo(){
  if(!navigator.geolocation){toast('Este aparato no permite tomar la ubicación.');return;}
  navigator.geolocation.getCurrentPosition(function(p){S.ext.geo={lat:p.coords.latitude,lng:p.coords.longitude,acc:Math.round(p.coords.accuracy)};render();},function(){toast('No se pudo tomar la ubicación. Podés confirmar igual.');},{enableHighAccuracy:true,timeout:15000,maximumAge:30000});}
function podReset(){S.ext.fts=S.ext.fts||{};S.ext.fts.pod=[];S.ext.pod=null;S.ext.sig='';S.ext.foto=null;S.ext.fotoUrl='';S.ext.geo=null;S.ext.noGeo=false;}
async function podOk(id){
  var e=D().entregas.find(function(x){return x.id===id;});if(!e)return;
  var rec=gv('pod-rec').trim(),comp=!!(document.getElementById('pod-ok')||{}).checked,nota=gv('pod-nota').trim();
  if(!rec){toast('Anotá quién recibió.');return;}
  if(!comp&&!nota){toast('Contá qué pasó (faltante o daño) en el detalle.');return;}
  if(!S.ext.sig&&!ftList('pod').length){toast('Hace falta la firma o una foto.');return;}
  var pod={receptor:rec,completa:comp,nota:nota,ts:isoNow(),firma:S.ext.sig||'',foto:'',por:actor()};var dvr=readDev('pod',e);if(dvr.length)pod.devuelve=dvr;
  if(S.ext.geo&&hasConsent()){pod.lat=S.ext.geo.lat;pod.lng=S.ext.geo.lng;pod.acc=S.ext.geo.acc;if(hasXY(e))pod.distM=Math.round(hav(S.ext.geo,e)*1000);}
  var up=await ftSubir('pod');if(up.urls.length){pod.fotos=up.urls;pod.foto=up.urls[0];}if(up.pend){pod.fotoPendiente=true;toast('Una foto no se pudo subir. La entrega se guarda igual.');}
  podReset();
  await setEstado(id,'entregada','',pod);
}
async function consentir(){
  var c={ok:true,ts:isoNow(),nombre:actor(),version:1};
  if(S.mode==='demo'){S.consentDemo=true;render();return;}
  try{await db.doc('consents/'+S.me.id).set(c);S.consent=c;toast('Consentimiento registrado');render();}catch(_){toast('No se pudo guardar. Probá de nuevo.');}
}
function panelPods(){
  var l=D().entregas.filter(function(e){return e.pod;}).sort(function(a,b){return String(b.pod.ts).localeCompare(String(a.pod.ts));}).slice(0,8);
  if(!l.length)return '';
  return '<div class="panel"><h3>Pruebas de entrega recientes</h3>'+l.map(function(e){return '<div class="pod-row"><div class="row sp"><div><span class="guia">'+esc(e.guia)+'</span> <strong>'+esc(e.cliente)+'</strong></div><span class="small muted">'+esc(fmtFecha(e.fecha))+'</span></div>'+podHtml(e)+'</div>';}).join('')+'</div>';}

/* ----- importar / exportar ----- */
var IMP_COLS=['Guía','Cliente','Chofer','Fecha','Desde','Hasta','Dirección','Latitud','Longitud','Bultos','Peso','Remito','Factura','Importe','Vence'];
var norm=function(s){return String(s==null?'':s).normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');};
var toNum=function(x){if(x==null||x==='')return NaN;if(typeof x==='number')return x;var s=String(x).trim().replace(/\s/g,'');if(/,/.test(s)&&/\./.test(s))s=s.replace(/\./g,'').replace(',','.');else s=s.replace(',','.');return parseFloat(s);};
async function leerTxt(file){
  var buf=await file.arrayBuffer(),u=new Uint8Array(buf);
  if(u[0]===0xFF&&u[1]===0xFE)return new TextDecoder('utf-16le').decode(buf);
  if(u[0]===0xFE&&u[1]===0xFF)return new TextDecoder('utf-16be').decode(buf);
  try{return new TextDecoder('utf-8',{fatal:true}).decode(buf);}catch(_){return new TextDecoder('windows-1252').decode(buf);}}
function csvParse(txt){
  txt=String(txt).replace(/^﻿/,'');var first=txt.split(/\r?\n/)[0]||'',sep=[';',',','\t'].map(function(d){return [d,first.split(d).length];}).sort(function(a,b){return b[1]-a[1]||(a[0]===';'?-1:1);})[0][0];
  var rows=[],row=[],cur='',q=false,flush=function(){row.push(cur);cur='';if(row.some(function(c){return String(c).trim()!=='';}))rows.push(row);row=[];};
  for(var i=0;i<txt.length;i++){var ch=txt[i];
    if(q){if(ch==='"'){if(txt[i+1]==='"'){cur+='"';i++;}else q=false;}else cur+=ch;}
    else if(ch==='"')q=true;else if(ch===sep){row.push(cur);cur='';}
    else if(ch==='\n'||ch==='\r'){if(ch==='\r'&&txt[i+1]==='\n')i++;flush();}
    else cur+=ch;}
  if(cur!==''||row.length)flush();return rows;}
function pFecha(v){
  if(v instanceof Date&&!isNaN(v))return new Date(v.getTime()+12*3600e3).toISOString().slice(0,10);
  if(typeof v==='number'&&v>20000)return new Date(Math.round((v-25569)*864e5)).toISOString().slice(0,10);
  var s=String(v==null?'':v).trim(),m;
  if((m=s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/)))return m[1]+'-'+pad(+m[2])+'-'+pad(+m[3]);
  if((m=s.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{2,4})/))){var y=+m[3];if(y<100)y+=2000;return y+'-'+pad(+m[2])+'-'+pad(+m[1]);}
  return '';}
function pHora(v){
  if(typeof v==='number'&&v>=0&&v<1){var t=Math.round(v*1440);return pad(Math.floor(t/60))+':'+pad(t%60);}
  if(v instanceof Date&&!isNaN(v))return pad(v.getUTCHours())+':'+pad(v.getUTCMinutes());
  var m=String(v==null?'':v).trim().match(/^(\d{1,2})[:.h](\d{2})/);return m&&+m[1]<24&&+m[2]<60?pad(+m[1])+':'+m[2]:'';}
function entregasDesdeFilas(rows){
  var out=[];if(!rows||rows.length<2)return {error:'El archivo no tiene filas para importar.',items:[]};
  var map={},alias={guia:'guia',cliente:'cliente',chofer:'chofer',fecha:'fecha',desde:'desde',hasta:'hasta',direccion:'direccion',latitud:'lat',lat:'lat',longitud:'lng',lng:'lng',bultos:'bultos',peso:'peso',pesokg:'peso',remito:'remito',factura:'factura',importe:'importe',vence:'vence',vencimiento:'vence'};
  rows[0].forEach(function(h,i){var k=alias[norm(h)];if(k&&map[k]==null)map[k]=i;});
  var need=['guia','cliente','fecha','direccion'].filter(function(k){return map[k]==null;});
  if(need.length)return {error:'Faltan columnas obligatorias: '+need.join(', ')+'. Descargá la plantilla y usá esos encabezados.',items:[]};
  var cli=D().perfiles.filter(function(p){return p.rol==='cliente';}),cho=D().perfiles.filter(function(p){return p.rol==='chofer';});
  var byName=function(l,n){n=norm(n);return l.find(function(p){return norm(p.nombre)===n;});};
  var seen={},ordN={};
  rows.slice(1).forEach(function(r,ix){
    var c=function(k){return map[k]==null?'':r[map[k]];},errs=[],warns=[];
    var guia=String(c('guia')).trim();if(!guia){errs.push('Falta la guía');}
    if(guia&&seen[guia.toLowerCase()])errs.push('Guía repetida en el archivo');seen[guia.toLowerCase()]=1;
    var cl=byName(cli,String(c('cliente')));if(!cl)errs.push('El cliente "'+String(c('cliente')).trim()+'" no existe en Usuarios');
    var ch=String(c('chofer')).trim()?byName(cho,String(c('chofer'))):null;if(String(c('chofer')).trim()&&!ch)warns.push('Chofer no encontrado: queda sin asignar');
    var fecha=pFecha(c('fecha'));if(!fecha)errs.push('Fecha no válida');
    var dir=String(c('direccion')).trim();if(!dir)errs.push('Falta la dirección');
    var des=pHora(c('desde')),has=pHora(c('hasta'));if(!des||!has){warns.push('Sin ventana horaria: se usa 08:00 a 18:00');des=des||'08:00';has=has||'18:00';}
    var lat=toNum(c('lat')),lng=toNum(c('lng')),hasXYv=!isNaN(lat)&&!isNaN(lng)&&Math.abs(lat)<=90&&Math.abs(lng)<=180;
    if(!hasXYv&&(String(c('lat')).trim()||String(c('lng')).trim()))warns.push('Coordenadas no válidas: se ignoran');
    var old=guia?D().entregas.find(function(e){return String(e.guia).toLowerCase()===guia.toLowerCase();}):null;
    var e=null;
    if(!errs.length){
      e=old?clean(old):{id:S.mode==='demo'?'d-'+Date.now().toString(36)+ix:db.collection('entregas').doc().id,estado:'programada',observaciones:[],historial:[{estado:'programada',ts:isoNow(),por:actor()}],remito:{numero:'',url:''},factura:null};
      e.guia=guia;e.clienteId=cl.id;e.cliente=cl.nombre;e.direccion=dir;e.fecha=fecha;e.desde=des;e.hasta=has;
      if(ch){e.choferId=ch.id;e.chofer=ch.nombre;}else if(!old){e.choferId='';e.chofer='';}
      if(hasXYv){e.lat=lat;e.lng=lng;}
      var b=parseInt(toNum(c('bultos')),10);if(b>0)e.bultos=b;else if(!old)e.bultos=1;
      var pk=toNum(c('peso'));if(pk>0)e.pesoKg=pk;
      var rm=String(c('remito')).trim();if(rm)e.remito={numero:rm,url:(old&&old.remito&&old.remito.url)||''};
      var fn=String(c('factura')).trim(),im=toNum(c('importe')),vc=pFecha(c('vence'));
      if(fn||im>0){var pf=(old&&old.factura)||{};e.factura={numero:fn||pf.numero||'',importe:im>0?im:(pf.importe||0),estado:pf.estado||(fn?'emitida':'pendiente'),vence:vc||pf.vence||'',url:pf.url||''};}
      if(!old){var kk=(e.choferId||'-')+'|'+fecha;ordN[kk]=(ordN[kk]!=null?ordN[kk]:D().entregas.filter(function(x){return x.choferId===e.choferId&&x.fecha===fecha;}).length)+1;e.orden=ordN[kk];}
    }
    out.push({fila:ix+2,guia:guia,accion:errs.length?'error':old?'actualiza':'nueva',errs:errs,warns:warns,e:e});
  });
  return {items:out};}
function csvOut(rows){return '﻿'+rows.map(function(r){return r.map(function(c){c=c==null?'':String(c);return /[;"\n\r]/.test(c)?'"'+c.replace(/"/g,'""')+'"':c;}).join(';');}).join('\r\n');}
async function guardarArchivo(name,text,mime){
  try{var dl=window.claude&&window.claude.use?await window.claude.use('downloads'):null;if(dl){await dl.save({filename:name,data:new Blob([text],{type:mime})});return;}}catch(_){}
  var a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type:mime}));a.download=name;document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},1500);}
function exportEntregas(){
  var rows=[IMP_COLS.concat(['Estado','Entregada a las','Recibió','Completa','Distancia a la dirección (m)'])];
  D().entregas.slice().sort(function(a,b){return (a.fecha+a.desde).localeCompare(b.fecha+b.desde);}).forEach(function(e){
    var h=(e.historial||[]).filter(function(x){return x.estado==='entregada';}).slice(-1)[0],f=e.factura||{};
    rows.push([e.guia,e.cliente,e.chofer||'',e.fecha,e.desde,e.hasta,e.direccion,hasXY(e)?e.lat:'',hasXY(e)?e.lng:'',e.bultos||'',e.pesoKg||'',(e.remito&&e.remito.numero)||'',f.numero||'',f.importe||'',f.vence||'',(EST[e.estado]||[e.estado])[0],h?new Date(h.ts).toLocaleString('es-AR'):'',e.pod?e.pod.receptor:'',e.pod?(e.pod.completa===false?'No':'Sí'):'',e.pod&&e.pod.distM!=null?e.pod.distM:'']);});
  guardarArchivo('entregas-'+HOY+'.csv',csvOut(rows),'text/csv;charset=utf-8');}
function plantillaCsv(){
  var rows=[IMP_COLS,['G-9001','Ferretería Del Plata','Marcos Peralta',addDays(1),'09:00','12:00','Av. Mitre 1890, Wilde','-34.6989','-58.3156','6','420','R-0003-00009001','','',''],['G-9002','Pinturería Los Aromos','','',addDays(2),'','','','','','','','','','']].slice(0,2);
  guardarArchivo('plantilla-entregas.csv',csvOut(rows),'text/csv;charset=utf-8');}
function respaldoJson(){
  var d=D(),o={generado:isoNow(),entregas:d.entregas,perfiles:d.perfiles,equipos:d.equipos,checks:d.checks,gastos:d.gastos||[],ordenes:d.ordenes||[],plantillas:d.plantillas||[],viajes:d.viajes,wms:d.wms};
  guardarArchivo('respaldo-'+HOY+'.json',JSON.stringify(o,null,1),'application/json');}
async function leerArchivoFilas(f){
  if(/\.(csv|txt)$/i.test(f.name))return csvParse(await leerTxt(f));
  await loadXLSX();var wb=XLSX.read(await f.arrayBuffer(),{type:'array',cellDates:true}),ws=wb.Sheets[wb.SheetNames[0]];
  return XLSX.utils.sheet_to_json(ws,{header:1,raw:true,defval:''});}
async function aplicarImport(){
  var imp=S.ext.imp;if(!imp)return;var ok=imp.items.filter(function(i){return i.e;}),n=0;
  if(S.mode!=='demo'&&ok.length>5){
    var post=function(coll,docs){return fetch('/api/docs/bulk',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({coll:coll,docs:docs})}).then(function(r){if(!r.ok)throw new Error('bulk');});},ds=ok.map(function(i){return clean(i.e);}),por={};
    toast('Importando '+ds.length+' entregas…');
    try{for(var a=0;a<ds.length;a+=300){var ch=ds.slice(a,a+300);await post('entregas',ch.map(function(e){return {id:e.id,data:e};}));
        ch.forEach(function(e){if(e.clienteId)(por[e.clienteId]=por[e.clienteId]||[]).push({id:e.id,data:e});});n+=ch.length;}
      for(var k in por)await post('portal/'+k+'/entregas',por[k]);}catch(_){}
  }else for(var i=0;i<ok.length;i++){try{await persist(ok[i].e);n++;}catch(_){}}
  S.ext.imp=null;toast(n+' entrega'+(n===1?'':'s')+' importada'+(n===1?'':'s')+(n<ok.length?' ('+(ok.length-n)+' fallaron)':'')+'.');render();}
function xImp(){
  var imp=S.ext.imp,st=standalone();
  var h='<div class="panel"><h3>Importar entregas desde Excel o CSV</h3><p class="small muted">Sirve para cargar de una vez lo que sale de tu ERP o de una planilla. La <strong>guía</strong> identifica la entrega: si ya existe se actualiza (sin perder estado, historial ni prueba de entrega); si no, se crea. El cliente debe existir en Usuarios con el mismo nombre.</p><div class="row"><button class="btn" data-act="x-plantilla">Descargar plantilla (CSV)</button><label class="btn pri" style="cursor:pointer">Elegir archivo<input id="imp-file" type="file" accept=".csv,.txt,.xlsx,.xls" hidden></label></div></div>';
  if(imp){
    if(imp.error)h+='<div class="banner bad" role="alert">'+ICON.alert+'<div><strong>No se pudo leer el archivo</strong>'+esc(imp.error)+'</div></div>';
    else{var ok=imp.items.filter(function(i){return i.e;}),er=imp.items.length-ok.length,nw=ok.filter(function(i){return i.accion==='nueva';}).length;
      h+='<div class="panel"><h3>Vista previa</h3><div class="row"><span class="chip ok">'+nw+' nuevas</span><span class="chip signal">'+(ok.length-nw)+' a actualizar</span>'+(er?'<span class="chip bad">'+er+' con error (no se importan)</span>':'')+'</div>'+
        tbl(['Fila','Guía','Acción','Avisos'],imp.items.slice(0,200).map(function(i){return [i.fila,esc(i.guia||'—'),'<span class="chip '+(i.accion==='error'?'bad':i.accion==='nueva'?'ok':'signal')+'">'+i.accion+'</span>',esc(i.errs.concat(i.warns).join(' · '))||'—'];}),520)+
        (ok.length?'<div class="row" style="margin-top:12px"><button class="btn ok" data-act="x-impok">Importar '+ok.length+'</button><button class="btn" data-act="x-impno">Descartar</button></div>':'<div class="row" style="margin-top:12px"><button class="btn" data-act="x-impno">Cerrar</button></div>')+'</div>';}
  }
  h+='<div class="panel"><h3>Exportar</h3><p class="small muted">Las entregas con su estado, hora de entrega, quién recibió y distancia a la dirección. Se abre en Excel.</p><div class="row"><button class="btn" data-act="x-export">Descargar entregas (CSV)</button></div></div>';
  if(st)h+='<div class="panel"><h3>Conexión automática con tu ERP</h3><p class="small muted">El servidor ofrece <span class="mono">POST /api/integracion/entregas</span> (alta o actualización por guía) y <span class="mono">GET /api/integracion/entregas</span> (estado y prueba de entrega) con el encabezado <span class="mono">X-API-Key</span>. Se activa definiendo <span class="mono">INTEGRATION_KEY</span> en el archivo .env. Detalle en el README.</p></div>';
  return h;}
var standalone=function(){return !!window.APP_CONFIG;};

/* ----- indicadores de servicio y costos de flota ----- */
function perSel(){return '<label>Período<select id="x-per"><option value="7"'+(S.ext.per==='7'?' selected':'')+'>Últimos 7 días</option><option value="30"'+(S.ext.per==='30'?' selected':'')+'>Últimos 30 días</option><option value="90"'+(S.ext.per==='90'?' selected':'')+'>Últimos 90 días</option></select></label>';}
function finalizadas(dias){var desde=addDays(-dias);return D().entregas.filter(function(e){return e.fecha>=desde&&e.fecha<=HOY&&(e.estado==='entregada'||e.estado==='no_entregada');});}
function enHora(e){var h=(e.historial||[]).filter(function(x){return x.estado==='entregada';}).slice(-1)[0];if(!h)return null;return new Date(h.ts)<=new Date(e.fecha+'T'+(e.hasta||'23:59')+':00');}
var completa=function(e){return !e.pod||e.pod.completa!==false;};
var pcn=function(a,b){return b?a/b*100:null;},fp=function(v){return v==null?'—':nf(v,1)+'%';};
function motivoDe(e){var o=(e.observaciones||[]).filter(function(x){return /^No entregada: /.test(x.texto);}).slice(-1)[0];return o?o.texto.replace(/^No entregada: /,'').replace(/\.$/,''):'Sin motivo cargado';}
function lunes(s){var p=s.split('-').map(Number),d=new Date(p[0],p[1]-1,p[2]);d.setDate(d.getDate()-((d.getDay()+6)%7));return ymd(d);}
function xInd(){
  var dias=parseInt(S.ext.per,10)||30,fin=finalizadas(dias),ent=fin.filter(function(e){return e.estado==='entregada';});
  var h='<div class="row sp"><h2>Indicadores de servicio</h2>'+perSel()+'</div>';
  if(!fin.length)return h+'<div class="empty">Todavía no hay entregas finalizadas en este período.</div>';
  var enH=ent.filter(function(e){return enHora(e)===true;}),comp=ent.filter(completa),otif=ent.filter(function(e){return enHora(e)===true&&completa(e);});
  var o=pcn(otif.length,fin.length);
  h+='<div class="kpis">'+KPI(fp(o),'OTIF','a tiempo y completas / intentadas',o>=95?'ok':o>=85?'warn':'bad')+KPI(fp(pcn(enH.length,ent.length)),'Entregas en hora','dentro de la ventana pactada')+KPI(fp(pcn(comp.length,ent.length)),'Entregas completas','sin faltantes ni daños')+KPI(fp(pcn(ent.length,fin.length)),'Éxito de entrega',(fin.length-ent.length)+' no entregadas')+KPI(fin.length,'Entregas intentadas','en '+dias+' días')+'</div>';
  var causas={};fin.filter(function(e){return e.estado==='no_entregada';}).forEach(function(e){var m=motivoDe(e);causas[m]=(causas[m]||0)+1;});
  var ck=Object.keys(causas).sort(function(a,b){return causas[b]-causas[a];}),cmax=causas[ck[0]]||1;
  h+='<div class="panel"><h3>Por qué no se entregó</h3>'+(ck.length?ck.map(function(k){return '<div class="row" style="flex-wrap:nowrap"><span style="width:190px">'+esc(k)+'</span><div class="bar" style="flex:1"><i style="width:'+Math.round(causas[k]/cmax*100)+'%;background:var(--bad)"></i></div><strong>'+causas[k]+'</strong></div>';}).join(''):'<div class="small muted">Sin entregas fallidas en el período.</div>')+'</div>';
  var wk={};fin.forEach(function(e){var k=lunes(e.fecha);(wk[k]=wk[k]||[]).push(e);});
  var ws=[];for(var i=5;i>=0;i--)ws.push(lunes(addDays(-7*i)));
  var pts=ws.map(function(k){var l=wk[k]||[],ok=l.filter(function(e){return e.estado==='entregada'&&enHora(e)===true&&completa(e);}).length;return {k:k,n:l.length,v:l.length?ok/l.length*100:null};});
  var W2=600,H2=170,bw=60,g='';pts.forEach(function(p,i){var x=20+i*(W2-20)/6+10,hh=p.v==null?0:p.v/100*(H2-50);g+='<rect x="'+x+'" y="'+(H2-30-hh)+'" width="'+bw+'" height="'+hh+'" rx="3" style="fill:var(--'+(p.v==null?'neutral-bg':p.v>=95?'ok':p.v>=85?'warn':'bad')+')"><title>'+esc(p.k)+': '+fp(p.v)+' ('+p.n+' entregas)</title></rect><text x="'+(x+bw/2)+'" y="'+(H2-34-hh)+'" text-anchor="middle">'+(p.v==null?'':Math.round(p.v)+'%')+'</text><text x="'+(x+bw/2)+'" y="'+(H2-12)+'" text-anchor="middle">'+esc(p.k.slice(8)+'/'+p.k.slice(5,7))+'</text>';});
  h+='<div class="panel"><h3>OTIF por semana (semana que empieza el…)</h3><svg class="chart" viewBox="0 0 '+W2+' '+H2+'" width="100%" role="img" aria-label="OTIF por semana">'+g+'</svg></div>';
  var fl=[];(D().perfiles||[]).filter(function(p){return p.rol==='chofer';}).forEach(function(c){
    var eq=(D().equipos||[]).find(function(e){return e.asignado===c.id&&(e.tipo==='camion'||e.tipo==='utilitario');});if(!eq||!eq.cap)return;
    var porDia={};D().entregas.filter(function(e){return e.choferId===c.id&&e.fecha>=addDays(-dias)&&e.fecha<=HOY&&e.pesoKg>0;}).forEach(function(e){porDia[e.fecha]=(porDia[e.fecha]||0)+e.pesoKg;});
    var ds=Object.keys(porDia);if(!ds.length)return;var us=ds.map(function(d){return porDia[d]/eq.cap*100;});
    fl.push([esc(c.nombre),esc(eq.nombre)+'<div class="small muted">'+nf(eq.cap)+' kg</div>',ds.length,fp(us.reduce(function(a,b){return a+b;},0)/us.length),fp(Math.max.apply(null,us))]);});
  h+='<div class="panel"><h3>Uso de la capacidad de la flota</h3>'+(fl.length?tbl(['Chofer','Equipo','Días con carga','Promedio','Máximo'],fl,480)+'<div class="small muted" style="margin-top:8px">Peso cargado por día sobre la capacidad del equipo asignado. Requiere el peso (kg) en cada entrega.</div>':'<div class="small muted">Cargá el peso (kg) de las entregas y asigná un equipo a cada chofer para ver este indicador.</div>')+'</div>';
  return h;}
function gPut(g){g=clean(g);if(S.mode==='demo'){upsertLocal(S.data.demo.gastos,g);render();return Promise.resolve();}return db.doc('gastos/'+g.id).set(g);}
function gDel(id){if(S.mode==='demo'){S.data.demo.gastos=S.data.demo.gastos.filter(function(x){return x.id!==id;});render();return Promise.resolve();}return db.doc('gastos/'+id).delete();}
function gastoForm(){
  var eqs=(D().equipos||[]).filter(function(e){return e.tipo==='camion'||e.tipo==='utilitario';}),yo=miId(),mine=eqs.find(function(e){return e.asignado===yo;});
  return '<form class="panel" id="x-form-gasto" autocomplete="off"><h3>Cargar combustible, peaje u otro gasto</h3><div class="grid2">'+
   '<label>Equipo<select id="g-eq">'+eqs.map(function(e){return '<option value="'+esc(e.id)+'"'+(mine&&mine.id===e.id?' selected':'')+'>'+esc(e.nombre)+' · '+esc(e.ident||'')+'</option>';}).join('')+'</select></label>'+
   '<label>Tipo<select id="g-tipo"><option value="combustible">Combustible</option><option value="peaje">Peaje</option><option value="otro">Otro</option></select></label>'+
   '<label>Importe ($)<input id="g-imp" type="number" min="1" step="any" required></label><label>Litros (si es combustible)<input id="g-lit" type="number" min="0" step="any"></label>'+
   '<label>Kilometraje del tablero<input id="g-odo" type="number" min="0" step="any"></label><label>Nota<input id="g-nota" maxlength="120"></label></div>'+
   '<div class="row"><button class="btn pri" type="submit">Guardar gasto</button></div><div class="small muted">Con litros y kilometraje en cada carga, el portal calcula el consumo real por equipo.</div></form>';}
function panelGasto(){
  if(!(D().equipos||[]).some(function(e){return e.tipo==='camion'||e.tipo==='utilitario';}))return '';
  return S.ext.gasto?gastoForm()+'<div class="row" style="margin:-8px 0 12px"><button class="btn sm" data-act="x-gtog">Cerrar</button></div>':'<div class="row" style="margin:8px 0"><button class="btn sm" data-act="x-gtog">Cargar combustible o peaje</button></div>';}
function lectEq(eq){var best=null;(D().checks||[]).forEach(function(c){if(c.equipoId===eq.id&&typeof c.lect==='number'&&(!best||c.ts>best.ts))best=c;});var o=0;(D().gastos||[]).forEach(function(g){if(g.equipoId===eq.id&&g.odo>o)o=g.odo;});return Math.max(best?best.lect:0,o);}
function xCost(){
  var dias=parseInt(S.ext.per,10)||30,desde=addDays(-dias),gs=(D().gastos||[]).filter(function(g){return g.fecha>=desde&&g.fecha<=HOY;}),ots=(D().ordenes||[]).filter(function(o){return o.estado==='cerrada'&&o.costo>0&&String(o.cierre||'').slice(0,10)>=desde;});
  var eqs=(D().equipos||[]).filter(function(e){return e.tipo==='camion'||e.tipo==='utilitario';});
  var tot=gs.reduce(function(t,g){return t+(g.importe||0);},0)+ots.reduce(function(t,o){return t+o.costo;},0),entr=finalizadas(dias).filter(function(e){return e.estado==='entregada';}).length;
  var rows=eqs.map(function(eq){
    var g=gs.filter(function(x){return x.equipoId===eq.id;}),comb=g.filter(function(x){return x.tipo==='combustible';}),mant=ots.filter(function(o){return o.equipoId===eq.id;}).reduce(function(t,o){return t+o.costo;},0);
    var ca=comb.filter(function(x){return x.odo>0;}).sort(function(a,b){return a.odo-b.odo;}),km=ca.length>1?ca[ca.length-1].odo-ca[0].odo:0,lit=ca.slice(1).reduce(function(t,x){return t+(x.litros||0);},0);
    var total=g.reduce(function(t,x){return t+(x.importe||0);},0)+mant;
    return [esc(eq.nombre)+'<div class="small muted">'+esc(eq.ident||'')+'</div>',fmtARS(comb.reduce(function(t,x){return t+(x.importe||0);},0)),fmtARS(g.filter(function(x){return x.tipo==='peaje';}).reduce(function(t,x){return t+(x.importe||0);},0)),fmtARS(mant),'<strong>'+fmtARS(total)+'</strong>',km?nf(km)+' km':'—',km&&lit?nf(lit/km*100,1)+' L/100 km':'—',km?fmtARS(total/km)+'/km':'—'];});
  var h='<div class="row sp"><h2>Costos de flota</h2>'+perSel()+'</div>';
  h+='<div class="kpis">'+KPI(fm(tot),'Costo total','combustible, peajes, otros y mantenimiento')+KPI(entr?fmtARS(tot/entr):'—','Costo por entrega','sobre '+entr+' entregas logradas')+KPI(gs.length,'Gastos cargados','en '+dias+' días')+'</div>';
  h+='<div class="panel"><h3>Por equipo</h3>'+(eqs.length?tbl(['Equipo','Combustible','Peajes','Mantenimiento','Total','Recorrido','Consumo real','Costo por km'],rows,780)+'<div class="small muted" style="margin-top:8px">El consumo se calcula entre la primera y la última carga con kilometraje del período (la primera carga no se cuenta porque llena lo recorrido antes). Mantenimiento = órdenes de trabajo cerradas con costo.</div>':'<div class="small muted">No hay camiones ni utilitarios cargados en Equipos.</div>')+'</div>';
  h+=gastoForm();
  var last=(D().gastos||[]).slice().sort(function(a,b){return (b.fecha+b.id).localeCompare(a.fecha+a.id);}).slice(0,15);
  h+='<div class="panel"><h3>Últimos gastos</h3>'+(last.length?tbl(['Fecha','Equipo','Tipo','Importe','Litros','Km','Cargó',''],last.map(function(g){return [esc(fmtFecha(g.fecha)),esc(g.equipo||''),esc(g.tipo),fmtARS(g.importe),g.litros?nf(g.litros,1):'—',g.odo?nf(g.odo):'—',esc(g.por||'—'),S.ui.confirmDel==='g'+g.id?'<button class="btn sm bad" data-act="x-gdel" data-id="'+esc(g.id)+'">Quitar</button> <button class="btn sm" data-act="x-gno">No</button>':'<button class="btn sm" data-act="x-gdel" data-id="'+esc(g.id)+'">Quitar</button>'];}),620):'<div class="small muted">Todavía no hay gastos.</div>')+'</div>';
  return h;}
async function gastoGuardar(){
  var imp=gnum('g-imp'),lit=gnum('g-lit'),odo=gnum('g-odo'),tipo=gv('g-tipo'),eq=(D().equipos||[]).find(function(e){return e.id===gv('g-eq');});
  if(!eq){toast('Elegí un equipo.');return;}if(!(imp>0)){toast('Anotá el importe.');return;}
  if(tipo==='combustible'&&!(lit>0)){toast('Anotá los litros cargados.');return;}
  var g={id:S.mode==='demo'?uid('g-'):db.collection('gastos').doc().id,fecha:HOY,tipo:tipo,equipoId:eq.id,equipo:eq.nombre,importe:imp,litros:lit>0?lit:0,odo:odo>0?odo:0,nota:gv('g-nota').trim(),porId:miId()||'',por:actor(),ts:isoNow()};
  await gPut(g);S.ext.gasto=false;toast('Gasto guardado');render();}

/* ----- mantenimiento: órdenes de trabajo, service por km/horas, listas editables ----- */
function otPut(o){o=clean(o);if(S.mode==='demo'){upsertLocal(S.data.demo.ordenes,o);render();return Promise.resolve();}return db.doc('ordenes/'+o.id).set(o);}
async function otDesdeCheck(eq,doc){
  if(!doc.fallas||!doc.fallas.length)return;
  var crit=doc.fallas.some(function(f){return f.crit;});
  await otPut({id:S.mode==='demo'?uid('ot-'):db.collection('ordenes').doc().id,equipoId:eq.id,equipo:eq.nombre,titulo:'Falla en check list: '+doc.fallas.map(function(f){return f.texto;}).join('; ').slice(0,200),origen:'check',checkId:doc.id||'',estado:'abierta',prio:crit?'alta':'media',creada:isoNow(),por:doc.por||'',fallas:doc.fallas,costo:0});}
function servDue(eq){if(!eq.servCada||!(eq.servCada>0))return null;var l=lectEq(eq),prox=(eq.servUlt||0)+eq.servCada;return {lect:l,prox:prox,resta:prox-l};}
function xMant(){
  var ots=(D().ordenes||[]).slice().sort(function(a,b){return (a.estado==='cerrada')-(b.estado==='cerrada')||String(b.creada).localeCompare(String(a.creada));}),ab=ots.filter(function(o){return o.estado!=='cerrada';}),ce=ots.filter(function(o){return o.estado==='cerrada'&&o.cierre;});
  var avg=ce.length?ce.reduce(function(t,o){return t+(new Date(o.cierre)-new Date(o.creada))/864e5;},0)/ce.length:null;
  var eqs=D().equipos||[],due=eqs.filter(function(e){var d=servDue(e);return d&&d.resta<=0&&!ab.some(function(o){return o.origen==='servicio'&&o.equipoId===e.id;});});
  var h='<div class="row sp"><h2>Mantenimiento</h2></div><div class="kpis">'+KPI(ab.length,'Órdenes abiertas','las críticas se ven en rojo',ab.some(function(o){return o.prio==='alta';})?'bad':'ok')+KPI(ce.length,'Cerradas','historial completo')+KPI(avg==null?'—':nf(avg,1)+' d','Tiempo medio de cierre','desde que se abre')+'</div>';
  if(due.length)h+='<div class="banner warn" role="status">'+ICON.alert+'<div><strong>'+due.length+' equipo'+(due.length>1?'s':'')+' con service vencido</strong>'+due.map(function(e){return esc(e.nombre)+' <button class="btn sm" data-act="x-svot" data-id="'+esc(e.id)+'">Generar orden</button>';}).join(' · ')+'</div></div>';
  h+='<div class="panel"><h3>Órdenes de trabajo</h3>'+(ots.length?ots.map(function(o){
    var cl=S.ext.otClose===o.id;
    return '<div class="ot'+(o.estado==='cerrada'?' done':'')+'"><div class="row sp"><div><span class="chip '+(o.prio==='alta'?'bad':'warn')+'">'+(o.prio==='alta'?'Crítica':'Media')+'</span> <span class="chip '+(o.estado==='cerrada'?'ok':o.estado==='en_curso'?'signal':'')+'">'+({abierta:'Abierta',en_curso:'En curso',cerrada:'Cerrada'}[o.estado])+'</span> <strong>'+esc(o.equipo)+'</strong></div><span class="small muted">'+esc(fmtFecha(String(o.creada).slice(0,10)))+' · '+({check:'por check list',servicio:'service programado',manual:'manual'}[o.origen]||'')+'</span></div><div class="small">'+esc(o.titulo)+'</div>'+(o.estado==='cerrada'?'<div class="small muted">Cerrada '+esc(fmtFecha(String(o.cierre).slice(0,10)))+(o.costo>0?' · '+fmtARS(o.costo):'')+(o.nota?' · '+esc(o.nota):'')+'</div>':'')+
      (o.estado!=='cerrada'?'<div class="row">'+(o.estado==='abierta'?'<button class="btn sm" data-act="x-otest" data-id="'+esc(o.id)+'" data-v="en_curso">Tomar</button>':'')+'<button class="btn sm ok" data-act="x-otcerrar" data-id="'+esc(o.id)+'">Cerrar…</button></div>':'')+
      (cl?'<div class="row"><label>Costo ($)<input id="ot-costo" type="number" min="0" step="any"></label><label style="flex:1;min-width:180px">Qué se hizo<input id="ot-nota" maxlength="160"></label><button class="btn ok" data-act="x-otok" data-id="'+esc(o.id)+'">Cerrar orden</button></div>':'')+'</div>';}).join(''):'<div class="small muted">No hay órdenes. Se crean solas cuando un check list tiene fallas, o por service vencido.</div>')+'</div>';
  h+='<div class="panel"><h3>Service por kilometraje u horas</h3><p class="small muted">Definí cada cuánto se hace el service y la lectura del último. La lectura actual sale del último check list o de la última carga de combustible.</p>'+
    tbl(['Equipo','Lectura actual','Cada','Último service a','Próximo',''],eqs.map(function(e){var d=servDue(e);return [esc(e.nombre),nf(lectEq(e))||'—','<input id="sv-c-'+esc(e.id)+'" type="number" min="0" value="'+esc(e.servCada||'')+'" style="width:90px">','<input id="sv-u-'+esc(e.id)+'" type="number" min="0" value="'+esc(e.servUlt==null?'':e.servUlt)+'" style="width:90px">',d?(d.resta<=0?'<span class="chip bad">Vencido</span>':'en '+nf(d.resta)):'—','<button class="btn sm" data-act="x-svsave" data-id="'+esc(e.id)+'">Guardar</button>'];}),620)+'</div>';
  return h;}
function xListas(){
  var h='<div class="row sp"><h2>Listas de control</h2></div><p class="small muted">Cada empresa ajusta estas listas a su equipo y a su normativa de higiene y seguridad. Escribí un punto por línea con el formato <span class="mono">Grupo | Texto | crítico</span> (escribí "si" en crítico si una falla deja el equipo fuera de servicio). Los puntos que no cambian conservan su historial.</p>';
  var seen={};Object.keys(TIPOS).forEach(function(t){var k=TIPOS[t][1];if(seen[k])return;seen[k]=1;
    var tpl=tplDe(t),pl=(D().plantillas||[]).find(function(x){return x.id===k;});
    h+='<div class="panel"><h3>'+(k==='camion'?'Camiones y utilitarios':'Autoelevadores y apiladores')+(pl?' <span class="chip signal">Personalizada</span>':' <span class="chip">Estándar</span>')+'</h3>'+
      '<label>Lista<textarea id="pl-'+k+'" rows="10" style="font-family:var(--mono,monospace);font-size:13px">'+esc(tpl.items.map(function(it){return it[1]+' | '+it[2]+' | '+(it[3]?'si':'no');}).join('\n'))+'</textarea></label>'+
      '<label>Fuente (manual del fabricante, normativa, procedimiento interno)<input id="pf-'+k+'" maxlength="160" value="'+esc((pl&&pl.fuente)||'')+'" placeholder="Ej.: Manual Toyota 8FGU25, cap. 4 · procedimiento HyS-012"></label>'+
      '<div class="row"><button class="btn pri" data-act="x-plsave" data-v="'+k+'">Guardar lista</button>'+(pl?'<button class="btn" data-act="x-plreset" data-v="'+k+'">Volver a la estándar</button>':'')+'</div></div>';});
  return h;}
async function plGuardar(k){
  var base=CHK[k].items,lines=gv('pl-'+k).split('\n').map(function(l){return l.trim();}).filter(Boolean),items=[],used={};
  for(var i=0;i<lines.length;i++){var p=lines[i].split('|').map(function(x){return x.trim();});if(p.length<2||!p[0]||!p[1]){toast('Línea '+(i+1)+': usá "Grupo | Texto | crítico".');return;}
    var old=((D().plantillas||[]).find(function(x){return x.id===k;})||{items:base}).items.find(function(it){return it[2]===p[1]&&!used[it[0]];});
    var id=old?old[0]:'n'+Date.now().toString(36)+i;used[id]=1;items.push([id,p[0],p[1],/^(si|sí|1|x|true)$/i.test(p[2]||'')?1:0]);}
  if(!items.length){toast('La lista no puede quedar vacía.');return;}
  var o={id:k,items:items,fuente:gv('pf-'+k).trim(),actualizada:isoNow(),por:actor()};
  if(S.mode==='demo')upsertLocal(S.data.demo.plantillas,o);else await db.doc('plantillas/'+k).set(o);
  toast('Lista guardada');render();}

/* ----- rutas con ventanas horarias y capacidad ----- */
function simRuta(start,seq,t0,spd,svc){var t=t0,p=start,km=0,late=0,rows=[];
  seq.forEach(function(s){var d=hasXY(s)&&p?hav(p,s)*FACTOR:0;km+=d;t+=d/spd*60;var d0=toMin(s.desde),d1=toMin(s.hasta),wait=0;if(t<d0){wait=d0-t;t=d0;}var l=Math.max(0,t-d1);late+=l;rows.push({e:s,eta:t,wait:wait,late:l});t+=svc;if(hasXY(s))p=s;});
  return {km:km,late:late,rows:rows,end:t};}
function optimizeTW(start,stops,t0,spd,svc){
  var cost=function(seq){var r=simRuta(start,seq,t0,spd,svc);return r.km+r.late*0.8;};
  var rest=stops.slice(),out=[],p=start,t=t0;
  while(rest.length){var bi=0,bs=1e12;
    rest.forEach(function(s,i){var d=hasXY(s)&&p?hav(p,s)*FACTOR:0,arr=Math.max(t+d/spd*60,toMin(s.desde)),slack=toMin(s.hasta)-arr,sc=d+Math.max(0,60-slack)*0.15+Math.max(0,-slack)*2;if(sc<bs){bs=sc;bi=i;}});
    var s=rest.splice(bi,1)[0],d2=hasXY(s)&&p?hav(p,s)*FACTOR:0;t=Math.max(t+d2/spd*60,toMin(s.desde))+svc;if(hasXY(s))p=s;out.push(s);}
  var best=cost(out),imp=true,g=0;
  while(imp&&g++<30){imp=false;
    for(var i=0;i<out.length-1;i++)for(var j=i+1;j<out.length;j++){var c=out.slice(0,i).concat(out.slice(i,j+1).reverse(),out.slice(j+1)),cc=cost(c);if(cc<best-1e-9){out=c;best=cc;imp=true;}}
    for(var a=0;a<out.length;a++)for(var b=0;b<out.length;b++){if(a===b)continue;var c2=out.slice(),m=c2.splice(a,1)[0];c2.splice(b,0,m);var c3=cost(c2);if(c3<best-1e-9){out=c2;best=c3;imp=true;}}}
  return out;}
function rutaCtx(){
  var ch=S.ui.optChofer||(D().perfiles.filter(function(p){return p.rol==='chofer';})[0]||{}).id,dia=diaStr(S.ui.optDia==='manana'?'manana':'hoy');
  var route=D().entregas.filter(function(e){return e.choferId===ch&&e.fecha===dia;}).sort(function(a,b){return (a.orden||0)-(b.orden||0);}),locked=[];
  for(var i=0;i<route.length;i++){var s=route[i];if(s.estado==='entregada'||s.estado==='no_entregada'||s.estado==='en_camino')locked.push(s);else break;}
  var free=route.filter(function(e){return locked.indexOf(e)<0;}),ll=locked.filter(hasXY).slice(-1)[0],now=new Date(),t0=dia===HOY?Math.max(now.getHours()*60+now.getMinutes(),0):480;
  return {ch:ch,dia:dia,route:route,locked:locked,free:free,start:ll||D().depot,t0:t0};}
function panelVentanas(){
  var c=rutaCtx(),v=S.ext.vrp;if(!c.free.length)return '';
  var xy=c.free.filter(hasXY),noxy=c.free.filter(function(e){return !hasXY(e);}),opt=optimizeTW(c.start,xy,c.t0,v.spd,v.svc).concat(noxy);
  var a=simRuta(c.start,c.free,c.t0,v.spd,v.svc),b=simRuta(c.start,opt,c.t0,v.spd,v.svc);
  var eq=(D().equipos||[]).find(function(e){return e.asignado===c.ch&&(e.tipo==='camion'||e.tipo==='utilitario');}),kg=c.route.filter(function(e){return e.estado!=='no_entregada';}).reduce(function(t,e){return t+(e.pesoKg||0);},0);
  var cap=eq&&eq.cap?'<div class="banner '+(kg>eq.cap?'bad':'info')+'" role="status">'+(kg>eq.cap?ICON.alert:ICON.truck)+'<div><strong>Carga del día: '+nf(kg)+' kg de '+nf(eq.cap)+' kg ('+nf(kg/eq.cap*100)+'%)</strong>'+(kg>eq.cap?'Supera la capacidad de '+esc(eq.nombre)+': hay que dividir la ruta o sumar otro vehículo.':'Equipo: '+esc(eq.nombre)+'.')+'</div></div>':'';
  return '<div class="panel"><h3>Orden con ventanas horarias</h3><p class="small muted">Calcula la hora estimada de llegada a cada parada con velocidad media y tiempo de descarga, y busca un orden que reduzca km y llegadas tarde. Es una heurística: no garantiza el óptimo ni usa el tránsito real.</p>'+
   '<div class="row"><label>Velocidad media (km/h)<input id="x-spd" type="number" min="10" max="90" value="'+v.spd+'" style="width:100px"></label><label>Minutos por parada<input id="x-svc" type="number" min="0" max="120" value="'+v.svc+'" style="width:100px"></label></div>'+cap+
   '<div class="row"><span class="chip">Orden actual: '+nf(a.km,1)+' km · '+(a.late?'<b style="color:var(--bad)">'+nf(a.late)+' min tarde</b>':'sin atrasos')+'</span><span class="chip ok">Con ventanas: '+nf(b.km,1)+' km · '+(b.late?nf(b.late)+' min tarde':'sin atrasos')+'</span></div>'+
   tbl(['#','Cliente','Ventana','Llegada estimada','Estado'],b.rows.map(function(r,i){return [i+1,esc(r.e.cliente),esc(ventana(r.e)),hhmm(r.eta),r.late>0?'<span class="chip bad">'+nf(r.late)+' min tarde</span>':r.wait>0?'<span class="chip warn">espera '+nf(r.wait)+' min</span>':'<span class="chip ok">a tiempo</span>'];}),460)+
   '<div class="row" style="margin-top:12px"><button class="btn pri" data-act="x-aplicarvt">Aplicar este orden</button></div></div>';}
async function aplicarVT(){
  var c=rutaCtx(),v=S.ext.vrp,xy=c.free.filter(hasXY),noxy=c.free.filter(function(e){return !hasXY(e);}),final=c.locked.concat(optimizeTW(c.start,xy,c.t0,v.spd,v.svc),noxy);
  try{for(var k=0;k<final.length;k++){if(final[k].orden!==k+1){var e=clean(final[k]);e.orden=k+1;await persist(e);}}toast('Orden aplicado. El chofer ya lo ve actualizado.');}catch(_){toast('No se pudo aplicar el orden.');}}

/* ----- depósito operativo: lotes, FEFO, putaway, conteos, picking ----- */
function wLotes(){var m={};W().kardex.forEach(function(x){if(!x.lote)return;var k=x.sku+'|'+x.ubicacion+'|'+x.lote,o=m[k]=m[k]||{sku:x.sku,ubi:x.ubicacion,lote:x.lote,vence:x.vence||'',q:0};o.q+=(x.in||0)-(x.out||0);if(x.vence&&!o.vence)o.vence=x.vence;});return Object.keys(m).map(function(k){return m[k];}).filter(function(o){return o.q!==0;});}
function wDisp(sinReservas){
  var st=wStock(),lots=wLotes(),out=[],used={},res={};
  if(!sinReservas)WC('picks').filter(function(p){return p.estado==='pendiente';}).forEach(function(p){(p.lineas||[]).forEach(function(l){var k=l.ubi+'|'+l.sku+'|'+(l.lote||'');res[k]=(res[k]||0)+l.qty;});});
  lots.forEach(function(l){var k0=l.ubi+'|'+l.sku;used[k0]=(used[k0]||0)+l.q;if(l.q>0){var q=l.q-(res[k0+'|'+l.lote]||0);if(q>0)out.push({sku:l.sku,ubi:l.ubi,lote:l.lote,vence:l.vence,q:q});}});
  Object.keys(st.m).forEach(function(k){var rest=st.m[k]-(used[k]||0)-(res[k+'|']||0);if(rest>0){var p=k.split('|');out.push({sku:p[1],ubi:p[0],lote:'',vence:'',q:rest});}});
  return out;}
var fefo=function(a,b){return (a.vence||'9999').localeCompare(b.vence||'9999')||a.ubi.localeCompare(b.ubi);};
function ingresoMap(){var m={};W().kardex.forEach(function(x){if(!(x['in']>0))return;var k=x.sku+'|'+(x.lote||'');if(!m[k]||String(x.fecha||'')<m[k])m[k]=String(x.fecha||'');});return m;}
function asignar(sku,qty){var ig=ingresoMap(),l=wDisp().filter(function(x){return x.sku===sku;}).sort(function(a,b){return (a.vence||'9999').localeCompare(b.vence||'9999')||(ig[sku+'|'+(a.lote||'')]||'9999').localeCompare(ig[sku+'|'+(b.lote||'')]||'9999')||String(a.lote||'').localeCompare(String(b.lote||''))||a.ubi.localeCompare(b.ubi);}),out=[],need=qty;
  for(var i=0;i<l.length&&need>0;i++){var t=Math.min(l[i].q,need);out.push({sku:sku,ubi:l[i].ubi,lote:l[i].lote,vence:l[i].vence,qty:t});need-=t;}
  return {lineas:out,falta:need};}
function putaway(sku,qty){var w=W(),st=wStock(),s=w.skus.find(function(x){return x.codigo===sku;}),c=[];
  w.ubic.forEach(function(u){var oc=0;Object.keys(st.m).forEach(function(k){if(k.split('|')[0]===u.codigo)oc+=Math.max(0,st.m[k]);});var libre=(u.cap||0)-oc;if(libre<qty)return;
    var mismo=(st.m[u.codigo+'|'+sku]||0)>0;c.push({u:u,libre:libre,mismo:mismo,score:(mismo?0:10)+(s&&u.codigo===s.ubic?-5:0)+(s&&u.deposito===s.deposito?0:5)+(libre-qty)/1000});});
  c.sort(function(a,b){return a.score-b.score;});return c.slice(0,3);}
function venceChip(v){if(!v)return '<span class="chip">Sin vencimiento</span>';var d=dleft(v);return '<span class="chip '+(d<0?'bad':d<=30?'bad':d<=60?'warn':'ok')+'">'+(d<0?'Vencido hace '+(-d)+' d':'Vence en '+d+' d')+'</span>';}
var skuTxt=function(c){var s=W().skus.find(function(x){return x.codigo===c;});return esc(c)+(s?' '+esc(s.producto):'');};
function xLotes(){
  var w=W(),lt=S.ext.lt,can=parseInt(lt.can,10)||0,lots=wLotes().filter(function(l){return l.q>0;}).sort(fefo),sug=lt.sku&&can>0?putaway(lt.sku,can):[];
  var venc=lots.filter(function(l){return l.vence&&dleft(l.vence)<=30;});
  var h=venc.length?'<div class="banner bad" role="status">'+ICON.alert+'<div><strong>'+venc.length+' lote'+(venc.length>1?'s':'')+' vencido'+(venc.length>1?'s':'')+' o por vencer en 30 días</strong>'+venc.map(function(l){return esc(l.sku+' '+l.lote);}).join(' · ')+'</div></div>':'';
  h+='<form class="panel" id="x-form-lote" autocomplete="off"><h3>Ingreso con lote y vencimiento</h3><div class="grid2"><label>SKU<select id="lt-sku"><option value="">Elegí…</option>'+w.skus.map(function(s){return '<option value="'+esc(s.codigo)+'"'+(lt.sku===s.codigo?' selected':'')+'>'+esc(s.codigo+' · '+s.producto)+'</option>';}).join('')+'</select></label>'+
    '<label>Cantidad<input id="lt-can" type="number" min="1" value="'+esc(lt.can)+'" required></label><label>Lote<input id="lt-lot" maxlength="30" required></label><label>Vencimiento<input id="lt-vto" type="date"></label></div>'+
    (sug.length?'<div class="banner info" role="status">'+ICON.bell+'<div><strong>Ubicación sugerida</strong>'+sug.map(function(x,i){return (i?' · ':'')+'<span class="mono">'+esc(x.u.codigo)+'</span> ('+(x.mismo?'ya tiene este SKU, ':'')+'entran '+nf(x.libre)+' u)';}).join('')+'</div></div>':(lt.sku&&can>0?'<div class="banner warn">'+ICON.alert+'<div>No hay ubicación con lugar libre para '+can+' unidades.</div></div>':''))+
    '<label>Ubicación<select id="lt-ubi">'+w.ubic.map(function(u){return '<option value="'+esc(u.codigo)+'"'+(sug[0]&&sug[0].u.codigo===u.codigo?' selected':'')+'>'+esc(u.codigo+' · '+(u.deposito||''))+'</option>';}).join('')+'</select></label><div class="row"><button class="btn pri" type="submit">Registrar ingreso</button></div></form>';
  h+='<div class="panel"><h3>Stock por lote (salen primero los que vencen antes)</h3>'+(lots.length?tbl(['SKU','Lote','Ubicación','Cantidad','Vencimiento',''],lots.map(function(l){return [skuTxt(l.sku),esc(l.lote),'<span class="mono">'+esc(l.ubi)+'</span>',nf(l.q),esc(l.vence||'—'),venceChip(l.vence)];}),560)+'<div class="small muted" style="margin-top:8px">El stock sin lote (ingresos donde no se cargó lote) no figura acá. Para que FEFO sea confiable, ingresá todo con lote.</div>':'<div class="small muted">Todavía no hay ingresos con lote.</div>')+'</div>';
  return h;}
async function loteGuardar(){
  var sku=gv('lt-sku'),can=parseInt(gv('lt-can'),10),lot=gv('lt-lot').trim(),ubi=gv('lt-ubi');
  if(!sku||!(can>0)||!lot||!ubi){toast('Completá SKU, cantidad, lote y ubicación.');return;}
  await wPut('kardex',{id:uid('M'),fecha:HOY,tipo:'IN',sku:sku,ubicacion:ubi,'in':can,out:0,lote:lot,vence:gv('lt-vto'),operador:actor()});
  S.ext.lt={sku:sku,can:''};toast('Ingreso registrado');render();}
function iraCalc(){var d=addDays(-90),n=0,ok=0;WC('conteos').filter(function(c){return c.estado==='cerrado'&&String(c.fecha)>=d;}).forEach(function(c){c.items.forEach(function(i){n++;if(i.dif===0)ok++;});});return n?ok/n*100:null;}
function xConteos(){
  var w=W(),cs=WC('conteos').slice().sort(function(a,b){return String(b.id).localeCompare(String(a.id));}),ira=iraCalc();
  var h='<div class="kpis">'+KPI(fp(ira),'Exactitud de inventario (IRA)','posiciones sin diferencia, 90 días',ira==null?'':ira>=98?'ok':ira>=95?'warn':'bad')+KPI(cs.filter(function(c){return c.estado==='abierto';}).length,'Conteos abiertos','')+KPI(cs.filter(function(c){return c.estado==='cerrado';}).length,'Conteos cerrados','')+'</div>';
  h+='<div class="panel"><h3>Nuevo conteo cíclico</h3><div class="row"><button class="btn" data-act="x-cnA">Contar las 5 posiciones con más salidas</button><label>Una ubicación<select id="cn-ubi"><option value="">Elegí…</option>'+w.ubic.map(function(u){return '<option value="'+esc(u.codigo)+'">'+esc(u.codigo)+'</option>';}).join('')+'</select></label><button class="btn" data-act="x-cnU">Contar esa ubicación</button></div><div class="small muted">El conteo es ciego: quien cuenta no ve la cantidad del sistema. Al cerrar, las diferencias se ajustan en el kardex como "AJUSTE".</div></div>';
  h+=cs.map(function(c){
    if(c.estado==='abierto')return '<div class="panel"><h3>Conteo '+esc(c.fecha)+' · abierto</h3>'+tbl(['Ubicación','SKU','Cantidad contada'],c.items.map(function(i,ix){return ['<span class="mono">'+esc(i.ubi)+'</span>',skuTxt0(i.sku),'<input id="cq-'+esc(c.id)+'-'+ix+'" type="number" min="0" style="width:110px">'];}),420)+'<div class="row" style="margin-top:12px"><button class="btn ok" data-act="x-cncerrar" data-id="'+esc(c.id)+'">Cerrar y ajustar</button><button class="btn" data-act="x-cndel" data-id="'+esc(c.id)+'">Descartar</button></div></div>';
    var dif=c.items.filter(function(i){return i.dif!==0;});
    return '<div class="panel"><h3>Conteo '+esc(c.fecha)+' · cerrado</h3><div class="small">'+(c.items.length-dif.length)+' de '+c.items.length+' posiciones sin diferencia'+(c.por?' · contó '+esc(c.por):'')+'</div>'+(dif.length?tbl(['Ubicación','SKU','Sistema','Contado','Diferencia'],dif.map(function(i){return ['<span class="mono">'+esc(i.ubi)+'</span>',skuTxt(i.sku),nf(i.sistema),nf(i.contado),'<span class="chip bad">'+(i.dif>0?'+':'')+i.dif+'</span>'];}),460):'')+'</div>';}).join('');
  return h;}
async function conteoNuevo(modo){
  var st=wStock(),keys=Object.keys(st.m).filter(function(k){return st.m[k]>0;});
  if(modo==='A'){var sal={};W().kardex.forEach(function(x){if(x.tipo==='OUT'&&x.out)sal[x.ubicacion+'|'+x.sku]=(sal[x.ubicacion+'|'+x.sku]||0)+x.out;});keys=keys.sort(function(a,b){return (sal[b]||0)-(sal[a]||0);}).slice(0,5);}
  else{var u=gv('cn-ubi');if(!u){toast('Elegí una ubicación.');return;}keys=keys.filter(function(k){return k.split('|')[0]===u;});}
  if(!keys.length){toast('No hay stock para contar ahí.');return;}
  await wPut('conteos',{id:uid('CN'),fecha:HOY,estado:'abierto',items:keys.map(function(k){var p=k.split('|');return {ubi:p[0],sku:p[1],sistema:st.m[k]};}),por:actor()});toast('Conteo armado');}
async function conteoCerrar(id){
  var c=WC('conteos').find(function(x){return x.id===id;});if(!c)return;c=clean(c);var vals=[];
  for(var i=0;i<c.items.length;i++){var n=parseInt(gv('cq-'+id+'-'+i),10);if(isNaN(n)||n<0){toast('Falta contar la posición '+(i+1)+'.');return;}vals.push(n);}
  for(var j=0;j<c.items.length;j++){var it=c.items[j];it.contado=vals[j];it.dif=vals[j]-it.sistema;
    if(it.dif!==0)await wPut('kardex',{id:uid('A'),fecha:HOY,tipo:'AJUSTE',sku:it.sku,ubicacion:it.ubi,'in':it.dif>0?it.dif:0,out:it.dif<0?-it.dif:0,operador:actor(),nota:'Conteo '+id});}
  c.estado='cerrado';c.cierre=isoNow();await wPut('conteos',c);toast('Conteo cerrado y ajustado');}
function xPicking(){
  var w=W(),dr=S.ext.pickDraft,ps=WC('picks').slice().sort(function(a,b){return String(b.id).localeCompare(String(a.id));});
  var h='<form class="panel" id="x-form-pick" autocomplete="off"><h3>Nueva orden de picking</h3><div class="grid2"><label>Referencia (pedido o cliente)<input id="pk-ref" maxlength="60"></label></div><div class="row"><label>SKU<select id="pk-sku">'+w.skus.map(function(s){return '<option value="'+esc(s.codigo)+'">'+esc(s.codigo+' · '+s.producto)+'</option>';}).join('')+'</select></label><label>Cantidad<input id="pk-can" type="number" min="1" style="width:110px"></label><button class="btn" type="submit">Agregar línea</button></div>'+
    (dr.length?tbl(['SKU','Cantidad',''],dr.map(function(l,i){return [skuTxt(l.sku),nf(l.qty),'<button class="btn sm" type="button" data-act="x-pkdel" data-id="'+i+'">Quitar</button>'];}),360)+'<div class="row" style="margin-top:12px"><button class="btn ok" type="button" data-act="x-pkgen">Generar orden (FEFO)</button></div>':'')+'</form>';
  h+=ps.map(function(p){
    var done=p.estado!=='pendiente';
    return '<div class="panel"><div class="row sp"><h3>'+esc(p.ref||'Sin referencia')+' · '+esc(p.fecha)+'</h3><span class="chip '+(done?'ok':'signal')+'">'+(done?'Completada':'Pendiente')+'</span></div>'+(p.faltan&&p.faltan.length?'<div class="banner warn" role="status">'+ICON.alert+'<div><strong>Stock insuficiente</strong>'+p.faltan.map(function(f){return esc(f.sku)+': faltan '+nf(f.qty);}).join(' · ')+'</div></div>':'')+
      tbl(['Ubicación','SKU','Lote','Vence','Cantidad'],(p.lineas||[]).map(function(l){return ['<span class="mono">'+esc(l.ubi)+'</span>',skuTxt(l.sku),esc(l.lote||'—'),esc(l.vence||'—'),'<strong>'+nf(l.qty)+'</strong>'];}),480)+
      (done?'':'<div class="row" style="margin-top:12px"><button class="btn ok" data-act="x-pkok" data-id="'+esc(p.id)+'">Confirmar picking</button><button class="btn" data-act="x-pkcancel" data-id="'+esc(p.id)+'">Cancelar</button></div>')+'</div>';}).join('');
  if(!ps.length)h+='<div class="small muted">La lista de cada orden sale ordenada por ubicación, para recorrer el depósito sin vueltas.</div>';
  return h;}
function opsList(){var m={};(WC('operarios')||[]).forEach(function(o){if(o.id&&o.nombre)m[o.id]={id:o.id,nombre:o.nombre};});(D().perfiles||[]).forEach(function(o){if(o.rol==='deposito'&&o.id)m[o.id]={id:o.id,nombre:o.nombre};});return Object.keys(m).map(function(k){return m[k];}).sort(function(a,b){return String(a.nombre).localeCompare(String(b.nombre),'es');});}
function stgPosList(){return WC('staging').filter(function(x){return x.tipo==='posicion'&&x.activo!==false;}).sort(function(a,b){return String(a.codigo).localeCompare(String(b.codigo),'es',{numeric:true});});}
function stgOcup(){var m={};WC('pedidos').filter(function(p){return p.estado==='preparado';}).concat(WC('picks').filter(function(k){return k.estado==='completado'&&!k.pedidoId&&k.stgPos&&!k.stgFuera;})).forEach(function(p){var l=p.stgPosL&&p.stgPosL.length?p.stgPosL:(p.stgPos?String(p.stgPos).split(' · '):[]);l.forEach(function(c){m[c]=(m[c]||0)+1;});});return m;}
function stgSug(sale){var ps=stgPosList(),oc=stgOcup(),lib=ps.filter(function(x){return !oc[x.codigo];}).map(function(x){return x.codigo;});if(!lib.length)return '';var d=sale?Math.round((new Date(sale+'T00:00:00')-new Date(HOY+'T00:00:00'))/864e5):-1;return d>=2?lib[lib.length-1]:lib[0];}
function nextPk(){var mx=0;WC('picks').forEach(function(k){var m=/^PED(\d+)$/i.exec(String(k.id));if(m)mx=Math.max(mx,parseInt(m[1],10));});mx=Math.max(mx,window.__pkLast||0)+1;window.__pkLast=mx;return 'PED'+String(mx).padStart(4,'0');}
function pkMetaSave(){S.ext.pkMeta={ref:gv('pk-ref'),op:gv('pk-op'),sale:gv('pk-sale'),stg:gv('pk-stg')};}
function pkPreview(dr){var agg={},ord=[];dr.forEach(function(l){if(!(l.sku in agg)){agg[l.sku]=0;ord.push(l.sku);}agg[l.sku]+=l.qty;});
  return ord.map(function(sku){var r=asignar(sku,agg[sku]);var t=r.lineas.map(function(x){return esc((x.lote||'sin lote')+' · '+(x.vence||'sin venc.')+' · '+x.ubi)+' ×'+nf(x.qty);}).join('<br>');if(r.falta>0)t+=(t?'<br>':'')+'<span class="chip warn">Faltan '+nf(r.falta)+'</span>';return {sku:sku,qty:agg[sku],txt:t||'<span class="chip warn">Sin stock disponible</span>'};});}
function pkBulk(){var ta=document.getElementById('pk-bulk'),txt=ta?ta.value:'';pkMetaSave();var w=W(),by={};w.skus.forEach(function(s){by[String(s.codigo).toLowerCase()]=s.codigo;});
  var ok=0,bad=[];txt.split(/\r?\n/).forEach(function(ln){ln=ln.trim();if(!ln)return;var m=ln.match(/^(.+?)[;,\t ]+(\d+(?:[.,]\d+)?)\s*$/);if(!m){bad.push(ln);return;}var code=by[m[1].trim().toLowerCase()],q=Math.round(parseFloat(m[2].replace(',','.')));if(!code||!(q>0)){bad.push(ln);return;}S.ext.pickDraft.push({sku:code,qty:q});ok++;});
  S.ext.pkBulkOpen=bad.length>0;
  toast(ok+' líneas agregadas'+(bad.length?' · '+bad.length+' no se reconocieron (revisá SKU y cantidad)':'.'));render();
  if(bad.length){var t2=document.getElementById('pk-bulk');if(t2)t2.value=bad.join('\n');}}
async function pickGenerar(){
  var dr=S.ext.pickDraft;if(!dr.length)return;var lineas=[],faltan=[],agg={};
  dr.forEach(function(l){agg[l.sku]=(agg[l.sku]||0)+l.qty;});
  Object.keys(agg).forEach(function(sku){var r=asignar(sku,agg[sku]);r.lineas.forEach(function(l){lineas.push(l);});if(r.falta>0)faltan.push({sku:sku,qty:r.falta});});
  lineas.sort(pickCmp);
  if(!lineas.length){toast('No hay stock disponible para esos SKUs.');return;}
  var opId=gv('pk-op'),opP=opId?opsList().find(function(x){return x.id===opId;}):null;await wPut('picks',{id:nextPk(),ref:gv('pk-ref').trim(),fecha:HOY,estado:'pendiente',lineas:lineas,faltan:faltan,por:actor(),asignado:opId||'',asignadoNombre:opP?opP.nombre:'',sale:gv('pk-sale')||'',stgPrev:gv('pk-stg')||''});S.ext.pickDraft=[];S.ext.pkMeta=null;toast('Orden de picking generada');render();}
async function pickConfirmar(id){
  var p=WC('picks').find(function(x){return x.id===id;});if(!p||p.estado!=='pendiente')return;p=clean(p);
  for(var i=0;i<p.lineas.length;i++){var l=p.lineas[i];await wPut('kardex',{id:uid('M'),fecha:HOY,tipo:'OUT',sku:l.sku,ubicacion:l.ubi,'in':0,out:l.qty,lote:l.lote||'',vence:l.vence||'',operador:actor(),nota:'Picking '+p.id});}
  p.estado='completado';p.cierre=isoNow();await wPut('picks',p);toast('Picking confirmado: salida registrada en el kardex.');}

/* ----- datos y seguridad ----- */
function xDatos(){
  var cons=D().consents||[],ch=(D().perfiles||[]).filter(function(p){return p.rol==='chofer';});
  var h='<div class="panel"><h3>Consentimiento de ubicación de choferes</h3><p class="small muted">La ubicación se toma solo al confirmar una entrega y únicamente si el chofer aceptó. Conservá este registro.</p>'+
    (ch.length?tbl(['Chofer','Consentimiento'],ch.map(function(c){var k=S.mode==='demo'?(S.consentDemo&&c.id==='d1'?{ts:isoNow()}:null):cons.find(function(x){return x.id===c.id;});return [esc(c.nombre),k&&k.ok!==false?'<span class="chip ok">Aceptó el '+esc(new Date(k.ts).toLocaleDateString('es-AR'))+'</span>':'<span class="chip">Sin respuesta</span>'];}),360):'<div class="small muted">No hay choferes cargados.</div>')+'</div>';
  h+='<div class="panel"><h3>Copia de tus datos</h3><p class="small muted">Descarga todo lo que cargaste (entregas, perfiles, equipos, check lists, gastos, órdenes, depósito) en un solo archivo. Tus datos son tuyos y te los podés llevar cuando quieras.</p><div class="row"><button class="btn" data-act="x-respaldo">Descargar copia completa (JSON)</button></div></div>';
  if(standalone())h+=xSeg();
  return h;}
function xSeg(){return '<div class="panel" id="seg-panel"><h3>Verificación en dos pasos (administración)</h3><div id="seg-body" class="small muted">Cargando…</div></div>';}
async function segCargar(){
  var b=document.getElementById('seg-body');if(!b)return;
  try{var st=await apiJson('GET','/api/2fa');S.ext.tfa=st;}catch(_){return;}
  render();}
function segHtml(){var st=S.ext.tfa;if(!st)return '';
  if(st.on)return 'Activada. Al ingresar se pide un código de 6 dígitos de tu aplicación de autenticación. <div class="row"><label>Tu contraseña<input id="tf-pass" type="password" autocomplete="current-password"></label><label>Código actual<input id="tf-code" inputmode="numeric" maxlength="6"></label><button class="btn bad" data-act="x-2faoff">Desactivar</button></div>';
  if(S.ext.tfaSetup)return 'Escaneá el código o cargá esta clave en tu aplicación de autenticación (Google Authenticator, Authy, 1Password…): <div class="mono" style="font-size:16px;margin:8px 0;word-break:break-all">'+esc(S.ext.tfaSetup.secret)+'</div><div class="small muted" style="word-break:break-all">'+esc(S.ext.tfaSetup.uri)+'</div><div class="row"><label>Código de 6 dígitos<input id="tf-code" inputmode="numeric" maxlength="6"></label><button class="btn ok" data-act="x-2faon">Activar</button></div>';
  return 'Desactivada. Recomendado para quien administra el portal. <div class="row"><button class="btn pri" data-act="x-2fasetup">Activar…</button></div>';}

/* ----- gestión (pestaña de administración) ----- */
function viewGest(){
  var st=S.ext.sub,tabs=[['ind','Indicadores'],['cost','Costos de flota'],['mant','Mantenimiento'],['listas','Check lists'],['imp','Importar / exportar'],['datos','Datos y seguridad']];
  var body={ind:xInd,cost:xCost,mant:xMant,listas:xListas,imp:xImp,datos:xDatos}[st]||xInd;
  if(st==='datos'&&standalone()&&!S.ext.tfa&&!S.ext.tfaAsk){S.ext.tfaAsk=true;setTimeout(segCargar,0);}
  var out='<div class="seg lt" role="group" aria-label="Gestión">'+tabs.map(function(t){return '<button data-act="x-sub" data-v="'+t[0]+'" aria-pressed="'+(st===t[0])+'">'+t[1]+'</button>';}).join('')+'</div>'+body();
  return out.replace('<div id="seg-body" class="small muted">Cargando…</div>','<div id="seg-body" class="small">'+(S.ext.tfa?segHtml():'Cargando…')+'</div>');}

/* ----- eventos del módulo ----- */
async function extClick(a,id,v,t){
  var A=a.slice(2);
  if(A==='sub'){S.ext.sub=v;render();}
  else if(A==='pod'){podReset();S.ext.pod=id;render();var f=document.querySelector('.pod-form');if(f)f.scrollIntoView({behavior:'smooth',block:'center'});}
  else if(A==='podno'){podReset();render();}
  else if(A==='consent'){await consentir();}
  else if(A==='nogeo'){S.ext.noGeo=true;render();}
  else if(A==='sigclear'){S.ext.sig='';render();}
  else if(A==='geo'){tomarGeo();}
  else if(A==='podok'){await podOk(id);}
  else if(A==='gtog'){S.ext.gasto=!S.ext.gasto;render();}
  else if(A==='gdel'){if(S.ui.confirmDel==='g'+id){S.ui.confirmDel=null;try{await gDel(id);toast('Gasto quitado');}catch(_){toast('No se pudo quitar.');}}else{S.ui.confirmDel='g'+id;render();}}
  else if(A==='gno'){S.ui.confirmDel=null;render();}
  else if(A==='plantilla'){plantillaCsv();}
  else if(A==='export'){exportEntregas();}
  else if(A==='respaldo'){respaldoJson();}
  else if(A==='impok'){await aplicarImport();}
  else if(A==='impno'){S.ext.imp=null;render();}
  else if(A==='otest'){var o=clean(XL('ordenes').find(function(x){return x.id===id;}));o.estado=v;await otPut(o);}
  else if(A==='otcerrar'){S.ext.otClose=S.ext.otClose===id?null:id;render();}
  else if(A==='otok'){var o2=clean(XL('ordenes').find(function(x){return x.id===id;})),c=gnum('ot-costo');o2.estado='cerrada';o2.cierre=isoNow();o2.costo=c>0?c:0;o2.nota=gv('ot-nota').trim();S.ext.otClose=null;await otPut(o2);
    if(o2.origen==='servicio'){var eq=(D().equipos||[]).find(function(e){return e.id===o2.equipoId;});if(eq)await eqPut(Object.assign(clean(eq),{servUlt:lectEq(eq)}));}toast('Orden cerrada');}
  else if(A==='svsave'){var eq2=(D().equipos||[]).find(function(e){return e.id===id;});if(!eq2)return;var sc=gnum('sv-c-'+id),su=gnum('sv-u-'+id);await eqPut(Object.assign(clean(eq2),{servCada:sc>0?sc:0,servUlt:su>=0?su:0}));toast('Service guardado');}
  else if(A==='svot'){var eq3=(D().equipos||[]).find(function(e){return e.id===id;});if(!eq3)return;await otPut({id:S.mode==='demo'?uid('ot-'):db.collection('ordenes').doc().id,equipoId:eq3.id,equipo:eq3.nombre,titulo:'Service programado a '+nf(eq3.servCada)+' (lectura '+nf(lectEq(eq3))+')',origen:'servicio',estado:'abierta',prio:'media',creada:isoNow(),por:actor(),costo:0});toast('Orden generada');}
  else if(A==='plsave'){await plGuardar(v);}
  else if(A==='plreset'){if(S.mode==='demo'){S.data.demo.plantillas=S.data.demo.plantillas.filter(function(x){return x.id!==v;});render();}else{await db.doc('plantillas/'+v).delete();}toast('Lista estándar restaurada');}
  else if(A==='aplicarvt'){await aplicarVT();}
  else if(A==='cnA'){await conteoNuevo('A');}
  else if(A==='cnU'){await conteoNuevo('U');}
  else if(A==='cncerrar'){await conteoCerrar(id);}
  else if(A==='cndel'){if(S.mode==='demo'){S.data.demo.wms.conteos=S.data.demo.wms.conteos.filter(function(x){return x.id!==id;});render();}else await wDel('conteos',id);}
  else if(A==='pkdel'){S.ext.pickDraft.splice(parseInt(id,10),1);render();}
  else if(A==='pkgen'){await pickGenerar();}
  else if(A==='pkbulk'){pkBulk();}
  else if(A==='pkclr'){pkMetaSave();S.ext.pickDraft=[];render();}
  else if(A==='pkok'){await pickConfirmar(id);}
  else if(A==='pkcancel'){await wDel('picks',id);toast('Orden cancelada');}
  else if(A==='2fasetup'){try{S.ext.tfaSetup=await apiJson('POST','/api/2fa/setup');render();}catch(e){toast(e.message);}}
  else if(A==='2faon'){try{await apiJson('POST','/api/2fa/enable',{code:gv('tf-code')});S.ext.tfa={on:true};S.ext.tfaSetup=null;toast('Verificación en dos pasos activada');render();}catch(e){toast(e.message);}}
  else if(A==='2faoff'){try{await apiJson('POST','/api/2fa/disable',{password:gv('tf-pass'),code:gv('tf-code')});S.ext.tfa={on:false};toast('Verificación en dos pasos desactivada');render();}catch(e){toast(e.message);}}
}
function eqPut(e){e=clean(e);if(S.mode==='demo'){upsertLocal(S.data.demo.equipos,e);render();return Promise.resolve();}return db.doc('equipos/'+e.id).set(e);}
document.addEventListener('click',async function(ev){
  var t=ev.target.closest('[data-act^="x-"]');if(!t||t.tagName==='SELECT'||(t.tagName==='INPUT'&&t.type!=='button'))return;
  try{await extClick(t.dataset.act,t.dataset.id,t.dataset.v,t);}catch(err){toast('Algo falló. Probá de nuevo.');if(window.console)console.error(err);}});
document.addEventListener('change',async function(ev){
  var t=ev.target,id=t.id||'';
  if(id==='x-per'){S.ext.per=t.value;render();}
  else if(id==='x-spd'||id==='x-svc'){var n=parseFloat(t.value);if(id==='x-spd'&&n>=10&&n<=90)S.ext.vrp.spd=n;if(id==='x-svc'&&n>=0&&n<=120)S.ext.vrp.svc=n;render();}
  else if(id==='lt-sku'||id==='lt-can'){S.ext.lt={sku:gv('lt-sku'),can:gv('lt-can')};render();}
  else if(id==='pod-foto'){var f=t.files&&t.files[0];t.value='';if(!f)return;try{S.ext.foto=await resizeFoto(f);if(S.mode==='demo')S.ext.fotoUrl=URL.createObjectURL(S.ext.foto);render();}catch(_){toast('No se pudo leer la foto.');}}
  else if(id==='imp-file'){var g=t.files&&t.files[0];t.value='';if(!g)return;try{var rows=await leerArchivoFilas(g);S.ext.imp=entregasDesdeFilas(rows);}catch(_){S.ext.imp={error:'No se pudo leer el archivo. Probá con la plantilla CSV.',items:[]};}render();}
});
document.addEventListener('submit',async function(ev){
  var id=ev.target.id||'';if(id.indexOf('x-form-')!==0)return;ev.preventDefault();
  try{
    if(id==='x-form-gasto')await gastoGuardar();
    else if(id==='x-form-lote')await loteGuardar();
    else if(id==='x-form-pick'){var s=gv('pk-sku'),q=parseInt(gv('pk-can'),10);if(!s||!(q>0)){toast('Elegí SKU y cantidad.');return;}pkMetaSave();S.ext.pickDraft.push({sku:s,qty:q});render();}
  }catch(err){toast('No se pudo guardar. Probá de nuevo.');if(window.console)console.error(err);}});
function extLive(rol,onErr){var live=S.data.live,mk=function(s){return s.docs.map(function(d){return Object.assign({id:d.id},d.data());});};
  if(rol==='admin'){['gastos','ordenes','consents'].forEach(function(c){unsubs.push(db.collection(c).onSnapshot(function(s){live[c]=mk(s);render();},onErr));});}
  if(rol==='admin'||rol==='chofer'||rol==='deposito')unsubs.push(db.collection('plantillas').onSnapshot(function(s){live.plantillas=mk(s);render();},onErr));
  if(rol==='chofer')unsubs.push(db.doc('consents/'+S.me.id).onSnapshot(function(s){S.consent=s.exists?s.data():null;render();},onErr));}
window.__ext={csvParse:csvParse,entregasDesdeFilas:entregasDesdeFilas,optimizeTW:optimizeTW,simRuta:simRuta,asignar:asignar,wDisp:wDisp,iraCalc:iraCalc,S:S,render:render};

/* ---------- EXT2: plano con lotes, stock con vencimientos, logística inversa, picking por línea ---------- */
var DEVOL_MOT=['Rechazada por el cliente','Producto dañado','Vencido o por vencer','Error de pedido','No entregada (vuelve al depósito)','Retiro por garantía'];
var DEVOL_DISP={reingreso:'Reingresa a stock',reproceso:'Reproceso o reembalaje',proveedor:'Devolución al proveedor',scrap:'Baja (scrap)'};
S.ext.dv=null;
S.data.live.wms.devoluciones=[];
S.data.demo.wms.devoluciones=[
  {id:'DV-D1',fecha:addDays(-6),guia:'G-4801',cliente:'Pinturería Los Aromos',sku:'P005',qty:3,lote:'L2599',vence:addDays(-3),motivo:'Vencido o por vencer',estado:'cerrada',disp:'scrap',cierre:at(-5,10,0),por:'Demostración'},
  {id:'DV-D2',fecha:addDays(-2),guia:'G-4790',cliente:'Pinturería Los Aromos',sku:'P001',qty:1,lote:'L2601',vence:addDays(25),motivo:'Producto dañado',estado:'recibida',por:'Demostración'},
  {id:'DV-D3',fecha:addDays(-1),guia:'',cliente:'Obras y Revestimientos',sku:'P003',qty:5,lote:'L2602',vence:addDays(50),motivo:'Error de pedido',estado:'recibida',por:'Demostración'}];
var _lc={k:'',v:[]};
function lotesAll(){var k=S.mode+W().kardex.length+(W().kardex[W().kardex.length-1]||{}).id;if(_lc.k!==k){_lc={k:k,v:wLotes().filter(function(l){return l.q>0;}).sort(fefo)};}return _lc.v;}
var lotesEn=function(u){return lotesAll().filter(function(l){return l.ubi===u;});};
function extLotLev(k){var m=null;lotesEn(k).forEach(function(l){if(!l.vence)return;var d=dleft(l.vence);if(m==null||d<m)m=d;});return m==null?null:m<=30?'bad':m<=60?'warn':'ok';}
function extLotLab(k){var ls=lotesEn(k);if(!ls.length)return 'sin lote';var l=ls[0],d=l.vence?dleft(l.vence):null;return l.lote+(d==null?'':' · '+d+' d')+(ls.length>1?' +'+(ls.length-1):'');}
function lotesPos(u){var ls=lotesEn(u);return '<div class="doc"><span class="k">Lotes en esta posición (sale primero el que vence antes)</span><span class="v">'+(ls.length?ls.map(function(l){return esc(l.sku)+' · lote '+esc(l.lote)+' · '+nf(l.q)+' u · '+venceChip(l.vence);}).join('<br>'):'Sin stock con lote')+'</span></div>';}
function xStockVenc(){
  var w=W(),st=wStock(),lots=lotesAll();
  var rows=w.skus.filter(function(s){return (st.tot[s.codigo]||0)>0;}).map(function(s){
    var t=st.tot[s.codigo],ls=lots.filter(function(l){return l.sku===s.codigo;}),con=ls.reduce(function(a,l){return a+l.q;},0),f=ls.filter(function(l){return l.vence;})[0];
    return [skuTxt(s.codigo),nf(t),nf(con),nf(Math.max(0,t-con)),f?esc(f.lote)+' · '+esc(f.vence):'—',f?venceChip(f.vence):'—'];});
  return '<div class="panel"><h3>Stock con lote y próximo vencimiento</h3>'+(rows.length?tbl(['SKU','Stock','Con lote','Sin lote','Primer lote a vencer','Vencimiento'],rows,640):'<div class="small muted">Sin stock.</div>')+'<div class="small muted" style="margin-top:8px">En el plano elegí "Lotes y vencimientos" para ver dónde está cada lote. El stock sin lote no tiene control de vencimiento.</div></div>';}
function xDevol(){
  var ds=WC('devoluciones').slice().sort(function(a,b){return String(b.id).localeCompare(String(a.id));}),d30=addDays(-30),rec=ds.filter(function(d){return d.fecha>=d30;});
  var sum=function(l){return l.reduce(function(t,d){return t+(d.qty||0);},0);},cer=ds.filter(function(d){return d.estado==='cerrada';}),rein=cer.reduce(function(t,d){return t+(d.okQty!=null?d.okQty:(d.disp==='reingreso'?(d.qty||0):0));},0);
  var abiertas=ds.filter(function(d){return d.estado==='recibida';}),viejas=abiertas.filter(function(d){return d.fecha<=addDays(-3);});
  var h='<div class="kpis">'+KPI(rec.length,'Devoluciones (30 días)',nf(sum(rec))+' unidades')+KPI(cer.length?fp(rein/Math.max(1,sum(cer))*100):'—','Reingresadas a stock','sobre lo ya resuelto')+KPI(abiertas.length,'Sin resolver',viejas.length?viejas.length+' hace más de 3 días':'ninguna atrasada',viejas.length?'bad':'ok')+'</div>';
  var mot={};rec.forEach(function(d){mot[d.motivo]=(mot[d.motivo]||0)+1;});var mk=Object.keys(mot).sort(function(a,b){return mot[b]-mot[a];}),mx=mot[mk[0]]||1;
  if(mk.length)h+='<div class="panel"><h3>Motivos (30 días)</h3>'+mk.map(function(k){return '<div class="row" style="flex-wrap:nowrap"><span style="width:230px">'+esc(k)+'</span><div class="bar" style="flex:1"><i style="width:'+Math.round(mot[k]/mx*100)+'%;background:var(--warn)"></i></div><strong>'+mot[k]+'</strong></div>';}).join('')+'</div>';
  var pend=D().entregas.filter(function(e){return e.fecha>=d30&&(e.estado==='no_entregada'||(e.pod&&e.pod.completa===false))&&!ds.some(function(d){return d.guia&&d.guia===e.guia;});}).slice(0,8);
  if(pend.length)h+='<div class="panel"><h3>Entregas con mercadería que puede volver</h3>'+tbl(['Guía','Cliente','Qué pasó','Declaró el chófer',''],pend.map(function(e){return ['<span class="guia">'+esc(e.guia)+'</span>',esc(e.cliente),e.estado==='no_entregada'?esc(motivoDe(e)):'Entrega parcial: '+esc((e.pod&&e.pod.nota)||''),(e.devuelve&&e.devuelve.length?e.devuelve.map(function(x){return esc(x.desc)+': <strong>'+nf(x.qty)+' u</strong> '+(x.estado==='mal'?'<span class="chip bad">dañada</span>':'<span class="chip ok">buen estado</span>');}).join('<br>'):'<span class="small muted">Sin detalle</span>'),'<button class="btn sm" data-act="x-dvpre" data-id="'+esc(e.id)+'">Registrar devolución</button>'];}),560)+'</div>';
  var dv=S.ext.dv||{},w=W();
  h+='<form class="panel" id="x-form-devol" autocomplete="off"><h3>Registrar mercadería devuelta</h3><div class="grid2"><label>Guía de la entrega (si la hay)<input id="dv-guia" maxlength="40" value="'+esc(dv.guia||'')+'"></label><label>Cliente<input id="dv-cli" maxlength="120" value="'+esc(dv.cliente||'')+'" required></label>'+
    '<label>SKU<select id="dv-sku">'+w.skus.map(function(s){return '<option value="'+esc(s.codigo)+'">'+esc(s.codigo+' · '+s.producto)+'</option>';}).join('')+'</select></label><label>Cantidad<input id="dv-can" type="number" min="1" required></label>'+
    '<label>Lote<input id="dv-lot" maxlength="30"></label><label>Vencimiento del lote<input id="dv-vto" type="date"></label><label>Motivo<select id="dv-mot">'+DEVOL_MOT.map(function(m){return '<option'+(dv.motivo===m?' selected':'')+'>'+esc(m)+'</option>';}).join('')+'</select></label><label>Nota<input id="dv-nota" maxlength="160"></label></div><div class="row"><button class="btn pri" type="submit">Registrar recepción</button></div><div class="small muted">La mercadería devuelta no suma a stock hasta que se decida qué hacer con ella.</div></form>';
  h+=abiertas.map(function(d){
    var sug=putaway(d.sku,d.qty)[0];
    return '<div class="panel"><div class="row sp"><h3>'+skuTxt(d.sku)+' · '+nf(d.qty)+' u'+(d.lote?' · lote '+esc(d.lote):'')+'</h3><span class="chip warn">Sin resolver</span></div><div class="small">'+esc(d.cliente)+(d.guia?' · guía '+esc(d.guia):'')+' · '+esc(d.motivo)+' · recibida '+esc(fmtFecha(d.fecha))+(d.vence?' · '+venceChip(d.vence):'')+'</div>'+
      (d.qtyDecl!=null?'<div class="banner info" role="status"><div><strong>Declarado por el chófer: '+nf(d.qtyDecl)+' u</strong>'+(d.estadoDecl==='mal'?'Dice que está dañada o rota.':'Dice que está en buen estado.')+' Contá lo que llegó y separalo abajo.</div></div>':'')+
      '<div class="row" style="flex-wrap:wrap"><label>Llegaron (unidades)<input id="dv-r-'+esc(d.id)+'" type="number" min="1" value="'+d.qty+'" style="width:110px"></label><label>Aptas para la venta<input id="dv-ok-'+esc(d.id)+'" type="number" min="0" value="'+d.qty+'" style="width:110px"></label><label>Ubicación donde reingresan<select id="dv-u-'+esc(d.id)+'">'+w.ubic.map(function(u){return '<option value="'+esc(u.codigo)+'"'+(sug&&sug.u.codigo===u.codigo?' selected':'')+'>'+esc(u.codigo)+'</option>';}).join('')+'</select></label></div>'+
      '<div class="row" style="flex-wrap:wrap"><span class="chip" id="dv-nn-'+esc(d.id)+'">No vendibles: 0</span><label>Qué hacer con las no vendibles<select id="dv-n-'+esc(d.id)+'">'+['scrap','proveedor','reproceso'].map(function(k){return '<option value="'+k+'">'+esc(DEVOL_DISP[k])+'</option>';}).join('')+'</select></label><button class="btn ok" data-act="x-dvok" data-id="'+esc(d.id)+'">Cerrar</button></div><div class="small muted">Ej.: llegaron 15, 10 sirven y 5 no → poné 15 y 10. Las 5 restantes se dan de baja (o van a proveedor / reproceso) y no suman a stock.</div></div>';}).join('');
  if(cer.length)h+='<div class="panel"><h3>Resueltas</h3>'+tbl(['Fecha','SKU','Cant.','Cliente','Motivo','Destino'],cer.slice(0,15).map(function(d){return [esc(fmtFecha(d.fecha)),skuTxt(d.sku),nf(d.qty),esc(d.cliente),esc(d.motivo),(d.okQty!=null?(d.okQty?nf(d.okQty)+' u a stock'+(d.ubi?' · '+esc(d.ubi):''):'')+(d.okQty&&d.noQty?'<br>':'')+(d.noQty?nf(d.noQty)+' u: '+esc(DEVOL_DISP[d.noDisp]||''):''):esc(DEVOL_DISP[d.disp]||'')+(d.ubi?' · '+esc(d.ubi):''))];}),640)+'</div>';
  return h;}
async function devolGuardar(){
  var sku=gv('dv-sku'),can=parseInt(gv('dv-can'),10),cli=gv('dv-cli').trim();
  if(!cli||!sku||!(can>0)){toast('Completá cliente, SKU y cantidad.');return;}
  await wPut('devoluciones',{id:uid('DV'),fecha:HOY,guia:gv('dv-guia').trim(),cliente:cli,sku:sku,qty:can,lote:gv('dv-lot').trim(),vence:gv('dv-vto'),motivo:gv('dv-mot'),nota:gv('dv-nota').trim(),estado:'recibida',por:actor()});
  S.ext.dv=null;toast('Devolución registrada');render();}
async function devolCerrar(id){
  var d=WC('devoluciones').find(function(x){return x.id===id;});if(!d||d.estado!=='recibida')return;d=clean(d);
  var r=parseInt(gv('dv-r-'+id),10),ok=parseInt(gv('dv-ok-'+id),10),ubi=gv('dv-u-'+id),nd=gv('dv-n-'+id);
  if(!(r>0)){toast('Anotá cuántas unidades llegaron.');return;}
  if(isNaN(ok)||ok<0){toast('Anotá cuántas están aptas para la venta (puede ser 0).');return;}
  if(ok>r){toast('Las aptas ('+ok+') no pueden ser más que las que llegaron ('+r+').');return;}
  var no=r-ok;
  if(ok>0){if(d.vence&&dleft(d.vence)<0){toast('El lote está vencido: no puede reingresar. Ponelas como no vendibles.');return;}if(!ubi){toast('Elegí la ubicación.');return;}}
  if(d.qtyDecl==null)d.qtyDecl=d.qty;
  if(ok>0){await wPut('kardex',{id:uid('M'),fecha:HOY,tipo:'DEVOLUCION',sku:d.sku,ubicacion:ubi,'in':ok,out:0,lote:d.lote||'',vence:d.vence||'',operador:actor(),nota:'Devolución '+id});d.ubi=ubi;}
  d.qty=r;d.okQty=ok;d.noQty=no;if(no>0)d.noDisp=nd||'scrap';d.disp=no===0?'reingreso':ok===0?(nd||'scrap'):'mixto';d.estado='cerrada';d.cierre=isoNow();d.cerroPor=actor();await wPut('devoluciones',d);
  toast(no===0?'Reingresaron '+ok+' u a stock.':ok===0?'Cerrada: '+no+' u no vendibles ('+(DEVOL_DISP[d.noDisp]||'').toLowerCase()+').':'Cerrada: '+ok+' u a stock y '+no+' u no vendibles.');}
function pickCmp(a,b){var x=locParse(a.ubi),y=locParse(b.ubi);
  if(!x||!y)return String(a.ubi).localeCompare(String(b.ubi));
  var sg=x.p%2===0?-1:1;if(x.p!==y.p)return x.p-y.p;if(x.r!==y.r)return sg*(x.r-y.r);if(x.u!==y.u)return sg*(x.u-y.u);return x.a-y.a;}
function xPicking(){
  var w=W(),dr=S.ext.pickDraft,ps=WC('picks').slice().sort(function(a,b){return String(b.id).localeCompare(String(a.id));});
  var h='<form class="panel" id="x-form-pick" autocomplete="off"><h3>Nueva orden de picking</h3><div class="grid2"><label>Referencia (pedido o cliente)<input id="pk-ref" maxlength="60"></label></div><div class="row"><label>SKU<select id="pk-sku">'+w.skus.map(function(s){return '<option value="'+esc(s.codigo)+'">'+esc(s.codigo+' · '+s.producto)+'</option>';}).join('')+'</select></label><label>Cantidad<input id="pk-can" type="number" min="1" style="width:110px"></label><button class="btn" type="submit">Agregar línea</button></div>'+
    (dr.length?tbl(['SKU','Cantidad',''],dr.map(function(l,i){return [skuTxt(l.sku),nf(l.qty),'<button class="btn sm" type="button" data-act="x-pkdel" data-id="'+i+'">Quitar</button>'];}),360)+'<div class="row" style="margin-top:12px"><button class="btn ok" type="button" data-act="x-pkgen">Generar orden (FEFO)</button></div>':'')+'</form>';
  h+=ps.map(function(p){
    var done=p.estado!=='pendiente';
    return '<div class="panel"><div class="row sp"><h3>'+esc(p.ref||'Sin referencia')+' · '+esc(p.fecha)+'</h3><span class="chip '+(done?'ok':'signal')+'">'+(done?'Completada':'Pendiente')+'</span></div>'+(p.faltan&&p.faltan.length?'<div class="banner warn" role="status">'+ICON.alert+'<div><strong>Faltante</strong>'+p.faltan.map(function(f){return esc(f.sku)+': faltan '+nf(f.qty);}).join(' · ')+'</div></div>':'')+
      tbl(done?['Ubicación','SKU','Lote','Vence','Pedido','Recogido']:['Ubicación','SKU','Lote','Vence','Pedido','Recogido'],(p.lineas||[]).map(function(l,i){return ['<span class="mono">'+esc(l.ubi)+'</span>',skuTxt(l.sku),esc(l.lote||'—'),esc(l.vence||'—'),nf(l.qty),done?'<strong>'+nf(l.rec==null?l.qty:l.rec)+'</strong>':'<input id="pq-'+esc(p.id)+'-'+i+'" type="number" min="0" max="'+l.qty+'" value="'+l.qty+'" style="width:90px">'];}),560)+
      '<div class="small muted">Recorrido en serpentina: pasillos impares desde el rack 01 en adelante, pares al revés (en cada rack, de abajo hacia arriba). Si no encontrás todo, bajá la cantidad recogida: el faltante queda registrado.</div>'+
      '<div class="row" style="margin-top:12px"><button class="btn" data-act="x-pkcsv" data-id="'+esc(p.id)+'">Descargar lista (CSV)</button>'+(done?'':'<button class="btn ok" data-act="x-pkok" data-id="'+esc(p.id)+'">Confirmar picking</button><button class="btn" data-act="x-pkcancel" data-id="'+esc(p.id)+'">Cancelar</button>')+'</div></div>';}).join('');
  if(!ps.length)h+='<div class="small muted">La lista de cada orden sale ordenada por ubicación, para recorrer el depósito sin vueltas.</div>';
  return h;}
async function pickConfirmar(id){
  var p=WC('picks').find(function(x){return x.id===id;});if(!p||p.estado!=='pendiente')return;p=clean(p);var recs=[];
  for(var i=0;i<p.lineas.length;i++){var raw=gv('pq-'+id+'-'+i),r=raw===''?p.lineas[i].qty:parseInt(raw,10);if(isNaN(r)||r<0||r>p.lineas[i].qty){toast('Cantidad recogida no válida en la línea '+(i+1)+'.');return;}recs.push(r);}
  var fal={};(p.faltan||[]).forEach(function(f){fal[f.sku]=(fal[f.sku]||0)+f.qty;});
  for(var j=0;j<p.lineas.length;j++){var l=p.lineas[j];l.rec=recs[j];if(l.qty>recs[j])fal[l.sku]=(fal[l.sku]||0)+(l.qty-recs[j]);
    if(recs[j]>0)await wPut('kardex',{id:uid('M'),fecha:HOY,tipo:'OUT',sku:l.sku,ubicacion:l.ubi,'in':0,out:recs[j],lote:l.lote||'',vence:l.vence||'',operador:actor(),nota:'Picking '+p.id});}
  p.faltan=Object.keys(fal).map(function(k){return {sku:k,qty:fal[k]};});p.estado='completado';p.cierre=isoNow();await wPut('picks',p);
  toast(p.faltan.length?'Picking confirmado con faltantes.':'Picking confirmado: salida registrada en el kardex.');}
document.addEventListener('click',async function(ev){
  var t=ev.target.closest('[data-act^="x-"]');if(!t||t.tagName==='SELECT'||(t.tagName==='INPUT'&&t.type!=='button'))return;
  var a=t.dataset.act,id=t.dataset.id;
  try{
    if(a==='x-dvpre'){var e=D().entregas.find(function(x){return x.id===id;});if(e&&e.devuelve&&e.devuelve.some(function(x){return x.sku;})){var nn=0,sinSku=[];for(var ii=0;ii<e.devuelve.length;ii++){var dl=e.devuelve[ii];if(!dl.sku){sinSku.push(dl.desc);continue;}await wPut('devoluciones',{id:uid('DV'),fecha:HOY,guia:e.guia,cliente:e.cliente,sku:dl.sku,qty:dl.qty,qtyDecl:dl.qty,estadoDecl:dl.estado,lote:'',vence:'',motivo:e.estado==='no_entregada'?'No entregada (vuelve al depósito)':'Rechazada por el cliente',nota:'Declarado por el chófer '+(e.chofer||''),estado:'recibida',por:actor()});nn++;}toast(nn+(nn===1?' devolución registrada':' devoluciones registradas')+' con lo que declaró el chófer. Contá y repartí abajo.'+(sinSku.length?' Falta cargar a mano: '+sinSku.join(', ')+'.':''));if(sinSku.length){S.ext.dv={guia:e.guia,cliente:e.cliente,motivo:'Rechazada por el cliente'};render();}}
    else if(e){S.ext.dv={guia:e.guia,cliente:e.cliente,motivo:e.estado==='no_entregada'?'No entregada (vuelve al depósito)':'Rechazada por el cliente'};render();var q=function(i,v){var el=document.getElementById(i);if(el)el.value=v;};q('dv-guia',S.ext.dv.guia);q('dv-cli',S.ext.dv.cliente);q('dv-mot',S.ext.dv.motivo);var f=document.getElementById('x-form-devol');if(f)f.scrollIntoView({behavior:'smooth',block:'center'});}}
    else if(a==='x-dvok'){await devolCerrar(id);}
    else if(a==='x-pkcsv'){var p=WC('picks').find(function(x){return x.id===id;});if(p){var rows=[['Ubicación','SKU','Producto','Lote','Vence','Pedido','Recogido']];(p.lineas||[]).forEach(function(l){var s=W().skus.find(function(k){return k.codigo===l.sku;});rows.push([l.ubi,l.sku,s?s.producto:'',l.lote||'',l.vence||'',l.qty,l.rec==null?'':l.rec]);});guardarArchivo('picking-'+(p.ref||p.id).replace(/[^\w-]+/g,'_')+'.csv',csvOut(rows),'text/csv;charset=utf-8');}}
  }catch(err){toast('Algo falló. Probá de nuevo.');if(window.console)console.error(err);}});
document.addEventListener('input',function(ev){var t=ev.target,m=t&&t.id&&/^dv-(r|ok)-(.+)$/.exec(t.id);if(!m)return;var id=m[2],r=parseInt(gv('dv-r-'+id),10)||0,ok=parseInt(gv('dv-ok-'+id),10)||0,sp=document.getElementById('dv-nn-'+id);if(sp){sp.textContent=ok>r?'Las aptas superan a las que llegaron':'No vendibles: '+(r-ok);sp.className='chip'+(ok>r?' bad':r-ok>0?' warn':'');}});
document.addEventListener('submit',async function(ev){
  if(ev.target.id!=='x-form-devol')return;ev.preventDefault();
  try{await devolGuardar();}catch(err){toast('No se pudo guardar. Probá de nuevo.');}});
window.__ext.xDevol=xDevol;window.__ext.pickCmp=pickCmp;window.__ext.lotesEn=lotesEn;

/* ---------- EXT3: recepción contra OC, escaneo, etiquetas Code 128, olas de picking ---------- */
S.data.live.wms.ocs=[];
S.data.demo.wms.ocs=[
  {id:'OC-D1',ref:'OC-7781',proveedor:'Pinturas del Sur (ficticio)',fecha:addDays(-1),estado:'abierta',lineas:[{sku:'P001',qty:20,rec:0},{sku:'P002',qty:12,rec:0}],por:'Demostración'},
  {id:'OC-D2',ref:'OC-7742',proveedor:'Químicos Andinos (ficticio)',fecha:addDays(-5),estado:'parcial',lineas:[{sku:'P003',qty:30,rec:10}],por:'Demostración'}];
S.ext.oc={draft:[]};S.ext.et={tipo:'ubic'};S.ext.gd=null;S.ext.dep='eq';
// Código 128 (juego B, ASCII 32-127) -> SVG
var C128=["212222","222122","222221","121223","121322","131222","122213","122312","132212","221213","221312","231212","112232","122132","122231","113222","123122","123221","223211","221132","221231","213212","223112","312131","311222","321122","321221","312212","322112","322211","212123","212321","232121","111323","131123","131321","112313","132113","132311","211313","231113","231311","112133","112331","132131","113123","113321","133121","313121","211331","231131","213113","213311","213131","311123","311321","331121","312113","312311","332111","314111","221411","431111","111224","111422","121124","121421","141122","141221","112214","112412","122114","122411","142112","142211","241211","221114","413111","241112","134111","111242","121142","121241","114212","124112","124211","411212","421112","421211","212141","214121","412121","111143","111341","131141","114113","114311","411113","411311","113141","114131","311141","411131","211412","211214","211232","2331112"];
function code128Widths(txt){var v=[104],sum=104;for(var i=0;i<txt.length;i++){var c=txt.charCodeAt(i)-32;if(c<0||c>95)throw new Error('carácter no admitido');v.push(c);sum+=c*(i+1);}v.push(sum%103);v.push(106);return v.map(function(x){return C128[x];}).join('');}

function code128Svg(txt,h){var w=code128Widths(txt),x=10,r='';for(var i=0;i<w.length;i++){var n=+w[i];if(i%2===0)r+='<rect x="'+x+'" y="0" width="'+n+'" height="'+(h||50)+'"/>';x+=n;}return {w:x+10,svg:'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 '+(x+10)+' '+(h||50)+'" preserveAspectRatio="none" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="#fff"/><g fill="#000">'+r+'</g></svg>'};}

function bcTxt(t){return String(t==null?'':t).normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/[^\x20-\x7e]/g,'?');}
function bcSvg(t){try{return code128Svg(bcTxt(t),46).svg;}catch(_){return '';}}
var WSUBS_ALL=[['stock','Stock'],['plano','Plano'],['efic','Peso y orden'],['mov','Movimiento'],['kardex','Kardex'],['abc','ABC-XYZ'],['recep','Recepción'],['lotes','Lotes y FEFO'],['conteos','Conteos'],['picking','Picking'],['devol','Logística inversa'],['etiq','Etiquetas'],['maestros','Productos y ubicaciones']];
var WSUBS_DEP=['stock','plano','recep','lotes','conteos','picking','devol','etiq'];
function wSub(){var l=S.ui.dep==='wms'&&!S.isAdmin&&S.demoRol!=='admin'&&((S.mode==='demo'&&S.demoRol==='deposito')||(S.perfil&&S.perfil.rol==='deposito'));
  var lst=WSUBS_ALL.filter(function(t){return !l||WSUBS_DEP.indexOf(t[0])>=0;});
  return '<div class="seg lt" role="group" aria-label="Depósito">'+lst.map(function(t){return '<button data-act="wsub" data-v="'+t[0]+'" aria-pressed="'+(S.ui.wsub===t[0])+'">'+t[1]+'</button>';}).join('')+'</div>';}
function viewWms(){
  var w=W(),h='<div class="row sp"><h2>Depósito</h2><div class="row">'+(S.ui.dep==='wms'?'':'<label class="btn" style="cursor:pointer">Importar Excel<input id="w-file" type="file" accept=".xlsx,.xls,.csv,.txt" hidden></label>')+(S.mode==='live'&&!w.skus.length&&S.ui.dep!=='wms'?'<button class="btn" data-act="wcargar">Cargar datos de ejemplo</button>':'')+'</div></div>'+wSub();
  if(!w.skus.length&&S.ui.wsub!=='maestros')return h+'<div class="empty">Todavía no hay productos. Agregá el primero a mano o importá tu Excel (hojas WMS 1, 2 y 3).<div style="margin-top:10px"><button class="btn pri" data-act="wsub" data-v="maestros">Agregar productos</button></div></div>';
  var v=S.ui.wsub;
  return h+(v==='recep'?xRecep():v==='etiq'?xEtiq():v==='devol'?xDevol():v==='lotes'?xLotes():v==='conteos'?xConteos():v==='picking'?xPicking():v==='efic'?wEfic():v==='plano'?wPlano():v==='mov'?wMov():v==='kardex'?wKardex():v==='abc'?wAbc():v==='maestros'?wMaestros():wStockView()+xStockVenc());}
function viewDeposito(){
  var eqs=(D().equipos||[]).filter(function(e){return TIPOS[e.tipo]&&TIPOS[e.tipo][1]==='autoelevador';});
  var sw='<div class="seg lt" role="group" aria-label="Sección" style="margin-bottom:14px"><button data-act="x-dep" data-id="eq" aria-pressed="'+(S.ui.dep!=='wms')+'">Equipos</button><button data-act="x-dep" data-id="wms" aria-pressed="'+(S.ui.dep==='wms')+'">Depósito (recepción, picking, etiquetas)</button></div>';
  if(S.ui.dep==='wms'){if(WSUBS_DEP.indexOf(S.ui.wsub)<0)S.ui.wsub='inicio';return sw+viewWms();}
  return sw+'<h2>Equipos del depósito</h2>'+alertasPropias()+viewCheck()+
    (eqs.length?eqs.map(function(e){return eqCard(e,false);}).join(''):'<div class="empty">Todavía no hay equipos cargados. Pedile a administración que los agregue.</div>');}
function extLive(rol,onErr){var live=S.data.live,mk=function(s){return s.docs.map(function(d){return Object.assign({id:d.id},d.data());});};
  if(rol==='admin'){['gastos','ordenes','consents'].forEach(function(c){unsubs.push(db.collection(c).onSnapshot(function(s){live[c]=mk(s);render();},onErr));});unsubs.push(db.collection('wms/ocs/items').onSnapshot(function(s){live.wms.ocs=mk(s);render();},onErr));}
  if(rol==='deposito'){['skus','ubic','kardex','conteos','picks','devoluciones','ocs'].forEach(function(k){unsubs.push(db.collection('wms/'+k+'/items').onSnapshot(function(s){live.wms[k]=mk(s);render();},onErr));});}
  if(rol==='admin'||rol==='chofer'||rol==='deposito')unsubs.push(db.collection('plantillas').onSnapshot(function(s){live.plantillas=mk(s);render();},onErr));
  if(rol==='chofer')unsubs.push(db.doc('consents/'+S.me.id).onSnapshot(function(s){S.consent=s.exists?s.data():null;render();},onErr));}

/* ----- recepción contra orden de compra ----- */
function ocEstado(o){var t=0,r=0;(o.lineas||[]).forEach(function(l){t+=l.qty;r+=l.rec||0;});return r<=0?'abierta':(o.lineas.every(function(l){return (l.rec||0)>=l.qty;})?'recibida':'parcial');}
function ocChip(e){return '<span class="chip '+(e==='recibida'?'ok':e==='parcial'?'warn':'signal')+'">'+(e==='recibida'?'Recibida':e==='parcial'?'Recibida parcial':'Abierta')+'</span>';}
function xRecep(){
  var w=W(),dr=S.ext.oc.draft,ocs=WC('ocs').slice().sort(function(a,b){return String(b.id).localeCompare(String(a.id));});
  var h='<form class="panel" id="x-form-oc" autocomplete="off"><h3>Nueva orden de compra</h3><div class="grid2"><label>Referencia de la OC<input id="oc-ref" maxlength="40" placeholder="OC-1234"></label><label>Proveedor<input id="oc-prov" maxlength="80"></label></div><div class="row"><label>SKU<select id="oc-sku">'+w.skus.map(function(s){return '<option value="'+esc(s.codigo)+'">'+esc(s.codigo+' · '+s.producto)+'</option>';}).join('')+'</select></label><label>Cantidad pedida<input id="oc-can" type="number" min="1" style="width:120px"></label><button class="btn" type="submit">Agregar línea</button></div>'+
    (dr.length?tbl(['SKU','Pedido',''],dr.map(function(l,i){return [skuTxt(l.sku),nf(l.qty),'<button class="btn sm" type="button" data-act="x-ocdel" data-id="'+i+'">Quitar</button>'];}),360)+'<div class="row" style="margin-top:12px"><button class="btn ok" type="button" data-act="x-ocgen">Guardar orden de compra</button></div>':'')+'</form>';
  h+=ocs.map(function(o){
    var est=o.estado||ocEstado(o),abierta=est!=='recibida'&&est!=='cancelada';
    var rows=(o.lineas||[]).map(function(l,i){var falta=Math.max(0,l.qty-(l.rec||0)),sug=putaway(l.sku,Math.max(1,falta))[0];
      var sel='<select id="ru-'+esc(o.id)+'-'+i+'">'+w.ubic.map(function(u){return '<option value="'+esc(u.codigo)+'"'+(sug&&sug.u.codigo===u.codigo?' selected':'')+'>'+esc(u.codigo)+'</option>';}).join('')+'</select>';
      return [skuTxt(l.sku),nf(l.qty),nf(l.rec||0)+((l.rec||0)>l.qty?' <span class="chip warn">Sobrante '+nf(l.rec-l.qty)+'</span>':''),abierta?'<input id="rc-'+esc(o.id)+'-'+i+'" type="number" min="0" value="" placeholder="0" style="width:80px" aria-label="Cantidad que llega ahora">':'—',abierta?'<input id="rl-'+esc(o.id)+'-'+i+'" maxlength="30" style="width:100px" aria-label="Lote">':'—',abierta?'<input id="rv-'+esc(o.id)+'-'+i+'" type="date" aria-label="Vencimiento">':'—',abierta?sel:'—'];});
    return '<div class="panel"><div class="row sp"><h3>'+esc(o.ref||o.id)+' · '+esc(o.proveedor||'Sin proveedor')+'</h3>'+ocChip(est)+'</div><div class="small muted">Emitida '+esc(o.fecha)+(o.cierre?' · cerrada '+esc(o.cierre.slice(0,10)):'')+'</div>'+
      (abierta?'<label style="display:block;margin:10px 0">Escanear o escribir código de SKU (Enter suma 1 a la línea)<input id="oc-scan-'+esc(o.id)+'" data-oc="'+esc(o.id)+'" autocomplete="off" inputmode="text" style="max-width:260px"></label>':'')+
      tbl(['SKU','Pedido','Recibido','Llega ahora','Lote','Vence','Ubicación sugerida'],rows,760)+
      (abierta?'<div class="small muted">La ubicación sugerida sale del putaway (mismo SKU, capacidad libre). Si llega más de lo pedido, queda registrado como sobrante.</div><div class="row" style="margin-top:12px"><button class="btn ok" data-act="x-ocrec" data-id="'+esc(o.id)+'">Confirmar recepción</button><button class="btn" data-act="x-occan" data-id="'+esc(o.id)+'">Cerrar sin recibir</button></div>':'')+'</div>';}).join('');
  if(!ocs.length)h+='<div class="small muted">Cargá la orden de compra del proveedor y recibí contra ella: cada recepción entra al kardex con lote, vencimiento y ubicación.</div>';
  return h;}
async function ocGuardar(){var dr=S.ext.oc.draft;if(!dr.length){toast('Agregá al menos una línea.');return;}var ref=gv('oc-ref').trim();if(!ref){toast('Poné la referencia de la OC.');return;}
  var ag={};dr.forEach(function(l){ag[l.sku]=(ag[l.sku]||0)+l.qty;});
  await wPut('ocs',{id:uid('OC'),ref:ref,proveedor:gv('oc-prov').trim(),fecha:HOY,estado:'abierta',lineas:Object.keys(ag).map(function(k){return {sku:k,qty:ag[k],rec:0};}),por:actor()});S.ext.oc.draft=[];toast('Orden de compra guardada');render();}
async function ocRecibir(id){
  var o=WC('ocs').find(function(x){return x.id===id;});if(!o)return;o=clean(o);var movs=[];
  for(var i=0;i<o.lineas.length;i++){var raw=gv('rc-'+id+'-'+i),q=raw===''?0:parseInt(raw,10);if(isNaN(q)||q<0){toast('Cantidad no válida en la línea '+(i+1)+'.');return;}
    if(q>0){var u=gv('ru-'+id+'-'+i);if(!u){toast('Elegí la ubicación de la línea '+(i+1)+'.');return;}movs.push({i:i,q:q,u:u,lote:gv('rl-'+id+'-'+i).trim(),vence:gv('rv-'+id+'-'+i)});}}
  if(!movs.length){toast('Cargá la cantidad que llega en al menos una línea.');return;}
  for(var j=0;j<movs.length;j++){var m=movs[j],l=o.lineas[m.i];l.rec=(l.rec||0)+m.q;
    await wPut('kardex',{id:uid('M'),fecha:HOY,tipo:'IN',origen:'recepcion',oc:o.id,sku:l.sku,ubicacion:m.u,'in':m.q,out:0,lote:m.lote,vence:m.vence,operador:actor(),nota:'Recepción '+(o.ref||o.id)});}
  o.estado=ocEstado(o);o.sobrante=o.lineas.filter(function(l){return l.rec>l.qty;}).map(function(l){return {sku:l.sku,qty:l.rec-l.qty};});if(o.estado==='recibida')o.cierre=isoNow();
  await wPut('ocs',o);toast(o.sobrante.length?'Recepción registrada con sobrante.':o.estado==='recibida'?'OC recibida completa.':'Recepción parcial registrada.');}
function ocScan(el){var id=el.dataset.oc,o=WC('ocs').find(function(x){return x.id===id;});if(!o)return;var v=bcTxt(el.value).trim().toUpperCase();el.value='';if(!v)return;
  var i=o.lineas.findIndex(function(l){return String(l.sku).toUpperCase()===v;});if(i<0){toast('El SKU '+v+' no está en esta orden.');return;}
  var inp=document.getElementById('rc-'+id+'-'+i);if(inp){inp.value=String((parseInt(inp.value,10)||0)+1);inp.scrollIntoView({block:'nearest'});}el.focus();}

/* ----- etiquetas ----- */
function etqItems(){var w=W(),t=S.ext.et.tipo,out=[];
  if(t==='ubic'||t==='ambas')w.ubic.forEach(function(u){out.push({code:u.codigo,t1:u.codigo,t2:u.deposito||''});});
  if(t==='sku'||t==='ambas')w.skus.forEach(function(s){out.push({code:s.codigo,t1:s.codigo,t2:s.producto});});
  return out;}
function etqHtml(items){return items.map(function(x){return '<div class="etq"><div class="etq-bc">'+bcSvg(x.code)+'</div><div class="etq-c">'+esc(x.t1)+'</div><div class="etq-t">'+esc(x.t2)+'</div></div>';}).join('');}
function xEtiq(){var it=etqItems();
  return '<div class="panel"><h3>Etiquetas con código de barras</h3><div class="row"><label>Qué etiquetar<select id="et-tipo"><option value="ubic"'+(S.ext.et.tipo==='ubic'?' selected':'')+'>Ubicaciones</option><option value="sku"'+(S.ext.et.tipo==='sku'?' selected':'')+'>SKUs</option><option value="ambas"'+(S.ext.et.tipo==='ambas'?' selected':'')+'>Ambas</option></select></label><button class="btn" data-act="x-etprint">Imprimir</button><button class="btn" data-act="x-ethtml">Descargar para imprimir (HTML)</button></div>'+
   '<div class="small muted">Código 128. Lo leen los lectores USB o Bluetooth comunes y la cámara del celular donde el navegador lo soporte. Antes de etiquetar todo, imprimí una hoja de prueba y leela con tu lector real.</div></div><div id="etq-sheet" class="etq-sheet">'+(it.length?etqHtml(it):'<div class="empty">No hay nada para etiquetar.</div>')+'</div>';}
function etqPrint(){document.body.classList.add('print-etq');setTimeout(function(){try{window.print();}catch(_){}document.body.classList.remove('print-etq');},50);}
function etqDescargar(){var css='body{font-family:Arial,sans-serif;margin:10mm}.s{display:flex;flex-wrap:wrap;gap:4mm}.etq{width:62mm;border:1px solid #000;padding:2mm;text-align:center;break-inside:avoid}.etq-bc svg{width:100%;height:14mm;display:block}.etq-c{font:700 14px monospace}.etq-t{font-size:11px}';
  guardarArchivo('etiquetas.html','<!doctype html><meta charset="utf-8"><title>Etiquetas</title><style>'+css+'</style><div class="s">'+etqHtml(etqItems())+'</div>','text/html;charset=utf-8');}

/* ----- picking: lista, olas y guiado ----- */
function pkEstado(p){return p.estado==='completado'?['ok','Completada']:p.estado==='en_ola'?['warn','En ola']:p.estado==='cancelado'?['','Cancelada']:['signal','Pendiente'];}
function xPicking(){
  var w=W(),dr=S.ext.pickDraft,ps=WC('picks').slice().sort(function(a,b){var ma=(a.asignado&&a.asignado===miId()&&a.estado==='pendiente')?1:0,mb=(b.asignado&&b.asignado===miId()&&b.estado==='pendiente')?1:0;return (mb-ma)||String(b.id).localeCompare(String(a.id));});
  var h=S.ext.gd?guiadoHtml():'';
  var ops=opsList(),pm=S.ext.pkMeta||{},spl=stgPosList(),soc=stgOcup();
  var prev=pkPreview(dr);
  h+='<form class="panel" id="x-form-pick" autocomplete="off"><h3>Nueva orden de picking</h3><div class="grid2"><label>Referencia (pedido o cliente)<input id="pk-ref" maxlength="60" value="'+esc(pm.ref||'')+'"></label>'+
    '<label>Asignar a operario<select id="pk-op"><option value="">Sin asignar (cualquiera la toma)</option>'+ops.map(function(o){return '<option value="'+esc(o.id)+'"'+(pm.op===o.id?' selected':'')+'>'+esc(o.nombre)+'</option>';}).join('')+'</select></label></div>'+
    '<div class="grid2"><label>¿Cuándo sale? (fecha)<input id="pk-sale" type="date" min="'+HOY+'" value="'+esc(pm.sale||'')+'"></label><label>Posición de staging al terminar<select id="pk-stg"><option value="">Elegir al terminar el picking</option>'+spl.map(function(x){var u=soc[x.codigo]||0;return '<option value="'+esc(x.codigo)+'"'+(pm.stg===x.codigo?' selected':'')+'>'+esc(x.codigo)+(x.nombre?' · '+esc(x.nombre):'')+(u?' ('+u+' en uso)':' (libre)')+'</option>';}).join('')+'</select></label></div>'+(spl.length?'<div class="small muted">Si sale en 2 días o más te sugiero la posición más lejos del andén; si sale hoy o mañana, la más cerca.</div>':'<div class="small muted">Todavía no hay posiciones de staging cargadas (administración las crea en Staging y despacho).</div>')+
    '<div class="row"><label>SKU<select id="pk-sku">'+w.skus.map(function(s){return '<option value="'+esc(s.codigo)+'">'+esc(s.codigo+' · '+s.producto)+'</option>';}).join('')+'</select></label><label>Cantidad<input id="pk-can" type="number" min="1" style="width:110px"></label><button class="btn" type="submit">Agregar línea</button></div>'+
    '<details class="guia25" style="margin-top:10px"'+(S.ext.pkBulkOpen?' open':'')+'><summary>📋 Cargar muchos productos de una vez</summary><div class="small muted" style="margin:6px 0">Pegá una lista, una línea por producto: <span class="mono">SKU;cantidad</span> (también sirve separado por coma, tab o espacio, o pegado desde Excel).</div><textarea id="pk-bulk" rows="6" style="width:100%" placeholder="SKU-0001;20&#10;SKU-0002;5&#10;SKU-0003;12"></textarea><div class="row" style="margin-top:8px"><button class="btn" type="button" data-act="x-pkbulk">Agregar lista</button></div></details>'+
    (dr.length?'<div class="small muted" style="margin-top:10px">El sistema toma primero el lote que <strong>vence antes</strong>; si no vence o vencen igual, el que <strong>ingresó antes</strong> (FEFO / FIFO).</div>'+tbl(['SKU','Cantidad','Se toma de (lote · vence · ubicación)',''],prev.map(function(r,i){return [skuTxt(r.sku),nf(r.qty),r.txt,'<button class="btn sm" type="button" data-act="x-pkdel" data-id="'+i+'">Quitar</button>'];}),420)+'<div class="row" style="margin-top:12px"><button class="btn ok" type="button" data-act="x-pkgen">Generar orden (FEFO)</button><button class="btn" type="button" data-act="x-pkclr">Vaciar lista</button></div>':'')+'</form>';
  var pend=ps.filter(function(p){return p.estado==='pendiente'&&!p.ola;});
  if(pend.length>=2)h+='<div class="panel"><h3>Ola de picking</h3><div class="small muted">Tildá dos o más órdenes pendientes y juntalas en una sola recorrida: las líneas de la misma ubicación y lote se suman.</div><div class="row" style="margin-top:8px">'+pend.map(function(p){return '<label class="chip" style="cursor:pointer"><input type="checkbox" class="pk-sel" value="'+esc(p.id)+'"> '+esc(p.ref||p.id)+'</label>';}).join('')+'<button class="btn ok" data-act="x-olagen">Crear ola con las tildadas</button></div></div>';
  h+=ps.map(function(p){
    var e=pkEstado(p),done=p.estado==='completado',pend1=p.estado==='pendiente';
    if(p.estado==='en_ola')return '<div class="panel"><div class="row sp"><h3>'+esc(p.ref||p.id)+' · '+esc(p.fecha)+'</h3><span class="chip warn">En ola '+esc(p.ola||'')+'</span></div><div class="small muted">Se recoge junto con las demás órdenes de la ola.</div></div>';
    if(p.estado==='cancelado')return '';
    var title=p.ola?'Ola · '+(p.miembros||[]).length+' órdenes · '+esc(p.fecha):esc(p.ref||'Sin referencia')+' · '+esc(p.fecha);if(p.asignado)title+=' <span class="chip '+(p.asignado===miId()?'signal':'')+'">👷 '+(p.asignado===miId()?'Asignada a vos':esc(p.asignadoNombre||'Operario'))+'</span>';
    return '<div class="panel"><div class="row sp"><h3>'+title+'</h3><span class="chip '+e[0]+'">'+e[1]+'</span></div>'+
      (p.ola?'<div class="small muted">Incluye: '+(p.miembros||[]).map(function(id){var m=WC('picks').find(function(x){return x.id===id;});return esc(m?(m.ref||m.id):id);}).join(' · ')+'</div>':'')+
      (p.faltan&&p.faltan.length?'<div class="banner warn" role="status">'+ICON.alert+'<div><strong>Faltante</strong>'+p.faltan.map(function(f){return esc(f.sku)+': faltan '+nf(f.qty);}).join(' · ')+'</div></div>':'')+
      tbl(['Ubicación','SKU','Lote','Vence','Pedido','Recogido'],(p.lineas||[]).map(function(l,i){return ['<span class="mono">'+esc(l.ubi)+'</span>',skuTxt(l.sku),esc(l.lote||'—'),esc(l.vence||'—'),nf(l.qty),done?'<strong>'+nf(l.rec==null?l.qty:l.rec)+'</strong>':'<input id="pq-'+esc(p.id)+'-'+i+'" type="number" min="0" max="'+l.qty+'" value="'+l.qty+'" style="width:90px">'];}),560)+
      '<div class="small muted">Recorrido en serpentina: pasillos impares desde el rack 01 en adelante, pares al revés (en cada rack, de abajo hacia arriba). Si no encontrás todo, bajá la cantidad recogida: el faltante queda registrado.</div>'+
      '<div class="row" style="margin-top:12px"><button class="btn" data-act="x-pkcsv" data-id="'+esc(p.id)+'">Descargar lista (CSV)</button>'+(pend1&&!p.ola?palCtl20(p.id):(done&&p.stgPos?'<span class="chip ok">📍 '+esc(p.stgPos)+'</span>':''))+(pend1?'<button class="btn" data-act="x-gdstart" data-id="'+esc(p.id)+'">Picking guiado con escaneo</button><button class="btn ok" data-act="x-pkok" data-id="'+esc(p.id)+'">Confirmar picking</button>'+(p.ola?'<button class="btn" data-act="x-olacancel" data-id="'+esc(p.id)+'">Deshacer ola</button>':'<button class="btn" data-act="x-pkcancel" data-id="'+esc(p.id)+'">Cancelar</button>'):'')+'</div></div>';}).join('');
  if(!ps.length)h+='<div class="small muted">La lista de cada orden sale ordenada por ubicación, para recorrer el depósito sin vueltas.</div>';
  return h;}
async function olaCrear(){
  var ids=[].slice.call(document.querySelectorAll('.pk-sel:checked')).map(function(c){return c.value;});if(ids.length<2){toast('Tildá al menos dos órdenes.');return;}
  var miembros=ids.map(function(id){return WC('picks').find(function(x){return x.id===id&&x.estado==='pendiente'&&!x.ola;});}).filter(Boolean);if(miembros.length<2){toast('Esas órdenes ya no están pendientes.');return;}
  var m={};miembros.forEach(function(p){(p.lineas||[]).forEach(function(l,i){var k=l.ubi+'|'+l.sku+'|'+(l.lote||'');var o=m[k]=m[k]||{ubi:l.ubi,sku:l.sku,lote:l.lote||'',vence:l.vence||'',qty:0,partes:[]};o.qty+=l.qty;o.partes.push({pick:p.id,i:i,qty:l.qty});});});
  var lineas=Object.keys(m).map(function(k){return m[k];}).sort(pickCmp),id=uid('OLA');
  await wPut('picks',{id:id,ola:true,ref:'Ola de '+miembros.length+' órdenes',fecha:HOY,estado:'pendiente',miembros:miembros.map(function(p){return p.id;}),lineas:lineas,faltan:[],por:actor()});
  for(var j=0;j<miembros.length;j++){var c=clean(miembros[j]);c.estado='en_ola';c.ola=id;await wPut('picks',c);}
  toast('Ola creada: '+lineas.length+' líneas para '+miembros.length+' órdenes.');}
async function olaDeshacer(id){var o=WC('picks').find(function(x){return x.id===id;});if(!o||o.estado!=='pendiente')return;
  for(var j=0;j<(o.miembros||[]).length;j++){var mm=WC('picks').find(function(x){return x.id===o.miembros[j];});if(mm&&mm.estado==='en_ola'){mm=clean(mm);mm.estado='pendiente';delete mm.ola;await wPut('picks',mm);}}
  await wDel('picks',id);toast('Ola deshecha: las órdenes volvieron a pendientes.');}
async function pickConfirmar(id,ov){
  var p=WC('picks').find(function(x){return x.id===id;});if(!p||p.estado!=='pendiente')return;p=clean(p);var recs=[];var pl20=S.ext.pal20&&S.ext.pal20[id],sp20=(!p.ola&&window.stgPick20)?window.stgPick20(id):null;if(sp20&&sp20.err){toast(sp20.err);return;}
  for(var i=0;i<p.lineas.length;i++){var r;if(ov){r=ov[i];}else{var raw=gv('pq-'+id+'-'+i);r=raw===''?p.lineas[i].qty:parseInt(raw,10);}if(typeof r!=='number'||isNaN(r)||r<0||r>p.lineas[i].qty){toast('Cantidad recogida no válida en la línea '+(i+1)+'.');return;}recs.push(r);}
  var fal={};(p.faltan||[]).forEach(function(f){fal[f.sku]=(fal[f.sku]||0)+f.qty;});
  for(var j=0;j<p.lineas.length;j++){var l=p.lineas[j];l.rec=recs[j];if(l.qty>recs[j])fal[l.sku]=(fal[l.sku]||0)+(l.qty-recs[j]);
    if(recs[j]>0)await wPut('kardex',{id:uid('M'),fecha:HOY,tipo:'OUT',sku:l.sku,ubicacion:l.ubi,'in':0,out:recs[j],lote:l.lote||'',vence:l.vence||'',operador:actor(),nota:(p.ola?'Ola ':'Picking ')+p.id});}
  p.faltan=Object.keys(fal).map(function(k){return {sku:k,qty:fal[k]};});p.estado='completado';p.cierre=isoNow();if(sp20&&sp20.list.length){p.stgPosL=sp20.list;p.stgPos=sp20.list.join(' · ');}p.pallets=pl20&&pl20.on?Math.max(2,Math.min(50,parseInt(pl20.n,10)||2)):1;await wPut('picks',p);
  if(p.ola){for(var a=0;a<(p.miembros||[]).length;a++){var mm=WC('picks').find(function(x){return x.id===p.miembros[a];});if(!mm)continue;mm=clean(mm);var mf={};
      p.lineas.forEach(function(l,li){var left=l.rec;l.partes.forEach(function(pt){var take=Math.min(pt.qty,left);left-=take;if(pt.pick===mm.id){var ml=mm.lineas[pt.i];if(ml){ml.rec=take;if(take<ml.qty)mf[ml.sku]=(mf[ml.sku]||0)+(ml.qty-take);}}});});
      mm.faltan=Object.keys(mf).map(function(k){return {sku:k,qty:mf[k]};});mm.estado='completado';mm.cierre=isoNow();await wPut('picks',mm);}}
  toast(p.faltan.length?'Picking confirmado con faltantes.':'Picking confirmado: salida registrada en el kardex.');}

/* ----- picking guiado: ubicación -> SKU -> cantidad ----- */
function guiadoHtml(){var g=S.ext.gd,p=WC('picks').find(function(x){return x.id===g.id;});if(!p){S.ext.gd=null;return '';}
  var l=p.lineas[g.i],n=p.lineas.length,s=W().skus.find(function(k){return k.codigo===l.sku;});
  var paso=!g.okU?'1. Andá a la ubicación y escaneá su etiqueta':!g.okS?'2. Escaneá el producto':'3. Confirmá la cantidad';
  return '<div class="panel" id="x-guiado" style="border:2px solid var(--accent)"><div class="row sp"><h3>Picking guiado · línea '+(g.i+1)+' de '+n+'</h3><button class="btn sm" data-act="x-gdend">Salir</button></div>'+
   '<div style="font-size:34px;font-weight:700;letter-spacing:.02em" class="mono">'+esc(l.ubi)+'</div><div style="font-size:18px">'+esc(l.sku)+' · '+esc(s?s.producto:'')+'</div><div class="small muted">Lote '+esc(l.lote||'—')+' · vence '+esc(l.vence||'—')+' · pedido '+nf(l.qty)+'</div>'+
   '<div class="banner '+(g.okU&&g.okS?'ok':'warn')+'" role="status" style="margin-top:10px"><div><strong>'+paso+'</strong>'+(g.okU?'Ubicación ✓ ':'')+(g.okS?'Producto ✓':'')+'</div></div>'+
   (g.okS?'<div class="row"><label>Cantidad recogida<input id="gd-q" type="number" min="0" max="'+l.qty+'" value="'+l.qty+'" style="width:110px"></label><button class="btn ok" data-act="x-gdok">Confirmar y seguir</button></div>':
    '<div class="row"><label>Escaneá o escribí el código<input id="gd-scan" autocomplete="off" style="max-width:240px"></label><button class="btn" data-act="x-gdcam">Usar cámara</button></div><div class="row"><button class="btn sm" data-act="x-gdman">'+(g.okU?'Marcar producto sin escanear':'Marcar ubicación sin escanear')+'</button></div>')+
   '<div class="row" style="margin-top:8px"><button class="btn sm" data-act="x-gdskip">No lo encuentro (recogí 0)</button></div><div id="gd-cam"></div></div>';}
function gdStart(id){S.ext.gd={id:id,i:0,okU:false,okS:false,rec:[]};render();gdFocus();}
function gdFocus(){setTimeout(function(){var e=document.getElementById('gd-scan')||document.getElementById('gd-q');if(e){e.focus();var g=document.getElementById('x-guiado');if(g)g.scrollIntoView({block:'nearest'});}},30);}
function gdScan(v){var g=S.ext.gd;if(!g)return;var p=WC('picks').find(function(x){return x.id===g.id;}),l=p.lineas[g.i];v=bcTxt(v).trim().toUpperCase();if(!v)return;
  if(!g.okU){if(locNorm(v)===locNorm(l.ubi)){g.okU=true;render();gdFocus();}else{toast('No es la ubicación: '+v+'. Buscá '+l.ubi+'.');gdFocus();}}
  else if(!g.okS){if(v===String(l.sku).toUpperCase()){g.okS=true;render();gdFocus();}else{toast('No es el producto: '+v+'. Buscá '+l.sku+'.');gdFocus();}}}
async function gdNext(q){var g=S.ext.gd,p=WC('picks').find(function(x){return x.id===g.id;});g.rec[g.i]=q;
  if(g.i+1<p.lineas.length){g.i++;g.okU=false;g.okS=false;render();gdFocus();}else{var rec=g.rec.slice(),id=g.id;S.ext.gd=null;await pickConfirmar(id,rec);}}
function gdCam(){var host=document.getElementById('gd-cam');if(!host)return;
  if(!('BarcodeDetector' in window)||!(navigator.mediaDevices&&navigator.mediaDevices.getUserMedia)){toast('Este navegador no lee códigos con la cámara. Usá un lector o escribí el código.');return;}
  var det;try{det=new BarcodeDetector({formats:['code_128']});}catch(_){toast('La cámara no puede leer Code 128 en este navegador.');return;}
  navigator.mediaDevices.getUserMedia({video:{facingMode:'environment'}}).then(function(st){
    var v=document.createElement('video');v.setAttribute('playsinline','');v.muted=true;v.srcObject=st;v.style.cssText='width:100%;max-width:420px;border-radius:8px;margin-top:8px';host.innerHTML='';host.appendChild(v);v.play();
    var stop=function(){st.getTracks().forEach(function(t){t.stop();});host.innerHTML='';clearInterval(tm);},tm=setInterval(function(){det.detect(v).then(function(r){if(r&&r.length){stop();gdScan(r[0].rawValue);}}).catch(function(){});},300);
    setTimeout(stop,60000);}).catch(function(){toast('No se pudo abrir la cámara (permiso denegado).');});}
document.addEventListener('click',async function(ev){
  var t=ev.target.closest('[data-act^="x-"]');if(!t||t.tagName==='SELECT'||(t.tagName==='INPUT'&&t.type!=='button'))return;
  var a=t.dataset.act,id=t.dataset.id;
  try{
    if(a==='x-dep'){S.ui.dep=id;render();}
    else if(a==='x-ocdel'){S.ext.oc.draft.splice(parseInt(id,10),1);render();}
    else if(a==='x-ocgen'){await ocGuardar();}
    else if(a==='x-ocrec'){await ocRecibir(id);}
    else if(a==='x-occan'){var o=WC('ocs').find(function(x){return x.id===id;});if(o){o=clean(o);o.estado=(o.lineas||[]).some(function(l){return l.rec>0;})?'recibida':'cancelada';o.cierre=isoNow();await wPut('ocs',o);toast('Orden cerrada');}}
    else if(a==='x-etprint'){etqPrint();}
    else if(a==='x-ethtml'){etqDescargar();}
    else if(a==='x-olagen'){await olaCrear();}
    else if(a==='x-olacancel'){await olaDeshacer(id);}
    else if(a==='x-gdstart'){gdStart(id);}
    else if(a==='x-gdend'){S.ext.gd=null;render();}
    else if(a==='x-gdcam'){gdCam();}
    else if(a==='x-gdman'){var g=S.ext.gd;if(g){if(!g.okU)g.okU=true;else g.okS=true;render();gdFocus();}}
    else if(a==='x-gdskip'){if(S.ext.gd)await gdNext(0);}
    else if(a==='x-gdok'){var q=parseInt(gv('gd-q'),10),g2=S.ext.gd;if(!g2)return;var p=WC('picks').find(function(x){return x.id===g2.id;});if(isNaN(q)||q<0||q>p.lineas[g2.i].qty){toast('Cantidad no válida.');return;}await gdNext(q);}
  }catch(err){toast('Algo falló. Probá de nuevo.');if(window.console)console.error(err);}});
document.addEventListener('change',function(ev){if(ev.target.id==='et-tipo'){S.ext.et.tipo=ev.target.value;render();}});
document.addEventListener('keydown',function(ev){if(ev.key!=='Enter')return;var el=ev.target;
  if(el&&el.id==='gd-scan'){ev.preventDefault();var v=el.value;el.value='';gdScan(v);}
  else if(el&&el.dataset&&el.dataset.oc&&/^oc-scan-/.test(el.id)){ev.preventDefault();ocScan(el);}
  else if(el&&el.id==='gd-q'){ev.preventDefault();var b=document.querySelector('[data-act="x-gdok"]');if(b)b.click();}});
document.addEventListener('submit',function(ev){
  if(ev.target.id!=='x-form-oc')return;ev.preventDefault();var s=gv('oc-sku'),q=parseInt(gv('oc-can'),10);if(!s||!(q>0)){toast('Elegí SKU y cantidad.');return;}S.ext.oc.draft.push({sku:s,qty:q});render();});
window.__ext.bcSvg=bcSvg;window.__ext.code128Widths=code128Widths;window.__ext.ocEstado=ocEstado;window.__ext.xPicking=xPicking;
/* ---------- EXT4: reparto automático entre varios vehículos ---------- */
S.ext.flota={max:25,def:1000,off:{}};
function flotaPlan(){
  var dia=diaStr(S.ui.optDia==='manana'?'manana':'hoy'),f=S.ext.flota,dep=D().depot,v=S.ext.vrp,t0=dia===HOY?Math.max(new Date().getHours()*60+new Date().getMinutes(),0):480;
  var chs=D().perfiles.filter(function(p){return p.rol==='chofer'&&!f.off[p.id];}).map(function(p){
    var eq=(D().equipos||[]).find(function(e){return e.asignado===p.id&&(e.tipo==='camion'||e.tipo==='utilitario');});
    return {id:p.id,nombre:p.nombre||p.id,cap:eq&&eq.cap>0?eq.cap:f.def,capReal:!!(eq&&eq.cap>0),eq:eq?eq.nombre:'',stops:[],kg:0};});
  var todas=D().entregas.filter(function(e){return e.fecha===dia&&e.estado==='programada';});
  var xy=todas.filter(hasXY),sinXY=todas.filter(function(e){return !hasXY(e);}),capMax=chs.reduce(function(m,c){return Math.max(m,c.cap);},0);
  var ang=function(e){return Math.atan2(e.lat-dep.lat,e.lng-dep.lng);};
  var ord=xy.slice().sort(function(a,b){return ang(a)-ang(b);}),sobran=[];
  // se arranca en el mayor hueco angular para no cortar un barrio por la mitad
  if(ord.length>2){var bi=0,bg=-1;for(var i=0;i<ord.length;i++){var g=(ang(ord[(i+1)%ord.length])-ang(ord[i])+2*Math.PI)%(2*Math.PI);if(g>bg){bg=g;bi=(i+1)%ord.length;}}ord=ord.slice(bi).concat(ord.slice(0,bi));}
  var ci=0;
  ord.forEach(function(e){var kg=e.pesoKg||0;if(kg>capMax||!chs.length){sobran.push({e:e,why:chs.length?'pesa '+nf(kg)+' kg, más que cualquier vehículo':'no hay choferes disponibles'});return;}
    while(ci<chs.length&&(chs[ci].kg+kg>chs[ci].cap||chs[ci].stops.length>=f.max))ci++;
    if(ci>=chs.length){sobran.push({e:e,why:'no entra en la capacidad ni en el máximo de paradas de la flota'});return;}
    chs[ci].stops.push(e);chs[ci].kg+=kg;});
  chs.forEach(function(c){c.seq=optimizeTW(dep,c.stops,t0,v.spd,v.svc);var r=simRuta(dep,c.seq,t0,v.spd,v.svc);c.km=r.km;c.late=r.late;c.fin=r.end;});
  return {dia:dia,chs:chs,sobran:sobran,sinXY:sinXY,total:todas.length};}
function panelFlota(){
  var P=flotaPlan(),f=S.ext.flota;if(!P.total)return '';
  var all=D().perfiles.filter(function(p){return p.rol==='chofer';});
  var h='<div class="panel"><h3>Reparto entre varios vehículos</h3><p class="small muted">Divide las entregas programadas sin salir de camino ('+P.total+') entre los choferes tildados: agrupa por zona alrededor del depósito, respeta la capacidad en kg de cada vehículo y el máximo de paradas, y ordena cada ruta con las ventanas horarias. Heurística sin tránsito real: revisala antes de aplicar.</p>'+
   '<div class="row">'+all.map(function(p){return '<label class="chip" style="cursor:pointer"><input type="checkbox" data-fl="'+esc(p.id)+'"'+(f.off[p.id]?'':' checked')+'> '+esc(p.nombre||p.id)+'</label>';}).join('')+'</div>'+
   '<div class="row"><label>Máx. paradas por ruta<input id="x-fmax" type="number" min="1" max="80" value="'+f.max+'" style="width:100px"></label><label>Capacidad si el vehículo no la tiene cargada (kg)<input id="x-fdef" type="number" min="50" value="'+f.def+'" style="width:120px"></label></div>';
  if(!P.chs.length)return h+'<div class="empty">Tildá al menos un chofer.</div></div>';
  h+=tbl(['Chofer','Vehículo','Paradas','Carga','Km','Atrasos','Termina'],P.chs.map(function(c){var pc=Math.round(c.kg/c.cap*100);return [esc(c.nombre),esc(c.eq||'—')+(c.capReal?'':' <span class="chip warn">capacidad supuesta</span>'),c.seq.length,nf(c.kg)+' / '+nf(c.cap)+' kg <span class="chip '+(pc>100?'bad':pc>85?'warn':'ok')+'">'+pc+'%</span>',nf(c.km,1),c.late?'<span class="chip bad">'+nf(c.late)+' min</span>':'<span class="chip ok">ninguno</span>',c.seq.length?hhmm(c.fin):'—'];}),620);
  if(P.sobran.length)h+='<div class="banner warn" role="status">'+ICON.alert+'<div><strong>'+P.sobran.length+' sin asignar</strong>'+P.sobran.map(function(s){return esc(s.e.guia+' '+s.e.cliente)+' ('+esc(s.why)+')';}).join(' · ')+'</div></div>';
  if(P.sinXY.length)h+='<div class="banner warn" role="status">'+ICON.alert+'<div><strong>'+P.sinXY.length+' sin coordenadas</strong>No se pueden ubicar en el mapa: '+P.sinXY.map(function(e){return esc(e.guia);}).join(' · ')+'. Corregí la dirección y volvé a calcular.</div></div>';
  return h+'<div class="row" style="margin-top:12px"><button class="btn pri" data-act="x-flotaaplicar">Aplicar este reparto</button></div></div>';}
async function flotaAplicar(){
  var P=flotaPlan(),n=0;
  try{for(var i=0;i<P.chs.length;i++){var c=P.chs[i];for(var k=0;k<c.seq.length;k++){var e=clean(c.seq[k]);if(e.choferId!==c.id||e.orden!==k+1||e.chofer!==c.nombre){e.choferId=c.id;e.chofer=c.nombre;e.orden=k+1;await persist(e);n++;}}}
    toast(n?'Reparto aplicado a '+n+' entregas. Cada chofer ve su ruta.':'El reparto ya estaba aplicado.');}catch(_){toast('No se pudo aplicar el reparto.');}}
document.addEventListener('click',function(ev){var t=ev.target.closest('[data-act="x-flotaaplicar"]');if(t)flotaAplicar();});
document.addEventListener('change',function(ev){var t=ev.target;
  if(t.dataset&&t.dataset.fl){S.ext.flota.off[t.dataset.fl]=!t.checked;render();}
  else if(t.id==='x-fmax'){var n=parseInt(t.value,10);if(n>=1&&n<=80){S.ext.flota.max=n;render();}}
  else if(t.id==='x-fdef'){var m=parseInt(t.value,10);if(m>=50){S.ext.flota.def=m;render();}}});
window.__ext.flotaPlan=flotaPlan;
/* ---------- EXT5: puesta en marcha (plantillas, alta masiva, vehículos, saldo inicial, acta, Lunes OK) ---------- */
S.data.live.wms.actas=[];S.data.demo.wms.actas=[];
S.ext.ob={bulk:null,cred:null,eq:null,cnt:null,full:false,srv:null,srvAsk:false,acta:null};
var OB_ROLES={admin:'admin',administracion:'admin',administración:'admin',administrativo:'admin',chofer:'chofer',deposito:'deposito',depósito:'deposito',cliente:'cliente'};
function obCsv(name,rows){guardarArchivo(name,csvOut(rows),'text/csv;charset=utf-8');}
function obPlantilla(k){
  if(k==='usuarios')obCsv('plantilla-usuarios.csv',[['Nombre','Correo','Rol (admin, chofer, deposito o cliente)','Teléfono','Área o empresa'],['Marcos Peralta','marcos@tuempresa.com','chofer','11 5555-0001','Flota propia'],['Julián Sosa','julian@tuempresa.com','deposito','','Picking'],['Ferretería Del Plata','compras@delplata.com','cliente','11 4444-0002','']]);
  else if(k==='vehiculos')obCsv('plantilla-vehiculos.csv',[['Tipo (camion, utilitario, autoelevador, apilador)','Nombre','Patente o código','Marca y modelo','Año','Capacidad (kg)','Energía','Chofer asignado (nombre exacto)','Vence seguro','Vence VTV/RTO','Vence mantenimiento'],['camion','Camión 1','AB123CD','Mercedes 1218','2019','8000','Diésel','Marcos Peralta','2027-03-31','2027-02-15','2027-01-20'],['autoelevador','Autoelevador 1','AE-01','Toyota 8FGU25','2019','2500','GLP','','','','2027-01-10']]);
  else if(k==='conteo')obCsv('plantilla-conteo.csv',[['Ubicación','SKU','Cantidad','Lote','Vence'],['01:01:01:00','P001','120','L2601','2027-06-30'],['01:01:01:01','P002','48','','']]);}
function obHead(rows){var h=rows[0].map(norm);return {rows:rows.slice(1),col:function(r,names){for(var i=0;i<names.length;i++){var nn=norm(names[i]),j=h.findIndex(function(x){return x.indexOf(nn)===0;});if(j>=0)return String(r[j]==null?'':r[j]).trim();}return '';}};}
function obXlsxRows(f){return loadXLSX().then(function(){return f.arrayBuffer();}).then(function(buf){var wb=XLSX.read(buf,{type:'array',cellDates:true}),ws=wb.Sheets[wb.SheetNames[0]],r=XLSX.utils.sheet_to_json(ws,{header:1,raw:true,defval:''});
  return r.map(function(row){return row.map(function(v){if(v instanceof Date&&!isNaN(v))return v.toISOString().slice(0,10);return v==null?'':String(v).trim();});}).filter(function(row){return row.some(function(v){return v!=='';});});});}
function obLeer(inputId,cb){var f=document.getElementById(inputId);if(!f||!f.files||!f.files[0]){toast('Elegí un archivo CSV o Excel.');return;}var file=f.files[0];
  var fin=function(rows){try{if(rows.length<2){toast('El archivo no tiene filas.');return;}cb(rows);}catch(_){toast('No se pudo leer el archivo.');}};
  if(/\.xlsx?$/i.test(file.name)){toast('Leyendo el Excel…');obXlsxRows(file).then(fin).catch(function(){toast('No se pudo leer el Excel. Probá guardarlo como CSV.');});return;}
  leerTxt(file).then(function(txt){fin(csvParse(txt));}).catch(function(){toast('No se pudo leer el archivo.');});}
/* usuarios */
function obUsuarios(rows){var H=obHead(rows),ok=[],err=[],seen={};
  H.rows.forEach(function(r,i){var n=H.col(r,['nombre']),m=H.col(r,['correo','email','mail']).toLowerCase(),ro=OB_ROLES[norm(H.col(r,['rol'])).replace('deposito','deposito')]||OB_ROLES[H.col(r,['rol']).toLowerCase()],tel=H.col(r,['telefono','tel']),ar=H.col(r,['area','área','empresa']);
    var e=!n?'Falta el nombre':!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(m)?'Correo no válido':!ro?'Rol no válido':seen[m]?'Correo repetido':'';
    if(e)err.push({fila:i+2,txt:n||m||'(vacía)',e:e});else{seen[m]=1;ok.push({name:n,email:m,role:ro,telefono:tel,area:ar});}});
  S.ext.ob.bulk={ok:ok,err:err};S.ext.ob.cred=null;render();}
async function obCrear(){var b=S.ext.ob.bulk;if(!b||!b.ok.length)return;
  try{var r=await apiJson('POST','/api/users/bulk',{users:b.ok});S.ext.ob.cred=r;S.ext.ob.bulk=null;loadUsers();toast(r.creados.length+' usuarios creados.'+((r.errores||[]).length?' '+r.errores.length+' no se crearon (ya existían o tenían error).':''));render();}catch(e){toast((e&&e.message)||'No se pudo crear.');}}
/* vehículos */
function obVehiculos(rows){var H=obHead(rows),ok=[],err=[],ch=(D().perfiles||[]).filter(function(p){return p.rol==='chofer';}),TM={camion:'camion',camión:'camion',utilitario:'utilitario',camioneta:'utilitario',autoelevador:'autoelevador',apilador:'apilador',zorra:'apilador'};
  H.rows.forEach(function(r,i){var tp=TM[H.col(r,['tipo']).toLowerCase()]||TM[norm(H.col(r,['tipo']))],nom=H.col(r,['nombre']),cap=toNum(H.col(r,['capacidad'])),an=parseInt(H.col(r,['ano','año']),10),chn=H.col(r,['chofer']),c=chn?ch.find(function(x){return norm(x.nombre)===norm(chn);}):null;
    var e=!nom?'Falta el nombre':!tp?'Tipo no válido':'';
    if(e){err.push({fila:i+2,txt:nom||'(vacía)',e:e});return;}
    var docs=[['Seguro',['vence seguro','seguro']],['VTV/RTO',['vence vtv','vtv']],['Mantenimiento',['vence mantenimiento','mantenimiento']]].map(function(d){var v=pFecha(H.col(r,d[1]));return /^\d{4}-\d{2}-\d{2}$/.test(v)?{nombre:d[0],vence:v}:null;}).filter(Boolean);
    var ident=H.col(r,['patente','codigo','ident']),old=ident?(D().equipos||[]).find(function(x){return norm(x.ident)===norm(ident);}):null;
    ok.push({id:old?old.id:uid('E'),tipo:tp,nombre:nom,ident:ident,marca:H.col(r,['marca']),anio:an>1950?an:'',cap:cap>0?cap:0,energia:H.col(r,['energia']),asignado:c?c.id:'',docs:docs,_nuevo:!old,_sin:chn&&!c?chn:''});});
  S.ext.ob.eq={ok:ok,err:err};render();}
async function obGuardarEq(){var q=S.ext.ob.eq,sin=[];if(!q||!q.ok.length)return;try{for(var i=0;i<q.ok.length;i++){var e=q.ok[i],n=e._nuevo;delete e._nuevo;if(e._sin)sin.push(e._sin);delete e._sin;await eqPut(e);}toast(q.ok.length+' vehículos guardados.'+(sin.length?' '+sin.length+' sin chofer asignado (no existe "'+sin[0]+'"'+(sin.length>1?' y otros':'')+'): asignalo en Equipos y personal.':''));S.ext.ob.eq=null;render();}catch(_){toast('No se pudieron guardar todos.');}}
/* conteo -> saldo inicial */
function obStockKey(){var m={};W().kardex.forEach(function(x){var k=x.ubicacion+'|'+x.sku+'|'+(x.lote||'');m[k]=(m[k]||0)+(x.in||0)-(x.out||0);});return m;}
function obConteo(rows){var H=obHead(rows),w=W(),err=[],cnt={},ub={},sk={};w.ubic.forEach(function(u){ub[norm(u.codigo)]=u.codigo;});w.skus.forEach(function(s){sk[norm(s.codigo)]=s;});
  H.rows.forEach(function(r,i){var u=ub[norm(H.col(r,['ubicacion','ubic']))],s=sk[norm(H.col(r,['sku','codigo']))],q=toNum(H.col(r,['cantidad','cant'])),lote=H.col(r,['lote']),v=pFecha(H.col(r,['vence']));
    var e=!u?'La ubicación "'+H.col(r,['ubicacion','ubic'])+'" no existe':!s?'El SKU "'+H.col(r,['sku','codigo'])+'" no existe':!(q>=0)||Math.floor(q)!==q?'Cantidad no válida':'';
    if(e){err.push({fila:i+2,txt:e});return;}
    var k=u+'|'+s.codigo+'|'+lote,o=cnt[k]=cnt[k]||{ubi:u,sku:s.codigo,lote:lote,vence:/^\d{4}-\d{2}-\d{2}$/.test(v)?v:'',q:0};o.q+=q;});
  S.ext.ob.cnt={cnt:cnt,err:err,rows:null};obCalc();render();}
function obCalc(){var c=S.ext.ob.cnt;if(!c)return;var sys=obStockKey(),keys={},rows=[];
  Object.keys(c.cnt).forEach(function(k){keys[k]=1;});if(S.ext.ob.full)Object.keys(sys).forEach(function(k){if(sys[k]!==0)keys[k]=1;});
  Object.keys(keys).sort().forEach(function(k){var p=k.split('|'),o=c.cnt[k]||{ubi:p[0],sku:p[1],lote:p[2],vence:'',q:0},s=sys[k]||0;rows.push({ubi:o.ubi,sku:o.sku,lote:o.lote,vence:o.vence,sis:s,cont:o.q,dif:o.q-s});});
  c.rows=rows;}
function obSkuNom(c){var s=W().skus.find(function(x){return x.codigo===c;});return s?s.producto:'';}
async function obAplicarConteo(){var c=S.ext.ob.cnt;if(!c||!c.rows)return;var mov=c.rows.filter(function(r){return r.dif!==0;}),tot={};
  W().kardex.forEach(function(x){var k=x.ubicacion+'|'+x.sku;tot[k]=(tot[k]||0)+(x.in||0)-(x.out||0);});
  try{for(var i=0;i<mov.length;i++){var r=mov[i],ini=!(tot[r.ubi+'|'+r.sku]>0);
      await wPut('kardex',{id:uid('M'),fecha:HOY,tipo:r.dif>0?'IN':'OUT',origen:ini?'saldo_inicial':'ajuste_conteo','in':r.dif>0?r.dif:0,out:r.dif<0?-r.dif:0,sku:r.sku,ubicacion:r.ubi,lote:r.lote,vence:r.vence,operador:actor(),nota:ini?'Saldo inicial':'Ajuste por conteo'});}
    var acta={id:uid('AC'),fecha:HOY,ts:isoNow(),por:actor(),completo:!!S.ext.ob.full,filas:c.rows,movs:mov.length,tipo:'Saldo inicial / ajuste por conteo'};await wPut('actas',acta);
    S.ext.ob.acta=acta;S.ext.ob.cnt=null;toast(mov.length?'Conteo aplicado: '+mov.length+' movimientos en el kardex.':'El conteo coincide con el sistema: no hubo movimientos.');render();}catch(_){toast('No se pudo aplicar el conteo.');}}
function actaHtml(a,solo){
  var emp=(window.APP_CONFIG&&window.APP_CONFIG.name)||'Empresa',tot=a.filas.reduce(function(t,r){return {s:t.s+r.sis,c:t.c+r.cont};},{s:0,c:0});
  var rows=a.filas.map(function(r){return '<tr><td>'+esc(r.ubi)+'</td><td>'+esc(r.sku)+' '+esc(obSkuNom(r.sku))+'</td><td>'+esc(r.lote||'—')+'</td><td>'+esc(r.vence||'—')+'</td><td class="n">'+nf(r.sis)+'</td><td class="n">'+nf(r.cont)+'</td><td class="n'+(r.dif?' d':'')+'">'+(r.dif>0?'+':'')+nf(r.dif)+'</td></tr>';}).join('');
  return '<div class="acta"><h2>Acta de conteo físico</h2><div class="small">'+esc(emp)+' · '+esc(dmy(a.fecha))+' · Realizó: '+esc(a.por)+(a.completo?' · Conteo completo del depósito':' · Conteo parcial')+'</div>'+
   '<table><thead><tr><th>Ubicación</th><th>SKU</th><th>Lote</th><th>Vence</th><th>Sistema</th><th>Contado</th><th>Dif.</th></tr></thead><tbody>'+rows+'</tbody><tfoot><tr><td colspan="4">Totales</td><td class="n">'+nf(tot.s)+'</td><td class="n">'+nf(tot.c)+'</td><td class="n">'+nf(tot.c-tot.s)+'</td></tr></tfoot></table>'+
   '<p class="small">Las partes dejan constancia de que las cantidades contadas son el saldo de partida del sistema. Las diferencias contra el sistema quedaron registradas en el kardex como saldo inicial o ajuste por conteo.</p>'+
   '<div class="firmas"><div>Responsable de la empresa<br><br>_______________________<br>Aclaración y DNI</div><div>Quien realizó el conteo<br><br>_______________________<br>Aclaración</div></div></div>';}
function actaDescargar(a){var css='body{font-family:Arial,sans-serif;margin:14mm;font-size:12px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #444;padding:4px 6px;text-align:left}.n{text-align:right}.d{font-weight:700}.firmas{display:flex;gap:40px;margin-top:50px}.firmas div{flex:1}';
  guardarArchivo('acta-conteo-'+a.fecha+'.html','<!doctype html><meta charset="utf-8"><title>Acta de conteo</title><style>'+css+'</style>'+actaHtml(a),'text/html;charset=utf-8');}
function actaImprimir(){document.body.classList.add('print-acta');setTimeout(function(){try{window.print();}catch(_){}document.body.classList.remove('print-acta');},50);}
/* Lunes OK */
function obCargarSrv(){if(!standalone())return;S.ext.ob.srvAsk=true;apiJson('GET','/api/onboarding').then(function(r){S.ext.ob.srv=r;render();}).catch(function(){S.ext.ob.srv={error:true};render();});}
function lunesItems(){
  var w=W(),eq=D().equipos||[],pf=D().perfiles||[],chs=pf.filter(function(p){return p.rol==='chofer';}),cli=pf.filter(function(p){return p.rol==='cliente';}),checks=D().checks||[],hace7=addDays(-7),srv=S.ext.ob.srv,it=[];
  var add=function(g,t,lvl,det,tab,req){it.push({g:g,t:t,lvl:lvl,det:det,tab:tab,req:req!==false});};
  var sinChk=eq.filter(function(e){return !checks.some(function(c){return c.equipoId===e.id&&c.fecha>=hace7;});});
  var sinCons=chs.filter(function(c){return S.mode==='demo'?false:!(D().consents||[]).some(function(x){return x.id===c.id&&x.ok!==false;});});
  var sinVeh=chs.filter(function(c){return !eq.some(function(e){return e.asignado===c.id&&(e.tipo==='camion'||e.tipo==='utilitario');});});
  var prog=D().entregas.filter(function(e){return e.fecha>=HOY&&e.estado==='programada';}).length;
  var tieneActa=(w.actas||[]).length>0,kard=w.kardex.length>0;
  add('Datos','Clientes cargados',cli.length?'ok':'bad',cli.length?cli.length+' clientes':'Todavía no hay clientes. Cargalos con la alta masiva.','carga');
  add('Datos','Choferes cargados',chs.length?'ok':'bad',chs.length?chs.length+' choferes':'Todavía no hay choferes.','carga');
  add('Datos','Vehículos cargados',eq.length?'ok':'bad',eq.length?eq.length+' equipos':'Importá la planilla de vehículos.','carga');
  add('Datos','Cada chofer con su vehículo asignado',!chs.length?'bad':sinVeh.length?'warn':'ok',sinVeh.length?'Sin vehículo: '+sinVeh.map(function(c){return c.nombre;}).join(', '):'Todos asignados','carga',false);
  add('Depósito','SKUs y ubicaciones cargados',w.skus.length&&w.ubic.length?'ok':'bad',w.skus.length+' SKUs · '+w.ubic.length+' ubicaciones','carga');
  add('Depósito','Saldo inicial cargado',kard?'ok':'bad',kard?'El kardex tiene movimientos':'Hacé el conteo físico y cargalo.','carga');
  add('Depósito','Acta de conteo emitida',tieneActa?'ok':'warn',tieneActa?'Hay '+w.actas.length+' acta(s)':'Imprimila y que la firme el cliente.','carga',false);
  add('Flota','Check list de cada vehículo en los últimos 7 días',!eq.length?'bad':sinChk.length?'warn':'ok',sinChk.length?'Sin check list: '+sinChk.map(function(e){return e.nombre;}).join(', '):'Todos al día','listas',false);
  add('Choferes','Consentimiento de ubicación de cada chofer',!chs.length?'bad':S.mode==='demo'?'warn':sinCons.length?'warn':'ok',S.mode==='demo'?'Se verifica en tu servidor':sinCons.length?'Faltan: '+sinCons.map(function(c){return c.nombre;}).join(', ')+' (lo aceptan al primer ingreso)':'Todos aceptaron','datos',false);
  add('Operación','Entregas programadas desde hoy',prog?'ok':'warn',prog?prog+' entregas':'Cargá las entregas del primer día por Importar / exportar.','imp',false);
  if(standalone()){
    if(!srv)add('Servidor','Estado del servidor','warn','Consultando…','',false);
    else if(srv.error)add('Servidor','Estado del servidor','warn','No se pudo consultar.','',false);
    else{
      add('Servidor','Administración con verificación en dos pasos',srv.totpAdmin?'ok':'bad',srv.totpAdmin?'Activada':'Activala en Datos y seguridad.','datos');
      add('Servidor','Conexión segura (https)',srv.https?'ok':'bad',srv.https?'BASE_URL con https':'Configurá BASE_URL con https.','',true);
      var d=srv.backup&&srv.backup.ultima,viejo=d&&d<addDays(-2);
      add('Servidor','Copia de seguridad reciente',!d?'bad':viejo?'warn':'ok',!d?'No hay copias. Corré npm run backup o activá el servicio de copia.':'Última: '+dmy(d)+(viejo?' (más de 2 días)':''),'',true);
      add('Servidor','Correo para avisos y recuperar claves',srv.correo?'ok':'warn',srv.correo?'Configurado':'Sin SMTP: no salen avisos ni recuperación de clave.','',false);}}
  return it;}
function xLunes(){
  if(standalone()&&!S.ext.ob.srvAsk)setTimeout(obCargarSrv,0);
  var it=lunesItems(),bad=it.filter(function(x){return x.lvl==='bad'&&x.req;}).length,warn=it.filter(function(x){return x.lvl==='warn'||(x.lvl==='bad'&&!x.req);}).length,okn=it.filter(function(x){return x.lvl==='ok';}).length;
  var ban=bad?'<div class="banner bad" role="status">'+ICON.alert+'<div><strong>Todavía no está listo: faltan '+bad+' requisitos</strong>Resolvelos antes de que arranque el lunes.</div></div>':warn?'<div class="banner warn" role="status">'+ICON.alert+'<div><strong>Se puede arrancar, con '+warn+' recomendaciones pendientes</strong>Conviene resolverlas esta semana.</div></div>':'<div class="banner ok" role="status">'+ICON.check+'<div><strong>Todo listo para arrancar el lunes</strong>Los '+okn+' controles están en verde.</div></div>';
  var gs=[];it.forEach(function(x){if(gs.indexOf(x.g)<0)gs.push(x.g);});
  return ban+'<div class="row" style="margin-bottom:8px"><button class="btn sm" data-act="x-lunesref">Actualizar</button></div>'+gs.map(function(g){return '<div class="panel"><h3>'+esc(g)+'</h3>'+tbl(['Control','Estado','Detalle',''],it.filter(function(x){return x.g===g;}).map(function(x){return [esc(x.t)+(x.req?'':' <span class="small muted">(recomendado)</span>'),'<span class="chip '+(x.lvl==='bad'&&!x.req?'warn':x.lvl)+'">'+(x.lvl==='ok'?'Listo':x.lvl==='warn'||(x.lvl==='bad'&&!x.req)?'Revisar':'Falta')+'</span>',esc(x.det),x.tab&&x.lvl!=='ok'?'<button class="btn sm" data-act="x-sub" data-v="'+x.tab+'">Ir</button>':''];}),520)+'</div>';}).join('');}
/* pantalla de carga */
function xCarga(){
  var o=S.ext.ob,st=standalone(),h='';
  h+='<div class="panel"><h3>1. Plantillas</h3><p class="small muted">Mandáselas al cliente antes de ir. Los archivos CSV se abren con Excel.</p><div class="row"><button class="btn" data-act="x-plant" data-id="usuarios">Usuarios (choferes, depósito, clientes)</button><button class="btn" data-act="x-plant" data-id="vehiculos">Vehículos</button><button class="btn" data-act="x-plant" data-id="conteo">Conteo de stock</button>'+(st?'<a class="btn" href="/plantillas/plantilla-carga.xlsx" download>Excel de depósito y entregas (SKUs, ubicaciones, kardex)</a>':'')+'</div></div>';
  h+='<div class="panel"><h3>2. Alta masiva de usuarios</h3>'+(st?'<p class="small muted">Crea cuentas con una clave temporal por persona. Las claves se muestran <strong>una sola vez</strong>: entregalas en mano y pedí que las cambien (administración puede cambiarlas en Usuarios).</p><div class="row"><input id="ob-usr" type="file" accept=".csv,.txt,.xlsx,.xls"><button class="btn" data-act="x-obusr">Revisar archivo</button></div>':'<p class="small muted">Disponible en tu servidor propio (en esta demostración no se crean cuentas).</p>');
  if(o.bulk){h+=(o.bulk.err.length?'<div class="banner warn" role="status">'+ICON.alert+'<div><strong>'+o.bulk.err.length+' filas con problemas (no se cargan)</strong>'+o.bulk.err.map(function(e){return 'Fila '+e.fila+' ('+esc(e.txt)+'): '+esc(e.e);}).join(' · ')+'</div></div>':'')+(o.bulk.ok.length?tbl(['Nombre','Correo','Rol','Teléfono'],o.bulk.ok.map(function(u){return [esc(u.name),esc(u.email),esc(u.role),esc(u.telefono||'—')];}),480)+'<div class="row" style="margin-top:12px"><button class="btn ok" data-act="x-obcrear">Crear '+o.bulk.ok.length+' usuarios</button></div>':'');}
  if(o.cred){h+='<div class="banner ok" role="status">'+ICON.check+'<div><strong>'+o.cred.creados.length+' usuarios creados</strong>'+(o.cred.errores.length?o.cred.errores.length+' con error: '+o.cred.errores.map(function(e){return 'fila '+e.fila+' ('+esc(e.email)+'): '+esc(e.error);}).join(' · '):'Sin errores.')+'</div></div>'+tbl(['Nombre','Correo','Rol','Clave temporal'],o.cred.creados.map(function(u){return [esc(u.name),esc(u.email),esc(u.role),'<span class="mono">'+esc(u.password)+'</span>'];}),520)+'<div class="row" style="margin-top:12px"><button class="btn" data-act="x-obcred">Descargar credenciales (CSV)</button></div><div class="small muted">Esta lista no se vuelve a mostrar. Borrá el archivo después de entregar las claves.</div>';}
  h+='</div>';
  h+='<div class="panel"><h3>3. Vehículos</h3><p class="small muted">Carga o actualiza equipos (por patente o código) con sus vencimientos. Cargá primero a los choferes para asignarlos.</p><div class="row"><input id="ob-veh" type="file" accept=".csv,.txt,.xlsx,.xls"><button class="btn" data-act="x-obveh">Revisar archivo</button></div>';
  if(o.eq){h+=(o.eq.err.length?'<div class="banner warn" role="status">'+ICON.alert+'<div><strong>'+o.eq.err.length+' filas con problemas</strong>'+o.eq.err.map(function(e){return 'Fila '+e.fila+' ('+esc(e.txt)+'): '+esc(e.e);}).join(' · ')+'</div></div>':'')+(o.eq.ok.length?tbl(['Equipo','Tipo','Patente','Capacidad','Chofer','Vencimientos',''],o.eq.ok.map(function(e){var c=(D().perfiles||[]).find(function(p){return p.id===e.asignado;});return [esc(e.nombre),esc(TIPOS[e.tipo][0]),esc(e.ident||'—'),e.cap?nf(e.cap)+' kg':'—',esc(c?c.nombre:'—'),e.docs.length,e._nuevo?'<span class="chip ok">Nuevo</span>':'<span class="chip warn">Actualiza</span>'];}),620)+'<div class="row" style="margin-top:12px"><button class="btn ok" data-act="x-obeqok">Guardar '+o.eq.ok.length+' vehículos</button></div>':'');}
  h+='</div>';
  h+='<div class="panel"><h3>4. Conteo físico: saldo inicial y acta</h3><p class="small muted">Cargá el conteo (Ubicación, SKU, Cantidad, Lote, Vence). Antes de aplicar ves las diferencias contra el sistema. Al confirmar se registran en el kardex y se genera el acta para firmar. Necesita que los SKUs y las ubicaciones ya estén cargados.</p><div class="row"><input id="ob-cnt" type="file" accept=".csv,.txt,.xlsx,.xls"><button class="btn" data-act="x-obcnt">Revisar conteo</button><label class="chip" style="cursor:pointer"><input type="checkbox" id="ob-full"'+(o.full?' checked':'')+'> Es el conteo completo (lo que no figura se da de baja)</label></div>';
  if(o.cnt){var c=o.cnt,mv=c.rows.filter(function(r){return r.dif!==0;}).length;
    h+=(c.err.length?'<div class="banner warn" role="status">'+ICON.alert+'<div><strong>'+c.err.length+' filas con problemas (no se cuentan)</strong>'+c.err.slice(0,12).map(function(e){return 'Fila '+e.fila+': '+esc(e.txt);}).join(' · ')+(c.err.length>12?' …':'')+'</div></div>':'')+
     '<div class="kpis">'+KPI(c.rows.length,'Líneas contadas','')+KPI(mv,'Con diferencia','contra el sistema',mv?'warn':'ok')+'</div>'+
     tbl(['Ubicación','SKU','Lote','Sistema','Contado','Dif.'],c.rows.map(function(r){return ['<span class="mono">'+esc(r.ubi)+'</span>',esc(r.sku)+' '+esc(obSkuNom(r.sku)),esc(r.lote||'—'),nf(r.sis),nf(r.cont),r.dif?'<span class="chip '+(r.dif>0?'ok':'bad')+'">'+(r.dif>0?'+':'')+nf(r.dif)+'</span>':'—'];}),620)+
     '<div class="row" style="margin-top:12px"><button class="btn ok" data-act="x-obaplicar">Aplicar y generar acta</button></div>';}
  if(o.acta){h+='<div class="panel"><div class="row"><button class="btn" data-act="x-actaprint">Imprimir acta</button><button class="btn" data-act="x-actadl" data-id="'+esc(o.acta.id)+'">Descargar acta (HTML)</button></div><div id="acta-sheet">'+actaHtml(o.acta)+'</div></div>';}
  var as=(W().actas||[]).filter(function(a){return !o.acta||a.id!==o.acta.id;}).slice().sort(function(a,b){return String(b.id).localeCompare(String(a.id));});
  if(as.length)h+='<div class="small muted" style="margin-top:10px">Actas anteriores: '+as.map(function(a){return '<button class="btn sm" data-act="x-actaver" data-id="'+esc(a.id)+'">'+esc(dmy(a.fecha))+' · '+a.movs+' mov.</button>';}).join(' ')+'</div>';
  return h+'</div>';}
function viewGest(){
  var st=S.ext.sub,tabs=[['lunes','Lunes OK'],['carga','Puesta en marcha'],['ind','Indicadores'],['cost','Costos de flota'],['mant','Mantenimiento'],['listas','Check lists'],['imp','Importar / exportar'],['datos','Datos y seguridad']];
  var body={lunes:xLunes,carga:xCarga,ind:xInd,cost:xCost,mant:xMant,listas:xListas,imp:xImp,datos:xDatos}[st]||xInd;
  if(st==='datos'&&standalone()&&!S.ext.tfa&&!S.ext.tfaAsk){S.ext.tfaAsk=true;setTimeout(segCargar,0);}
  var out='<div class="seg lt" role="group" aria-label="Gestión">'+tabs.map(function(t){return '<button data-act="x-sub" data-v="'+t[0]+'" aria-pressed="'+(st===t[0])+'">'+t[1]+'</button>';}).join('')+'</div>'+body();
  return out.replace('<div id="seg-body" class="small muted">Cargando…</div>','<div id="seg-body" class="small">'+(S.ext.tfa?segHtml():'Cargando…')+'</div>');}
(function(){var _ex=extLive;extLive=function(rol,onErr){_ex(rol,onErr);if(rol==='admin'||rol==='deposito'){var live=S.data.live;unsubs.push(db.collection('wms/actas/items').onSnapshot(function(s){live.wms.actas=s.docs.map(function(d){return Object.assign({id:d.id},d.data());});render();},onErr));}};})();
document.addEventListener('click',async function(ev){
  var t=ev.target.closest('[data-act^="x-"]');if(!t||t.tagName==='SELECT'||(t.tagName==='INPUT'&&t.type!=='button'))return;var a=t.dataset.act,id=t.dataset.id;
  try{
    if(a==='x-plant')obPlantilla(id);
    else if(a==='x-obusr')obLeer('ob-usr',obUsuarios);
    else if(a==='x-obcrear')await obCrear();
    else if(a==='x-obcred'){var c=S.ext.ob.cred;if(c)obCsv('credenciales-temporales.csv',[['Nombre','Correo','Rol','Clave temporal']].concat(c.creados.map(function(u){return [u.name,u.email,u.role,u.password];})));}
    else if(a==='x-obveh')obLeer('ob-veh',obVehiculos);
    else if(a==='x-obeqok')await obGuardarEq();
    else if(a==='x-obcnt')obLeer('ob-cnt',obConteo);
    else if(a==='x-obaplicar')await obAplicarConteo();
    else if(a==='x-actaprint')actaImprimir();
    else if(a==='x-actadl'){var ac=S.ext.ob.acta||(W().actas||[]).find(function(x){return x.id===id;});if(ac)actaDescargar(ac);}
    else if(a==='x-actaver'){var av=(W().actas||[]).find(function(x){return x.id===id;});if(av){S.ext.ob.acta=av;render();}}
    else if(a==='x-lunesref'){S.ext.ob.srv=null;S.ext.ob.srvAsk=false;render();}
  }catch(err){toast('Algo falló. Probá de nuevo.');if(window.console)console.error(err);}});
document.addEventListener('change',function(ev){if(ev.target.id==='ob-full'){S.ext.ob.full=ev.target.checked;if(S.ext.ob.cnt){obCalc();render();}}});
S.ext.sub='lunes';
window.__ext.obUsuarios=obUsuarios;window.__ext.obVehiculos=obVehiculos;window.__ext.obConteo=obConteo;window.__ext.lunesItems=lunesItems;window.__ext.obAplicarConteo=obAplicarConteo;
/* ---------- EXT6: mapas reales, lector físico, reportes y análisis ---------- */
S.ext.an={fijo:0,ing:'ninguno',tarifa:0,lead:7,z:1.65,rep:'ent',rd:'',rh:''};S.ext.mx=null;
document.addEventListener('click',function(ev){var t=ev.target.closest('[data-act="x-reintentar"],[data-act="x-lostok"]');if(!t)return;
  if(t.dataset.act==='x-reintentar'&&window.portalRetry){window.portalRetry();toast('Reintentando…');}else if(window.portalClearLost)window.portalClearLost();});
/* ----- tiempos y distancias por calle (si el servidor tiene ROUTING_URL) con respaldo en la estimación ----- */
var mxKey=function(p){return (+p.lat).toFixed(6)+','+(+p.lng).toFixed(6);};
function leg(a,b,spd){
  var m=S.ext.mx;if(m&&a&&b){var i=m.idx[mxKey(a)],j=m.idx[mxKey(b)];if(i!=null&&j!=null&&m.dur[i][j]!=null&&m.dist[i][j]!=null)return {d:m.dist[i][j]/1000,t:m.dur[i][j]/60,real:true};}
  var d=hav(a,b)*FACTOR;return {d:d,t:d/spd*60,real:false};}
function simRuta(start,seq,t0,spd,svc){var t=t0,p=start,km=0,late=0,rows=[];
  seq.forEach(function(s){var L=hasXY(s)&&p?leg(p,s,spd):{d:0,t:0},wait=0;km+=L.d;t+=L.t;var d0=toMin(s.desde),d1=toMin(s.hasta);if(t<d0){wait=d0-t;t=d0;}var l=Math.max(0,t-d1);late+=l;rows.push({e:s,eta:t,wait:wait,late:l});t+=svc;if(hasXY(s))p=s;});
  return {km:km,late:late,rows:rows,end:t};}
function optimizeTW(start,stops,t0,spd,svc){
  var cost=function(seq){var r=simRuta(start,seq,t0,spd,svc);return r.km+r.late*0.8;};
  var rest=stops.slice(),out=[],p=start,t=t0;
  while(rest.length){var bi=0,bs=1e12;
    rest.forEach(function(s,i){var L=hasXY(s)&&p?leg(p,s,spd):{d:0,t:0},arr=Math.max(t+L.t,toMin(s.desde)),slack=toMin(s.hasta)-arr,sc=L.d+Math.max(0,60-slack)*0.15+Math.max(0,-slack)*2;if(sc<bs){bs=sc;bi=i;}});
    var s=rest.splice(bi,1)[0],L2=hasXY(s)&&p?leg(p,s,spd):{d:0,t:0};t=Math.max(t+L2.t,toMin(s.desde))+svc;if(hasXY(s))p=s;out.push(s);}
  var best=cost(out),imp=true,g=0;
  while(imp&&g++<30){imp=false;
    for(var i=0;i<out.length-1;i++)for(var j=i+1;j<out.length;j++){var c=out.slice(0,i).concat(out.slice(i,j+1).reverse(),out.slice(j+1)),cc=cost(c);if(cc<best-1e-9){out=c;best=cc;imp=true;}}
    for(var a=0;a<out.length;a++)for(var b=0;b<out.length;b++){if(a===b)continue;var c2=out.slice(),m=c2.splice(a,1)[0];c2.splice(b,0,m);var c3=cost(c2);if(c3<best-1e-9){out=c2;best=c3;imp=true;}}}
  return out;}
async function mapaCargar(){
  var dia=diaStr(S.ui.optDia==='manana'?'manana':'hoy'),dep=D().depot,pts=[dep],seen={};seen[mxKey(dep)]=1;
  D().entregas.filter(function(e){return e.fecha===dia&&e.estado!=='entregada'&&e.estado!=='no_entregada'&&hasXY(e);}).forEach(function(e){var k=mxKey(e);if(!seen[k]&&pts.length<100){seen[k]=1;pts.push({lat:e.lat,lng:e.lng});}});
  if(pts.length<2){toast('No hay entregas con coordenadas para ese día.');return;}
  try{var r=await apiJson('POST','/api/ruta/matriz',{puntos:pts.map(function(p){return {lat:p.lat,lng:p.lng};})});
    var idx={};pts.forEach(function(p,i){idx[mxKey(p)]=i;});S.ext.mx={idx:idx,dur:r.durations,dist:r.distances,fuente:r.fuente,ts:Date.now(),n:pts.length};toast('Tiempos y distancias por calle cargados ('+pts.length+' puntos).');render();}
  catch(e){S.ext.mx=null;toast(e&&e.code===501?'Este servidor no tiene mapas configurados (ROUTING_URL). Se sigue con la estimación.':'No se pudo consultar el mapa. Se sigue con la estimación.');render();}}
function mapaBar(){var m=S.ext.mx;
  if(!standalone())return '<div class="small muted" style="margin-bottom:8px">Cálculo con estimación (línea recta × 1,3). Los tiempos por calle están disponibles en tu servidor propio.</div>';
  return '<div class="row" style="margin-bottom:8px">'+(m?'<span class="chip ok">Tiempos por calle de '+esc(m.fuente)+' · '+m.n+' puntos · hace '+Math.max(0,Math.round((Date.now()-m.ts)/60000))+' min</span>':'<span class="chip">Estimación (línea recta × 1,3)</span>')+'<button class="btn sm" data-act="x-mapa">'+(m?'Actualizar':'Usar mapa real')+'</button>'+(m?'<button class="btn sm" data-act="x-mapaoff">Volver a la estimación</button>':'')+'</div><div class="small muted" style="margin-bottom:8px">El mapa da tiempos de calle sin tránsito en vivo. Para tránsito real hace falta un proveedor pago.</div>';}
(function(){var pv=panelVentanas,pf=panelFlota;
  panelVentanas=function(){var h=pv();return h?h.replace('<div class="row"><label>Velocidad media',mapaBar()+'<div class="row"><label>Velocidad media'):h;};
  panelFlota=function(){var h=pf();return h?h.replace('<div class="row">',mapaBar()+'<div class="row">'):h;};})();
document.addEventListener('click',function(ev){var t=ev.target.closest('[data-act="x-mapa"],[data-act="x-mapaoff"]');if(!t)return;if(t.dataset.act==='x-mapa')mapaCargar();else{S.ext.mx=null;render();}});
/* ----- lector físico (USB o Bluetooth que "teclea" el código y termina con Enter) ----- */
function lectorRoute(code){
  code=bcTxt(code).trim();if(code.length<2)return false;
  if(S.ext.gd){gdScan(code);return true;}
  var ocs=[].slice.call(document.querySelectorAll('input[id^="oc-scan-"]'));
  if(ocs.length){var U0=code.toUpperCase(),hit=ocs.find(function(el){var o=WC('ocs').find(function(x){return x.id===el.dataset.oc;});return o&&o.lineas.some(function(l){return String(l.sku).toUpperCase()===U0;});})||ocs[0];hit.value=code;ocScan(hit);return true;}
  if(S.mode&&D().wms&&D().wms.skus){var w=W(),U=code.toUpperCase(),sku=w.skus.find(function(s){return String(s.codigo).toUpperCase()===U;}),ub=w.ubic.find(function(u){return locNorm(u.codigo)===locNorm(code);}),st=wStock();
    if(sku){toast(sku.codigo+' · '+sku.producto+' — stock '+nf(st.tot[sku.codigo]||0)+' '+(sku.um||'')+' (mín. '+nf(sku.min)+')');return true;}
    if(ub){var has=Object.keys(st.m).filter(function(k){return k.split('|')[0]===ub.codigo&&st.m[k]>0;}).map(function(k){return k.split('|')[1]+' ×'+nf(st.m[k]);});toast('Ubicación '+ub.codigo+': '+(has.length?has.join(', '):'vacía'));return true;}
    toast('Código no reconocido: '+code);return true;}
  return false;}
(function(){var buf='',last=0,burst=0;
  document.addEventListener('keydown',function(ev){
    var el=ev.target,tag=el&&el.tagName,txt=tag==='INPUT'||tag==='TEXTAREA'||tag==='SELECT'||(el&&el.isContentEditable);
    if(txt||ev.ctrlKey||ev.metaKey||ev.altKey)return;
    var now=Date.now(),gap=now-last;last=now;
    if(ev.key==='Enter'||ev.key==='Tab'){if(buf.length>=3&&burst>=2){ev.preventDefault();var c=buf;buf='';burst=0;lectorRoute(c);}else{buf='';burst=0;}return;}
    if(ev.key.length!==1)return;
    if(gap>60){buf=ev.key;burst=0;}else{buf+=ev.key;burst++;}
  },true);})();
window.__ext.lectorRoute=lectorRoute;window.__ext.leg=leg;window.__ext.mapaCargar=mapaCargar;
/* ----- datos de ejemplo para el análisis (solo en la demostración) ----- */
(function(){
  var seed=20260101,rnd=function(){seed=(seed*1664525+1013904223)%4294967296;return seed/4294967296;};
  var Z=[['Wilde',-34.699,-58.316,0.08],['Avellaneda',-34.662,-58.365,0.14],['Lanús',-34.706,-58.392,0.34],['Banfield',-34.742,-58.397,0.26],['Quilmes',-34.721,-58.254,0.12]];
  var CL=['c1','c2','c3','c4','c5'],NM={c1:'Ferretería Del Plata',c2:'Pinturería Los Aromos',c3:'Corralón Santa Lucía',c4:'Obras y Revestimientos',c5:'Casa Hogar Adrogué'},CH=[['d1','Marcos Peralta',0],['d2','Diego Ruiz',0.12]];
  var out=[],gs=[],hoy=new Date();
  for(var dd=85;dd>=2;dd--){var d=new Date(hoy);d.setDate(d.getDate()-dd);if(d.getDay()===0||d.getDay()===6)continue;var f=ymd(d);
    for(var k=0;k<4;k++){var z=Z[Math.floor(rnd()*Z.length)],ch=CH[k%2],cl=CL[Math.floor(rnd()*CL.length)],ini=[8,10,13,15][Math.floor(rnd()*4)],hasta=ini+3;
      var p=z[3]+ch[2]+(ini>=13?0.12:0)+(cl==='c4'?0.08:0),late=rnd()<p,no=rnd()<0.07,min=late?(hasta*60+10+Math.floor(rnd()*60)):(ini*60+10+Math.floor(rnd()*(hasta*60-ini*60-20)));
      var ts=new Date(f+'T00:00:00');ts.setMinutes(min);var kg=60+Math.floor(rnd()*840),lat=z[1]+(rnd()-.5)*0.01,lng=z[2]+(rnd()-.5)*0.01;
      var e={id:'hz'+f+k,guia:'H-'+f.slice(5).replace('-','')+k,clienteId:cl,cliente:NM[cl],direccion:'Calle '+(100+Math.floor(rnd()*900))+', '+z[0],lat:lat,lng:lng,fecha:f,desde:pad(ini)+':00',hasta:pad(hasta)+':00',choferId:ch[0],chofer:ch[1],orden:k+1,estado:no?'no_entregada':'entregada',bultos:1+Math.floor(rnd()*8),pesoKg:kg,factura:{numero:'A-'+(1000+out.length),importe:60000+Math.floor(rnd()*190000),estado:'emitida',vence:f},
        observaciones:no?[{ts:ts.toISOString(),por:ch[1],texto:'No entregada: Cliente ausente.'}]:[],historial:[{estado:'programada',ts:new Date(ts.getTime()-864e5).toISOString(),por:'Administración'},{estado:no?'no_entregada':'entregada',ts:ts.toISOString(),por:ch[1]}]};
      if(!no)e.pod={receptor:'Encargado',completa:rnd()>0.07,nota:'',ts:ts.toISOString(),firma:'',foto:'',por:ch[1],lat:lat,lng:lng,distM:Math.floor(rnd()*(rnd()<0.05?900:120))};
      out.push(e);}
    if(d.getDay()===1){[['e4','d1'],['e5','d2']].forEach(function(q,i){var c=ymd(d);gs.push({id:'hg'+f+i,fecha:c,tipo:'combustible',equipoId:q[0],equipo:q[0]==='e4'?'Camión 1':'Utilitario 1',importe:90000+Math.floor(rnd()*60000),litros:70+Math.floor(rnd()*40),odo:50000+Math.floor((85-dd)/7)*300+i*9000,nota:'',porId:q[1],por:q[1],ts:c+'T10:00:00.000Z'});});}}
  var ids={};S.data.demo.entregas.forEach(function(e){ids[e.id]=1;});out.forEach(function(e){if(!ids[e.id])S.data.demo.entregas.push(e);});
  var gi={};S.data.demo.gastos.forEach(function(g){gi[g.id]=1;});gs.forEach(function(g){if(!gi[g.id])S.data.demo.gastos.push(g);});
  var kd=S.data.demo.wms.kardex,sk=S.data.demo.wms.skus.slice(0,5),tot={};
  sk.forEach(function(s,si){var base=[4,2.5,6,1.2,3][si],u=s.ubic||'01:01:01:00';tot[s.codigo]=0;
    for(var dd2=90;dd2>=1;dd2--){var d2=new Date(hoy);d2.setDate(d2.getDate()-dd2);if(d2.getDay()===0)continue;var q=Math.max(0,Math.round(base*(d2.getDay()===6?0.5:1)*(0.6+rnd()*0.8)));if(q>0){tot[s.codigo]+=q;kd.push({id:'KH'+s.codigo+dd2,fecha:ymd(d2),tipo:'OUT',sku:s.codigo,ubicacion:u,'in':0,out:q,operador:'Demostración histórica',nota:'Despacho de ejemplo'});}}
    kd.push({id:'KHI'+s.codigo,fecha:ymd(new Date(hoy.getTime()-91*864e5)),tipo:'IN',sku:s.codigo,ubicacion:u,'in':tot[s.codigo],out:0,operador:'Demostración histórica',nota:'Entrada de ejemplo (netea con los despachos)'});});
})();
/* ----- utilidades de análisis ----- */
var zonaDe=function(e){if(e.zona)return String(e.zona);var m=String(e.direccion||'').split(',');return m.length>1?m[m.length-1].trim():'Sin zona';};
var franjaDe=function(e){var h=parseInt(String(e.desde||'8').split(':')[0],10);return h<10?'Mañana temprano':h<13?'Media mañana':h<16?'Tarde':'Tarde noche';};
var logit=function(p){return Math.log(p/(1-p));},sig=function(z){return 1/(1+Math.exp(-z));};
function atrFeatures(e){return {chofer:e.chofer||'(sin chofer)',zona:zonaDe(e),franja:franjaDe(e),cliente:e.cliente||'?'};}
function atrEntrenar(hist){
  var n=hist.length,late=hist.filter(function(e){return e.late;}).length,p0=(late+1)/(n+2),K=8,W=0.7,tab={};
  hist.forEach(function(e){var f=atrFeatures(e.e);Object.keys(f).forEach(function(k){var key=k+'|'+f[k],o=tab[key]=tab[key]||{n:0,l:0};o.n++;if(e.late)o.l++;});});
  return {p0:p0,n:n,late:late,tab:tab,
    predict:function(e){var f=atrFeatures(e),z=logit(p0),why=[];
      Object.keys(f).forEach(function(k){var o=tab[k+'|'+f[k]]||{n:0,l:0},r=(o.l+K*p0)/(o.n+K),dz=logit(r)-logit(p0);z+=W*dz;if(o.n>=5)why.push({k:k,v:f[k],r:o.l/o.n,n:o.n,dz:dz});});
      why.sort(function(a,b){return b.dz-a.dz;});return {p:sig(z),why:why};}};}
function auc(items){var pos=items.filter(function(x){return x.y;}),neg=items.filter(function(x){return !x.y;});if(pos.length<5||neg.length<5)return null;
  var w=0;pos.forEach(function(a){neg.forEach(function(b){w+=a.p>b.p?1:a.p===b.p?0.5:0;});});return w/(pos.length*neg.length);}
function atrHist(){return D().entregas.filter(function(e){return e.estado==='entregada'&&e.fecha<=HOY&&e.fecha>=addDays(-150)&&enHora(e)!==null;}).map(function(e){return {e:e,late:enHora(e)===false,f:e.fecha};}).sort(function(a,b){return a.f<b.f?-1:a.f>b.f?1:0;});}
function atrModelo(){var h=atrHist();if(h.length<30)return {h:h,m:null};
  var cut=Math.floor(h.length*0.7),tr=atrEntrenar(h.slice(0,cut)),te=h.slice(cut),A=auc(te.map(function(x){return {y:x.late,p:tr.predict(x.e).p};}));
  var rate=te.filter(function(x){return x.late;}).length/te.length;return {h:h,m:atrEntrenar(h),auc:A,nTest:te.length,rateTest:rate};}
function atrPendientes(M){var rows=D().entregas.filter(function(e){return (e.estado==='programada'||e.estado==='en_camino')&&e.fecha>=HOY&&e.fecha<=addDays(1);});
  var v=S.ext.vrp,dep=D().depot,byRoute={};rows.forEach(function(e){var k=e.choferId+'|'+e.fecha;(byRoute[k]=byRoute[k]||[]).push(e);});
  var sim={};Object.keys(byRoute).forEach(function(k){var l=byRoute[k].slice().sort(function(a,b){return (a.orden||0)-(b.orden||0);}),t0=l[0].fecha===HOY?Math.max(new Date().getHours()*60+new Date().getMinutes(),0):480;simRuta(dep,l.filter(hasXY),t0,v.spd,v.svc).rows.forEach(function(r){sim[r.e.id]=r.late;});});
  return rows.map(function(e){var pr=M.m?M.m.predict(e):{p:null,why:[]},sl=sim[e.id]||0,p=pr.p;if(p!=null&&sl>0)p=1-(1-p)*0.25;return {e:e,p:p,hist:pr.p,why:pr.why,simLate:sl};}).sort(function(a,b){return (b.p||0)-(a.p||0)||b.simLate-a.simLate;});}
/* ----- costos ----- */
function fechaEnPer(f,dias){return f>=addDays(-dias)&&f<=HOY;}
function costos(dias){
  var an=S.ext.an,ent=D().entregas.filter(function(e){return e.estado==='entregada'&&fechaEnPer(e.fecha,dias);}),gas=(D().gastos||[]).filter(function(g){return fechaEnPer(g.fecha,dias);}),eqs=D().equipos||[];
  var porCh={},dep=D().depot;ent.forEach(function(e){(porCh[e.choferId]=porCh[e.choferId]||[]).push(e);});
  // km que aporta cada parada: tramo desde la anterior del recorrido del día; la última suma la vuelta al depósito
  var kmI={},dias2={};ent.forEach(function(e){var k=e.choferId+'|'+e.fecha;(dias2[k]=dias2[k]||[]).push(e);});
  Object.keys(dias2).forEach(function(k){var l=dias2[k].slice().sort(function(a,b){return (a.orden||0)-(b.orden||0);}),p=dep,con=[],sin=[];l.forEach(function(e){if(hasXY(e)){kmI[e.id]=hav(p,e)*FACTOR;p=e;con.push(e);}else sin.push(e);});
    if(con.length)kmI[con[con.length-1].id]+=hav(p,dep)*FACTOR;var avg=con.length?con.reduce(function(t,e){return t+kmI[e.id];},0)/con.length:1;sin.forEach(function(e){kmI[e.id]=avg;});});
  var wk=function(e){return Math.max(kmI[e.id]||0,0.2);};
  var chDe=function(g){var q=eqs.find(function(x){return x.id===g.equipoId;});return (q&&q.asignado)||g.porId||'';};
  var cost={},sinAsig=0,totalG=0;ent.forEach(function(e){cost[e.id]=0;});
  gas.forEach(function(g){totalG+=g.importe||0;var ch=chDe(g),l=porCh[ch];if(!l||!l.length){sinAsig+=g.importe||0;return;}var w=l.reduce(function(t,e){return t+wk(e);},0);l.forEach(function(e){cost[e.id]+=(g.importe||0)*wk(e)/w;});});
  if(an.fijo>0)Object.keys(dias2).forEach(function(k){var l=dias2[k];l.forEach(function(e){cost[e.id]+=an.fijo/l.length;});});
  var ing=function(e){return an.ing==='factura'?((e.factura&&e.factura.importe)||0):an.ing==='tarifa'?an.tarifa:0;};
  var agg=function(keyFn){var m={};ent.forEach(function(e){var k=keyFn(e),o=m[k]=m[k]||{k:k,n:0,kg:0,c:0,i:0};o.n++;o.kg+=e.pesoKg||0;o.c+=cost[e.id];o.i+=ing(e);});return Object.keys(m).map(function(k){var o=m[k];o.cpe=o.c/o.n;o.ckg=o.kg?o.c/o.kg:null;o.mg=o.i-o.c;return o;});};
  return {ent:ent,porCliente:agg(function(e){return e.cliente||'?';}),porZona:agg(zonaDe),sinAsig:sinAsig,totalG:totalG,cost:cost,ing:ing};}
function kmEntregas(list,dep){var by={};list.forEach(function(e){if(!hasXY(e))return;var k=e.choferId+'|'+e.fecha;(by[k]=by[k]||[]).push(e);});var km=0;
  Object.keys(by).forEach(function(k){var l=by[k].sort(function(a,b){return (a.orden||0)-(b.orden||0);}),p=dep;l.forEach(function(e){km+=hav(p,e)*FACTOR;p=e;});km+=hav(p,dep)*FACTOR;});return km;}
function rentabilidad(dias){
  var an=S.ext.an,C=costos(dias),eqs=(D().equipos||[]).filter(function(q){return q.tipo==='camion'||q.tipo==='utilitario';}),dep=D().depot,ots=(D().ordenes||[]).filter(function(o){return o.costo>0&&String(o.creada||'').slice(0,10)>=addDays(-dias);});
  return eqs.map(function(q){var ent=C.ent.filter(function(e){return q.asignado&&e.choferId===q.asignado;}),gas=(D().gastos||[]).filter(function(g){return g.equipoId===q.id&&fechaEnPer(g.fecha,dias);}),
    comb=gas.filter(function(g){return g.tipo==='combustible';}),otros=gas.reduce(function(t,g){return t+(g.importe||0);},0),otc=ots.filter(function(o){return o.equipoId===q.id;}).reduce(function(t,o){return t+o.costo;},0),
    dd={};ent.forEach(function(e){dd[e.fecha]=1;});var dT=Object.keys(dd).length,fijo=an.fijo*dT,costo=otros+otc+fijo,ingr=ent.reduce(function(t,e){return t+C.ing(e);},0),kg=ent.reduce(function(t,e){return t+(e.pesoKg||0);},0),km=kmEntregas(ent,dep);
    var cs=comb.filter(function(g){return g.odo>0;}).sort(function(a,b){return a.odo-b.odo;}),rend=null,ckm=null;
    if(cs.length>=2){var kmO=cs[cs.length-1].odo-cs[0].odo,lit=cs.slice(1).reduce(function(t,g){return t+(g.litros||0);},0),cmb=cs.slice(1).reduce(function(t,g){return t+(g.importe||0);},0);if(kmO>0&&lit>0){var rr=kmO/lit;if(rr>=1&&rr<=40){rend=rr;ckm=cmb/kmO;}}}
    return {q:q,n:ent.length,kg:kg,km:km,dias:dT,costo:costo,ingr:ingr,mg:ingr-costo,util:q.cap&&dT?kg/dT/q.cap*100:null,cpe:ent.length?costo/ent.length:null,ckm:ckm,rend:rend,otc:otc};});}
/* ----- stock ----- */
function stockPron(){
  var w=W(),an=S.ext.an,L=an.lead,z=an.z,H=90,ini=addDays(-H),st=wStock(),oc={};
  (w.ocs||[]).forEach(function(o){if(o.estado==='recibida'||o.estado==='cancelada')return;(o.lineas||[]).forEach(function(l){oc[l.sku]=(oc[l.sku]||0)+Math.max(0,l.qty-(l.rec||0));});});
  var ser=function(sku,desde,hasta){var days=[],m={};w.kardex.forEach(function(x){if(x.sku===sku&&x.tipo==='OUT'&&x.out>0&&x.fecha>=desde&&x.fecha<=hasta&&!/devoluci/i.test(x.nota||''))m[x.fecha]=(m[x.fecha]||0)+x.out;});
    var a=new Date(desde+'T12:00:00'),b=new Date(hasta+'T12:00:00');for(var d=new Date(a);d<=b;d.setDate(d.getDate()+1))days.push(m[ymd(d)]||0);return days;};
  var mean=function(a){return a.length?a.reduce(function(t,x){return t+x;},0)/a.length:0;},sd=function(a){var m=mean(a);return a.length>1?Math.sqrt(a.reduce(function(t,x){return t+(x-m)*(x-m);},0)/(a.length-1)):0;};
  var rows=w.skus.map(function(s){var d90=ser(s.codigo,ini,HOY),d28=d90.slice(-28),d=0.6*mean(d28)+0.4*mean(d90),sg=sd(d90),stk=st.tot[s.codigo]||0,rop=d*L+z*sg*Math.sqrt(L),cob=d>0?stk/d:null,enc=oc[s.codigo]||0,sug=Math.max(0,Math.ceil(rop+d*7-stk-enc));
    var est=d<=0?'Sin movimiento':(stk+enc<=rop?(cob!=null&&cob<L?'Quiebre en '+Math.max(0,Math.floor(cob))+' d':'Pedir'):(cob>90&&stk>s.max?'Sobrestock':'OK'));
    return {s:s,stk:stk,d:d,sg:sg,rop:rop,cob:cob,enc:enc,sug:sug,est:est,hist:d90.length};});
  var ae=0,aa=0,nb=0;w.skus.forEach(function(s){var all=ser(s.codigo,addDays(-(H)),addDays(-14)),act=ser(s.codigo,addDays(-13),HOY);if(all.reduce(function(t,x){return t+x;},0)<=0)return;var dd=0.6*mean(all.slice(-28))+0.4*mean(all),f=dd*act.length,a=act.reduce(function(t,x){return t+x;},0);ae+=Math.abs(f-a);aa+=a;nb++;});
  return {rows:rows,wape:aa>0&&nb>=2?ae/aa*100:null,nb:nb};}
/* ----- alertas de desvíos ----- */
function alertas(){
  var al=[],push=function(sev,t,d,tab){al.push({sev:sev,t:t,d:d,tab:tab});},ents=D().entregas,hoyMin=new Date().getHours()*60+new Date().getMinutes();
  var atr=ents.filter(function(e){return e.fecha===HOY&&(e.estado==='programada'||e.estado==='en_camino')&&toMin(e.hasta)<hoyMin;});
  if(atr.length)push('bad',atr.length+' entregas de hoy con la ventana vencida',atr.slice(0,6).map(function(e){return e.guia+' '+e.cliente+' ('+e.hasta+' h)';}).join(' · '),'op');
  var sinPod=ents.filter(function(e){return e.estado==='entregada'&&!e.pod&&e.fecha>=addDays(-7);});
  if(sinPod.length)push('warn',sinPod.length+' entregas de la última semana sin prueba de entrega',sinPod.slice(0,6).map(function(e){return e.guia;}).join(' · '),'op');
  var lejos=ents.filter(function(e){return e.pod&&e.pod.distM>300&&e.fecha>=addDays(-14);});
  if(lejos.length)push('warn',lejos.length+' entregas confirmadas a más de 300 m de la dirección',lejos.slice(0,6).map(function(e){return e.guia+' ('+nf(e.pod.distM)+' m)';}).join(' · '),'op');
  var f7=ents.filter(function(e){return (e.estado==='entregada'||e.estado==='no_entregada')&&e.fecha>=addDays(-14);}),pc={};f7.forEach(function(e){var o=pc[e.chofer]=pc[e.chofer]||{n:0,no:0};o.n++;if(e.estado==='no_entregada')o.no++;});
  Object.keys(pc).forEach(function(c){var o=pc[c];if(o.n>=8&&o.no/o.n>=0.2)push('warn',c+': '+nf(o.no/o.n*100)+'% de no entregadas en 14 días',o.no+' de '+o.n+' entregas intentadas.','ind');});
  var w1=costos(7),w4=costos(35);var c1=w1.ent.length?Object.keys(w1.cost).reduce(function(t,k){return t+w1.cost[k];},0)/w1.ent.length:null,c4=w4.ent.length?Object.keys(w4.cost).reduce(function(t,k){return t+w4.cost[k];},0)/w4.ent.length:null;
  if(c1&&c4&&c1>c4*1.3)push('warn','El costo por entrega de la última semana subió '+nf((c1/c4-1)*100)+'% contra el promedio de 5 semanas','$'+nf(c1)+' contra $'+nf(c4)+' por entrega.','cost');
  var eqs=D().equipos||[],chk=D().checks||[];var sinCheck=eqs.filter(function(q){return !chk.some(function(c){return c.equipoId===q.id&&c.fecha>=addDays(-7);});});
  if(sinCheck.length)push('warn',sinCheck.length+' equipos sin check list en 7 días',sinCheck.map(function(q){return q.nombre;}).join(' · '),'listas');
  var mal=chk.filter(function(c){return c.fecha>=addDays(-3)&&c.resultado&&c.resultado!=='ok';});
  if(mal.length)push('bad',mal.length+' check lists recientes con fallas',mal.slice(0,5).map(function(c){return c.equipoNombre+' ('+c.resultado+')';}).join(' · '),'listas');
  if(D().wms&&D().wms.skus&&D().wms.skus.length){var sp=stockPron().rows.filter(function(r){return /^Quiebre/.test(r.est);});if(sp.length)push('bad',sp.length+' SKUs con quiebre de stock previsto antes de que llegue la reposición',sp.slice(0,6).map(function(r){return r.s.codigo+' ('+r.est+')';}).join(' · '),'anal');
    var vn=(typeof wLotes==='function'?wLotes():[]).filter(function(l){return l.q>0&&l.vence&&dleft(l.vence)<=30;});if(vn.length)push(vn.some(function(l){return dleft(l.vence)<0;})?'bad':'warn',vn.length+' lotes vencidos o por vencer en 30 días',vn.slice(0,6).map(function(l){return l.sku+' '+l.lote+' ('+(dleft(l.vence)<0?'vencido':l.vence)+')';}).join(' · '),'wms');
    (W().actas||[]).filter(function(a){return a.fecha>=addDays(-30);}).forEach(function(a){var t=a.filas.reduce(function(s,r){return s+r.sis;},0),d=a.filas.reduce(function(s,r){return s+Math.abs(r.dif);},0);if(t>0&&d/t>0.05)push('warn','Acta del '+dmy(a.fecha)+': diferencias del '+nf(d/t*100)+'% contra el sistema','Revisá los movimientos de ese día.','carga');});}
  var cap=D().equipos||[];cap.filter(function(q){return (q.tipo==='camion'||q.tipo==='utilitario')&&q.cap>0&&q.asignado;}).forEach(function(q){var kg=ents.filter(function(e){return e.choferId===q.asignado&&e.fecha===HOY&&e.estado!=='no_entregada';}).reduce(function(t,e){return t+(e.pesoKg||0);},0);if(kg>q.cap)push('bad',q.nombre+' cargado por encima de su capacidad hoy',nf(kg)+' kg de '+nf(q.cap)+' kg.','op');});
  var ord={bad:0,warn:1};al.sort(function(a,b){return ord[a.sev]-ord[b.sev];});return al;}
/* ----- pantallas: Análisis y Reportes ----- */
var riskChip=function(p){return p==null?'<span class="chip">Sin datos</span>':'<span class="chip '+(p>=0.5?'bad':p>=0.3?'warn':'ok')+'">'+Math.round(p*100)+'%</span>';};
function anInputs(){var an=S.ext.an;return '<div class="row"><label>Costo fijo diario por vehículo ($)<input id="an-fijo" type="number" min="0" value="'+an.fijo+'" style="width:130px"></label><label>Ingreso a considerar<select id="an-ing"><option value="ninguno"'+(an.ing==='ninguno'?' selected':'')+'>Ninguno (solo costos)</option><option value="factura"'+(an.ing==='factura'?' selected':'')+'>Importe de la factura (valor de la mercadería)</option><option value="tarifa"'+(an.ing==='tarifa'?' selected':'')+'>Tarifa fija por entrega</option></select></label>'+(an.ing==='tarifa'?'<label>Tarifa por entrega ($)<input id="an-tar" type="number" min="0" value="'+an.tarifa+'" style="width:120px"></label>':'')+'</div>';}
function xAnal(){
  var dias=parseInt(S.ext.per,10)||30,an=S.ext.an,h='<div class="row sp"><h2>Análisis</h2>'+perSel()+'</div>',al=alertas();
  h+='<div class="panel"><h3>Alertas de desvíos ('+al.length+')</h3>'+(al.length?al.map(function(a){return '<div class="banner '+a.sev+'" role="status" style="margin-bottom:8px">'+ICON.alert+'<div><strong>'+esc(a.t)+'</strong>'+esc(a.d)+(a.tab&&a.tab!=='anal'?' <button class="btn sm" data-act="'+(['op','wms'].indexOf(a.tab)>=0?'tab':'x-sub')+'" data-v="'+a.tab+'">Ver</button>':'')+'</div></div>';}).join(''):'<div class="banner ok" role="status">'+ICON.check+'<div><strong>Sin desvíos detectados</strong>Con las reglas de abajo.</div></div>')+'<div class="small muted">Reglas: ventanas vencidas, sin prueba de entrega, entrega a más de 300 m, no entregadas ≥20%, costo por entrega +30%, check lists faltantes o con fallas, quiebre de stock, lotes por vencer, diferencias de conteo >5%, camión sobre su capacidad.</div></div>';
  // atrasos
  var M=atrModelo(),pend=atrPendientes(M);
  h+='<div class="panel"><h3>Predicción de atrasos</h3>';
  if(!M.m)h+='<div class="banner info" role="status">'+ICON.bell+'<div><strong>Todavía hay pocos datos para predecir ('+M.h.length+' entregas con hora; hacen falta 30)</strong>Mientras tanto, la simulación de la ruta igual marca las paradas que llegarían tarde.</div></div>';
  else h+='<p class="small muted">Con '+M.m.n+' entregas históricas ('+nf(M.m.late/M.m.n*100)+'% llegó tarde). Estima el riesgo con el comportamiento pasado del chofer, la zona, la franja horaria y el cliente, más la simulación de la ruta del día. '+(M.auc!=null?'<strong>Prueba contra el pasado:</strong> entrenado con el 70% más viejo y probado en el 30% más nuevo, acierta el orden de riesgo con un AUC de '+nf(M.auc,2)+' (0,5 es azar, 1 es perfecto; '+M.nTest+' entregas de prueba).':'No hay suficientes atrasos y entregas a tiempo para medir qué tan bien acierta.')+' Es una estadística simple y explicable, no una garantía.</p>';
  h+=pend.length?tbl(['Entrega','Chofer','Ventana','Riesgo','Por qué'],pend.slice(0,15).map(function(r){var e=r.e,w=r.why.slice(0,2).filter(function(x){return x.dz>0.15;}).map(function(x){return x.k+' '+x.v+': '+nf(x.r*100)+'% tarde ('+x.n+')';});if(r.simLate>0)w.push('la ruta simulada llega '+nf(r.simLate)+' min tarde');return [esc(e.guia+' · '+e.cliente),esc(e.chofer||'—'),esc(e.fecha===HOY?'hoy ':'mañana ')+esc(ventana(e)),riskChip(r.p),esc(w.join(' · ')||'sin factores de riesgo')];}),640):'<div class="small muted">No hay entregas pendientes para hoy o mañana.</div>';
  h+='</div>';
  // costos
  var C=costos(dias),rk=function(a){return a.slice().sort(function(x,y){return an.ing==='ninguno'?(y.ckg||0)-(x.ckg||0):x.mg-y.mg;});},conIng=an.ing!=='ninguno';
  var cols=['','Entregas','Kg','Costo','Costo por entrega','Costo por kg'].concat(conIng?['Ingreso','Margen']:[]);
  var rowF=function(o){return [esc(o.k),o.n,nf(o.kg),'$'+nf(o.c),'$'+nf(o.cpe),o.ckg==null?'—':'$'+nf(o.ckg,1)].concat(conIng?['$'+nf(o.i),'<span class="chip '+(o.mg<0?'bad':'ok')+'">$'+nf(o.mg)+'</span>']:[]);};
  h+='<div class="panel"><h3>Costos por cliente y por zona</h3><p class="small muted">Reparte los gastos cargados (combustible, peajes, otros) entre las entregas del chofer en proporción a los km que aporta cada parada (estimados desde el depósito), y el costo fijo diario en partes iguales entre las paradas del día. Es un reparto aproximado: no incluye sueldos ni amortización salvo que los cargues en el costo fijo.</p>'+anInputs();
  if(!C.ent.length)h+='<div class="empty">No hay entregas completadas en el período.</div>';
  else{h+='<div class="kpis">'+KPI('$'+nf(C.totalG),'Gastos cargados','en el período')+KPI('$'+nf(Object.keys(C.cost).reduce(function(t,k){return t+C.cost[k];},0)/C.ent.length),'Costo por entrega',C.ent.length+' entregas')+(C.sinAsig>0?KPI('$'+nf(C.sinAsig),'Gastos sin entregas','no se pudieron repartir','warn'):'')+'</div>'+
    '<h4>Por zona</h4>'+tbl(['Zona'].concat(cols.slice(1)),rk(C.porZona).map(rowF),640)+'<h4>Por cliente</h4>'+tbl(['Cliente'].concat(cols.slice(1)),rk(C.porCliente).map(rowF),640);}
  h+='</div>';
  // rentabilidad
  var R=rentabilidad(dias);
  h+='<div class="panel"><h3>Rentabilidad por vehículo</h3><p class="small muted">Costos: gastos del vehículo, órdenes de trabajo con costo y costo fijo por día trabajado. Los km son estimados con la secuencia de entregas (línea recta × 1,3). El rendimiento real sale del odómetro de las cargas de combustible.</p>'+
    (R.length?tbl(['Vehículo','Entregas','Kg','Km estimados','Costo','Costo por entrega','Utilización','Rendimiento (km/l)','$ comb. por km'].concat(conIng?['Ingreso','Margen']:[]),R.map(function(r){return [esc(r.q.nombre),r.n,nf(r.kg),nf(r.km),'$'+nf(r.costo),r.cpe==null?'—':'$'+nf(r.cpe),r.util==null?'—':'<span class="chip '+(r.util>100?'bad':r.util<30?'warn':'ok')+'">'+nf(r.util)+'%</span>',r.rend==null?'—':nf(r.rend,1),r.ckm==null?'—':'$'+nf(r.ckm)].concat(conIng?['$'+nf(r.ingr),'<span class="chip '+(r.mg<0?'bad':'ok')+'">$'+nf(r.mg)+'</span>']:[]);}),760):'<div class="empty">No hay camiones o utilitarios cargados.</div>')+'</div>';
  // stock
  if(D().wms&&D().wms.skus&&D().wms.skus.length){var P=stockPron();
    h+='<div class="panel"><h3>Predicción de necesidades de stock</h3><p class="small muted">Demanda diaria = 60% del promedio de 28 días + 40% del de 90 días, sobre los despachos del kardex. Punto de pedido = demanda × plazo de reposición + stock de seguridad (desvío diario × √plazo × nivel de servicio). No ve estacionalidad, promociones ni obras grandes. '+(P.wape!=null?'<strong>Prueba contra el pasado:</strong> pronosticando las últimas 2 semanas con los datos anteriores, el error total fue de '+nf(P.wape)+'% ('+P.nb+' SKUs).':'Todavía no hay historial suficiente para medir el error.')+'</p>'+
     '<div class="row"><label>Plazo de reposición (días)<input id="an-lead" type="number" min="1" max="120" value="'+an.lead+'" style="width:100px"></label><label>Nivel de servicio<select id="an-z"><option value="1.28"'+(an.z===1.28?' selected':'')+'>90%</option><option value="1.65"'+(an.z===1.65?' selected':'')+'>95%</option><option value="2.33"'+(an.z===2.33?' selected':'')+'>99%</option></select></label></div>'+
     tbl(['SKU','Stock','En camino (OC)','Demanda por día','Cobertura','Punto de pedido','Sugerido pedir','Estado'],P.rows.slice().sort(function(a,b){var f=function(r){return /^Quiebre/.test(r.est)?0:r.est==='Pedir'?1:r.est==='Sobrestock'?2:r.est==='OK'?3:4;};return f(a)-f(b);}).map(function(r){return [esc(r.s.codigo+' '+r.s.producto),nf(r.stk),r.enc?nf(r.enc):'—',nf(r.d,1),r.cob==null?'—':nf(r.cob)+' d',nf(r.rop),r.sug?'<strong>'+nf(r.sug)+'</strong>':'—','<span class="chip '+(/^Quiebre/.test(r.est)?'bad':r.est==='Pedir'?'warn':r.est==='Sobrestock'?'warn':'ok')+'">'+esc(r.est)+'</span>'];}),780)+'</div>';}
  return h;}
/* ----- reportes ----- */
function repRango(){var an=S.ext.an;return {d:an.rd||addDays(-30),h:an.rh||HOY};}
function repDatos(){var an=S.ext.an,R=repRango(),k=an.rep,E=D().entregas.filter(function(e){return e.fecha>=R.d&&e.fecha<=R.h;}),fin=E.filter(function(e){return e.estado==='entregada'||e.estado==='no_entregada';});
  var resum=function(keyFn,label){var m={};fin.forEach(function(e){var kk=keyFn(e),o=m[kk]=m[kk]||{k:kk,n:0,ent:0,no:0,hora:0,comp:0,otif:0,kg:0,dist:[],};o.n++;o.kg+=e.pesoKg||0;if(e.estado==='no_entregada')o.no++;else{o.ent++;var eh=enHora(e)===true,cp=completa(e);if(eh)o.hora++;if(cp)o.comp++;if(eh&&cp)o.otif++;if(e.pod&&e.pod.distM!=null)o.dist.push(e.pod.distM);}});
    var rows=Object.keys(m).sort().map(function(x){var o=m[x];return [o.k,o.n,o.ent,o.no,o.ent?Math.round(o.hora/o.ent*1000)/10:'',o.ent?Math.round(o.comp/o.ent*1000)/10:'',o.n?Math.round(o.otif/o.n*1000)/10:'',Math.round(o.kg),o.dist.length?Math.round(o.dist.reduce(function(t,x2){return t+x2;},0)/o.dist.length):''];});
    return {head:[label,'Intentadas','Entregadas','No entregadas','% en hora','% completas','OTIF %','Kg','Distancia prom. a la dirección (m)'],rows:rows};};
  if(k==='ent')return {t:'Entregas',head:['Fecha','Guía','Cliente','Zona','Chofer','Estado','Ventana','Entregada a las','En hora','Completa','Receptor','Distancia (m)','Kg','Bultos'],rows:E.slice().sort(function(a,b){return a.fecha<b.fecha?-1:a.fecha>b.fecha?1:0;}).map(function(e){var h2=(e.historial||[]).filter(function(x){return x.estado==='entregada';}).slice(-1)[0],eh=enHora(e);return [e.fecha,e.guia,e.cliente,zonaDe(e),e.chofer||'',(EST[e.estado]||[e.estado])[0],e.desde+'-'+e.hasta,h2?new Date(h2.ts).toLocaleTimeString('es-AR',{hour:'2-digit',minute:'2-digit'}):'',eh==null?'':eh?'Sí':'No',e.estado==='entregada'?(completa(e)?'Sí':'No'):'',(e.pod&&e.pod.receptor)||'',e.pod&&e.pod.distM!=null?e.pod.distM:'',e.pesoKg||'',e.bultos||''];})};
  if(k==='chofer')return Object.assign({t:'Resumen por chofer'},resum(function(e){return e.chofer||'(sin chofer)';},'Chofer'));
  if(k==='cliente')return Object.assign({t:'Resumen por cliente'},resum(function(e){return e.cliente||'?';},'Cliente'));
  if(k==='zona')return Object.assign({t:'Resumen por zona'},resum(zonaDe,'Zona'));
  if(k==='gastos')return {t:'Gastos de flota',head:['Fecha','Equipo','Tipo','Importe','Litros','Odómetro','Cargó','Nota'],rows:(D().gastos||[]).filter(function(g){return g.fecha>=R.d&&g.fecha<=R.h;}).sort(function(a,b){return a.fecha<b.fecha?-1:1;}).map(function(g){return [g.fecha,g.equipo,g.tipo,g.importe,g.litros||'',g.odo||'',g.por||'',g.nota||''];})};
  if(k==='kardex')return {t:'Movimientos de stock',head:['Fecha','Tipo','SKU','Ubicación','Entra','Sale','Lote','Vence','Operador','Nota'],rows:(D().wms?D().wms.kardex:[]).filter(function(x){return x.fecha>=R.d&&x.fecha<=R.h;}).sort(function(a,b){return a.fecha<b.fecha?-1:a.fecha>b.fecha?1:0;}).map(function(x){return [x.fecha,x.tipo,x.sku,x.ubicacion,x.in||'',x.out||'',x.lote||'',x.vence||'',x.operador||'',x.nota||''];})};
  return {t:'Check lists',head:['Fecha','Equipo','Resultado','Lectura','Realizó','Fallas','Nota'],rows:(D().checks||[]).filter(function(c){return c.fecha>=R.d&&c.fecha<=R.h;}).sort(function(a,b){return a.fecha<b.fecha?-1:1;}).map(function(c){return [c.fecha,c.equipoNombre,c.resultado,c.lect===''||c.lect==null?'':c.lect,c.por||'',(c.fallas||[]).map(function(f){return f.texto;}).join('; '),c.nota||''];})};}
function xRep(){var an=S.ext.an,R=repRango(),d=repDatos(),T=[['ent','Entregas (detalle)'],['chofer','Resumen por chofer'],['cliente','Resumen por cliente'],['zona','Resumen por zona'],['gastos','Gastos de flota'],['kardex','Movimientos de stock'],['checks','Check lists']];
  return '<div class="panel"><h3>Reportes</h3><div class="row"><label>Reporte<select id="rp-t">'+T.map(function(t){return '<option value="'+t[0]+'"'+(an.rep===t[0]?' selected':'')+'>'+t[1]+'</option>';}).join('')+'</select></label><label>Desde<input id="rp-d" type="date" value="'+R.d+'"></label><label>Hasta<input id="rp-h" type="date" value="'+R.h+'"></label><button class="btn" data-act="x-repcsv">Descargar CSV (Excel)</button><button class="btn" data-act="x-repprint">Imprimir / guardar PDF</button></div></div>'+
   '<div class="panel" id="rep-sheet"><h3>'+esc(d.t)+' · '+esc(dmy(R.d))+' a '+esc(dmy(R.h))+'</h3><div class="small muted">'+d.rows.length+' filas'+(d.rows.length>200?' (se muestran las primeras 200; el CSV trae todas)':'')+'</div>'+(d.rows.length?tbl(d.head,d.rows.slice(0,200).map(function(r){return r.map(function(c){return esc(c);});}),Math.max(560,d.head.length*90)):'<div class="empty">No hay datos en ese rango.</div>')+'</div>';}
function viewGest(){
  var st=S.ext.sub,al=0;try{al=alertas().length;}catch(_){}
  var tabs=[['lunes','Lunes OK'],['carga','Puesta en marcha'],['ind','Indicadores'],['anal','Análisis'+(al?' ('+al+')':'')],['rep','Reportes'],['cost','Costos de flota'],['mant','Mantenimiento'],['listas','Check lists'],['imp','Importar / exportar'],['datos','Datos y seguridad']];
  var body={lunes:xLunes,carga:xCarga,ind:xInd,anal:xAnal,rep:xRep,cost:xCost,mant:xMant,listas:xListas,imp:xImp,datos:xDatos}[st]||xInd;
  if(st==='datos'&&standalone()&&!S.ext.tfa&&!S.ext.tfaAsk){S.ext.tfaAsk=true;setTimeout(segCargar,0);}
  var out='<div class="seg lt" role="group" aria-label="Gestión">'+tabs.map(function(t){return '<button data-act="x-sub" data-v="'+t[0]+'" aria-pressed="'+(st===t[0])+'">'+t[1]+'</button>';}).join('')+'</div>'+body();
  return out.replace('<div id="seg-body" class="small muted">Cargando…</div>','<div id="seg-body" class="small">'+(S.ext.tfa?segHtml():'Cargando…')+'</div>');}
document.addEventListener('change',function(ev){var t=ev.target,an=S.ext.an;
  if(t.id==='an-fijo'){an.fijo=Math.max(0,parseFloat(t.value)||0);render();}
  else if(t.id==='an-ing'){an.ing=t.value;render();}
  else if(t.id==='an-tar'){an.tarifa=Math.max(0,parseFloat(t.value)||0);render();}
  else if(t.id==='an-lead'){an.lead=Math.min(120,Math.max(1,parseInt(t.value,10)||7));render();}
  else if(t.id==='an-z'){an.z=parseFloat(t.value);render();}
  else if(t.id==='rp-t'){an.rep=t.value;render();}
  else if(t.id==='rp-d'||t.id==='rp-h'){if(t.value){if(t.id==='rp-d')an.rd=t.value;else an.rh=t.value;render();}}});
document.addEventListener('click',function(ev){var t=ev.target.closest('[data-act="x-repcsv"],[data-act="x-repprint"]');if(!t)return;
  if(t.dataset.act==='x-repcsv'){var d=repDatos(),R=repRango();guardarArchivo('reporte-'+S.ext.an.rep+'-'+R.d+'-a-'+R.h+'.csv',csvOut([d.head].concat(d.rows)),'text/csv;charset=utf-8');}
  else{document.body.classList.add('print-rep');setTimeout(function(){try{window.print();}catch(_){}document.body.classList.remove('print-rep');},50);}});
window.__ext.atrModelo=atrModelo;window.__ext.atrPendientes=atrPendientes;window.__ext.costos=costos;window.__ext.rentabilidad=rentabilidad;window.__ext.stockPron=stockPron;window.__ext.alertas=alertas;window.__ext.repDatos=repDatos;window.__ext.auc=auc;
/* ---------- EXT7: ver PDF de factura/remito (en la demostración se genera uno de ejemplo) ---------- */
function pdfEjemplo(lineas){
  var L=lineas.map(function(t){return String(t).replace(/[^\x20-\xFF]/g,'?').replace(/\\/g,'\\\\').replace(/\(/g,'\\(').replace(/\)/g,'\\)');});
  var c='BT /F1 11 Tf 56 780 Td 16 TL\n';L.forEach(function(t,i){c+=(i===0?'/F1 16 Tf 20 TL\n':'')+'('+t+') Tj T*\n';});c+='ET';
  var o=['<< /Type /Catalog /Pages 2 0 R >>','<< /Type /Pages /Kids [3 0 R] /Count 1 >>','<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>','<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>','<< /Length '+c.length+' >>\nstream\n'+c+'\nendstream'];
  var s='%PDF-1.4\n',off=[];o.forEach(function(b,i){off.push(s.length);s+=(i+1)+' 0 obj\n'+b+'\nendobj\n';});
  var x=s.length;s+='xref\n0 '+(o.length+1)+'\n0000000000 65535 f \n'+off.map(function(n){return String(n).padStart(10,'0')+' 00000 n \n';}).join('')+'trailer\n<< /Size '+(o.length+1)+' /Root 1 0 R >>\nstartxref\n'+x+'\n%%EOF';
  var u=new Uint8Array(s.length);for(var i=0;i<s.length;i++)u[i]=s.charCodeAt(i)&255;return new Blob([u],{type:'application/pdf'});}
window.__ext=window.__ext||{};window.__ext.pdfEjemplo=pdfEjemplo;
function docUrl(e,t){var d=e&&e[t];return d&&d.url?d.url:'';}
function pdfBtn(e,t){
  if(!e||!e[t]||!e[t].numero)return '';
  if(!docUrl(e,t)&&S.mode!=='demo')return '';
  return '<button class="btn sm" data-act="x-verpdf" data-id="'+esc(e.id)+'" data-t="'+t+'" style="margin-top:4px">Ver PDF</button>';}
document.addEventListener('click',function(ev){var b=ev.target.closest('[data-act="x-verpdf"]');if(!b)return;
  var e=D().entregas.find(function(x){return x.id===b.dataset.id;}),t=b.dataset.t==='remito'?'remito':'factura';if(!e)return;
  var u=docUrl(e,t);
  if(!u){var d=e[t],f=e.factura||{};
    u=URL.createObjectURL(pdfEjemplo([(t==='factura'?'Factura ':'Remito ')+d.numero,'DOCUMENTO DE EJEMPLO (demostracion) - no es un comprobante fiscal','',
      'Cliente: '+e.cliente,'Direccion: '+e.direccion,'Guia: '+e.guia,'Fecha de entrega: '+fmtFecha(e.fecha)].concat(t==='factura'?['','Importe: '+fmtARS(d.importe),'Estado: '+(FACT[d.estado]||''),d.vence?'Vencimiento: '+d.vence:'']:[]).concat(['','En tu servidor propio se abre aqui el PDF real que cargues en Editar.'])));}
  var w=window.open(u,'_blank','noopener');if(!w){var a=document.createElement('a');a.href=u;a.target='_blank';a.rel='noopener';a.click();}});

/* EXT7b start */
/* ===== EXT7b: demostración con depósito lleno e historial de 180 días ===== */
var DEMO_RICO=[];
function demoRico(w){if(DEMO_RICO.indexOf(w)>=0)return;DEMO_RICO.push(w);
  var seed=7,rnd=function(){seed=(seed*16807)%2147483647;return seed/2147483647;},T=new Date(),R=function(n){return Math.floor(rnd()*n);},pd=function(n){return (n<10?'0':'')+n;};
  var ops=['Julián Sosa','Carla Medina','Juan','Ana','Pedro','Luis'],provs=['Aceros del Sur','Plásticos Norte','Química Industrial','Envases SA','Distribuidora Oeste','Importadora Atlántica'],cats=['Envases','Materias Primas','Insumos','Productos Terminados'],pesos=[0.4,2.5,6,8,1.2,12];
  var occ={};w.kardex.forEach(function(x){occ[x.ubicacion]=(occ[x.ubicacion]||0)+(x.in||0)-(x.out||0);});
  var dep=function(c){return {'01':'Deposito A','02':'Deposito B','03':'Deposito C'}[String(c).slice(0,2)]||'Deposito A';};
  w.skus.forEach(function(s,i){if(!s.costo)s.costo=80+((i*137)%900);if(!s.lead)s.lead=4+((i*3)%11);if(!s.prov)s.prov=provs[i%provs.length];});
  var empty=w.ubic.filter(function(u){return !(occ[u.codigo]>0);}).map(function(u){return u.codigo;}).sort(function(a,b){var x=locParse(a),y=locParse(b);return (x.a===0?0:1)-(y.a===0?0:1)||(a<b?-1:1);});
  var N=Math.min(42,empty.length),cap={};w.ubic.forEach(function(u){cap[u.codigo]=u.cap||150;});
  var skuN=w.skus.length,extra=empty.slice(N),k=0,ev=[],date=function(d){var x=new Date(T);x.setDate(x.getDate()-d);return x.getFullYear()+'-'+pd(x.getMonth()+1)+'-'+pd(x.getDate());},vf=function(d){var x=new Date(T);x.setDate(x.getDate()+d);return x.getFullYear()+'-'+pd(x.getMonth()+1)+'-'+pd(x.getDate());};
  var add=function(d,tipo,sku,ubi,inn,out,lote,vence,op,nota){var h=7+R(10);ev.push({id:'KD'+(1000+ev.length),fecha:date(d),tipo:tipo,sku:sku,ubicacion:ubi,'in':inn,out:out,lote:lote||'',vence:vence||'',operador:op,nota:nota,ts:date(d)+'T'+pd(h)+':'+pd(R(60))+':00.000Z'});};
  for(var i=0;i<N;i++){
    var code='P'+String(skuN+1+i).padStart(3,'0'),pos=[empty[i]];if(i<extra.length)pos.push(extra[i]);
    var cls=i%11===3?'lento':i%13===5?'quiebre':i%9===4?'rep':'norm',base=cls==='lento'?0.05:cls==='quiebre'?6:cls==='rep'?3:(0.6+rnd()*4)*(i%7===0?3:1),hasLot=i%3===0;
    w.skus.push({id:code,codigo:code,producto:'Producto '+(skuN+1+i),categoria:cats[i%4],um:'UN',min:20+R(60),max:200+R(300),ubic:pos[0],deposito:dep(pos[0]),peso:pesos[i%6],costo:90+R(2400),lead:4+R(12),prov:provs[i%provs.length],vol:0.002+rnd()*0.04});
    var bal={};pos.forEach(function(u){bal[u]=[];});var lotN=0;
    var recv=function(d,u,q,op){if(q<=0)return;var l=hasLot?('L'+code.slice(1)+String.fromCharCode(65+(lotN++%26))):'',v=hasLot?vf(i%17===0?R(25)-5:40+R(460)):'';bal[u].push({lote:l,vence:v,q:q});add(d,'IN',code,u,q,0,l,v,op,'Recepción OC-'+(7000+R(900)));};
    var tot=function(u){return bal[u].reduce(function(t,x){return t+x.q;},0);};
    var take=function(d,u,q,tipo,op,nota,dest){var left=q;bal[u].sort(function(a,b){return String(a.vence||'9999')<String(b.vence||'9999')?-1:1;});
      while(left>0&&bal[u].length){var l=bal[u][0],t=Math.min(left,l.q);l.q-=t;left-=t;if(l.q<=0)bal[u].shift();add(d,tipo,code,u,0,t,l.lote,l.vence,op,nota);if(dest){bal[dest].push({lote:l.lote,vence:l.vence,q:t});add(d,tipo,code,dest,t,0,l.lote,l.vence,op,nota);}}};
    var face=pos[0],res=pos[1];recv(181,face,Math.min(cap[face],100+R(40)),'Sistema (ajuste inicial)');if(res)recv(181,res,Math.min(cap[res],110+R(40)),'Sistema (ajuste inicial)');
    for(var d=180;d>=1;d--){var dt=new Date(T);dt.setDate(dt.getDate()-d);if(dt.getDay()===0)continue;
      if(rnd()<(cls==='lento'?0.05:0.78)){var q=Math.max(1,Math.round(base*(0.4+rnd()*1.2)*(dt.getDay()===6?0.5:1))),op=ops[R(6)];
        if(tot(face)<q&&res&&tot(res)>0)take(d,res,Math.min(tot(res),cap[face]-tot(face)),'TRANSFERENCIA',ops[R(2)],'Reposición RP-'+(500+R(400)),face);
        if(tot(face)<q)recv(d,face,cap[face]-tot(face),ops[R(2)]);
        take(d,face,Math.min(q,tot(face)),'OUT',op,'Picking PK-'+(1000+R(9000)));}
      if(res&&d%14===i%14&&tot(res)<70)recv(d,res,Math.min(110,cap[res]-tot(res)),ops[R(2)]);}
    var keep=cls==='quiebre'?2:cls==='rep'?Math.max(4,Math.round(base*3)):0;
    if(keep){pos.slice().reverse().forEach(function(u){var ex=tot(u)-(u===face?keep:1);if(ex>0)take(1,u,ex,'OUT','Juan','Picking PK-'+(1000+R(9000)));});}
    else if(cls==='lento'){pos.forEach(function(u){recv(2,u,Math.max(0,Math.min(cap[u],cap[u]-5)-tot(u)),'Carla Medina');});}
    pos.forEach(function(u){if(tot(u)<=0)recv(1,u,6,'Carla Medina');});
  }
  ev.forEach(function(e){w.kardex.push(e);});
}
demoRico(S.data.demo.wms);demoRico(WMS_DEMO);
/* ===== EXT7b end ===== */

/* EXT7b end */



/* EXT9 start */
/* ===== EXT9: stock valorizado por posición ===== */
function valRows(){return x8c('valr',function(){var st=wStock(),sk=x8skus(),ub=x8ubic(),rows=[],sinCosto={};
  Object.keys(st.m).forEach(function(k){var q=st.m[k];if(q<=0)return;var p=k.split('|'),s=sk[p[1]],c=s&&+s.costo>0?+s.costo:0,o=locParse(p[0]),u=ub[p[0]];
    if(!c)sinCosto[p[1]]=(sinCosto[p[1]]||0)+q;
    rows.push({ubi:p[0],sku:p[1],q:q,c:c,v:q*c,p:o?o.p:0,r:o?o.r:0,u:o?o.u:0,a:o?o.a:0,dep:(u&&u.deposito)||'—',cat:(s&&s.categoria)||'Sin categoría'});});
  return {rows:rows,sinCosto:sinCosto};});}
function xVal(){var d=valRows(),g=X8.ui.vg||'p',tot=x8sum(d.rows,function(r){return r.v;}),conC=d.rows.filter(function(r){return r.c>0;}),pos={};
  d.rows.forEach(function(r){pos[r.ubi]=(pos[r.ubi]||0)+r.v;});
  var G={p:['Pasillo',function(r){return 'Pasillo '+pad(r.p);}],r:['Rack',function(r){return 'Pasillo '+pad(r.p)+' · Rack '+pad(r.r);}],a:['Altura',function(r){return r.a===0?'Altura 00 (piso)':'Altura '+pad(r.a);}],dep:['Depósito',function(r){return r.dep;}],cat:['Categoría',function(r){return r.cat;}]},gr={};
  d.rows.forEach(function(r){var k=G[g][1](r),o=gr[k]=gr[k]||{v:0,q:0,pos:{}};o.v+=r.v;o.q+=r.q;o.pos[r.ubi]=1;});
  var ks=Object.keys(gr).sort(function(a,b){return gr[b].v-gr[a].v;}),top=Object.keys(pos).sort(function(a,b){return pos[b]-pos[a];}).slice(0,20),nsc=Object.keys(d.sinCosto);
  var h='<div class="kpis">'+KPI('$'+nf(tot),'Stock valorizado','a costo unitario cargado')+KPI(nf(Object.keys(pos).length),'Posiciones con stock','de '+nf((W().ubic||[]).length))+KPI('$'+nf(Object.keys(pos).length?tot/Object.keys(pos).length:0),'Valor medio por posición')+KPI(nf(nsc.length),'SKUs sin costo',nsc.length?'no suman al valor':'todo valorizado',nsc.length?'warn':'ok')+'</div>';
  var vm=X8.ui.vm||'plano';
  h+='<div class="seg lt" role="group" aria-label="Vista" style="margin:0 0 12px"><button data-act="x9-vm" data-v="plano" aria-pressed="'+(vm==='plano')+'">Plano de valor</button><button data-act="x9-vm" data-v="res" aria-pressed="'+(vm==='res')+'">Resumen y tablas</button></div>';
  if(vm==='plano')return h+x9plano();
  h+='<div class="panel"><div class="row sp"><h3>Valor del stock según su posición</h3><label>Agrupar por<select id="val-g">'+Object.keys(G).map(function(k){return '<option value="'+k+'"'+(g===k?' selected':'')+'>'+G[k][0]+'</option>';}).join('')+'</select></label></div><div class="small muted">Valor = unidades × costo unitario del SKU (un solo costo por SKU, no promedio ponderado ni FIFO). Sirve para ver dónde está concentrado el capital y qué posiciones conviene proteger o contar más seguido.</div>'+
   (ks.length?tbl([G[g][0],'Posiciones','Unidades','Valor','% del total',''],ks.map(function(k){var o=gr[k],pct=tot?o.v/tot*100:0;return [esc(k),nf(Object.keys(o.pos).length),nf(o.q),'$'+nf(o.v),nf(pct,1)+'%','<div style="background:var(--line,#ddd);height:8px;width:120px;border-radius:4px"><div style="background:var(--accent,#2563eb);height:8px;border-radius:4px;width:'+(gr[ks[0]].v?o.v/gr[ks[0]].v*100:0)+'%"></div></div>'];}),620):'<div class="empty">No hay stock para valorizar.</div>')+'</div>';
  if(top.length)h+='<div class="panel"><h3>20 posiciones con más valor</h3>'+tbl(['Posición','Contenido','Unidades','Valor'],top.map(function(u){var it=d.rows.filter(function(r){return r.ubi===u;});return ['<span class="mono">'+esc(u)+'</span>',it.map(function(r){return esc(r.sku);}).join(', '),nf(x8sum(it,function(r){return r.q;})),'$'+nf(pos[u])];}),560)+'</div>';
  if(nsc.length)h+='<div class="panel"><h3>SKUs con stock y sin costo</h3><div class="small muted">Cargá el costo en Control › Abastecimiento › Parámetros, o importá el archivo de parámetros por SKU.</div>'+tbl(['SKU','Producto','Unidades'],nsc.slice(0,200).map(function(c){var s=skuBy(c);return [esc(c),esc(s?s.producto||'':''),nf(d.sinCosto[c])];}),420)+'</div>';
  return h;}
function vfmt(v){return v>=1e6?'$'+nf(v/1e6,1)+' M':v>=1e3?'$'+nf(v/1e3,0)+' k':'$'+nf(v);}
var x9only=false;
function x9pos(){return x8c('x9p',function(){var d=valRows(),pos={},sc={},max=0,tot=0;d.rows.forEach(function(r){pos[r.ubi]=(pos[r.ubi]||0)+r.v;if(!r.c)sc[r.ubi]=true;tot+=r.v;});
  var ks=Object.keys(pos).sort(function(a,b){return pos[b]-pos[a];}),rank={};ks.forEach(function(k,i){rank[k]=i+1;if(pos[k]>max)max=pos[k];});
  return {pos:pos,sc:sc,max:max,tot:tot,n:ks.length,rank:rank,al:function(k){return pos[k]>0&&max?0.14+0.82*pos[k]/max:0;}};});}
function x9fill(VP,k){return 'rgba(56,189,248,'+VP.al(k).toFixed(2)+')';}
function x9legend(VP){return '<div class="legend" style="align-items:center"><span class="small">Menos</span><span style="width:140px;height:10px;border-radius:5px;background:linear-gradient(90deg,rgba(56,189,248,.12),rgba(56,189,248,.95))"></span><span class="small">Más ('+vfmt(VP.max)+')</span><span><i style="background:var(--surface2);border:1px solid var(--line)"></i>Libre</span><span><i style="background:var(--accent)"></i>Seleccionada</span><span class="small muted">* hay stock sin costo cargado</span></div>';}
function x9v(sku,q){var s=skuBy(sku);return s&&+s.costo>0?'$'+nf(q*s.costo):'sin costo';}
function x9doc(VP,k){var v=VP.pos[k]||0;return '<div class="doc"><span class="k">Valor de la posición</span><span class="v">'+(v>0?'$'+nf(v)+'<br>'+nf(VP.tot?v/VP.tot*100:0,2)+'% del stock · puesto '+VP.rank[k]+' de '+VP.n:'Libre')+(VP.sc[k]?'<br><span class="small muted">Hay stock sin costo cargado</span>':'')+'</span></div>';}
function x9plano(){var v0=S.ui.wvista;S.ui.wvista='valor';x9only=true;try{return wPlano();}finally{x9only=false;S.ui.wvista=v0;}}
document.addEventListener('click',function(ev){var b=ev.target.closest('[data-act="x9-vm"]');if(!b)return;X8.ui.vm=b.dataset.v;render();});
document.addEventListener('change',function(ev){if(ev.target.id==='val-g'){X8.ui.vg=ev.target.value;render();}});
WSUBS_ALL.splice(WSUBS_ALL.length-1,0,['x9val','Valorizado']);
var x9vw0=viewWms;viewWms=function(){if(S.ui.wsub==='x9val'&&rolActual()==='admin'){S.ext.sub='x9val';return '<div class="row sp"><h2>Depósito</h2></div>'+wSub()+xVal();}if(S.ui.wsub==='x9val')S.ui.wsub='stock';return x9vw0();};
/* ===== EXT9 end ===== */

/* EXT9 end */


/* EXT8 start */
/* ===== EXT8 start: gestión integral (escala, módulos, stock disponible, abastecimiento, reposición) ===== */
var X8={rc:0,cache:{},vals:{},ui:{}};
['pedidos','expediciones','transportistas','fletes','repos','alertas','cfgx'].forEach(function(k){if(S.data.demo.wms&&!S.data.demo.wms[k])S.data.demo.wms[k]=[];});
function x8c(key,fn){var c=X8.cache;if(c._rc!==X8.rc){c={_rc:X8.rc};X8.cache=c;}if(!(key in c))c[key]=fn();return c[key];}
function x8dt(iso){return iso?new Date(iso):null;}
function x8hrs(a,b){return (new Date(b)-new Date(a))/36e5;}
function x8d(s){return String(s||'').slice(0,10);}
function x8skus(){return x8c('skum',function(){var o={};(W().skus||[]).forEach(function(s){o[s.codigo]=s;});return o;});}
function skuBy(c){return x8skus()[c];}
function x8ubic(){return x8c('ubm',function(){var o={};(W().ubic||[]).forEach(function(u){o[u.codigo]=u;});return o;});}
function x8pick(){return x8c('pkm',function(){var o={};WC('picks').forEach(function(p){o[p.id]=p;});return o;});}
function x8ent(){return x8c('entm',function(){var o={};(D().entregas||[]).forEach(function(e){o[e.id]=e;});return o;});}
function x8set(k,v){X8.ui[k]=v;render();}
async function x8put(kind,o){return wPut(kind,o);}
function x8by(list,key){var o={};list.forEach(function(x){(o[x[key]]=o[x[key]]||[]).push(x);});return o;}
function x8sum(a,f){return a.reduce(function(t,x){return t+(f?f(x):x);},0);}
function x8user(){return actor();}

/* ----- render con caché por pasada + ajustes para depósitos grandes ----- */
var x8render0=render;
render=function(){X8.rc++;x8render0.apply(this,arguments);try{x8Post();}catch(e){if(window.console)console.error(e);}};
var x8wstock0=wStock,x8wsc={k:null,n:-1,l:''};
wStock=function(){var k=W().kardex||[],last=k.length?k[k.length-1].id:'';if(x8wsc.r&&x8wsc.k===k&&x8wsc.n===k.length&&x8wsc.l===last)return x8wsc.r;x8wsc.r=x8wstock0();x8wsc.k=k;x8wsc.n=k.length;x8wsc.l=last;return x8wsc.r;};
function x8Post(){
  document.querySelectorAll('#app select').forEach(function(sel,n){
    if(!sel.id||sel.options.length<=120||sel.multiple)return;
    var inp=document.createElement('input');inp.type='text';inp.id=sel.id;inp.className=sel.className;inp.setAttribute('autocomplete','off');
    Array.prototype.slice.call(sel.attributes).forEach(function(a){if(/^data-/.test(a.name))inp.setAttribute(a.name,a.value);});
    var dl=document.createElement('datalist');dl.id='dl-'+sel.id;var vals={};
    Array.prototype.forEach.call(sel.options,function(o){var op=document.createElement('option');op.value=o.value;if(o.textContent&&o.textContent!==o.value)op.label=o.textContent;dl.appendChild(op);vals[o.value]=1;});
    inp.setAttribute('list',dl.id);inp.value=sel.value;inp.dataset.x8vals='1';inp.placeholder='Escribí para buscar…';X8.vals[inp.id]=vals;
    sel.parentNode.insertBefore(dl,sel);sel.parentNode.replaceChild(inp,sel);});
  document.querySelectorAll('#app .tablewrap > table').forEach(function(t,i){
    var rows=t.tBodies[0]?Array.prototype.slice.call(t.tBodies[0].rows):[];if(rows.length<=60)return;
    var key=(S.ui.tab||'')+'|'+(S.ui.wsub||'')+'|'+(S.ext.sub||'')+'|'+i,tp=S.ext.tp=S.ext.tp||{},st=tp[key]=tp[key]||{q:'',p:1},q=st.q.toLowerCase();
    var vis=rows.filter(function(r){return !q||r.textContent.toLowerCase().indexOf(q)>=0;}),per=50,n=Math.max(1,Math.ceil(vis.length/per));
    if(st.p>n)st.p=n;if(st.p<1)st.p=1;var from=(st.p-1)*per;
    rows.forEach(function(r){r.style.display='none';});vis.slice(from,from+per).forEach(function(r){r.style.display='';});
    var bar=document.createElement('div');bar.className='row x8pg';
    bar.innerHTML='<input type="search" class="x8q" data-k="'+esc(key)+'" placeholder="Buscar en esta tabla…" value="'+esc(st.q)+'" style="max-width:240px"><button class="btn sm" data-act="x8-tp" data-k="'+esc(key)+'" data-d="-1"'+(st.p<=1?' disabled':'')+'>‹</button><span class="small">Página '+st.p+' de '+n+' · '+vis.length+' de '+rows.length+' filas</span><button class="btn sm" data-act="x8-tp" data-k="'+esc(key)+'" data-d="1"'+(st.p>=n?' disabled':'')+'>›</button>';
    t.parentNode.parentNode.insertBefore(bar,t.parentNode);});}
document.addEventListener('change',function(ev){var t=ev.target;
  if(t&&t.dataset&&t.dataset.x8vals&&t.value&&!(X8.vals[t.id]||{})[t.value]){toast('No existe "'+t.value+'". Elegí una opción de la lista.');t.value='';}
  else if(t&&t.classList&&t.classList.contains('x8q')){var st=S.ext.tp[t.dataset.k];if(st){st.q=t.value;st.p=1;render();}}},true);
document.addEventListener('click',function(ev){var b=ev.target.closest('[data-act="x8-tp"]');if(!b)return;var st=S.ext.tp&&S.ext.tp[b.dataset.k];if(st){st.p+=parseInt(b.dataset.d,10);render();}});
/* Plano por pasillo cuando hay muchas posiciones */
var x8plano0=wPlano;
wPlano=function(){var w=W(),all=w.ubic||[];if(all.length<=400)return x8plano0();
  var ps={};all.forEach(function(u){var o=locParse(u.codigo);if(o)ps[o.p]=1;});var pl=Object.keys(ps).map(Number).sort(function(a,b){return a-b;});
  var sel=X8.ui.pas&&ps[X8.ui.pas]?X8.ui.pas:pl[0];
  var sub=all.filter(function(u){var o=locParse(u.codigo);return o&&o.p===sel;});w.ubic=sub;var h;try{h=x8plano0();}finally{w.ubic=all;}
  return '<div class="panel"><div class="row"><label>Pasillo<select id="x8-pas" data-act="x8keep">'+pl.map(function(p){return '<option value="'+p+'"'+(p===sel?' selected':'')+'>'+pad(p)+'</option>';}).join('')+'</select></label><span class="small muted">El depósito tiene '+nf(all.length)+' posiciones: el plano muestra un pasillo por vez.</span></div></div>'+h;};
document.addEventListener('change',function(ev){if(ev.target.id==='x8-pas'){X8.ui.pas=parseInt(ev.target.value,10);render();}});

/* ----- módulos activables ----- */
var MODS=[['ctl','Centro de control'],['ped','Pedidos'],['exp','Expedición por escaneo'],['fle','Auditoría de fletes'],['abs','Abastecimiento'],['rep','Reposición de picking'],['prd','Productividad'],['esc','Escenarios y flota']];
var PRESETS={minimo:['ctl','ped'],pyme:['ctl','ped','exp','fle','abs','rep'],completo:['ctl','ped','exp','fle','abs','rep','prd','esc']};
function cfgx(){return WC('cfgx').find(function(x){return x.id==='main';})||{id:'main'};}
function modSug(){var n=(W().skus||[]).length,np=(W().ubic||[]).length;return (n<=30&&np<=80)?'minimo':(n<=400&&np<=1500)?'pyme':'completo';}
function modLista(){var c=cfgx();return c.mods||PRESETS[S.mode==='demo'?'completo':modSug()];}
function modOn(k){return modLista().indexOf(k)>=0;}
async function cfgSave(patch){var c=clean(cfgx());Object.keys(patch).forEach(function(k){c[k]=patch[k];});c.id='main';await wPut('cfgx',c);}

/* ----- demanda y pronóstico de stock (versión indexada: escala a miles de SKUs) ----- */
function stockPron(){return x8c('spron',function(){
  var w=W(),an=S.ext.an,L=an.lead,z=an.z,H=90,ini=addDays(-H),st=wStock(),oc={},idx={};
  (w.ocs||[]).forEach(function(o){if(o.estado==='recibida'||o.estado==='cancelada')return;(o.lineas||[]).forEach(function(l){oc[l.sku]=(oc[l.sku]||0)+Math.max(0,l.qty-(l.rec||0));});});
  w.kardex.forEach(function(x){if(x.tipo==='OUT'&&x.out>0&&x.fecha>=ini&&x.fecha<=HOY&&!/devoluci/i.test(x.nota||'')){var o=idx[x.sku]=idx[x.sku]||{};o[x.fecha]=(o[x.fecha]||0)+x.out;}});
  var ser=function(sku,desde,hasta){var days=[],m=idx[sku]||{};var a=new Date(desde+'T12:00:00'),b=new Date(hasta+'T12:00:00');for(var d=new Date(a);d<=b;d.setDate(d.getDate()+1))days.push(m[ymd(d)]||0);return days;};
  var mean=function(a){return a.length?a.reduce(function(t,x){return t+x;},0)/a.length:0;},sd=function(a){var m=mean(a);return a.length>1?Math.sqrt(a.reduce(function(t,x){return t+(x-m)*(x-m);},0)/(a.length-1)):0;};
  var rows=w.skus.map(function(s){var d90=ser(s.codigo,ini,HOY),d28=d90.slice(-28),d=0.6*mean(d28)+0.4*mean(d90),sg=sd(d90),stk=st.tot[s.codigo]||0,rop=d*L+z*sg*Math.sqrt(L),cob=d>0?stk/d:null,enc=oc[s.codigo]||0,sug=Math.max(0,Math.ceil(rop+d*7-stk-enc));
    var est=d<=0?'Sin movimiento':(stk+enc<=rop?(cob!=null&&cob<L?'Quiebre en '+Math.max(0,Math.floor(cob))+' d':'Pedir'):(cob>90&&stk>s.max?'Sobrestock':'OK'));
    return {s:s,stk:stk,d:d,sg:sg,rop:rop,cob:cob,enc:enc,sug:sug,est:est,hist:d90.length};});
  var ae=0,aa=0,nb=0;w.skus.forEach(function(s){var all=ser(s.codigo,addDays(-(H)),addDays(-14)),act=ser(s.codigo,addDays(-13),HOY);if(all.reduce(function(t,x){return t+x;},0)<=0)return;var dd=0.6*mean(all.slice(-28))+0.4*mean(all),f=dd*act.length,a=act.reduce(function(t,x){return t+x;},0);ae+=Math.abs(f-a);aa+=a;nb++;});
  return {rows:rows,wape:aa>0&&nb>=2?ae/aa*100:null,nb:nb};});}

/* ----- stock disponible / comprometido ----- */
function x8comp(){return x8c('comp',function(){var comp={},cu={};
  var cl={};var add=function(sku,ubi,q,lote){comp[sku]=(comp[sku]||0)+q;cu[ubi+'|'+sku]=(cu[ubi+'|'+sku]||0)+q;var k=ubi+'|'+sku+'|'+(lote||'');cl[k]=(cl[k]||0)+q;};
  WC('pedidos').forEach(function(p){var f=pedFase(p);if(f==='reservado'||f==='preparacion')(p.reserva||[]).forEach(function(r){add(r.sku,r.ubi,r.qty,r.lote);});});
  WC('picks').forEach(function(k){if(k.ola||k.pedidoId)return;if(k.estado==='pendiente'||k.estado==='en_ola')(k.lineas||[]).forEach(function(l){add(l.sku,l.ubi,l.qty,l.lote);});});
  return {comp:comp,cu:cu,cl:cl};});}
function x8disp(sku){var st=wStock(),c=x8comp();var s=st.tot[sku]||0,cm=c.comp[sku]||0;return {stock:s,comp:cm,disp:Math.max(0,s-cm)};}

/* ----- abastecimiento ----- */
function abastRows(){return x8c('abast',function(){
  var an=S.ext.an,pr=stockPron(),st=wStock(),c=x8comp(),cfg=cfgx(),cobObj=cfg.cobObj||14,defL=cfg.leadDef||7;
  return pr.rows.map(function(r){var s=r.s,L=s.lead>0?s.lead:defL,stock=r.stk,cm=c.comp[s.codigo]||0,disp=Math.max(0,stock-cm),d=r.d,ss=an.z*r.sg*Math.sqrt(L),rop=d*L+ss,cob=d>0?disp/d:null,enc=r.enc;
    var target=d*(L+cobObj)+ss,sug=d>0||disp+enc<(s.min||0)?Math.max(0,Math.ceil(Math.max(target,s.min||0)-disp-enc)):0;
    var est=d<=0&&disp>=(s.min||0)?'Sin movimiento':disp<=0&&(d>0||(s.min||0)>0)?'Quiebre':(disp+enc<=rop||disp+enc<(s.min||0))?'Reponer':(cob!=null&&cob>90&&s.max>0&&stock>s.max)?'Exceso':'Normal';
    return {s:s,stock:stock,comp:cm,disp:disp,d:d,cob:cob,enc:enc,L:L,rop:rop,sug:sug,est:est};});});}
var ABS_C={Quiebre:'bad',Reponer:'warn',Normal:'ok',Exceso:'',  'Sin movimiento':''};
function xAbast(){
  var rows=abastRows(),f=X8.ui.abf||'todos',cnt={};rows.forEach(function(r){cnt[r.est]=(cnt[r.est]||0)+1;});
  var sug=rows.filter(function(r){return r.sug>0&&(r.est==='Quiebre'||r.est==='Reponer');}),lst=f==='todos'?rows:rows.filter(function(r){return r.est===f;});
  var h='<div class="kpis">'+KPI(nf(rows.length),'SKUs',nf(cnt.Normal||0)+' en situación normal')+KPI(nf(cnt.Quiebre||0),'En quiebre','sin stock disponible y con demanda',(cnt.Quiebre?'bad':''))+KPI(nf(cnt.Reponer||0),'A reponer','bajo el punto de reposición',(cnt.Reponer?'warn':''))+KPI(nf(cnt.Exceso||0),'Con exceso','más de 90 días de cobertura')+'</div>';
  h+='<div class="panel"><div class="row sp"><h3>Abastecimiento</h3><div class="row"><label>Cobertura objetivo (días)<input id="ab-cob" type="number" min="1" max="180" value="'+(cfgx().cobObj||14)+'" style="width:90px"></label><label>Lead time por defecto (días)<input id="ab-lead" type="number" min="1" max="120" value="'+(cfgx().leadDef||7)+'" style="width:90px"></label></div></div>'+
    '<div class="small muted">Disponible = stock − comprometido (reservas de pedidos y picking pendiente). Punto de reposición = demanda diaria × lead time + stock de seguridad. Sugerido = lo que falta para cubrir lead time + cobertura objetivo, descontando órdenes de compra pendientes. La demanda sale de los despachos de los últimos 90 días.</div>'+
    '<div class="chips" style="margin:10px 0">'+['todos','Quiebre','Reponer','Normal','Exceso','Sin movimiento'].map(function(k){return '<button class="chip'+(f===k?' ok':'')+'" data-act="x8-abf" data-v="'+k+'">'+(k==='todos'?'Todos ('+rows.length+')':k+' ('+(cnt[k]||0)+')')+'</button>';}).join('')+'</div>'+
    '<div class="row">'+(sug.length?'<button class="btn pri" data-act="x8-ocgen">Generar órdenes de compra sugeridas ('+sug.length+' SKUs)</button>':'<span class="small muted">No hay SKUs para reponer.</span>')+'<button class="btn" data-act="x8-skuimp">Importar parámetros por SKU (CSV/Excel)</button><input id="x8-skufile" type="file" accept=".csv,.xlsx,.xls" hidden></div>'+
    (X8.ui.ocConf?'<div class="banner warn" role="status">'+ICON.alert+'<div><strong>Confirmá la generación</strong>'+X8.ui.ocConf.map(function(g){return esc(g.prov)+': '+g.n+' SKUs, '+nf(g.u)+' u';}).join(' · ')+'<div class="row" style="margin-top:6px"><button class="btn pri" data-act="x8-ocok">Crear órdenes</button><button class="btn" data-act="x8-occancel">Cancelar</button></div></div></div>':'')+
    (X8.ui.skuEdit?skuEditForm(X8.ui.skuEdit):'')+
    tbl(['SKU','Producto','Stock','Comprom.','Disponible','Demanda/día','Cobertura','OC pend.','Lead','Pto. reposición','Sugerido','Situación',''],lst.map(function(r){return ['<span class="guia">'+esc(r.s.codigo)+'</span>',esc(r.s.producto||''),nf(r.stock),nf(r.comp),'<strong>'+nf(r.disp)+'</strong>',nf(r.d,1),r.cob==null?'—':nf(r.cob,0)+' d',nf(r.enc),r.L+' d'+(r.s.lead>0?'':'*'),nf(r.rop),r.sug?'<strong>'+nf(r.sug)+'</strong>':'—','<span class="chip '+(ABS_C[r.est]||'')+'">'+r.est+'</span>','<button class="btn sm" data-act="x8-skued" data-id="'+esc(r.s.codigo)+'">Parámetros</button>'];}),900)+
    '<div class="small muted">* lead time por defecto: cargalo por SKU en "Parámetros" o importalo en bloque.</div></div>';
  return h;}
function skuEditForm(c){var s=skuBy(c);if(!s)return '';return '<div class="panel" id="x8-skuform"><h3>Parámetros de '+esc(s.codigo)+' · '+esc(s.producto||'')+'</h3><div class="grid2">'+
  '<label>Proveedor<input id="sp-prov" value="'+esc(s.prov||'')+'"></label><label>Lead time (días)<input id="sp-lead" type="number" min="0" value="'+esc(s.lead||'')+'"></label>'+
  '<label>Costo unitario ($)<input id="sp-costo" type="number" min="0" step="any" value="'+esc(s.costo||'')+'"></label><label>Volumen por unidad (m³)<input id="sp-vol" type="number" min="0" step="any" value="'+esc(s.vol||'')+'"></label>'+
  '<label>Stock mínimo<input id="sp-min" type="number" min="0" value="'+esc(s.min||0)+'"></label><label>Stock máximo<input id="sp-max" type="number" min="0" value="'+esc(s.max||0)+'"></label>'+
  '<label>Stock mínimo en picking (u)<input id="sp-minpick" type="number" min="0" value="'+esc(s.minPick||'')+'"></label></div><div class="row"><button class="btn pri" data-act="x8-skusave" data-id="'+esc(c)+'">Guardar</button><button class="btn" data-act="x8-skucancel">Cancelar</button></div></div>';}
async function skuSave(c){var s=skuBy(c);if(!s)return;s=clean(s);var n=function(i){var v=parseFloat(gv(i));return isNaN(v)?0:v;};
  s.prov=gv('sp-prov').trim();s.lead=n('sp-lead');s.costo=n('sp-costo');s.vol=n('sp-vol');s.min=n('sp-min');s.max=n('sp-max');s.minPick=n('sp-minpick');await wPut('skus',s);X8.ui.skuEdit=null;toast('Parámetros guardados');render();}
async function skuImport(file){var rows=await leerArchivoFilas(file);if(!rows||rows.length<2){toast('El archivo está vacío.');return;}var H=obHead(rows),ok=0,bad=[],num=function(v){v=parseFloat(String(v==null?'':v).replace(',','.'));return isNaN(v)?null:v;};
  var jobs=[];H.rows.forEach(function(r,i){var code=String(H.col(r,['sku','codigo'])||'').trim();if(!code)return;var s=skuBy(code);if(!s){bad.push('fila '+(i+2)+': el SKU '+code+' no existe');return;}s=clean(s);
    var p=H.col(r,['proveedor']);if(p!==''&&p!=null)s.prov=String(p).trim();[['lead',['lead','leadtime','dias']],['costo',['costo','costounitario']],['vol',['volumen','vol','m3']],['min',['minimo','min']],['max',['maximo','max']],['minPick',['minpicking','minpick']]].forEach(function(m){var v=num(H.col(r,m[1]));if(v!=null)s[m[0]]=v;});jobs.push(s);ok++;});
  for(var i=0;i<jobs.length;i+=20)await Promise.all(jobs.slice(i,i+20).map(function(s){return wPut('skus',s);}));
  toast(ok+' SKUs actualizados'+(bad.length?'; '+bad.length+' con problemas ('+bad.slice(0,2).join(', ')+')':'')+'.');}
function ocGenPrev(){var g={};abastRows().forEach(function(r){if(r.sug>0&&(r.est==='Quiebre'||r.est==='Reponer')){var p=r.s.prov||'Sin proveedor',o=g[p]=g[p]||{prov:p,lineas:[],n:0,u:0};o.lineas.push({sku:r.s.codigo,qty:r.sug,rec:0});o.n++;o.u+=r.sug;}});return Object.keys(g).map(function(k){return g[k];});}
async function ocGenOk(){var gs=ocGenPrev();for(var i=0;i<gs.length;i++){await wPut('ocs',{id:uid('OC'),ref:'Sugerida '+HOY,proveedor:gs[i].prov,fecha:HOY,estado:'abierta',lineas:gs[i].lineas,por:actor(),sugerida:true});}X8.ui.ocConf=null;toast(gs.length+' órdenes de compra creadas.');render();}
document.addEventListener('change',async function(ev){var t=ev.target;
  if(t.id==='ab-cob'){await cfgSave({cobObj:Math.max(1,parseInt(t.value,10)||14)});}
  else if(t.id==='ab-lead'){await cfgSave({leadDef:Math.max(1,parseInt(t.value,10)||7)});}
  else if(t.id==='x8-skufile'&&t.files[0]){try{await skuImport(t.files[0]);}catch(e){toast('No se pudo leer el archivo.');}t.value='';}});

/* ----- reposición de picking (piso = picking, alturas > 0 = reserva) ----- */
function repoPct(){return cfgx().repoPct||30;}
function repoSug(){return x8c('repoSug',function(){
  var st=wStock(),ub=x8ubic(),pct=repoPct()/100,lots=wLotes(),lotBy={},pend={},out=[];
  lots.forEach(function(l){if(l.q>0)(lotBy[l.sku+'|'+l.ubi]=lotBy[l.sku+'|'+l.ubi]||[]).push(l);});
  WC('repos').forEach(function(r){if(r.estado==='pendiente')pend[r.sku+'|'+r.hacia]=1;});
  var bySku={};Object.keys(st.m).forEach(function(k){var q=st.m[k];if(q<=0)return;var p=k.split('|');(bySku[p[1]]=bySku[p[1]]||[]).push({ubi:p[0],q:q});});
  (W().skus||[]).forEach(function(s){
    var face=null,fu=s.ubic?locParse(s.ubic):null;if(fu&&fu.a===0)face=locNorm(s.ubic);
    if(!face){var fl=(bySku[s.codigo]||[]).filter(function(x){var o=locParse(x.ubi);return o&&o.a===0;}).sort(function(a,b){return b.q-a.q;});if(fl.length)face=fl[0].ubi;}
    if(!face)return;var u=ub[face];if(!u||!(u.cap>0))return;if(pend[s.codigo+'|'+face])return;
    var cur=Math.max(0,st.m[face+'|'+s.codigo]||0),trig=s.minPick>0?s.minPick:Math.ceil(u.cap*pct);if(cur>=trig)return;
    var need=u.cap-cur,fo=locParse(face);
    var srcs=(bySku[s.codigo]||[]).filter(function(x){return x.ubi!==face;}).map(function(x){var o=locParse(x.ubi),ls=(lotBy[s.codigo+'|'+x.ubi]||[]).slice().sort(function(a,b){return String(a.vence||'9999').localeCompare(String(b.vence||'9999'));}),v=ls.length&&ls[0].vence?ls[0].vence:'9999';return {ubi:x.ubi,q:x.q,v:v,o:o,ls:ls};});
    srcs.sort(function(a,b){var ra=a.o&&a.o.a>0?0:1,rb=b.o&&b.o.a>0?0:1;if(ra!==rb)return ra-rb;if(a.v!==b.v)return a.v<b.v?-1:1;var sa=a.o&&fo&&a.o.p===fo.p?0:1,sb=b.o&&fo&&b.o.p===fo.p?0:1;return sa-sb;});
    srcs.forEach(function(x){if(need<=0)return;var take=Math.min(need,x.q-((x.ubi&&x8comp().cu[x.ubi+'|'+s.codigo])||0));if(take<=0)return;var lote='',vence='';if(x.ls.length){lote=x.ls[0].lote;vence=x.ls[0].vence||'';take=Math.min(take,x.ls[0].q);}if(take<=0)return;
      out.push({sku:s.codigo,producto:s.producto||'',hacia:face,desde:x.ubi,lote:lote,vence:vence,qty:take,actual:cur,cap:u.cap});need-=take;});});
  return out;});}
async function reposCrear(auto){var sg=repoSug(),n=0;for(var i=0;i<sg.length;i++){var r=sg[i];await wPut('repos',{id:uid('RP'),sku:r.sku,producto:r.producto,hacia:r.hacia,desde:r.desde,lote:r.lote,vence:r.vence,qty:r.qty,estado:'pendiente',creada:isoNow(),por:auto?'Automática':actor(),auto:!!auto});n++;}
  if(!auto)toast(n?n+' tareas de reposición creadas.':'No hay nada para reponer.');return n;}
async function reposHecha(id){var r=WC('repos').find(function(x){return x.id===id;});if(!r||r.estado!=='pendiente')return;
  var vo=gv('rp-o-'+id).trim(),vd=gv('rp-d-'+id).trim();
  if(vo&&locNorm(vo)!==locNorm(r.desde)){toast('El origen leído ('+vo+') no es '+r.desde+'.');return;}
  if(vd&&locNorm(vd)!==locNorm(r.hacia)){toast('El destino leído ('+vd+') no es '+r.hacia+'.');return;}
  var have=(wStock().m[r.desde+'|'+r.sku]||0);if(have<r.qty){toast('En '+r.desde+' ya no hay '+r.qty+' u de '+r.sku+' (hay '+have+').');return;}
  var base={sku:r.sku,lote:r.lote||'',vence:r.vence||'',operador:actor(),nota:'Reposición '+r.id,tipo:'TRANSFERENCIA',fecha:HOY};
  await wPut('kardex',Object.assign({id:uid('M'),ubicacion:r.desde,'in':0,out:r.qty},base));await wPut('kardex',Object.assign({id:uid('M'),ubicacion:r.hacia,'in':r.qty,out:0},base));
  r=clean(r);r.estado='hecha';r.hecha=isoNow();r.hechaPor=actor();await wPut('repos',r);toast('Reposición registrada: '+r.qty+' u de '+r.sku+' a '+r.hacia+'.');}
function xRepo(){var pend=WC('repos').filter(function(r){return r.estado==='pendiente';}),sg=repoSug(),hech=WC('repos').filter(function(r){return r.estado==='hecha';}).sort(function(a,b){return String(b.hecha).localeCompare(String(a.hecha));}).slice(0,15);
  return '<div class="panel"><div class="row sp"><h3>Reposición de picking</h3><label>Reponer cuando quede menos de (% de la capacidad)<input id="rp-pct" type="number" min="5" max="90" value="'+repoPct()+'" style="width:80px"></label></div>'+
   '<div class="small muted">La posición de picking es la del piso (altura 00) donde cada SKU tiene su ubicación habitual. Cuando baja del mínimo, se genera una tarea para traer mercadería de las alturas de arriba, primero lo que vence antes. Se crean solas al confirmar un picking, o con el botón.</div>'+
   '<div class="row" style="margin-top:8px">'+(sg.length?'<button class="btn pri" data-act="x8-repcrear">Crear '+sg.length+' tareas sugeridas</button>':'<span class="small muted">Ninguna posición de picking está bajo el mínimo.</span>')+'</div></div>'+
   '<div class="panel"><h3>Tareas pendientes ('+pend.length+')</h3>'+(pend.length?tbl(['Creada','SKU','Origen','Destino (picking)','Cantidad','Confirmar'],pend.map(function(r){return [esc(fmtFecha(x8d(r.creada)))+'<div class="small muted">'+esc(r.por||'')+'</div>','<span class="guia">'+esc(r.sku)+'</span><div class="small muted">'+esc(r.producto||'')+'</div>','<span class="mono">'+esc(r.desde)+'</span>'+(r.lote?'<div class="small muted">lote '+esc(r.lote)+(r.vence?' · vence '+esc(r.vence):'')+'</div>':''),'<span class="mono">'+esc(r.hacia)+'</span>',nf(r.qty)+' u','<div class="row"><input id="rp-o-'+esc(r.id)+'" placeholder="Escaneá origen" style="width:130px"><input id="rp-d-'+esc(r.id)+'" placeholder="Escaneá destino" style="width:130px"><button class="btn sm pri" data-act="x8-rephecha" data-id="'+esc(r.id)+'">Hecha</button></div>'];}),760):'<div class="empty">No hay tareas pendientes.</div>')+'</div>'+
   (hech.length?'<div class="panel"><h3>Últimas hechas</h3>'+tbl(['Cuándo','SKU','Origen','Destino','Cantidad','Quién'],hech.map(function(r){return [esc(fmtFecha(x8d(r.hecha))),esc(r.sku),'<span class="mono">'+esc(r.desde)+'</span>','<span class="mono">'+esc(r.hacia)+'</span>',nf(r.qty),esc(r.hechaPor||'')];}),560)+'</div>':'');}
document.addEventListener('change',async function(ev){if(ev.target.id==='rp-pct'){await cfgSave({repoPct:Math.min(90,Math.max(5,parseInt(ev.target.value,10)||30))});}});
var x8pc0=pickConfirmar;
pickConfirmar=async function(id,ov){var before=(WC('picks').find(function(x){return x.id===id;})||{}).estado;await x8pc0(id,ov);
  var after=(WC('picks').find(function(x){return x.id===id;})||{}).estado;
  if(before==='pendiente'&&after==='completado'&&modOn('rep')){try{X8.rc++;await reposCrear(true);}catch(e){}}};
/* ===== EXT8a end ===== */
/* ===== EXT8c: pedidos y expedición ===== */
var PED_FASES={borrador:'Borrador',reservado:'Reservado',preparacion:'En preparación',preparado:'Preparado',despachado:'Despachado',entregado:'Entregado',cancelado:'Cancelado'};
var PED_CLS={borrador:'',reservado:'signal',preparacion:'warn',preparado:'warn',despachado:'signal',entregado:'ok',cancelado:'bad'};
function pedFase(p){if(p.estado==='despachado'){var e=x8ent()[p.entregaId];if(e&&e.estado==='entregada')return 'entregado';}return p.estado||'borrador';}
function pedCod(n){return 'PED-'+String(n).padStart(6,'0');}
function pedNext(){var m=0;WC('pedidos').forEach(function(p){var n=parseInt(String(p.id).replace(/\D/g,''),10)||0;if(n>m)m=n;});return m+1;}
function pedBultoCod(p,i){return p.id+'-'+i;}
function pedBloqueos(p){var f=pedFase(p),out=[];if(f==='cancelado'||f==='entregado')return out;
  (p.lineas||[]).forEach(function(l){if(!skuBy(l.sku))out.push('El SKU '+l.sku+' no existe en el maestro');});
  if(!p.direccion)out.push('Falta la dirección de entrega');
  if(!p.entrega)out.push('Falta la fecha prometida');
  if(f==='borrador'){(p.lineas||[]).forEach(function(l){if(!skuBy(l.sku))return;var d=x8disp(l.sku);if(d.disp<l.qty)out.push('Falta stock de '+l.sku+': pide '+nf(l.qty)+', disponible '+nf(d.disp));});}
  if(f==='reservado'&&p.parcial)out.push('Reserva parcial: faltan '+(p.faltante||[]).map(function(x){return nf(x.qty)+' u de '+x.sku;}).join(', '));
  if(f==='reservado'||f==='preparacion')(p.reserva||[]).forEach(function(r){if(r.vence&&p.entrega&&r.vence<p.entrega&&out.indexOf('Hay lotes que vencen antes de la fecha de entrega')<0)out.push('Hay lotes que vencen antes de la fecha de entrega');});
  if(f==='preparado'&&(p.faltaPick||[]).length)out.push('Se recogió menos de lo reservado: faltan '+p.faltaPick.map(function(x){return nf(x.qty)+' u de '+x.sku;}).join(', '));
  if(f==='despachado'){var e=x8ent()[p.entregaId];if(e&&e.estado==='no_entregada')out.push('La entrega no se concretó');}
  if((f==='borrador'||f==='reservado'||f==='preparacion'||f==='preparado')&&p.entrega&&p.entrega<HOY)out.push('Atrasado: debía entregarse el '+fmtFecha(p.entrega));
  return out;}
function pedClienteInfo(nombre){var perf=(D().perfiles||[]).find(function(x){return x.rol==='cliente'&&x.nombre===nombre;});if(!perf)return {};var ult=(D().entregas||[]).filter(function(e){return e.clienteId===perf.id&&e.direccion;}).sort(function(a,b){return String(b.fecha).localeCompare(String(a.fecha));})[0];return {id:perf.id,dir:ult?ult.direccion:'',lat:ult?ult.lat:null,lng:ult?ult.lng:null,desde:ult?ult.desde:'',hasta:ult?ult.hasta:''};}
function pedGet(id){return WC('pedidos').find(function(x){return x.id===id;});}
async function pedGuardar(p){await wPut('pedidos',p);}

/* alta manual */
function pedDraft(){return X8.ui.pd=X8.ui.pd||{cliente:'',direccion:'',entrega:addDays(1),desde:'09:00',hasta:'18:00',ref:'',lineas:[]};}
function pedLeerForm(){var d=pedDraft();['cliente','direccion','entrega','desde','hasta','ref'].forEach(function(k){var el=document.getElementById('pd-'+k);if(el)d[k]=el.value;});return d;}
async function pedCrear(){var d=pedLeerForm();
  if(!d.cliente.trim()){toast('Indicá el cliente.');return;}if(!d.lineas.length){toast('Agregá al menos una línea.');return;}
  var ci=pedClienteInfo(d.cliente.trim()),n=pedNext();
  await pedGuardar({id:pedCod(n),cliente:d.cliente.trim(),clienteId:ci.id||'',direccion:(d.direccion||ci.dir||'').trim(),lat:ci.lat==null?null:ci.lat,lng:ci.lng==null?null:ci.lng,entrega:d.entrega,desde:d.desde||'09:00',hasta:d.hasta||'18:00',ref:d.ref.trim(),lineas:d.lineas.map(function(l){return {sku:l.sku,qty:l.qty};}),estado:'borrador',creado:isoNow(),por:actor()});
  X8.ui.pd=null;X8.ui.pedNew=false;toast('Pedido '+pedCod(n)+' creado.');render();}
async function pedImport(file){var rows=await leerArchivoFilas(file);if(!rows||rows.length<2){toast('El archivo está vacío.');return;}
  var H=obHead(rows),g={},ord=[],bad=[];
  H.rows.forEach(function(r,i){var ref=H.col(r,['pedido','referencia','orden','nro']),cli=H.col(r,['cliente']),sku=H.col(r,['sku','codigo']),q=parseFloat(String(H.col(r,['cantidad','qty','unidades'])).replace(',','.'));
    if(!cli&&!sku&&!ref)return;if(!cli){bad.push('fila '+(i+2)+': falta el cliente');return;}if(!sku||!(q>0)){bad.push('fila '+(i+2)+': falta SKU o cantidad');return;}if(!skuBy(sku)){bad.push('fila '+(i+2)+': el SKU '+sku+' no existe');return;}
    var k=(ref||'')+'|'+cli;if(!g[k]){g[k]={ref:ref,cliente:cli,direccion:H.col(r,['direccion','domicilio']),entrega:H.col(r,['fecha','entrega','fechaentrega'])||addDays(1),desde:H.col(r,['desde'])||'09:00',hasta:H.col(r,['hasta'])||'18:00',lineas:{}};ord.push(k);}
    g[k].lineas[sku]=(g[k].lineas[sku]||0)+q;});
  if(bad.length&&!ord.length){toast('No se importó nada: '+bad.slice(0,2).join('; ')+'.');return;}
  var n=pedNext(),jobs=[];ord.forEach(function(k){var o=g[k],ci=pedClienteInfo(o.cliente);jobs.push({id:pedCod(n++),cliente:o.cliente,clienteId:ci.id||'',direccion:o.direccion||ci.dir||'',lat:ci.lat==null?null:ci.lat,lng:ci.lng==null?null:ci.lng,entrega:/^\d{4}-\d{2}-\d{2}$/.test(o.entrega)?o.entrega:addDays(1),desde:o.desde,hasta:o.hasta,ref:o.ref,lineas:Object.keys(o.lineas).map(function(s){return {sku:s,qty:o.lineas[s]};}),estado:'borrador',creado:isoNow(),por:actor()});});
  for(var i=0;i<jobs.length;i+=20)await Promise.all(jobs.slice(i,i+20).map(function(p){return pedGuardar(p);}));
  toast(jobs.length+' pedidos importados'+(bad.length?'; '+bad.length+' filas con problemas ('+bad.slice(0,2).join(', ')+')':'')+'.');}

/* reserva FEFO */
function pedCandidatos(){var st=wStock(),c=x8comp(),by={},ls={};
  wLotes().forEach(function(l){if(l.q<=0)return;ls[l.ubi+'|'+l.sku]=(ls[l.ubi+'|'+l.sku]||0)+l.q;var q=l.q-(c.cl[l.ubi+'|'+l.sku+'|'+l.lote]||0);if(q>0)(by[l.sku]=by[l.sku]||[]).push({ubi:l.ubi,lote:l.lote,vence:l.vence||'',q:q});});
  Object.keys(st.m).forEach(function(k){var q=st.m[k];if(q<=0)return;var pp=k.split('|'),rest=q-(ls[k]||0)-(c.cl[pp[0]+'|'+pp[1]+'|']||0);if(rest>0)(by[pp[1]]=by[pp[1]]||[]).push({ubi:pp[0],lote:'',vence:'',q:rest});});
  Object.keys(by).forEach(function(s){by[s].sort(function(a,b){var va=a.vence||'9999',vb=b.vence||'9999';if(va!==vb)return va<vb?-1:1;var pa=locParse(a.ubi),pb=locParse(b.ubi),aa=pa?pa.a:9,ab=pb?pb.a:9;if(aa!==ab)return aa-ab;return a.ubi<b.ubi?-1:1;});});
  return by;}
async function pedReservar(id,parcial){var p=pedGet(id);if(!p||p.estado!=='borrador')return;p=clean(p);
  var mal=(p.lineas||[]).filter(function(l){return !skuBy(l.sku);});if(mal.length){toast('El SKU '+mal[0].sku+' no existe. Corregí el pedido.');return;}
  var by=pedCandidatos(),res=[],fal=[];
  p.lineas.forEach(function(l){var need=l.qty,cs=by[l.sku]||[];for(var i=0;i<cs.length&&need>0;i++){var t=Math.min(need,cs[i].q);if(t<=0)continue;res.push({sku:l.sku,ubi:cs[i].ubi,lote:cs[i].lote,vence:cs[i].vence,qty:t});cs[i].q-=t;need-=t;}if(need>0)fal.push({sku:l.sku,qty:need});});
  if(fal.length&&!parcial){toast('No alcanza el stock: '+fal.map(function(x){return 'faltan '+nf(x.qty)+' de '+x.sku;}).join(', ')+'. Podés reservar lo disponible.');X8.ui.pedFalta=id;render();return;}
  if(!res.length){toast('No hay nada disponible para reservar.');return;}
  p.reserva=res;p.faltante=fal;p.parcial=fal.length>0;p.estado='reservado';p.reservado=isoNow();X8.ui.pedFalta=null;await pedGuardar(p);toast(fal.length?'Reserva parcial hecha.':'Stock reservado (primero lo que vence antes).');}
async function pedCancelar(id){var p=pedGet(id);if(!p)return;var f=pedFase(p);if(f!=='borrador'&&f!=='reservado'&&f!=='preparacion'){toast('Un pedido '+(PED_FASES[f]||f).toLowerCase()+' no se puede cancelar desde acá.');return;}
  if(f==='preparacion'){var pk=WC('picks').find(function(x){return x.id===p.pickId;});if(pk&&pk.estado==='en_ola'){toast('El picking está dentro de una ola. Sacalo de la ola primero.');return;}if(pk&&pk.estado==='completado'){toast('El picking ya se confirmó.');return;}if(pk)await wDel('picks',pk.id);}
  p=clean(p);p.estado='cancelado';p.cancelado=isoNow();p.canceladoPor=actor();await pedGuardar(p);X8.ui.pedCan=null;toast('Pedido cancelado; la reserva quedó libre.');}
async function pedGenPick(id){var p=pedGet(id);if(!p||p.estado!=='reservado')return;p=clean(p);
  var ls=(p.reserva||[]).map(function(r){return {sku:r.sku,qty:r.qty,ubi:r.ubi,lote:r.lote||'',vence:r.vence||''};}).sort(pickCmp),pid=nextPk();
  await wPut('picks',{id:pid,ref:p.id+' · '+p.cliente,pedidoId:p.id,fecha:HOY,estado:'pendiente',lineas:ls,faltan:p.faltante||[],por:actor()});
  p.pickId=pid;p.estado='preparacion';await pedGuardar(p);toast('Picking generado. Aparece en Depósito › Picking.');}
async function pedSync(){var ps=WC('pedidos').filter(function(p){return p.estado==='preparacion';}),pks=WC('picks');
  for(var i=0;i<ps.length;i++){var p=ps[i],pk=pks.find(function(x){return x.id===p.pickId;});
    if(!pk){var q=clean(p);q.estado='reservado';delete q.pickId;await pedGuardar(q);continue;}
    if(pk.estado==='completado'){var q2=clean(p);q2.estado='preparado';q2.pallets=pk.pallets||1;if(pk.stgPosL&&pk.stgPosL.length){q2.stgPosL=pk.stgPosL;q2.stgPos=pk.stgPos;q2.stgTs=isoNow();q2.stgPor=actor();q2.stgLog=[{ts:isoNow(),por:actor(),ev:'ubicar',de:'',a:pk.stgPos}];}q2.faltaPick=pk.faltan||[];q2.preparado=isoNow();await pedGuardar(q2);}}}
var x8pc1=pickConfirmar;
pickConfirmar=async function(id,ov){await x8pc1(id,ov);try{X8.rc++;await pedSync();}catch(e){if(window.console)console.error(e);}};
async function pedBultosGen(id){var p=pedGet(id);if(!p||p.estado!=='preparado')return;var n=parseInt(gv('pb-'+id),10);if(!(n>=1&&n<=500)){toast('Indicá cuántos bultos (1 a 500).');return;}
  p=clean(p);p.nb=n;p.bultos=[];for(var i=1;i<=n;i++)p.bultos.push({n:i,codigo:pedBultoCod(p,i),esc:null});await pedGuardar(p);toast(n+' etiquetas de bulto generadas.');}
function pedEtiquetas(id){var p=pedGet(id);if(!p||!p.bultos)return;var w=window.open('','_blank');if(!w){toast('El navegador bloqueó la ventana. Permití ventanas emergentes.');return;}
  w.document.write('<html><head><title>Etiquetas '+esc(p.id)+'</title><style>body{font-family:sans-serif;margin:0}.e{width:10cm;height:6cm;border:1px dashed #999;padding:8px;box-sizing:border-box;page-break-inside:avoid;display:inline-block;vertical-align:top}.e svg{width:100%;height:60px}b{font-size:16px}</style></head><body>'+p.bultos.map(function(b){return '<div class="e"><b>'+esc(p.cliente)+'</b><div>'+esc(p.direccion||'')+'</div><div>Entrega: '+esc(p.entrega||'')+' · Bulto '+b.n+' de '+p.nb+'</div>'+bcSvg(b.codigo)+'<div style="text-align:center;font-family:monospace">'+esc(b.codigo)+'</div></div>';}).join('')+'<script>window.print()<\/script></body></html>');w.document.close();}

/* expedición por escaneo */
function expEscanear(raw){var v=bcTxt(raw).trim().toUpperCase();if(!v)return;
  var m=/^(PED-\d{6})-(\d{1,3})$/.exec(v);if(!m){toast('"'+v+'" no es una etiqueta de bulto (formato PED-000123-1).');return;}
  var p=pedGet(m[1]);if(!p){toast('No existe el pedido '+m[1]+'.');return;}
  var sel=X8.ui.expSel;
  if(sel&&sel!==p.id){toast('Ese bulto es del pedido '+p.id+' ('+p.cliente+'), no del '+sel+'. No lo cargues en este camión.');return;}
  var f=pedFase(p);if(f==='despachado'||f==='entregado'){toast('El pedido '+p.id+' ya fue despachado.');return;}if(f==='cancelado'){toast('El pedido '+p.id+' está cancelado.');return;}if(f!=='preparado'||!p.bultos){toast('El pedido '+p.id+' todavía no está preparado con etiquetas.');return;}
  var b=p.bultos.find(function(x){return x.n===parseInt(m[2],10);});if(!b){toast('El pedido '+p.id+' tiene '+p.nb+' bultos; el '+m[2]+' no existe.');return;}
  if(b.esc){toast('Ese bulto ya estaba escaneado ('+b.esc.por+').');return;}
  X8.ui.expSel=p.id;var q=clean(p);q.bultos.find(function(x){return x.n===b.n;}).esc={ts:isoNow(),por:actor()};pedGuardar(q);}
async function expDespachar(id){var p=pedGet(id);if(!p||p.estado!=='preparado'||!p.bultos)return;
  var falta=p.bultos.filter(function(b){return !b.esc;});if(falta.length){toast('Faltan escanear '+falta.length+' bultos.');return;}
  var ch=gv('ex-chofer'),fe=gv('ex-fecha')||HOY,perf=(D().perfiles||[]).find(function(x){return x.id===ch;});if(!perf){toast('Elegí el chofer.');return;}if(!x10CapOk(p))return;
  var nums=(D().entregas||[]).map(function(e){return parseInt(String(e.guia||'').replace(/\D/g,''),10)||0;}),n=Math.max.apply(null,nums.concat([4800]))+1;
  var ord=(D().entregas||[]).filter(function(e){return e.choferId===ch&&e.fecha===fe;}).length+1;
  var e={id:'d-p'+Date.now().toString(36),guia:'G-'+n,clienteId:p.clienteId||'',cliente:p.cliente,direccion:p.direccion||'',lat:p.lat==null?null:p.lat,lng:p.lng==null?null:p.lng,fecha:fe,desde:p.desde||'09:00',hasta:p.hasta||'18:00',choferId:ch,chofer:perf.nombre,orden:ord,estado:'programada',bultos:p.nb,items:(p.lineas||[]).slice(0,60).map(function(l){var k=(W().skus||[]).find(function(x){return x.codigo===l.sku;});return {sku:l.sku,producto:k?k.producto:'',qty:l.qty};}),remito:null,factura:null,pedidoId:p.id,observaciones:[],historial:[{estado:'programada',ts:isoNow(),por:actor()}]};
  Object.assign(e,x10Extra(p));await persist(e);var q=clean(p);q.estado='despachado';q.entregaId=e.id;q.despachado=isoNow();q.despachadoPor=actor();await pedGuardar(q);X8.ui.expSel=null;toast('Despachado: guía '+e.guia+' asignada a '+perf.nombre+'.');}

/* vistas */
function xPed(){
  var ps=WC('pedidos'),f=X8.ui.pf||'activos',cnt={},blq=0;
  ps.forEach(function(p){var fa=pedFase(p);cnt[fa]=(cnt[fa]||0)+1;if(pedBloqueos(p).length)blq++;});
  var act=ps.filter(function(p){var fa=pedFase(p);return fa!=='entregado'&&fa!=='cancelado';});
  var lst=(f==='activos'?act:f==='bloqueados'?ps.filter(function(p){return pedBloqueos(p).length;}):f==='todos'?ps:ps.filter(function(p){return pedFase(p)===f;})).slice().sort(function(a,b){return String(a.entrega||'').localeCompare(String(b.entrega||''))||String(b.id).localeCompare(String(a.id));});
  var d=pedDraft(),cl=(D().perfiles||[]).filter(function(x){return x.rol==='cliente';});
  var h='<div class="kpis">'+KPI(nf(act.length),'Pedidos activos','sin entregar ni cancelar')+KPI(nf(cnt.borrador||0),'Sin reservar','esperando stock o datos')+KPI(nf((cnt.reservado||0)+(cnt.preparacion||0)+(cnt.preparado||0)),'En el depósito','reservados, en picking o listos')+KPI(nf(blq),'Con bloqueos','requieren acción',blq?'bad':'')+'</div>';
  h+='<div class="panel"><div class="row sp"><h3>Pedidos</h3><div class="row"><button class="btn pri" data-act="x8-pednew">'+(X8.ui.pedNew?'Cerrar formulario':'Nuevo pedido')+'</button><button class="btn" data-act="x8-pedimp">Importar pedidos (CSV/Excel)</button><input id="x8-pedfile" type="file" accept=".csv,.xlsx,.xls" hidden></div></div>'+
   '<div class="small muted">Ciclo: pedido → reserva de stock (primero lo que vence antes) → picking → bultos con etiqueta → escaneo en expedición → despacho (se crea la guía) → entrega. Archivo para importar: columnas pedido, cliente, direccion, fecha, desde, hasta, sku, cantidad (una fila por línea).</div>';
  if(X8.ui.pedNew){h+='<div class="panel" style="margin-top:10px"><h3>Nuevo pedido</h3><div class="grid2"><label>Cliente<input id="pd-cliente" list="dl-pdcli" value="'+esc(d.cliente)+'" autocomplete="off"><datalist id="dl-pdcli">'+cl.map(function(c){return '<option value="'+esc(c.nombre)+'">';}).join('')+'</datalist></label><label>Referencia del cliente (opcional)<input id="pd-ref" value="'+esc(d.ref)+'" maxlength="40"></label>'+
    '<label>Dirección de entrega (si el cliente es nuevo)<input id="pd-direccion" value="'+esc(d.direccion)+'" maxlength="140"></label><label>Fecha de entrega<input id="pd-entrega" type="date" value="'+esc(d.entrega)+'"></label><label>Ventana desde<input id="pd-desde" type="time" value="'+esc(d.desde)+'"></label><label>Ventana hasta<input id="pd-hasta" type="time" value="'+esc(d.hasta)+'"></label></div>'+
    '<div class="row"><label>SKU<input id="pd-sku" list="dl-pdsku" autocomplete="off" placeholder="Escribí código o nombre" style="min-width:220px"></label><datalist id="dl-pdsku">'+(W().skus||[]).slice(0,3000).map(function(s){return '<option value="'+esc(s.codigo)+'" label="'+esc(s.producto||'')+'">';}).join('')+'</datalist><label>Cantidad<input id="pd-qty" type="number" min="1" style="width:100px"></label><button class="btn" data-act="x8-pdadd">Agregar línea</button></div>'+
    (d.lineas.length?tbl(['SKU','Producto','Cantidad','Disponible',''],d.lineas.map(function(l,i){var dd=x8disp(l.sku),s=skuBy(l.sku);return ['<span class="guia">'+esc(l.sku)+'</span>',esc(s?s.producto||'':''),nf(l.qty),dd.disp<l.qty?'<span class="chip warn">'+nf(dd.disp)+' (no alcanza)</span>':nf(dd.disp),'<button class="btn sm" data-act="x8-pddel" data-id="'+i+'">Quitar</button>'];}),520)+'<div class="row" style="margin-top:8px"><button class="btn ok" data-act="x8-pdsave">Crear pedido</button></div>':'')+'</div>';}
  h+=X8.ui.res?xResPanel(X8.ui.res):'';
  h+='<div class="chips" style="margin:10px 0">'+[['activos','Activos ('+act.length+')'],['bloqueados','Bloqueados ('+blq+')'],['borrador','Borrador ('+(cnt.borrador||0)+')'],['reservado','Reservados ('+(cnt.reservado||0)+')'],['preparacion','En preparación ('+(cnt.preparacion||0)+')'],['preparado','Preparados ('+(cnt.preparado||0)+')'],['despachado','Despachados ('+(cnt.despachado||0)+')'],['entregado','Entregados ('+(cnt.entregado||0)+')'],['cancelado','Cancelados ('+(cnt.cancelado||0)+')'],['todos','Todos ('+ps.length+')']].map(function(k){return '<button class="chip'+(f===k[0]?' ok':'')+'" data-act="x8-pf" data-v="'+k[0]+'">'+k[1]+'</button>';}).join('')+'</div>';
  h+=lst.length?tbl(['Pedido','Cliente','Entrega','Líneas','Fase','Bloqueos / acción'],lst.map(function(p){var fa=pedFase(p),bl=pedBloqueos(p),acc='';
    if(fa==='borrador')acc='<button class="btn sm pri" data-act="x8-pres" data-id="'+esc(p.id)+'">Reservar stock</button>'+(X8.ui.pedFalta===p.id?' <button class="btn sm" data-act="x8-pres-parc" data-id="'+esc(p.id)+'">Reservar lo disponible</button>':'');
    else if(fa==='reservado')acc='<button class="btn sm pri" data-act="x8-pgen" data-id="'+esc(p.id)+'">Generar picking</button>'+(p.parcial?' <button class="btn sm" data-act="x10-comp" data-id="'+esc(p.id)+'">Completar reserva</button>':'');
    else if(fa==='preparacion')acc='<span class="small muted">Esperando que el depósito confirme el picking.</span>';
    else if(fa==='preparado'&&!p.bultos)acc='<input id="pb-'+esc(p.id)+'" type="number" min="1" max="500" placeholder="Bultos" style="width:80px"> <button class="btn sm pri" data-act="x8-pbul" data-id="'+esc(p.id)+'">Generar etiquetas</button>';
    else if(fa==='preparado')acc='<button class="btn sm" data-act="x8-petq" data-id="'+esc(p.id)+'">Imprimir etiquetas</button> <span class="small muted">Siguiente: Expedición.</span>';
    else if(fa==='despachado'||fa==='entregado'){var e=x8ent()[p.entregaId];acc='<span class="small muted">Guía '+esc(e?e.guia:'—')+(e?' · '+esc(e.estado):'')+'</span>'+(e&&(e.estado==='entregada'||e.estado==='no_entregada')&&!p.entregado?' <button class="btn sm pri" data-act="x10-res" data-id="'+esc(p.id)+'">Registrar resultado</button>':'')+' '+otifChip(p);}
    if(fa==='borrador'||fa==='reservado'||fa==='preparacion')acc+=(X8.ui.pedCan===p.id?' <button class="btn sm bad" data-act="x8-pcan2" data-id="'+esc(p.id)+'">Confirmar cancelación</button> <button class="btn sm" data-act="x8-pcan0">No</button>':' <button class="btn sm" data-act="x8-pcan" data-id="'+esc(p.id)+'">Cancelar</button>');
    return ['<span class="guia">'+esc(p.id)+'</span>'+(p.ref?'<div class="small muted">'+esc(p.ref)+'</div>':''),esc(p.cliente)+'<div class="small muted">'+esc(p.direccion||'sin dirección')+'</div>',esc(fmtFecha(p.entrega||''))+'<div class="small muted">'+esc((p.desde||'')+'–'+(p.hasta||''))+'</div>',nf((p.lineas||[]).length)+' · '+nf(x8sum(p.lineas||[],function(l){return l.qty;}))+' u','<span class="chip '+(PED_CLS[fa]||'')+'">'+PED_FASES[fa]+'</span>',(bl.length?'<div class="small" style="color:var(--bad)">'+bl.map(esc).join('<br>')+'</div>':'')+acc];}),900):'<div class="empty">No hay pedidos en esta vista.</div>';
  return h+'</div>';}
function xExp(){
  var prep=WC('pedidos').filter(function(p){return p.estado==='preparado';}),sel=X8.ui.expSel?pedGet(X8.ui.expSel):null;if(sel&&sel.estado!=='preparado'){sel=null;X8.ui.expSel=null;}
  var h='<div class="panel"><h3>Expedición por escaneo</h3><div class="small muted">Escaneá cada bulto antes de cargarlo. Si el bulto es de otro pedido, el sistema avisa. Cuando están todos, se despacha y se crea la guía de entrega.</div>'+
   '<div class="row" style="margin-top:10px"><label>Escaneá o escribí la etiqueta del bulto<input id="ex-scan" autocomplete="off" placeholder="PED-000123-1" style="min-width:230px"></label>'+(sel?'<button class="btn" data-act="x8-expsel" data-id="">Cambiar de pedido</button>':'')+'</div></div>';
  if(!prep.length)return h+'<div class="empty">No hay pedidos preparados para despachar. Un pedido aparece acá cuando el picking está confirmado y tiene etiquetas de bulto.</div>';
  var show=sel?[sel]:prep.filter(function(p){return p.bultos;});
  if(!show.length)return h+'<div class="empty">Hay pedidos preparados pero sin etiquetas. Generá los bultos en Pedidos.</div>';
  h+=show.map(function(p){var tot=p.bultos.length,ok=p.bultos.filter(function(b){return b.esc;}).length,fin=ok===tot,chof=(D().perfiles||[]).filter(function(x){return x.rol==='chofer';});
    return '<div class="panel"><div class="row sp"><h3>'+esc(p.id)+' · '+esc(p.cliente)+'</h3><span class="chip '+(fin?'ok':'warn')+'">'+ok+' de '+tot+' bultos</span></div><div class="small muted">'+esc(p.direccion||'sin dirección')+' · entrega '+esc(fmtFecha(p.entrega||''))+'</div>'+
     '<div class="row" style="flex-wrap:wrap;margin:8px 0">'+p.bultos.map(function(b){return '<span class="chip '+(b.esc?'ok':'')+'">'+b.n+(b.esc?' ✓':'')+'</span>';}).join('')+'</div>'+
     (fin&&rolActual()!=='admin'?'<div class="banner ok" role="status"><div><strong>Todo escaneado</strong>Administración crea la guía y asigna el chofer.</div></div>':fin?'<div class="row"><label>Chofer<select id="ex-chofer"><option value="">Elegí…</option>'+chof.map(function(c){return '<option value="'+esc(c.id)+'">'+esc(c.nombre)+'</option>';}).join('')+'</select></label><label>Fecha de salida<input id="ex-fecha" type="date" value="'+esc(p.entrega&&p.entrega>=HOY?p.entrega:HOY)+'"></label>'+x10Desp(p)+'<button class="btn ok" data-act="x8-despachar" data-id="'+esc(p.id)+'">Despachar y crear guía</button></div>':'<div class="small muted">Faltan: '+p.bultos.filter(function(b){return !b.esc;}).map(function(b){return b.n;}).join(', ')+'</div>')+'</div>';}).join('');
  return h;}
document.addEventListener('keydown',function(ev){if(ev.key==='Enter'&&ev.target&&ev.target.id==='ex-scan'){ev.preventDefault();var v=ev.target.value;ev.target.value='';expEscanear(v);}});
document.addEventListener('change',async function(ev){if(ev.target.id==='x8-pedfile'&&ev.target.files[0]){try{await pedImport(ev.target.files[0]);}catch(e){toast('No se pudo leer el archivo.');}ev.target.value='';}});
/* ===== EXT8c end ===== */
/* ===== EXT8d: centro de control, fletes, economía, productividad, escenarios ===== */
function x8hash(s){var h=0;for(var i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))|0;return Math.abs(h).toString(36);}
var SEV_O={alta:0,media:1,baja:2};
function alertasX(){return x8c('alr',function(){
  var out=[],tm={};WC('alertas').forEach(function(t){tm[t.id]=t;});var cap={};
  function add(key,sev,tipo,txt,sub,group){var id=key.replace(/[^A-Za-z0-9_-]/g,'_').slice(0,100),t=tm[id];
    if(t&&t.estado==='resuelta'&&t.ts&&(Date.now()-new Date(t.ts))<864e5)return;if(t&&t.estado==='ignorada'&&t.hasta&&t.hasta>HOY)return;
    if(group){cap[group]=cap[group]||{n:0,extra:0};if(cap[group].n>=25){cap[group].extra++;return;}cap[group].n++;}
    out.push({id:id,sev:sev,tipo:tipo,txt:txt,sub:sub,t:t});}
  if(modOn('abs')){abastRows().filter(function(r){return r.est==='Quiebre'&&r.d>0;}).sort(function(a,b){return b.d-a.d;}).forEach(function(r){add('q-'+r.s.codigo,'alta','Stock','Sin stock disponible: '+r.s.codigo+' · '+(r.s.producto||'')+' (se vende '+nf(r.d,1)+' por día)','abs','q');});
    abastRows().filter(function(r){return r.est==='Reponer';}).sort(function(a,b){return b.d-a.d;}).forEach(function(r){add('r-'+r.s.codigo,'media','Stock','Hay que reponer '+r.s.codigo+' · '+(r.s.producto||'')+': disponible '+nf(r.disp)+', sugerido pedir '+nf(r.sug),'abs','r');});}
  if(modOn('ped'))WC('pedidos').forEach(function(p){var f=pedFase(p);if(f==='entregado'||f==='cancelado')return;var bl=pedBloqueos(p);bl.forEach(function(b){var atr=/^Atrasado/.test(b);add('pb-'+p.id+'-'+x8hash(b),atr?'alta':'media','Pedido',p.id+' · '+p.cliente+': '+b,'ped');});});
  if(modOn('rep'))WC('repos').forEach(function(r){if(r.estado==='pendiente'&&r.creada&&Date.now()-new Date(r.creada)>864e5)add('rp-'+r.id,'media','Reposición','Reposición pendiente hace más de un día: '+r.sku+' de '+r.desde+' a '+r.hacia,'rep');});
  var l30=addDays(30),l7=addDays(7);wLotes().filter(function(l){return l.q>0&&l.vence&&l.vence<=l30;}).sort(function(a,b){return a.vence<b.vence?-1:1;}).forEach(function(l){var v=l.vence<HOY;add('v-'+l.sku+'-'+l.ubi+'-'+l.lote,l.vence<=l7?'alta':'media','Vencimiento',(v?'VENCIDO ':'Vence '+fmtFecha(l.vence)+': ')+l.sku+' lote '+l.lote+' en '+l.ubi+' ('+nf(l.q)+' u)','lotes','v');});
  var ah=new Date(),hh=pad(ah.getHours())+':'+pad(ah.getMinutes());
  (D().entregas||[]).forEach(function(e){if(e.fecha!==HOY)return;if(e.estado==='no_entregada')add('en-'+e.id,'alta','Entrega','Entrega no concretada: '+e.guia+' · '+e.cliente,'');else if((e.estado==='programada')&&e.hasta&&e.hasta<hh)add('es-'+e.id,'alta','Entrega','Sin salir y vencida la ventana: '+e.guia+' · '+e.cliente+' (hasta '+e.hasta+')','');else if(e.estado==='en_camino'&&e.hasta&&e.hasta<hh)add('ec-'+e.id,'media','Entrega','En camino y fuera de ventana: '+e.guia+' · '+e.cliente+' (hasta '+e.hasta+')','');});
  if(modOn('fle'))fleAudit().forEach(function(f){if(f.est==='Cobro de más'||f.est==='Duplicado'||f.est==='Guía inexistente')add('fl-'+f.f.id+'-'+x8hash(f.est),'media','Flete',(f.f.transportista||'')+' '+fmtFecha(f.f.fecha)+': '+f.est+(f.est==='Cobro de más'?' (+$'+nf(f.dif)+')':''),'fle','f');});
  (W().ocs||[]).forEach(function(o){if((o.estado==='abierta'||o.estado==='parcial')&&o.fecha&&o.fecha<addDays(-((cfgx().leadDef||7)+3)))add('oc-'+o.id,'media','Compras','Orden de compra '+(o.ref||o.id)+' ('+(o.proveedor||'')+') sigue pendiente desde el '+fmtFecha(o.fecha),'recep','oc');});
  if(modOn('ped'))WC('incidencias').forEach(function(i){if(i.estado==='cerrada')return;var dd=(Date.now()-new Date(i.creada))/864e5;if(dd>1)add('inc-'+i.id,dd>3?'alta':'media','Incidencia',(i.pedidoId||'Sin pedido')+' · '+(i.cliente||'')+': '+i.tipo+' abierta hace '+Math.floor(dd)+' días','inc');});
  Object.keys(cap).forEach(function(g){if(cap[g].extra>0)out.push({id:'agg-'+g,sev:'baja',tipo:'Resumen',txt:'Y '+cap[g].extra+' alertas más de este tipo (se muestran las 25 más importantes).',t:null,agg:true});});
  out.sort(function(a,b){return (SEV_O[a.sev]-SEV_O[b.sev])||(a.agg?1:0)-(b.agg?1:0);});return out;});}
async function alSet(id,patch){var t=WC('alertas').find(function(x){return x.id===id;})||{id:id};t=clean(t);Object.keys(patch).forEach(function(k){t[k]=patch[k];});t.ts=isoNow();t.por=actor();await wPut('alertas',t);}
function xCtl(){
  var al=alertasX().filter(function(a){return !a.agg;}),alta=al.filter(function(a){return a.sev==='alta';}).length,es=(D().entregas||[]).filter(function(e){return e.fecha===HOY;}),
   ps=WC('pedidos'),act=ps.filter(function(p){var f=pedFase(p);return f!=='entregado'&&f!=='cancelado';}),atr=act.filter(function(p){return p.entrega&&p.entrega<HOY;}).length,
   ab=modOn('abs')?abastRows():[],qb=ab.filter(function(r){return r.est==='Quiebre'&&r.d>0;}).length;
  var h='<div class="kpis">'+KPI(nf(alta),'Alertas urgentes',nf(al.length)+' en total',alta?'bad':'ok')+KPI(nf(es.filter(function(e){return e.estado==='entregada';}).length)+' / '+nf(es.length),'Entregas de hoy','hechas / programadas')+KPI(nf(act.length),'Pedidos activos',atr?atr+' atrasados':'ninguno atrasado',atr?'bad':'')+(modOn('abs')?KPI(nf(qb),'SKUs en quiebre','con demanda y sin stock disponible',qb?'bad':'ok'):'')+'</div>';
  var mias=al.filter(function(a){return a.t&&a.t.asignado===actor();}).length;
  h+='<div class="panel"><div class="row sp"><h3>Alertas</h3><span class="small muted">'+(mias?mias+' asignadas a vos. ':'')+'Tomá una alerta para que el resto sepa que alguien la atiende. Si resolvés una y el problema sigue, vuelve a aparecer a las 24 horas.</span></div>';
  h+=al.length?tbl(['Urgencia','Tipo','Qué pasa','Responsable','Acción'],alertasX().map(function(a){if(a.agg)return ['<span class="chip">Resumen</span>','','<span class="small muted">'+esc(a.txt)+'</span>','',''];
    var t=a.t,pers=(D().perfiles||[]).filter(function(p){return p.rol==='deposito'||p.rol==='admin';});
    return ['<span class="chip '+(a.sev==='alta'?'bad':a.sev==='media'?'warn':'')+'">'+a.sev+'</span>',esc(a.tipo),esc(a.txt)+(t&&t.nota?'<div class="small muted">Nota: '+esc(t.nota)+'</div>':''),t&&t.asignado?'<strong>'+esc(t.asignado)+'</strong>':'<span class="muted">Sin asignar</span>',
     '<div class="row">'+(!t||t.asignado!==actor()?'<button class="btn sm pri" data-act="x8-atom" data-id="'+esc(a.id)+'">Tomar</button>':'')+'<input id="al-n-'+esc(a.id)+'" placeholder="Nota" style="width:120px"><button class="btn sm ok" data-act="x8-ares" data-id="'+esc(a.id)+'">Resolver</button><button class="btn sm" data-act="x8-aign" data-id="'+esc(a.id)+'">Ignorar 7 días</button>'+(a.sub?'<button class="btn sm" data-act="x8-ago" data-id="'+esc(a.sub)+'">Ver</button>':'')+'</div>'];}),900):'<div class="empty">No hay alertas. Todo en orden.</div>';
  h+='</div>';
  var ent=es.slice().sort(function(a,b){return String(a.desde).localeCompare(String(b.desde));});
  h+='<div class="panel"><h3>Entregas de hoy</h3>'+(ent.length?tbl(['Guía','Cliente','Chofer','Ventana','Estado'],ent.map(function(e){return [esc(e.guia),esc(e.cliente),esc(e.chofer||''),esc((e.desde||'')+'–'+(e.hasta||'')),'<span class="chip '+(e.estado==='entregada'?'ok':e.estado==='no_entregada'?'bad':'signal')+'">'+esc(e.estado)+'</span>'];}),600):'<div class="empty">No hay entregas programadas para hoy.</div>')+'</div>';
  return h;}

/* ----- transportistas, fletes y auditoría ----- */
function trList(){return WC('transportistas');}
function trEsp(tr,f){return (tr?(+tr.fija||0)+(+f.km||0)*(+tr.km||0)+(+f.bultos||0)*(+tr.bulto||0):0);}
function fleAudit(){return x8c('fleA',function(){var tol=(cfgx().tolFlete!=null?cfgx().tolFlete:5)/100,trm={},seen={},en=x8ent();trList().forEach(function(t){trm[t.id]=t;});
  var gs={};Object.keys(en).forEach(function(k){gs[String(en[k].guia).toUpperCase()]=en[k];});
  return WC('fletes').slice().sort(function(a,b){return String(a.fecha).localeCompare(String(b.fecha))||String(a.id).localeCompare(String(b.id));}).map(function(f){
    var tr=trm[f.trId]||trList().find(function(t){return t.nombre===f.transportista;}),esp=trEsp(tr,f),dif=(+f.cobrado||0)-esp,est='OK';
    var k=(f.trId||f.transportista)+'|'+String(f.ref||'').toUpperCase()+'|'+f.fecha,dup=f.ref&&seen[k];seen[k]=true;
    if(dup)est='Duplicado';else if(f.ref&&!gs[String(f.ref).toUpperCase()]&&!WC('pedidos').some(function(p){return p.id===f.ref;}))est='Guía inexistente';
    else if(!tr)est='Sin tarifa';else if(esp>0&&dif>esp*tol)est='Cobro de más';else if(esp>0&&dif<-esp*tol)est='Cobro de menos';
    return {f:f,tr:tr,esp:esp,dif:dif,est:est,ent:gs[String(f.ref||'').toUpperCase()]};});});}
var FL_C={'OK':'ok','Cobro de más':'bad','Cobro de menos':'warn','Duplicado':'bad','Guía inexistente':'warn','Sin tarifa':'warn'};
async function trGuardar(){var n=gv('tr-nom').trim();if(!n){toast('Poné el nombre del transportista.');return;}var num=function(i){var v=parseFloat(gv(i));return isNaN(v)||v<0?0:v;};
  await wPut('transportistas',{id:uid('TR'),nombre:n,tipo:gv('tr-tipo')||'tercero',fija:num('tr-fija'),km:num('tr-km'),bulto:num('tr-bulto')});toast('Transportista guardado.');}
async function fleGuardar(){var tr=trList().find(function(t){return t.id===gv('fl-tr');});if(!tr){toast('Elegí el transportista.');return;}var num=function(i){var v=parseFloat(gv(i));return isNaN(v)||v<0?0:v;},cob=num('fl-cob');if(!(cob>0)){toast('Indicá el importe cobrado.');return;}
  await wPut('fletes',{id:uid('FL'),trId:tr.id,transportista:tr.nombre,fecha:gv('fl-fecha')||HOY,ref:gv('fl-ref').trim(),km:num('fl-km'),bultos:num('fl-bul'),cobrado:cob,estado:'pendiente',por:actor()});toast('Flete cargado.');}
async function fleImport(file){var rows=await leerArchivoFilas(file);if(!rows||rows.length<2){toast('El archivo está vacío.');return;}var H=obHead(rows),jobs=[],bad=[];
  H.rows.forEach(function(r,i){var tn=H.col(r,['transportista','proveedor']),cob=parseFloat(String(H.col(r,['cobrado','importe','total'])).replace(',','.'));if(!tn&&!(cob>0))return;var tr=trList().find(function(t){return t.nombre.toLowerCase()===tn.toLowerCase();});if(!tr){bad.push('fila '+(i+2)+': transportista "'+tn+'" no cargado');return;}if(!(cob>0)){bad.push('fila '+(i+2)+': falta el importe');return;}
    var fe=H.col(r,['fecha']);jobs.push({id:uid('FL'),trId:tr.id,transportista:tr.nombre,fecha:/^\d{4}-\d{2}-\d{2}$/.test(fe)?fe:HOY,ref:H.col(r,['guia','ref','referencia']),km:parseFloat(H.col(r,['km']))||0,bultos:parseFloat(H.col(r,['bultos']))||0,cobrado:cob,estado:'pendiente',por:actor()});});
  for(var i=0;i<jobs.length;i+=20)await Promise.all(jobs.slice(i,i+20).map(function(f){return wPut('fletes',f);}));toast(jobs.length+' fletes importados'+(bad.length?'; '+bad.length+' con problemas ('+bad.slice(0,2).join(', ')+')':'')+'.');}
function xFle(){
  var au=fleAudit(),trs=trList(),per=X8.ui.fper||'30',desde=addDays(-parseInt(per,10)),vis=au.filter(function(a){return a.f.fecha>=desde;}).slice().reverse();
  var tot=x8sum(vis,function(a){return +a.f.cobrado||0;}),esp=x8sum(vis,function(a){return a.esp;}),de=x8sum(vis.filter(function(a){return a.est==='Cobro de más';}),function(a){return a.dif;}),dup=x8sum(vis.filter(function(a){return a.est==='Duplicado';}),function(a){return +a.f.cobrado||0;});
  var h='<div class="kpis">'+KPI('$'+nf(tot),'Cobrado por transportistas','últimos '+per+' días')+KPI('$'+nf(esp),'Esperado según tarifas','calculado con las tarifas cargadas')+KPI('$'+nf(de+dup),'Posible ahorro','cobros de más y duplicados',(de+dup)>0?'warn':'ok')+KPI(nf(vis.filter(function(a){return a.est!=='OK'&&a.est!=='Cobro de menos';}).length),'Fletes para revisar','de '+vis.length)+'</div>';
  h+='<div class="panel"><div class="row sp"><h3>Transportistas y tarifas</h3></div>'+(trs.length?tbl(['Nombre','Tipo','Fijo por viaje','$ por km','$ por bulto',''],trs.map(function(t){return [esc(t.nombre),esc(t.tipo),'$'+nf(t.fija),'$'+nf(t.km),'$'+nf(t.bulto),'<button class="btn sm" data-act="x8-trdel" data-id="'+esc(t.id)+'">Quitar</button>'];}),520):'<div class="small muted">Cargá al menos un transportista con su tarifa para poder auditar.</div>')+
   '<div class="row" style="margin-top:8px"><label>Nombre<input id="tr-nom" maxlength="60"></label><label>Tipo<select id="tr-tipo"><option value="tercero">Tercero</option><option value="propio">Flota propia</option></select></label><label>Fijo por viaje ($)<input id="tr-fija" type="number" min="0" style="width:110px"></label><label>$ por km<input id="tr-km" type="number" min="0" step="any" style="width:90px"></label><label>$ por bulto<input id="tr-bulto" type="number" min="0" step="any" style="width:90px"></label><button class="btn" data-act="x8-trsave">Agregar</button></div></div>';
  h+='<div class="panel"><div class="row sp"><h3>Facturas de fletes</h3><div class="row"><label>Período<select id="fl-per">'+[['7','7 días'],['30','30 días'],['90','90 días'],['365','Un año']].map(function(o){return '<option value="'+o[0]+'"'+(per===o[0]?' selected':'')+'>'+o[1]+'</option>';}).join('')+'</select></label><label>Tolerancia (%)<input id="fl-tol" type="number" min="0" max="50" value="'+(cfgx().tolFlete!=null?cfgx().tolFlete:5)+'" style="width:70px"></label><button class="btn" data-act="x8-flimp">Importar (CSV/Excel)</button><input id="x8-flfile" type="file" accept=".csv,.xlsx,.xls" hidden></div></div>'+
   '<div class="small muted">Esperado = fijo + km × tarifa + bultos × tarifa. Se marca "Cobro de más" si el cobrado supera lo esperado por encima de la tolerancia. Archivo: columnas transportista, fecha (AAAA-MM-DD), guia, km, bultos, cobrado.</div>'+
   (trs.length?'<div class="row" style="margin:8px 0"><label>Transportista<select id="fl-tr">'+trs.map(function(t){return '<option value="'+esc(t.id)+'">'+esc(t.nombre)+'</option>';}).join('')+'</select></label><label>Fecha<input id="fl-fecha" type="date" value="'+HOY+'"></label><label>Guía o pedido<input id="fl-ref" list="dl-flref" style="width:120px"></label><datalist id="dl-flref">'+(D().entregas||[]).slice(-300).map(function(e){return '<option value="'+esc(e.guia)+'">';}).join('')+'</datalist><label>Km<input id="fl-km" type="number" min="0" style="width:80px"></label><label>Bultos<input id="fl-bul" type="number" min="0" style="width:80px"></label><label>Cobrado ($)<input id="fl-cob" type="number" min="0" style="width:110px"></label><button class="btn pri" data-act="x8-flsave">Cargar</button></div>':'')+
   (vis.length?tbl(['Fecha','Transportista','Guía','Km','Bultos','Cobrado','Esperado','Diferencia','Auditoría','Estado'],vis.map(function(a){var f=a.f;return [esc(fmtFecha(f.fecha)),esc(f.transportista||''),esc(f.ref||'—'),nf(f.km),nf(f.bultos),'$'+nf(f.cobrado),a.tr?'$'+nf(a.esp):'—',a.tr?'<span style="color:var(--'+(a.dif>0?'bad':'ok')+')">'+(a.dif>0?'+':'')+'$'+nf(a.dif)+'</span>':'—','<span class="chip '+(FL_C[a.est]||'')+'">'+a.est+'</span>',f.estado==='aprobado'?'<span class="chip ok">Aprobado</span>':f.estado==='disputa'?'<span class="chip warn">En disputa</span>':'<button class="btn sm ok" data-act="x8-flap" data-id="'+esc(f.id)+'">Aprobar</button> <button class="btn sm" data-act="x8-fldis" data-id="'+esc(f.id)+'">Disputar</button>'];}),980):'<div class="empty">No hay fletes cargados en este período.</div>')+'</div>';
  /* costo por transportista y economía por cliente */
  var bt={};vis.forEach(function(a){var k=a.f.transportista||'—',o=bt[k]=bt[k]||{c:0,km:0,b:0,n:0};o.c+=+a.f.cobrado||0;o.km+=+a.f.km||0;o.b+=+a.f.bultos||0;o.n++;});
  var ks=Object.keys(bt);if(ks.length)h+='<div class="panel"><h3>Costo real por transportista</h3>'+tbl(['Transportista','Viajes','Total','Por viaje','Por km','Por bulto'],ks.map(function(k){var o=bt[k];return [esc(k),nf(o.n),'$'+nf(o.c),'$'+nf(o.c/o.n),o.km?'$'+nf(o.c/o.km):'—',o.b?'$'+nf(o.c/o.b):'—'];}),560)+'</div>';
  var ec={},cov=0,totE=0;(D().entregas||[]).filter(function(e){return e.estado==='entregada'&&e.fecha>=desde&&e.factura&&e.factura.importe>0;}).forEach(function(e){totE++;var k=e.cliente,o=ec[k]=ec[k]||{v:0,c:0,n:0,cn:0};o.v+=e.factura.importe;o.n++;var fl=au.filter(function(a){return a.f.ref&&String(a.f.ref).toUpperCase()===String(e.guia).toUpperCase();});if(fl.length){o.c+=x8sum(fl,function(a){return +a.f.cobrado||0;});o.cn++;cov++;}});
  var ek=Object.keys(ec).sort(function(a,b){return ec[b].v-ec[a].v;});
  h+='<div class="panel"><h3>Control económico por cliente</h3><div class="small muted">Margen logístico = facturado − costo de flete de las guías que tienen flete cargado. Hoy hay costo de flete cargado en '+cov+' de '+totE+' entregas facturadas del período; el resto figura "sin costo" y no entra en el margen.</div>'+(ek.length?tbl(['Cliente','Entregas facturadas','Facturado','Flete cargado','Margen logístico','Flete / venta'],ek.map(function(k){var o=ec[k];return [esc(k),nf(o.n)+' ('+nf(o.cn)+' con flete)','$'+nf(o.v),o.cn?'$'+nf(o.c):'<span class="muted">sin costo</span>',o.cn?'$'+nf(o.v-o.c):'—',o.cn?pc(o.c,o.v):'—'];}),760):'<div class="empty">Todavía no hay entregas facturadas en el período.</div>')+'</div>';
  return h;}
document.addEventListener('change',async function(ev){var t=ev.target;
  if(t.id==='fl-per'){X8.ui.fper=t.value;render();}else if(t.id==='fl-tol'){await cfgSave({tolFlete:Math.min(50,Math.max(0,parseFloat(t.value)||0))});}
  else if(t.id==='x8-flfile'&&t.files[0]){try{await fleImport(t.files[0]);}catch(e){toast('No se pudo leer el archivo.');}t.value='';}});

/* ----- productividad del depósito ----- */
function xPrd(){
  var dias=parseInt(X8.ui.prdD||'7',10),desde=addDays(-dias),op={};var g=function(n){return op[n]=op[n]||{lin:0,uni:0,pk:{},rep:0,bul:0,rec:0,mov:0,tm:0,tl:0,tn:0};};
  WC('kardex').forEach(function(x){if(x.fecha<desde||/Demostraci|ajuste inicial|Sistema/i.test(x.operador||''))return;var o=g(x.operador||'—');o.mov++;if(x.tipo==='OUT'&&/^(Picking|Ola) /.test(x.nota||'')){o.lin++;o.uni+=x.out||0;o.pk[x.nota]=1;}if(x.tipo==='IN'&&/recep/i.test(x.nota||''))o.rec++;});
  WC('picks').forEach(function(p){if(p.estado==='completado'&&p.inicio&&p.cierre&&p.hechoPor&&String(p.cierre).slice(0,10)>=desde){var m=(new Date(p.cierre)-new Date(p.inicio))/6e4;if(m>0&&m<240){var o=g(p.hechoPor);o.tm+=m;o.tl+=(p.lineas||[]).length;o.tn++;}}});
  WC('repos').forEach(function(r){if(r.estado==='hecha'&&String(r.hecha).slice(0,10)>=desde)g(r.hechaPor||'—').rep++;});
  WC('pedidos').forEach(function(p){(p.bultos||[]).forEach(function(b){if(b.esc&&String(b.esc.ts).slice(0,10)>=desde)g(b.esc.por||'—').bul++;});});
  var ks=Object.keys(op).sort(function(a,b){return op[b].lin-op[a].lin;});
  var h='<div class="panel"><div class="row sp"><h3>Productividad del depósito</h3><label>Período<select id="prd-d">'+[['7','7 días'],['30','30 días'],['90','90 días']].map(function(o){return '<option value="'+o[0]+'"'+(String(dias)===o[0]?' selected':'')+'>'+o[1]+'</option>';}).join('')+'</select></label></div><div class="small muted">Cuenta lo que cada persona registró: líneas y unidades de picking, órdenes de picking, reposiciones hechas, bultos escaneados y movimientos. El tiempo por línea se mide solo en el picking guiado (desde que se inicia hasta que se confirma); el resto cuenta tareas, no tiempos.</div>';
  h+=ks.length?tbl(['Operador','Órdenes de picking','Líneas','Unidades','Líneas por día','Reposiciones','Bultos escaneados','Movimientos','Min por línea (guiado)'],ks.map(function(k){var o=op[k];return [esc(k),nf(Object.keys(o.pk).length),nf(o.lin),nf(o.uni),nf(o.lin/dias,1),nf(o.rep),nf(o.bul),nf(o.mov),o.tl?nf(o.tm/o.tl,1)+' ('+o.tn+' órd.)':'—'];}),780):'<div class="empty">No hay actividad registrada en el período.</div>';
  return h+'</div>';}
document.addEventListener('change',function(ev){if(ev.target.id==='prd-d'){X8.ui.prdD=ev.target.value;render();}});

/* ----- P2: escenarios, consolidación, retorno vacío, flota propia vs tercerizada ----- */
function escenario(dx,dl){var cob=cfgx().cobObj||14,z=S.ext.an.z,base=abastRows().filter(function(r){return r.d>0;}),n0=0,n1=0,u1=0,cap1=0,u0=0,cap0=0;
  base.forEach(function(r){var c=+r.s.costo||0;if(r.est==='Quiebre'||r.est==='Reponer'){n0++;u0+=r.sug;cap0+=r.sug*c;}
    var d2=r.d*(1+dx),L2=r.L+dl,sg2=(r.rop-r.d*r.L)/Math.sqrt(Math.max(1,r.L)),ss2=sg2*(1+dx)*Math.sqrt(L2),rop2=d2*L2+ss2,pos=r.disp+r.enc,
      quiebre=r.disp<=0||pos<=rop2*0.5,rep=pos<=rop2,t2=d2*(L2+cob)+ss2,sug2=Math.max(0,Math.ceil(t2-pos));
    if(quiebre||rep){n1++;u1+=sug2;cap1+=sug2*c;}});
  return {n0:n0,n1:n1,u0:u0,u1:u1,cap0:cap0,cap1:cap1,total:base.length};}
function consolid(){var m={};WC('pedidos').forEach(function(p){var f=pedFase(p);if(f==='cancelado'||f==='entregado'||f==='despachado')return;var k=(p.clienteId||p.cliente)+'|'+(p.entrega||'');(m[k]=m[k]||[]).push(p);});return Object.keys(m).map(function(k){return m[k];}).filter(function(a){return a.length>1;});}
function retornoVacio(){var dep=D().depot,out={};if(!dep||typeof dep.lat!=='number')return null;(D().entregas||[]).filter(function(e){return hasXY(e)&&e.fecha>=addDays(-30)&&e.choferId;}).forEach(function(e){var k=e.choferId+'|'+e.fecha,o=out[k]=out[k]||{ch:e.chofer,fecha:e.fecha,l:[]};o.l.push(e);});
  return Object.keys(out).map(function(k){var o=out[k];o.l.sort(function(a,b){return (a.orden||0)-(b.orden||0);});var last=o.l[o.l.length-1];o.km=hav(last,dep)*1.3;o.cli=o.l.map(function(e){return e.cliente;});return o;});}
function xEsc(){
  var sc=X8.ui.sc=X8.ui.sc||{dx:20,dl:7},r=escenario(sc.dx/100,sc.dl),h='<div class="panel"><h3>Escenarios: ¿qué pasa si…?</h3><div class="small muted">Recalcula abastecimiento con otra demanda y otro plazo de entrega de proveedores. Usa los mismos datos reales de ventas y stock; no modifica nada.</div>'+
   '<div class="row" style="margin:8px 0"><label>La demanda sube (%)<input id="sc-dx" type="number" min="-50" max="300" value="'+sc.dx+'" style="width:90px"></label><label>Los proveedores demoran (días más)<input id="sc-dl" type="number" min="-5" max="60" value="'+sc.dl+'" style="width:90px"></label></div>'+
   tbl(['','Hoy','Escenario','Diferencia'],[['SKUs a reponer o en quiebre',nf(r.n0)+' de '+nf(r.total),nf(r.n1),(r.n1-r.n0>=0?'+':'')+nf(r.n1-r.n0)],['Unidades a pedir',nf(r.u0),nf(r.u1),(r.u1-r.u0>=0?'+':'')+nf(r.u1-r.u0)],['Capital necesario (con costo cargado)','$'+nf(r.cap0),'$'+nf(r.cap1),(r.cap1-r.cap0>=0?'+':'')+'$'+nf(r.cap1-r.cap0)]],520)+'<div class="small muted">El capital solo cuenta SKUs con costo unitario cargado en Abastecimiento › Parámetros.</div></div>';
  var cs=consolid();h+='<div class="panel"><h3>Consolidación de pedidos</h3><div class="small muted">Pedidos del mismo cliente para la misma fecha que todavía no salieron: conviene mandarlos en una sola entrega.</div>'+(cs.length?tbl(['Cliente','Fecha','Pedidos','Bultos/unidades'],cs.map(function(a){return [esc(a[0].cliente),esc(fmtFecha(a[0].entrega||'')),a.map(function(p){return esc(p.id);}).join(', '),nf(x8sum(a,function(p){return x8sum(p.lineas||[],function(l){return l.qty;});}))+' u'];}),520):'<div class="empty">No hay pedidos para consolidar.</div>')+'</div>';
  var rv=retornoVacio();h+='<div class="panel"><h3>Retorno vacío</h3><div class="small muted">Kilómetros que cada camión hace de vuelta al depósito desde la última entrega (estimados, en línea recta × 1,3). Si el cliente de esa parada tiene devoluciones o retiros, conviene traerlos en ese tramo.</div>'+(rv&&rv.length?(function(){var tk=x8sum(rv,function(o){return o.km;});return '<div class="small">Últimos 30 días: <strong>'+nf(tk)+' km</strong> de vuelta vacía en '+rv.length+' rutas.</div>'+tbl(['Fecha','Chofer','Paradas','Última parada','Km de vuelta'],rv.sort(function(a,b){return b.km-a.km;}).slice(0,20).map(function(o){return [esc(fmtFecha(o.fecha)),esc(o.ch),nf(o.l.length),esc(o.l[o.l.length-1].cliente),nf(o.km,1)];}),560);})():'<div class="empty">Faltan entregas con coordenadas o la ubicación del depósito.</div>')+'</div>';
  var au=fleAudit().filter(function(a){return a.f.fecha>=addDays(-30)&&a.tr&&a.tr.tipo!=='propio';}),km=x8sum(au,function(a){return +a.f.km||0;}),cos=x8sum(au,function(a){return +a.f.cobrado||0;}),pr=X8.ui.fp=X8.ui.fp||{fijo:0,km:0};
  var prop=pr.fijo+pr.km*km;
  h+='<div class="panel"><h3>Flota propia vs. tercerizada</h3><div class="small muted">Compara lo que pagaste a transportistas en los últimos 30 días (según los fletes cargados) con lo que costaría hacer esos mismos kilómetros con un vehículo propio.</div>'+
   '<div class="row" style="margin:8px 0"><label>Costo fijo mensual del vehículo propio ($: cuota, seguro, chofer)<input id="fp-fijo" type="number" min="0" value="'+(pr.fijo||'')+'" style="width:150px"></label><label>Costo por km propio ($: combustible, mantenimiento)<input id="fp-km" type="number" min="0" step="any" value="'+(pr.km||'')+'" style="width:130px"></label></div>'+
   tbl(['','Monto'],[['Tercerizado (30 días, '+nf(au.length)+' fletes, '+nf(km)+' km)','$'+nf(cos)],['Flota propia estimada para los mismos km',pr.fijo||pr.km?'$'+nf(prop):'cargá los costos'],['Diferencia',pr.fijo||pr.km?'<strong style="color:var(--'+(prop<cos?'ok':'bad')+')">'+(prop<cos?'Conviene propia: ahorra $'+nf(cos-prop):'Conviene tercerizar: ahorra $'+nf(prop-cos))+'</strong>':'—']],520)+(pr.km&&km&&cos/km>pr.km&&pr.fijo?'<div class="small muted">Punto de equilibrio: '+nf(pr.fijo/(cos/km-pr.km))+' km por mes.</div>':'')+'<div class="small muted">Es una estimación de un mes: no incluye amortización ni la posibilidad de que un solo vehículo no alcance para el volumen.</div></div>';
  return h;}
document.addEventListener('change',function(ev){var t=ev.target;
  if(t.id==='sc-dx'||t.id==='sc-dl'){var sc=X8.ui.sc=X8.ui.sc||{dx:20,dl:7};sc[t.id==='sc-dx'?'dx':'dl']=parseFloat(t.value)||0;render();}
  else if(t.id==='fp-fijo'||t.id==='fp-km'){var pr=X8.ui.fp=X8.ui.fp||{fijo:0,km:0};pr[t.id==='fp-fijo'?'fijo':'km']=Math.max(0,parseFloat(t.value)||0);render();}});

/* ----- configuración de módulos ----- */
function xCfg(){var cur=modLista(),sug=modSug(),n=(W().skus||[]).length,np=(W().ubic||[]).length;
  var h='<div class="panel"><h3>Módulos activos</h3><div class="small muted">Tenés '+nf(n)+' SKUs y '+nf(np)+' posiciones. Para ese tamaño se sugiere el paquete <strong>'+({minimo:'Mínimo',pyme:'Pyme',completo:'Completo'})[sug]+'</strong>. Activá solo lo que vas a usar: lo que queda apagado no aparece en los menús ni genera alertas.</div>'+
   '<div class="row" style="margin:10px 0">'+['minimo','pyme','completo'].map(function(k){var on=cur.slice().sort().join()===PRESETS[k].slice().sort().join();return '<button class="btn'+(on?' pri':'')+'" data-act="x8-preset" data-v="'+k+'">'+({minimo:'Mínimo (pocos SKUs)',pyme:'Pyme (cientos de SKUs)',completo:'Completo (miles de SKUs)'})[k]+'</button>';}).join('')+'</div>'+
   '<div class="chips">'+MODS.map(function(m){var on=cur.indexOf(m[0])>=0;return '<button class="chip'+(on?' ok':'')+'" data-act="x8-modtog" data-v="'+m[0]+'" aria-pressed="'+on+'">'+(on?'✓ ':'')+m[1]+'</button>';}).join('')+'</div></div>';
  return h;}
function viewCtrl(){var subs=[['ctl','Control','ctl'],['ped','Pedidos','ped'],['exp','Expedición','exp'],['inc','Incidencias','ped'],['otf','Gestión y OTIF','ctl'],['abs','Abastecimiento','abs'],['rep','Reposición','rep'],['fle','Fletes y costos','fle'],['prd','Productividad','prd'],['esc','Escenarios','esc'],['cfg','Módulos',null]].filter(function(s){return !s[2]||modOn(s[2]);});
  var sub=X8.ui.sub&&subs.some(function(s){return s[0]===X8.ui.sub;})?X8.ui.sub:subs[0][0];X8.ui.sub=sub;S.ext.sub=sub;
  var h='<div class="seg lt" role="group" aria-label="Control" style="margin:10px 0">'+subs.map(function(s){return '<button data-act="x8-sub" data-v="'+s[0]+'" aria-pressed="'+(sub===s[0])+'">'+s[1]+'</button>';}).join('')+'</div>';
  return '<h2>Control logístico</h2>'+h+(sub==='ctl'?xCtl():sub==='ped'?xPed():sub==='exp'?xExp():sub==='inc'?xInc():sub==='otf'?xOtf():sub==='abs'?xAbast():sub==='rep'?xRepo():sub==='fle'?xFle():sub==='prd'?xPrd():sub==='esc'?xEsc():xCfg());}
adminTabs=function(){var n=0;try{if(S.ui.tab!=='ctrl')n=alertasX().filter(function(a){return a.sev==='alta'&&!a.agg;}).length;}catch(e){}
  return '<div class="seg lt" role="group" aria-label="Sección">'+[['op','Operación'],['ctrl','Control'+(n?' ('+n+')':'')],['dash','Dashboard'],['viajes','Viajes'],['wms','Depósito'],['eq','Equipos y personal'],['gest','Gestión'],['sim','Simulación']].map(function(t){return '<button data-act="tab" data-v="'+t[0]+'" aria-pressed="'+(S.ui.tab===t[0])+'">'+t[1]+'</button>';}).join('')+'</div>';};
var x8va0=viewAdmin;viewAdmin=function(){if(S.ui.tab==='ctrl')return adminTabs()+eqBanner()+viewCtrl();return x8va0();};
/* reposición y expedición también dentro de Depósito (rol depósito incluido) */
WSUBS_ALL.splice(WSUBS_ALL.length-1,0,['x8rep','Reposición'],['x8exp','Expedición']);WSUBS_DEP.push('x8rep','x8exp');
var x8vw0=viewWms;viewWms=function(){var v=S.ui.wsub;if(v==='x8rep'||v==='x8exp'){S.ext.sub=v;return '<div class="row sp"><h2>Depósito</h2></div>'+wSub()+(v==='x8rep'?xRepo():xExp());}return x8vw0();};
var x8vd0=viewDeposito;viewDeposito=function(){if(S.ui.dep==='wms'&&(S.ui.wsub==='x8rep'||S.ui.wsub==='x8exp')){var sw='<div class="seg lt" role="group" aria-label="Sección" style="margin-bottom:14px"><button data-act="x-dep" data-id="eq" aria-pressed="false">Equipos</button><button data-act="x-dep" data-id="wms" aria-pressed="true">Depósito (recepción, picking, etiquetas)</button></div>';return sw+viewWms();}return x8vd0();};
/* ===== EXT8d end ===== */
/* ===== EXT8e: acciones, sincronización en vivo y datos de ejemplo ===== */
['pedidos','expediciones','transportistas','fletes','repos','alertas','cfgx'].forEach(function(k){if(S.data.live.wms&&!S.data.live.wms[k])S.data.live.wms[k]=[];});
(function(){var _ex=extLive;extLive=function(rol,onErr){_ex(rol,onErr);var live=S.data.live,mk=function(s){return s.docs.map(function(d){return Object.assign({id:d.id},d.data());});};
  var ks=rol==='admin'?['pedidos','repos','alertas','cfgx','transportistas','fletes']:rol==='deposito'?['pedidos','repos','cfgx']:[];
  ks.forEach(function(k){unsubs.push(db.collection('wms/'+k+'/items').onSnapshot(function(s){live.wms[k]=mk(s);render();},onErr));});};})();
window.__ext=window.__ext||{};window.__ext.S=S;window.__ext.X8=X8;
function x8go(sub){if(sub==='lotes'||sub==='recep'){S.ui.tab='wms';S.ui.wsub=sub;render();return;}X8.ui.sub=sub;render();}
document.addEventListener('click',async function(ev){var t=ev.target.closest('[data-act^="x8-"]');if(!t||t.tagName==='SELECT')return;var a=t.dataset.act,id=t.dataset.id,v=t.dataset.v;if(a==='x8-tp')return;
  try{
  if(a==='x8-abf'){X8.ui.abf=v;render();}
  else if(a==='x8-ocgen'){X8.ui.ocConf=ocGenPrev();render();}else if(a==='x8-ocok')await ocGenOk();else if(a==='x8-occancel'){X8.ui.ocConf=null;render();}
  else if(a==='x8-skuimp'){var f=document.getElementById('x8-skufile');if(f)f.click();}
  else if(a==='x8-skued'){X8.ui.skuEdit=id;render();setTimeout(function(){var e=document.getElementById('x8-skuform');if(e)e.scrollIntoView({block:'nearest'});},30);}
  else if(a==='x8-skusave')await skuSave(id);else if(a==='x8-skucancel'){X8.ui.skuEdit=null;render();}
  else if(a==='x8-repcrear')await reposCrear(false);else if(a==='x8-rephecha')await reposHecha(id);
  else if(a==='x8-pednew'){X8.ui.pedNew=!X8.ui.pedNew;render();}
  else if(a==='x8-pedimp'){var pf=document.getElementById('x8-pedfile');if(pf)pf.click();}
  else if(a==='x8-pdadd'){var d=pedLeerForm(),sk=gv('pd-sku').trim(),q=parseInt(gv('pd-qty'),10);if(!skuBy(sk)){toast('El SKU "'+sk+'" no existe.');return;}if(!(q>0)){toast('Indicá una cantidad mayor a cero.');return;}var ex=d.lineas.find(function(l){return l.sku===sk;});if(ex)ex.qty+=q;else d.lineas.push({sku:sk,qty:q});render();}
  else if(a==='x8-pddel'){pedLeerForm().lineas.splice(parseInt(id,10),1);render();}
  else if(a==='x8-pdsave')await pedCrear();
  else if(a==='x8-pf'){X8.ui.pf=v;render();}
  else if(a==='x8-pres')await pedReservar(id,false);else if(a==='x8-pres-parc')await pedReservar(id,true);
  else if(a==='x8-pgen')await pedGenPick(id);else if(a==='x8-pbul')await pedBultosGen(id);else if(a==='x8-petq')pedEtiquetas(id);
  else if(a==='x8-pcan'){X8.ui.pedCan=id;render();}else if(a==='x8-pcan0'){X8.ui.pedCan=null;render();}else if(a==='x8-pcan2')await pedCancelar(id);
  else if(a==='x8-expsel'){X8.ui.expSel=id||null;render();}else if(a==='x8-despachar')await expDespachar(id);
  else if(a==='x8-atom'){await alSet(id,{estado:'tomada',asignado:actor()});}
  else if(a==='x8-ares'){await alSet(id,{estado:'resuelta',nota:gv('al-n-'+id).trim()});toast('Alerta resuelta. Si el problema sigue, vuelve en 24 horas.');}
  else if(a==='x8-aign'){await alSet(id,{estado:'ignorada',hasta:addDays(7)});}
  else if(a==='x8-ago')x8go(id);
  else if(a==='x8-trsave')await trGuardar();else if(a==='x8-trdel')await wDel('transportistas',id);
  else if(a==='x8-flsave')await fleGuardar();else if(a==='x8-flimp'){var ff=document.getElementById('x8-flfile');if(ff)ff.click();}
  else if(a==='x8-flap'||a==='x8-fldis'){var fl=WC('fletes').find(function(x){return x.id===id;});if(fl){fl=clean(fl);fl.estado=a==='x8-flap'?'aprobado':'disputa';fl.revisado=actor();await wPut('fletes',fl);}}
  else if(a==='x8-sub'){X8.ui.sub=v;render();}
  else if(a==='x8-preset'){await cfgSave({mods:PRESETS[v]});toast('Paquete aplicado.');}
  else if(a==='x8-modtog'){var cur=modLista().slice(),i=cur.indexOf(v);if(i>=0)cur.splice(i,1);else cur.push(v);await cfgSave({mods:cur});}
  }catch(e){if(window.console)console.error(e);toast('No se pudo completar la acción.');}});

/* datos de ejemplo (modo demostración) */
(function(){var w=S.data.demo.wms;if(!w||(w.transportistas&&w.transportistas.length)||(w.pedidos&&w.pedidos.length))return;
  w.transportistas=[{id:'TR-D1',nombre:'Transportes Sur SRL',tipo:'tercero',fija:12000,km:450,bulto:120},{id:'TR-D2',nombre:'Fletes Rápidos',tipo:'tercero',fija:8000,km:520,bulto:90}];
  var fl=function(id,tr,nom,fe,ref,km,b,c){return {id:id,trId:tr,transportista:nom,fecha:fe,ref:ref,km:km,bultos:b,cobrado:c,estado:'pendiente',por:'Demostración'};};
  w.fletes=[fl('FL-D1','TR-D1','Transportes Sur SRL',HOY,'G-4818',18,6,20820),fl('FL-D2','TR-D1','Transportes Sur SRL',addDays(-1),'G-4790',22,10,29500),fl('FL-D3','TR-D2','Fletes Rápidos',HOY,'G-4821',25,12,22080),fl('FL-D4','TR-D1','Transportes Sur SRL',addDays(-1),'G-4790',22,10,29500),fl('FL-D5','TR-D2','Fletes Rápidos',addDays(-2),'G-9999',15,4,17000)];
  var mk=function(n,cli,fe,ls,extra){var ci=pedClienteInfo(cli),o={id:pedCod(n),cliente:cli,clienteId:ci.id||'',direccion:ci.dir||'',lat:ci.lat==null?null:ci.lat,lng:ci.lng==null?null:ci.lng,entrega:fe,desde:ci.desde||'09:00',hasta:ci.hasta||'18:00',ref:'',lineas:ls,estado:'borrador',creado:isoNow(),por:'Demostración'};Object.keys(extra||{}).forEach(function(k){o[k]=extra[k];});return o;};
  w.pedidos=[mk(1,'Ferretería Del Plata',addDays(1),[{sku:'P001',qty:20},{sku:'P003',qty:30}]),mk(2,'Pinturería Los Aromos',addDays(2),[{sku:'P004',qty:5000}]),mk(3,'Corralón Santa Lucía',addDays(1),[{sku:'P005',qty:10},{sku:'P008',qty:15}]),mk(4,'Cliente Nuevo SRL',addDays(-1),[{sku:'P006',qty:5}]),mk(6,'Ferretería Del Plata',HOY,[{sku:'P009',qty:4}],{estado:'despachado',entregaId:'d-4818'})];
  try{var by=pedCandidatos(),p3=w.pedidos[2],res=[];p3.lineas.forEach(function(l){var need=l.qty,cs=by[l.sku]||[];for(var i=0;i<cs.length&&need>0;i++){var t=Math.min(need,cs[i].q);if(t>0){res.push({sku:l.sku,ubi:cs[i].ubi,lote:cs[i].lote,vence:cs[i].vence,qty:t});cs[i].q-=t;need-=t;}}});if(res.length){p3.reserva=res;p3.faltante=[];p3.parcial=false;p3.estado='reservado';p3.reservado=isoNow();}}catch(e){}
})();
/* ===== EXT8e end ===== */

/* EXT8 end */
/* EXT10 start */
/* ===== EXT10: circuito cerrado (resultado de entrega, OTIF, incidencias, vehículo, costo por pedido, tiempos) ===== */
['incidencias'].forEach(function(k){S.data.demo.wms[k]=S.data.demo.wms[k]||[];S.data.live.wms[k]=S.data.live.wms[k]||[];});
(function(){var _ex=extLive;extLive=function(rol,onErr){_ex(rol,onErr);if(rol==='admin'||rol==='deposito'){var live=S.data.live;unsubs.push(db.collection('wms/incidencias/items').onSnapshot(function(s){live.wms.incidencias=s.docs.map(function(d){return Object.assign({id:d.id},d.data());});render();},onErr));}};})();
var MOTIVOS=['Faltó mercadería','Dañado','Rechazado por el cliente','Error de pedido','Otro'];
/* --- cálculos --- */
function kmEnt(e){var dep=D().depot;return dep&&typeof dep.lat==='number'&&hasXY(e)?hav(dep,e)*1.3*2:0;}
function pedRec(p){var fal={};(p.faltaPick||[]).forEach(function(f){fal[f.sku]=(fal[f.sku]||0)+f.qty;});return (p.lineas||[]).map(function(l){return {sku:l.sku,pedido:l.qty,rec:Math.max(0,l.qty-(fal[l.sku]||0))};});}
function pedVolPeso(p){var v=0,k=0;pedRec(p).forEach(function(l){var s=skuBy(l.sku);if(s){v+=l.rec*(+s.vol||0);k+=l.rec*(+s.peso||0);}});return {m3:v,kg:k};}
function pedOtif(p){var e=x8ent()[p.entregaId];if(!e)return null;
  if(e.estado==='no_entregada')return {ot:false,inf:false,causa:'No se entregó',asum:false};if(e.estado!=='entregada')return null;
  var h=(e.historial||[]).filter(function(x){return x.estado==='entregada';}).slice(-1)[0],ot=true;if(h){var ds=ymd(new Date(h.ts));ot=onTime(e)&&ds<=(p.entrega||e.fecha);}
  var inf,asum=!p.entregado;if(p.entregado)inf=p.entregado.lineas.every(function(l){return l.entregado>=l.pedido;});else inf=!(p.faltaPick||[]).length;
  return {ot:ot,inf:inf,causa:!ot&&!inf?'Tarde e incompleto':!ot?'Tarde':!inf?'Incompleto':'OK',asum:asum};}
function costoPed(p,fm){var e=x8ent()[p.entregaId];if(!e)return null;var fl=fm[String(e.guia).toUpperCase()];
  if(fl)return {v:fl,t:'factura'};
  if(e.trId){var tr=trList().find(function(t){return t.id===e.trId;});if(tr)return {v:trEsp(tr,{km:kmEnt(e),bultos:e.bultos}),t:'estimado'};}
  var ck=+cfgx().costoKm||0,k=kmEnt(e);if(!e.trId&&ck>0&&k>0)return {v:ck*k,t:'propio'};return {v:null,t:null};}
function fleteMap(){var m={};fleAudit().forEach(function(a){if(a.f.ref&&a.est!=='Duplicado')m[String(a.f.ref).toUpperCase()]=(m[String(a.f.ref).toUpperCase()]||0)+(+a.f.cobrado||0);});return m;}
function otifChip(p){var o=pedOtif(p);if(!o)return '';return '<span class="chip '+(o.causa==='OK'?'ok':'bad')+'">'+(o.causa==='OK'?'OTIF':o.causa)+'</span>'+(o.asum?' <span class="small muted">(en cantidad asumida)</span>':'');}
/* --- bloqueos y reservas --- */
var x10pb0=pedBloqueos;pedBloqueos=function(p){var out=x10pb0(p);if(pedFase(p)==='borrador'&&p.cliente&&!(D().perfiles||[]).some(function(x){return x.rol==='cliente'&&x.nombre===p.cliente;}))out.push('El cliente no está en el maestro de clientes (Gestión › Usuarios)');return out;};
async function pedCompletar(id){var p=pedGet(id);if(!p||p.estado!=='reservado'||!p.parcial)return;p=clean(p);var by=pedCandidatos(),add=[],fal=[];
  (p.faltante||[]).forEach(function(f){var need=f.qty,cs=by[f.sku]||[];for(var i=0;i<cs.length&&need>0;i++){var t=Math.min(need,cs[i].q);if(t>0){add.push({sku:f.sku,ubi:cs[i].ubi,lote:cs[i].lote,vence:cs[i].vence,qty:t});cs[i].q-=t;need-=t;}}if(need>0)fal.push({sku:f.sku,qty:need});});
  if(!add.length){toast('Todavía no hay stock para completar este pedido.');return;}
  p.reserva=(p.reserva||[]).concat(add);p.faltante=fal;p.parcial=fal.length>0;await pedGuardar(p);toast(fal.length?'Se completó una parte; todavía falta stock.':'Reserva completa.');}
/* --- vehículo y flete al despachar --- */
function vehiculos(){return (D().equipos||[]).filter(function(q){return q.tipo==='camion'||q.tipo==='utilitario';});}
function vehCap(id){var c=cfgx().veh||{};return c[id]||null;}
function x10Desp(p){var vp=pedVolPeso(p),trs=trList();
  return '<label>Vehículo<select id="ex-veh"><option value="">Sin asignar</option>'+vehiculos().map(function(q){var c=vehCap(q.id);return '<option value="'+esc(q.id)+'">'+esc(q.nombre)+(c?' ('+nf(c.m3||0,1)+' m³ · '+nf(c.kg||0)+' kg)':'')+'</option>';}).join('')+'</select></label><label>Flete<select id="ex-tr"><option value="">Flota propia</option>'+trs.map(function(t){return '<option value="'+esc(t.id)+'">'+esc(t.nombre)+'</option>';}).join('')+'</select></label><span class="small muted">Este pedido: '+nf(vp.m3,2)+' m³ · '+nf(vp.kg)+' kg'+(vp.m3===0?' (cargá el volumen por SKU en Abastecimiento › Parámetros)':'')+'</span>';}
function x10Load(vid,fe){var m3=0,kg=0;(D().entregas||[]).forEach(function(e){if(e.vehiculoId===vid&&e.fecha===fe&&e.estado!=='cancelada'){m3+=+e.volM3||0;kg+=+e.pesoKg||0;}});return {m3:m3,kg:kg};}
function x10CapOk(p){var vid=gv('ex-veh');if(!vid)return true;var cap=vehCap(vid);if(!cap)return true;var fe=gv('ex-fecha')||HOY,vp=pedVolPeso(p),ld=x10Load(vid,fe),m=ld.m3+vp.m3,k=ld.kg+vp.kg,pm=cap.m3>0?m/cap.m3*100:0,pk=cap.kg>0?k/cap.kg*100:0;
  if((cap.m3>0&&m>cap.m3||cap.kg>0&&k>cap.kg)&&X8.ui.exOver!==p.id){X8.ui.exOver=p.id;toast('Con este pedido el vehículo queda al '+nf(pm)+'% del volumen y '+nf(pk)+'% del peso. Tocá Despachar de nuevo para confirmar.');return false;}X8.ui.exOver=null;return true;}
function x10Extra(p){var vp=pedVolPeso(p),vid=gv('ex-veh'),q=vehiculos().find(function(x){return x.id===vid;}),tid=gv('ex-tr'),tr=trList().find(function(t){return t.id===tid;});
  return {lineas:pedRec(p).map(function(l){return {sku:l.sku,qty:l.pedido,rec:l.rec};}),volM3:Math.round(vp.m3*1000)/1000,pesoKg:Math.round(vp.kg*10)/10,vehiculoId:q?q.id:'',vehiculo:q?q.nombre:'',trId:tr?tr.id:'',trNombre:tr?tr.nombre:''};}
/* --- resultado de la entrega e incidencias --- */
function xResPanel(id){var p=pedGet(id);if(!p)return '';var e=x8ent()[p.entregaId],none=e&&e.estado==='no_entregada',ls=pedRec(p);
  return '<div class="panel" id="x10-res" style="border:2px solid var(--accent)"><h3>Resultado de la entrega · '+esc(p.id)+' · '+esc(p.cliente)+'</h3><div class="small muted">Cargá lo que el cliente recibió de verdad. Si hay diferencia se abre una incidencia y el pedido cuenta como incompleto en el OTIF.</div>'+
   tbl(['SKU','Pedido','Salió del depósito','Recibió el cliente','Motivo de la diferencia'],ls.map(function(l,i){return ['<span class="guia">'+esc(l.sku)+'</span>',nf(l.pedido),nf(l.rec),'<input id="rs-q-'+i+'" type="number" min="0" max="'+l.pedido+'" value="'+(none?0:l.rec)+'" style="width:90px">','<select id="rs-m-'+i+'"><option value="">—</option>'+MOTIVOS.map(function(m){return '<option>'+m+'</option>';}).join('')+'</select>'];}),620)+
   '<div class="row" style="margin-top:8px"><button class="btn ok" data-act="x10-ressave" data-id="'+esc(id)+'">Guardar resultado</button><button class="btn" data-act="x10-rescancel">Cancelar</button></div></div>';}
async function incCrear(o){var id=uid('INC');await wPut('incidencias',{id:id,pedidoId:o.pedidoId||'',entregaId:o.entregaId||'',cliente:o.cliente||'',tipo:o.tipo,detalle:o.detalle||'',estado:'abierta',creada:isoNow(),por:o.por||actor(),resp:'',notas:[],auto:!!o.auto});return id;}
async function resGuardar(id){var p=pedGet(id);if(!p)return;var ls=pedRec(p),out=[],dif=[];
  for(var i=0;i<ls.length;i++){var q=parseInt(gv('rs-q-'+i),10),m=gv('rs-m-'+i);if(isNaN(q)||q<0||q>ls[i].pedido){toast('Cantidad no válida en la línea '+(i+1)+'.');return;}if(q<ls[i].pedido&&!m){toast('Indicá el motivo de la diferencia en '+ls[i].sku+'.');return;}out.push({sku:ls[i].sku,pedido:ls[i].pedido,recogido:ls[i].rec,entregado:q,motivo:q<ls[i].pedido?m:''});if(q<ls[i].pedido)dif.push(ls[i].sku+' '+q+'/'+ls[i].pedido+' ('+m+')');}
  p=clean(p);p.entregado={ts:isoNow(),por:actor(),lineas:out,asumido:false};await pedGuardar(p);
  if(dif.length)await incCrear({pedidoId:p.id,entregaId:p.entregaId,cliente:p.cliente,tipo:out.some(function(l){return l.motivo==='Rechazado por el cliente';})?'Rechazo':out.some(function(l){return l.motivo==='Dañado';})?'Dañado':'Faltante',detalle:'Diferencias: '+dif.join('; '),auto:true});
  X8.ui.res=null;toast(dif.length?'Resultado guardado; se abrió una incidencia.':'Resultado guardado: entrega completa.');render();}
function xInc(){var all=WC('incidencias'),ab=all.filter(function(i){return i.estado!=='cerrada';}).sort(function(a,b){return String(a.creada).localeCompare(String(b.creada));}),ce=all.filter(function(i){return i.estado==='cerrada';}).sort(function(a,b){return String(b.cierre).localeCompare(String(a.cierre));}).slice(0,15);
  var viejas=ab.filter(function(i){return Date.now()-new Date(i.creada)>3*864e5;}).length,dias=ce.length?x8sum(ce,function(i){return (new Date(i.cierre)-new Date(i.creada))/864e5;})/ce.length:0;
  var h='<div class="kpis">'+KPI(nf(ab.length),'Incidencias abiertas',viejas?viejas+' con más de 3 días':'ninguna demorada',viejas?'bad':'ok')+KPI(nf(all.length-ab.length),'Cerradas','histórico')+KPI(ce.length?nf(dias,1)+' d':'—','Tiempo medio de cierre','últimas '+ce.length+' cerradas')+'</div>';
  h+='<div class="panel"><h3>Nueva incidencia</h3><div class="row"><label>Pedido<input id="in-ped" list="dl-inped" style="width:140px" autocomplete="off"></label><datalist id="dl-inped">'+WC('pedidos').slice(-300).map(function(p){return '<option value="'+esc(p.id)+'" label="'+esc(p.cliente)+'">';}).join('')+'</datalist><label>Tipo<select id="in-tipo">'+['Faltante','Dañado','Rechazo','Dirección o ausente','Reclamo del cliente','Otro'].map(function(t){return '<option>'+t+'</option>';}).join('')+'</select></label><label style="min-width:260px">Detalle<input id="in-det" maxlength="300"></label><button class="btn pri" data-act="x10-incnew">Abrir</button></div></div>';
  h+='<div class="panel"><h3>Abiertas</h3>'+(ab.length?tbl(['Abierta','Pedido','Cliente','Tipo','Detalle','Responsable','Acción'],ab.map(function(i){var d=Math.floor((Date.now()-new Date(i.creada))/864e5);return [esc(fmtFecha(x8d(i.creada)))+'<div class="small muted">'+d+' d</div>',esc(i.pedidoId||'—'),esc(i.cliente||''),'<span class="chip warn">'+esc(i.tipo)+'</span>',esc(i.detalle||'')+(i.notas&&i.notas.length?'<div class="small muted">'+i.notas.slice(-2).map(function(n){return esc(n.por)+': '+esc(n.txt);}).join('<br>')+'</div>':''),i.resp?'<strong>'+esc(i.resp)+'</strong>':'<span class="muted">Sin asignar</span>',
    '<div class="row">'+(i.resp!==actor()?'<button class="btn sm pri" data-act="x10-inctake" data-id="'+esc(i.id)+'">Tomar</button>':'')+'<input id="in-n-'+esc(i.id)+'" placeholder="Nota" style="width:120px"><button class="btn sm" data-act="x10-incnote" data-id="'+esc(i.id)+'">Anotar</button><select id="in-r-'+esc(i.id)+'">'+['Reprogramar entrega','Reenvío del faltante','Nota de crédito','Reposición sin cargo','Sin acción'].map(function(r){return '<option>'+r+'</option>';}).join('')+'</select><button class="btn sm ok" data-act="x10-incclose" data-id="'+esc(i.id)+'">Cerrar</button></div>'];}),980):'<div class="empty">No hay incidencias abiertas.</div>')+'</div>';
  if(ce.length)h+='<div class="panel"><h3>Últimas cerradas</h3>'+tbl(['Cierre','Pedido','Tipo','Resolución','Por'],ce.map(function(i){return [esc(fmtFecha(x8d(i.cierre))),esc(i.pedidoId||'—'),esc(i.tipo),esc(i.resolucion||''),esc(i.cerroPor||'')];}),560)+'</div>';
  return h;}
async function incUpd(id,fn){var i=WC('incidencias').find(function(x){return x.id===id;});if(!i)return;i=clean(i);fn(i);await wPut('incidencias',i);}
/* --- gestión: OTIF y costo por pedido --- */
function xOtf(){var per=X8.ui.otp||'90',desde=addDays(-parseInt(per,10)),fm=fleteMap(),rows=[];
  WC('pedidos').forEach(function(p){if(p.estado!=='despachado')return;var o=pedOtif(p);if(!o)return;var e=x8ent()[p.entregaId];if(!e||e.fecha<desde)return;var c=costoPed(p,fm),fac=e.factura&&e.factura.importe>0?e.factura.importe:null;rows.push({p:p,e:e,o:o,c:c,fac:fac});});
  var n=rows.length,ot=rows.filter(function(r){return r.o.ot;}).length,inf=rows.filter(function(r){return r.o.inf;}).length,ok=rows.filter(function(r){return r.o.ot&&r.o.inf;}).length,cc=rows.filter(function(r){return r.c&&r.c.v!=null;}),costo=x8sum(cc,function(r){return r.c.v;}),bul=x8sum(cc,function(r){return +r.e.bultos||0;}),asum=rows.filter(function(r){return r.o.asum;}).length;
  var fa=rows.filter(function(r){return r.fac&&r.c&&r.c.v!=null;}),vf=x8sum(fa,function(r){return r.fac;}),cf=x8sum(fa,function(r){return r.c.v;});
  var h='<div class="panel"><div class="row sp"><h3>Gestión del circuito</h3><label>Período<select id="otf-p">'+[['30','30 días'],['90','90 días'],['365','Un año']].map(function(o){return '<option value="'+o[0]+'"'+(per===o[0]?' selected':'')+'>'+o[1]+'</option>';}).join('')+'</select></label></div><div class="small muted">OTIF = entregado a tiempo (en la fecha prometida y dentro de la ventana) <strong>y</strong> completo (todo lo pedido). Solo cuentan pedidos despachados cuya entrega ya terminó.</div></div>';
  h+='<div class="kpis">'+KPI(n?nf(ok/n*100,1)+'%':'—','OTIF',nf(ok)+' de '+nf(n)+' pedidos',n&&ok/n<0.9?'warn':'ok')+KPI(n?nf(ot/n*100,1)+'%':'—','A tiempo',nf(ot)+' de '+nf(n))+KPI(n?nf(inf/n*100,1)+'%':'—','Completos',nf(inf)+' de '+nf(n))+KPI(cc.length?'$'+nf(costo/cc.length):'—','Costo medio por pedido',cc.length+' pedidos con costo')+'</div>';
  h+='<div class="kpis">'+KPI(bul?'$'+nf(costo/bul):'—','Costo por bulto','flete / bultos')+KPI(vf?nf(cf/vf*100,1)+'%':'—','Flete sobre venta',fa.length+' pedidos facturados')+KPI(vf?'$'+nf(vf-cf):'—','Margen logístico','facturado − flete')+KPI(n?nf(asum/n*100)+'%':'—','Cantidad asumida','pedidos sin resultado cargado',asum>n*0.3?'warn':'')+'</div>';
  var bc={};rows.forEach(function(r){var k=r.p.cliente,o=bc[k]=bc[k]||{n:0,ok:0,ot:0,inf:0,v:0,c:0,cn:0};o.n++;if(r.o.ot)o.ot++;if(r.o.inf)o.inf++;if(r.o.ot&&r.o.inf)o.ok++;if(r.fac&&r.c&&r.c.v!=null){o.v+=r.fac;o.c+=r.c.v;o.cn++;}});
  var ks=Object.keys(bc).sort(function(a,b){return bc[b].n-bc[a].n;});
  h+='<div class="panel"><h3>Por cliente</h3>'+(ks.length?tbl(['Cliente','Pedidos','OTIF','A tiempo','Completos','Facturado','Flete','Margen'],ks.map(function(k){var o=bc[k];return [esc(k),nf(o.n),'<strong style="color:var(--'+(o.ok/o.n<0.8?'bad':o.ok/o.n<0.9?'warn':'ok')+')">'+nf(o.ok/o.n*100)+'%</strong>',nf(o.ot/o.n*100)+'%',nf(o.inf/o.n*100)+'%',o.cn?'$'+nf(o.v):'—',o.cn?'$'+nf(o.c):'—',o.cn?'$'+nf(o.v-o.c):'—'];}),780):'<div class="empty">No hay pedidos entregados en el período.</div>')+'</div>';
  var ca={};rows.forEach(function(r){if(r.o.causa!=='OK')ca[r.o.causa]=(ca[r.o.causa]||0)+1;});var mo={};rows.forEach(function(r){if(r.p.entregado)r.p.entregado.lineas.forEach(function(l){if(l.motivo)mo[l.motivo]=(mo[l.motivo]||0)+1;});});
  if(Object.keys(ca).length)h+='<div class="grid2"><div class="panel"><h3>Por qué falló el OTIF</h3>'+tbl(['Causa','Pedidos'],Object.keys(ca).sort(function(a,b){return ca[b]-ca[a];}).map(function(k){return [esc(k),nf(ca[k])];}),300)+'</div><div class="panel"><h3>Motivos de diferencia</h3>'+(Object.keys(mo).length?tbl(['Motivo','Líneas'],Object.keys(mo).sort(function(a,b){return mo[b]-mo[a];}).map(function(k){return [esc(k),nf(mo[k])];}),300):'<div class="small muted">Sin diferencias cargadas.</div>')+'</div></div>';
  var bad=rows.filter(function(r){return r.o.causa!=='OK';}).sort(function(a,b){return String(b.e.fecha).localeCompare(String(a.e.fecha));}).slice(0,25);
  if(bad.length)h+='<div class="panel"><h3>Pedidos que no cumplieron</h3>'+tbl(['Pedido','Cliente','Fecha','Causa'],bad.map(function(r){return [esc(r.p.id),esc(r.p.cliente),esc(fmtFecha(r.e.fecha)),'<span class="chip bad">'+esc(r.o.causa)+'</span>'];}),520)+'</div>';
  h+='<div class="small muted">Costo del pedido = factura del transportista si está cargada; si no, el estimado con su tarifa; para flota propia, kilómetros estimados × costo por km (Módulos). Los kilómetros son una estimación en línea recta × 1,3 (ida y vuelta). "Cantidad asumida" = el pedido no tiene resultado cargado y se supone que se entregó lo que salió del depósito.</div>';
  return h;}
document.addEventListener('change',function(ev){if(ev.target.id==='otf-p'){X8.ui.otp=ev.target.value;render();}});
/* --- conciliación automática: entregas con flete tercerizado sin factura --- */
function x10Conc(){var fm=fleteMap(),per=parseInt(X8.ui.fper||'30',10),desde=addDays(-per),pend=[];
  (D().entregas||[]).forEach(function(e){if(!e.trId||e.estado!=='entregada'||e.fecha<desde||fm[String(e.guia).toUpperCase()])return;var tr=trList().find(function(t){return t.id===e.trId;});if(!tr)return;pend.push({e:e,tr:tr,km:kmEnt(e),esp:trEsp(tr,{km:kmEnt(e),bultos:e.bultos})});});
  return '<div class="panel"><h3>Entregas tercerizadas sin factura de flete</h3><div class="small muted">Entregadas con un transportista asignado al despachar y todavía sin factura cargada con esa guía. El importe es lo que debería cobrar según su tarifa (km estimados): sirve para provisionar y para controlar cuando llegue la factura.</div>'+
   (pend.length?'<div class="small">A provisionar: <strong>$'+nf(x8sum(pend,function(r){return r.esp;}))+'</strong> en '+pend.length+' entregas.</div>'+tbl(['Guía','Fecha','Cliente','Transportista','Km est.','Bultos','Esperado'],pend.slice(0,60).map(function(r){return [esc(r.e.guia),esc(fmtFecha(r.e.fecha)),esc(r.e.cliente),esc(r.tr.nombre),nf(r.km,1),nf(r.e.bultos||0),'$'+nf(r.esp)];}),700):'<div class="empty">No hay entregas pendientes de factura.</div>')+'</div>';}
var x10fle0=xFle;xFle=function(){return x10fle0()+x10Conc();};
/* --- configuración: vehículos y costo propio --- */
function x10Cfg(){var vs=vehiculos(),c=cfgx();return '<div class="panel"><h3>Vehículos y costo de flota propia</h3><div class="small muted">La capacidad se usa al despachar: si el pedido más lo ya cargado ese día supera el vehículo, avisa antes de confirmar. El costo por km propio (combustible, mantenimiento, chofer) se usa para calcular el costo por pedido de la flota propia.</div>'+
  '<div class="row" style="margin:8px 0"><label>Costo por km de flota propia ($)<input id="cfg-ckm" type="number" min="0" step="any" value="'+(c.costoKm||'')+'" style="width:130px"></label></div>'+
  (vs.length?tbl(['Vehículo','Capacidad (m³)','Capacidad (kg)'],vs.map(function(q){var v=vehCap(q.id)||{};return [esc(q.nombre),'<input id="vh-m3-'+esc(q.id)+'" type="number" min="0" step="any" value="'+(v.m3||'')+'" style="width:100px">','<input id="vh-kg-'+esc(q.id)+'" type="number" min="0" value="'+(v.kg||'')+'" style="width:100px">'];}),420):'<div class="small muted">No hay camiones ni utilitarios cargados en Equipos.</div>')+'</div>';}
var x10cfg0=xCfg;xCfg=function(){return x10cfg0()+x10Cfg();};
document.addEventListener('change',async function(ev){var t=ev.target,m=/^vh-(m3|kg)-(.+)$/.exec(t.id||'');
  if(t.id==='cfg-ckm'){await cfgSave({costoKm:Math.max(0,parseFloat(t.value)||0)});}
  else if(m){var veh=clean(cfgx().veh||{}),o=veh[m[2]]=veh[m[2]]||{};o[m[1]]=Math.max(0,parseFloat(t.value)||0);await cfgSave({veh:veh});}});
/* --- tiempos reales de picking --- */
var x10gd0=gdStart;gdStart=function(id){x10gd0(id);var p=WC('picks').find(function(x){return x.id===id;});if(p&&!p.inicio){var q=clean(p);q.inicio=isoNow();q.inicioPor=actor();wPut('picks',q);}};
var x10pc2=pickConfirmar;pickConfirmar=async function(id,ov){await x10pc2(id,ov);var p=WC('picks').find(function(x){return x.id===id;});if(p&&p.estado==='completado'&&!p.hechoPor){var q=clean(p);q.hechoPor=actor();await wPut('picks',q);}};
/* --- acciones --- */
document.addEventListener('click',async function(ev){var t=ev.target.closest('[data-act^="x10-"]');if(!t)return;var a=t.dataset.act,id=t.dataset.id;
  try{
  if(a==='x10-comp')await pedCompletar(id);
  else if(a==='x10-res'){X8.ui.res=id;render();setTimeout(function(){var e=document.getElementById('x10-res');if(e)e.scrollIntoView({block:'nearest'});},30);}
  else if(a==='x10-rescancel'){X8.ui.res=null;render();}else if(a==='x10-ressave')await resGuardar(id);
  else if(a==='x10-incnew'){var pid=gv('in-ped').trim(),p=pid?pedGet(pid):null,det=gv('in-det').trim();if(pid&&!p){toast('No existe el pedido '+pid+'.');return;}if(!det){toast('Escribí el detalle.');return;}await incCrear({pedidoId:pid,entregaId:p?p.entregaId:'',cliente:p?p.cliente:'',tipo:gv('in-tipo'),detalle:det});toast('Incidencia abierta.');}
  else if(a==='x10-inctake')await incUpd(id,function(i){i.resp=actor();i.estado='en_gestion';});
  else if(a==='x10-incnote'){var txt=gv('in-n-'+id).trim();if(!txt){toast('Escribí la nota.');return;}await incUpd(id,function(i){(i.notas=i.notas||[]).push({ts:isoNow(),por:actor(),txt:txt});});}
  else if(a==='x10-incclose'){var r=gv('in-r-'+id);await incUpd(id,function(i){i.estado='cerrada';i.cierre=isoNow();i.cerroPor=actor();i.resolucion=r;});toast('Incidencia cerrada.');}
  }catch(e){if(window.console)console.error(e);toast('No se pudo completar la acción.');}});
/* --- demo: historial de pedidos entregados con OTIF, costos e incidencias --- */
(function(){var w=S.data.demo.wms;var seed=11,rnd=function(){seed=(seed*16807)%2147483647;return seed/2147483647;};
  var hs=(S.data.demo.entregas||[]).filter(function(e){return /^d-h/.test(e.id)&&e.clienteId&&(e.estado==='entregada'||e.estado==='no_entregada');}).sort(function(a,b){return String(b.fecha).localeCompare(String(a.fecha));}).slice(0,60);
  var sk=w.skus.map(function(s){return s.codigo;}),tr=['TR-D1','TR-D2',''];w.incidencias=w.incidencias||[];
  hs.forEach(function(e,i){var ls=[];for(var j=0;j<2+Math.floor(rnd()*2);j++){var s=sk[Math.floor(rnd()*sk.length)];if(!ls.some(function(l){return l.sku===s;}))ls.push({sku:s,qty:1+Math.floor(rnd()*12)});}
    var id='PED-'+String(300+i).padStart(6,'0');e.trId=tr[i%3];e.trNombre=e.trId==='TR-D1'?'Transportes Sur SRL':e.trId==='TR-D2'?'Fletes Rápidos':'';
    var corto=rnd()<0.2&&e.estado==='entregada',lin=ls.map(function(l,k2){var s=corto&&k2===0?Math.max(0,l.qty-1-Math.floor(rnd()*3)):l.qty;return {sku:l.sku,pedido:l.qty,recogido:l.qty,entregado:e.estado==='no_entregada'?0:s,motivo:(e.estado==='no_entregada'||s<l.qty)?(e.estado==='no_entregada'?'Otro':MOTIVOS[Math.floor(rnd()*3)]):''};});
    var p={id:id,cliente:e.cliente,clienteId:e.clienteId,direccion:e.direccion,lat:e.lat,lng:e.lng,entrega:e.fecha,desde:e.desde,hasta:e.hasta,ref:'',lineas:ls,estado:'despachado',entregaId:e.id,creado:addDays(-1)+'T10:00:00.000Z',por:'Demostración',despachado:e.fecha+'T07:00:00.000Z'};
    if(i%5!==4)p.entregado={ts:e.fecha+'T12:00:00.000Z',por:'Demostración',lineas:lin,asumido:false};w.pedidos.push(p);
    if(lin.some(function(l){return l.entregado<l.pedido;})&&i%5!==4){var cerrada=i%2===0;w.incidencias.push({id:'INC-D'+i,pedidoId:id,entregaId:e.id,cliente:e.cliente,tipo:lin[0].motivo==='Dañado'?'Dañado':lin[0].motivo==='Rechazado por el cliente'?'Rechazo':'Faltante',detalle:'Diferencias en '+lin.filter(function(l){return l.entregado<l.pedido;}).map(function(l){return l.sku;}).join(', '),estado:cerrada?'cerrada':(i%3===0?'en_gestion':'abierta'),creada:e.fecha+'T15:00:00.000Z',por:'Demostración',resp:cerrada||i%3===0?'Administración':'',notas:[],cierre:cerrada?addDays(-Math.max(0,Math.floor((Date.now()-new Date(e.fecha))/864e5)-2))+'T11:00:00.000Z':'',cerroPor:cerrada?'Administración':'',resolucion:cerrada?'Reenvío del faltante':''});}
    if(e.trId&&i%3===0){var tt=w.transportistas.find(function(t){return t.id===e.trId;});if(tt){var esp=tt.fija+kmEnt(e)*tt.km+(e.bultos||0)*tt.bulto;w.fletes.push({id:'FL-H'+i,trId:tt.id,transportista:tt.nombre,fecha:e.fecha,ref:e.guia,km:Math.round(kmEnt(e)),bultos:e.bultos||0,cobrado:Math.round(esp*(i%9===0?1.18:1)),estado:'pendiente',por:'Demostración'});}}});
})();
/* ===== EXT10 end ===== */

/* EXT10 end */
/* ---------- eventos ---------- */
document.addEventListener('click',async function(ev){
  var t=ev.target.closest('[data-act]');if(!t||t.tagName==='SELECT'||t.tagName==='INPUT')return;
  var a=t.dataset.act,id=t.dataset.id,v=t.dataset.v;
  if(a==='tab'){S.ui.tab=v;render();}
  else if(a.indexOf('eq')===0||a.indexOf('chk')===0||a.indexOf('fic')===0){await eqClick(a,id,v);}
  else if(a==='trsave'){var tn=(document.getElementById('tr-nom').value||'').trim()||'Tráfico',tt=(document.getElementById('tr-tel').value||'').trim(),tv={nombre:tn,telefono:tt};try{if(S.mode==='demo')S.trafDemo=tv;else{await db.doc('config/trafico').set(tv);S.trafico=tv;}toast('Contacto guardado');render();}catch(_){toast('No se pudo guardar el contacto.');}}
  else if(a==='auditver'){try{S.audit=await apiJson('GET','/api/audit');render();}catch(_){toast('No se pudo leer el registro.');}}
  else if(a==='auditocultar'){S.audit=null;render();}
  else if(a==='salir'){var pn=(window.PORTAL_STATUS||{}).pending||0;if(pn&&!window.confirm('Hay '+pn+' cambio(s) sin enviar. Si salís ahora se pierden. ¿Salir igual?'))return;try{await fetch('/api/logout',{method:'POST',credentials:'same-origin'});}catch(_){}if(window.portalClearLocal)window.portalClearLocal();try{if(window.caches)await caches.delete('portal-api');}catch(_){}location.reload();}
  else if(a==='uclave'){S.ui.resetId=S.ui.resetId===id?null:id;render();}
  else if(a==='uguardar'){var np=(document.getElementById('u-newpass')||{}).value||'';try{await apiJson('PATCH','/api/users/'+id,{password:np});S.ui.resetId=null;toast('Contraseña actualizada');render();}catch(e){toast(e.message);}}
  else if(a==='uquitar'){if(S.ui.confirmDel==='u'+id){S.ui.confirmDel=null;try{await apiJson('DELETE','/api/users/'+id);toast('Usuario quitado');loadUsers();}catch(e){toast(e.message);}}else{S.ui.confirmDel='u'+id;render();}}
  else if(a==='simplay'){simPlay();}
  else if(a==='wloc'){S.ui.wloc=id;S.ui.wver='';render();var dd=document.getElementById('loc-det');if(dd)dd.scrollIntoView({behavior:'smooth',block:'nearest'});}
  else if(a==='wsub'){S.ui.wsub=v;render();}
  else if(a==='wcargar'){try{var nn=await wBulkLive(WMS_DEMO);toast(nn+' registros de ejemplo cargados.');}catch(_){toast('No se pudieron cargar.');}}
  else if(a==='wpedir'){S.ui.confirmDel=t.dataset.k+id;render();}
  else if(a==='wdel'){S.ui.confirmDel=null;try{await wDel(t.dataset.k,id);toast('Quitado');}catch(_){toast('No se pudo quitar.');}}
  else if(a==='demorol'){S.demoRol=v;S.ui.formOpen=false;S.ui.edit=null;render();}
  else if(a==='modo'){S.mode=v;S.note=v==='demo'?'Datos de ejemplo ficticios. Los cambios que hagas acá no se guardan.':'';render();}
  else if(a==='dia'){S.ui.dia=v;render();}
  else if(a==='estado'){await setEstado(id,v);}
  else if(a==='motivo'){S.ui.motivo=S.ui.motivo===id?null:id;render();}
  else if(a==='noent'){var m=document.getElementById('mot-'+id),mn=document.getElementById('mnota-'+id),nota0=mn?mn.value.trim():'',dv0=readDev('no-'+id,D().entregas.find(function(x){return x.id===id;}));S.ui.motivo=null;var up=await ftSubir('no:'+id);ftList('no:'+id).length=0;await setEstado(id,'no_entregada',m?m.value:'',null,{nota:nota0,fotos:up.urls,pend:up.pend,devuelve:dv0});}
  else if(a==='obs'){var ta=document.getElementById('obs-'+id),tx=ta?ta.value:'';if(!tx.trim()&&!ftList('obs:'+id).length){toast('Escribí algo o agregá una foto.');return;}S.ui.obsOpen=null;var up2=await ftSubir('obs:'+id);ftList('obs:'+id).length=0;if(ta)ta.value='';await addObs(id,tx,up2.urls,up2.pend);}
  else if(a==='nuevo'){S.ui.formOpen=true;S.ui.edit=null;render();var f=document.getElementById('form-ent');if(f)f.scrollIntoView({behavior:'smooth',block:'start'});}
  else if(a==='editar'){S.ui.edit=clean(D().entregas.find(function(x){return x.id===id;}));S.ui.formOpen=true;render();var f2=document.getElementById('form-ent');if(f2)f2.scrollIntoView({behavior:'smooth',block:'start'});}
  else if(a==='cancelar'){S.ui.formOpen=false;S.ui.edit=null;render();}
  else if(a==='pedirBorrar'){S.ui.confirmDel=id;render();}
  else if(a==='borrar'){S.ui.confirmDel=null;var e=D().entregas.find(function(x){return x.id===id;});if(e){try{await removeEntrega(e);toast('Entrega eliminada');}catch(_){toast('No se pudo eliminar.');}}}
  else if(a==='aplicarOrden'){await aplicarOrden();}
  else if(a==='guardarDeposito'){var xy=parseXY((document.getElementById('dep-xy')||{}).value);if(!xy){toast('Formato: -34.66, -58.36');return;}try{await db.doc('config/deposito').set({nombre:D().depot.nombre||'Depósito',lat:xy.lat,lng:xy.lng});toast('Depósito guardado');}catch(_){toast('No se pudo guardar.');}}
  else if(a==='elegir'){S.ui.pick={id:id,name:t.dataset.name};S.ui.hits=[];render();}
  else if(a==='guardarPerfil'){var rol=document.getElementById('u-rol').value,nom=(document.getElementById('u-nom').value||'').trim();if(!nom||!S.ui.pick){toast('Completá el nombre del perfil.');return;}
    try{await db.doc('perfiles/'+S.ui.pick.id).set({rol:rol,nombre:nom});S.ui.pick=null;toast('Perfil guardado');render();}catch(_){toast('No se pudo guardar el perfil.');}}
  else if(a==='quitarPerfil'){try{await db.doc('perfiles/'+id).delete();toast('Perfil quitado');}catch(_){toast('No se pudo quitar.');}}
});
document.addEventListener('change',function(ev){
  var t=ev.target;
  if(t.id==='f-dia'){S.ui.dia=t.value;render();}
  else if(t.id==='eq-fil'){S.ui.eqFil=t.value;render();}
  else if(t.id==='ch-eq'){S.ui.miEq=t.value;S.ui.chk=null;render();}
  else if(t.id==='f-chof'){S.ui.chofer=t.value;render();}
  else if(t.id==='o-cho'){S.ui.optChofer=t.value;render();}
  else if(t.id==='o-dia'){S.ui.optDia=t.value;render();}
  else if(t.id==='v-file'){if(t.files&&t.files[0]){var ff=t.files[0];t.value='';importViajes(ff);}}
  else if(t.id&&t.id.indexOf('sm-')===0){var sk=t.id.slice(3);if(!S.ui.sim)S.ui.sim=Object.assign({},SIMD);S.ui.sim[sk]=sk==='esc'?t.value:(parseFloat(t.value)>0?parseFloat(t.value):S.ui.sim[sk]);if(sk!=='spd')simStop();render();}
  else if(t.id==='wv-vista'){S.ui.wvista=t.value;render();}
  else if(t.id&&t.id.indexOf('cf-')===0){var cv=parseFloat(t.value),kk=t.id.slice(3);if(kk==='cor')S.cfg.corte=t.value;else if(cv>=0){if(kk==='kg')S.cfg.kgPos=cv||S.cfg.kgPos;if(kk==='d1')S.cfg.d1=cv;if(kk==='d2')S.cfg.d2=Math.max(cv,S.cfg.d1);}
    if(S.mode==='live'&&db)db.doc('config/almacen').set(clean(S.cfg)).catch(function(){toast('No se pudo guardar la configuración.');});render();}
  else if(t.id==='wf-sku'){S.ui.wfind=t.value;render();}
  else if(t.id==='w-file'){if(t.files&&t.files[0]){var f3=t.files[0];t.value='';importWms(f3);}}
  else if(t.id==='m-tipo'){S.ui.m.tipo=t.value;S.ui.m.ubi='';render();}
  else if(t.id==='m-sku'){S.ui.m.sku=t.value;if(S.ui.m.tipo!=='IN')S.ui.m.ubi='';render();}
  else if(t.id==='m-ubi'){S.ui.m.ubi=t.value;render();}
  else if(t.id==='k-fil'){S.ui.wfil=t.value;render();}
  else if(t.id==='abc-ini'){S.ui.abcStart=t.value;render();}
  else if(t.id==='abc-dia'){S.ui.abcDias=t.value;render();}
  else if(t.id==='p-per'){S.ui.periodo=t.value;render();}
  else if(t.id==='m-cho'){S.ui.mapChofer=t.value;render();}
  else if(t.id==='m-dia'){S.ui.mapDia=t.value;render();}
  else if(t.id==='fu-con'||t.id==='fu-pre'){var c=parseFloat(document.getElementById('fu-con').value),pr=parseFloat(document.getElementById('fu-pre').value);S.fuel={consumo:c>0?c:S.fuel.consumo,precio:pr>0?pr:S.fuel.precio};if(S.mode==='live'&&db){db.doc('config/combustible').set(S.fuel).catch(function(){toast('No se pudo guardar el consumo.');});}render();}
});
document.addEventListener('keydown',function(ev){if(ev.key!=='Enter'&&ev.key!==' ')return;var t=ev.target;if(t&&t.getAttribute&&t.getAttribute('data-act')==='wloc'){ev.preventDefault();t.dispatchEvent(new MouseEvent('click',{bubbles:true}));}});
var searchTimer=null;
document.addEventListener('input',function(ev){
  if(ev.target.id==='w-ver'){S.ui.wver=ev.target.value;render();return;}
  if(ev.target.id!=='u-q'||!user)return;
  var q=ev.target.value;clearTimeout(searchTimer);
  searchTimer=setTimeout(async function(){var hits=await user.search(q);S.ui.hits=(hits||[]).filter(function(h){return h.name;});render();},250);
});
function parseXY(s){var m=String(s||'').match(/(-?\d+(?:[.,]\d+)?)\s*[,;\s]\s*(-?\d+(?:[.,]\d+)?)/);if(!m)return null;var la=parseFloat(m[1].replace(',','.')),ln=parseFloat(m[2].replace(',','.'));if(isNaN(la)||isNaN(ln)||Math.abs(la)>90||Math.abs(ln)>180)return null;return {lat:la,lng:ln};}
document.addEventListener('submit',async function(ev){
  if(ev.target.id==='form-eq'){ev.preventDefault();saveEquipo();return;}
  if(ev.target.id==='form-fic'){ev.preventDefault();saveFicha();return;}
  if(ev.target.id!=='form-ent')return;ev.preventDefault();
  var g=function(i){return document.getElementById(i);};
  var old=S.ui.edit||{},cliId=old.clienteId||g('x-cli').value;
  if(!cliId){toast('Elegí un cliente.');return;}
  var cli=D().perfiles.find(function(p){return p.id===cliId;}),cho=D().perfiles.find(function(p){return p.id===g('x-cho').value;});
  var xyTxt=g('x-xy').value.trim(),xy=xyTxt?parseXY(xyTxt):null;
  if(xyTxt&&!xy){toast('Coordenadas no válidas. Ejemplo: -34.7064, -58.3922');return;}
  var e={id:old.id||(S.mode==='demo'?'d-'+Date.now():db.collection('entregas').doc().id),guia:g('x-guia').value.trim(),clienteId:cliId,cliente:cli?cli.nombre:(old.cliente||''),
    direccion:g('x-dir').value.trim(),fecha:g('x-fec').value,desde:g('x-des').value,hasta:g('x-has').value,choferId:cho?cho.id:'',chofer:cho?cho.nombre:'',
    orden:old.orden||(D().entregas.filter(function(x){return x.choferId===(cho&&cho.id)&&x.fecha===g('x-fec').value;}).length+1),
    estado:old.estado||'programada',bultos:parseInt(g('x-bul').value,10)||1,pesoKg:parseFloat(g('x-peso')?g('x-peso').value:'')||0,
    remito:{numero:g('x-rem').value.trim(),url:(old.remito&&old.remito.url)||''},
    factura:{numero:g('x-fac').value.trim(),importe:parseFloat(g('x-imp').value)||0,estado:g('x-fes').value,vence:g('x-ven').value,url:(old.factura&&old.factura.url)||''},
    observaciones:old.observaciones||[],historial:old.historial||[{estado:'programada',ts:new Date().toISOString(),por:'Administración'}]};
  if(xy){e.lat=xy.lat;e.lng=xy.lng;}
  try{
    if(assets&&S.mode==='live'){
      var pr=g('x-prem'),pf=g('x-pfac');
      if(pr&&pr.files[0]){var u1=await assets.upload(pr.files[0]);e.remito.url=u1.url;}
      if(pf&&pf.files[0]){var u2=await assets.upload(pf.files[0]);e.factura.url=u2.url;}
    }
    await persist(e);S.ui.formOpen=false;S.ui.edit=null;toast('Entrega guardada');render();
  }catch(err){toast('No se pudo guardar la entrega.');}
});
function wBulkLive(d){return wBulk(['skus','ubic','kardex'],d);}
document.addEventListener('submit',async function(ev){
  var id=ev.target.id,g=function(i){return document.getElementById(i);};
  if(id==='form-user'){ev.preventDefault();try{await apiJson('POST','/api/users',{name:g('n-nom').value,email:g('n-mail').value,role:g('n-rol').value,password:g('n-pas').value});toast('Usuario creado');ev.target.reset();loadUsers();}catch(e){toast(e.message);}return;}
  if(id==='form-mov'){ev.preventDefault();
    var tipo=g('m-tipo').value,sku=g('m-sku').value,ubi=g('m-ubi').value,des=g('m-des')?g('m-des').value:'',can=parseInt(g('m-can').value,10),fec=g('m-fec').value,ope=g('m-ope').value.trim()||actor();
    if(!sku||!ubi||!(can>0)){toast('Completá SKU, ubicación y cantidad.');return;}
    var st=wStock(),have=st.m[ubi+'|'+sku]||0;
    var lotM=g('m-lot')?g('m-lot').value.trim():'',vtoM=g('m-vto')?g('m-vto').value:'';
    if(tipo!=='IN'){var lt0=lotM?wLotes().filter(function(l){return l.sku===sku&&l.ubi===ubi&&l.lote===lotM;})[0]:null;if(lt0)vtoM=lt0.vence||'';
      var disp=lotM?(lt0?lt0.q:0):have;
      if(can>disp){toast(lotM?'No alcanza el lote '+lotM+' en '+ubi+': hay '+disp+'.':'No alcanza el stock en '+ubi+': hay '+have+'.');return;}}
    if(tipo==='TRANSFERENCIA'&&(!des||des===ubi)){toast('Elegí una ubicación destino distinta.');return;}
    var mk=function(u,i,o){var r0={id:'M'+Date.now().toString(36)+Math.random().toString(36).slice(2,6),fecha:fec,tipo:tipo,sku:sku,ubicacion:u,'in':i,out:o,operador:ope};if(lotM){r0.lote=lotM;if(vtoM)r0.vence=vtoM;}if(S.ui.fefoNota)r0.nota=S.ui.fefoNota;return r0;};
    try{
      if(tipo==='IN')await wPut('kardex',mk(ubi,can,0));
      else if(tipo==='OUT')await wPut('kardex',mk(ubi,0,can));
      else{await wPut('kardex',mk(ubi,0,can));await wPut('kardex',mk(des,can,0));}
      toast('Movimiento registrado');S.ui.m={tipo:tipo,sku:sku,ubi:ubi};render();
    }catch(e){toast('No se pudo registrar el movimiento.');}
  }else if(id==='form-sku'){ev.preventDefault();var c=g('s-cod').value.trim();
    var w0=W(),ex0=w0.skus.filter(function(z){return z.codigo===c;})[0]||{},ini=parseInt(g('s-ini').value,10)||0,ubN=locParse(g('s-ubi').value),ubC=ubN?locFmt(ubN.p,ubN.r,ubN.u,ubN.a):'';
    if(!c){toast('Falta el código.');return;}
    if(ini>0&&(!ubC||!w0.ubic.some(function(u){return u.codigo===ubC;}))){toast('Para cargar stock inicial elegí una ubicación que exista (por ejemplo 01:01:01:00). Si no existe, creala más abajo en Ubicaciones.');return;}
    var o0=Object.assign({},ex0,{id:c,codigo:c,producto:g('s-pro').value.trim(),categoria:g('s-cat').value.trim(),um:g('s-um').value.trim()||'UN',min:parseFloat(g('s-min').value)||0,max:parseFloat(g('s-max').value)||0,ubic:ubC||g('s-ubi').value.trim(),deposito:g('s-dep').value.trim(),peso:parseFloat(g('s-pes').value)||0});
    if(g('s-prov').value.trim())o0.prov=g('s-prov').value.trim();
    [['s-lead','lead'],['s-costo','costo'],['s-vol','vol']].forEach(function(q){var v=parseFloat(g(q[0]).value);if(!isNaN(v))o0[q[1]]=v;});
    try{await wPut('skus',o0);
      if(ini>0)await wPut('kardex',{id:'M'+Date.now().toString(36)+Math.random().toString(36).slice(2,6),fecha:HOY,tipo:'IN',sku:c,ubicacion:ubC,'in':ini,out:0,operador:actor()});
      toast(ini>0?'SKU guardado con '+ini+' unidades en '+ubC:'SKU guardado');ev.target.reset();render();}catch(_){toast('No se pudo guardar.');}
  }else if(id==='form-gen'){ev.preventDefault();
    var gp=parseInt(g('g-pas').value,10)||0,gr=parseInt(g('g-rack').value,10)||0,gu=parseInt(g('g-ubi').value,10)||0,ga=parseInt(g('g-alt').value,10)||0,gc=parseFloat(g('g-cap').value)||0,gk=parseFloat(g('g-kg').value)||0,gd=g('g-dep').value.trim(),gt=gp*gr*gu*ga;
    if(!(gt>0)){toast('Completá pasillos, racks, ubicaciones y alturas.');return;}
    if(gt>5000){toast('Son '+gt+' posiciones; el máximo por vez es 5.000.');return;}
    var gex={};W().ubic.forEach(function(u){gex[u.codigo]=1;});var garr=[];
    for(var i1=1;i1<=gp;i1++)for(var i2=1;i2<=gr;i2++)for(var i3=1;i3<=gu;i3++)for(var i4=0;i4<ga;i4++){var cd=locFmt(i1,i2,i3,i4);if(!gex[cd]){var ob={id:cd,codigo:cd,descripcion:'',deposito:gd,cap:gc};if(gk)ob.capKg=gk;garr.push(ob);}}
    if(!garr.length){toast('Esas posiciones ya existen.');return;}
    try{toast('Creando '+garr.length+' posiciones…');await wBulk(['ubic'],{ubic:garr});toast(garr.length+' posiciones creadas');render();}catch(_){toast('No se pudieron crear todas.');}
  }else if(id==='form-ubi'){ev.preventDefault();var c2=locParse(g('u-cod').value);if(!c2){toast('Usá el formato pasillo:rack:ubicación:altura, por ejemplo 01:01:01:00 (altura 00 = piso).');return;}c2=locFmt(c2.p,c2.r,c2.u,c2.a);
    try{await wPut('ubic',{id:c2,codigo:c2,descripcion:g('u-des').value.trim(),deposito:g('u-dep').value.trim(),cap:parseFloat(g('u-cap').value)||0,capKg:parseFloat(g('u-kg').value)||0});toast('Ubicación guardada');ev.target.reset();}catch(_){toast('No se pudo guardar.');}
  }
});
async function aplicarOrden(){
  var ch=S.ui.optChofer||(D().perfiles.filter(function(p){return p.rol==='chofer';})[0]||{}).id,dia=diaStr(S.ui.optDia==='manana'?'manana':'hoy');
  var route=D().entregas.filter(function(e){return e.choferId===ch&&e.fecha===dia;}).sort(function(a,b){return (a.orden||0)-(b.orden||0);});
  var locked=[];for(var i=0;i<route.length;i++){var s=route[i];if(s.estado==='entregada'||s.estado==='no_entregada'||s.estado==='en_camino')locked.push(s);else break;}
  var free=route.filter(function(e){return locked.indexOf(e)<0;}),freeXY=free.filter(hasXY),freeNo=free.filter(function(e){return !hasXY(e);});
  var lastLocked=locked.filter(hasXY).slice(-1)[0],best=optimize(lastLocked||D().depot,freeXY).concat(freeNo),final=locked.concat(best);
  try{for(var k=0;k<final.length;k++){if(final[k].orden!==k+1){var e=clean(final[k]);e.orden=k+1;await persist(e);}}toast('Orden aplicado. El chofer ya lo ve actualizado.');}
  catch(_){toast('No se pudo aplicar el orden.');}
}

/* ---------- arranque ---------- */
async function boot(){
  render();
  try{
    if(window.claude&&window.claude.use){user=await window.claude.use('user');db=await window.claude.use('db');assets=await window.claude.use('assets');}
  }catch(_){}
  if(!db){S.hasDb=false;S.mode='demo';S.note='Demostración con datos de ejemplo ficticios.';render();return;}
  S.hasDb=true;
  try{
    var me=await user.me();S.me={id:me.id,name:me.name||''};
    S.isAdmin=!!(me.isOwner||me.canEdit);
    if(S.isAdmin){S.perfil={rol:'admin',nombre:me.name||'Administración'};}
    else if(me.id){var snap=await db.doc('perfiles/'+me.id).get();S.perfil=snap.exists?snap.data():null;}
    S.perfilListo=true;S.mode='live';
    if(S.isAdmin||S.perfil)startLive();
    if(S.isAdmin)loadUsers();
  }catch(_){S.perfilListo=true;S.mode='demo';S.note='No se pudo verificar tu cuenta. Mostrando la demostración.';}
  render();
}
/* EXT11 start */
/* ===== EXT11: carga y salida de datos del depósito por planilla + botón de soporte ===== */
var norm11=function(s){return String(s==null?'':s).normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');};
var WCOLS11=['Código','Producto','Categoría','U.M.','Stock mínimo','Stock máximo','Ubicación','Stock actual','Peso (kg)','Costo','Proveedor','Plazo proveedor (días)','Lote','Vencimiento'];
function wPlantillaCsv(){
  guardarArchivo('plantilla-productos-y-stock.csv',csvOut([WCOLS11,
    ['P100','Pintura látex 20 L','Pinturas','UN','10','60','01:01:01:00','35','24','48000','Proveedor SA','7','L2611','2027-06-30'],
    ['P101','Rodillo 22 cm','Accesorios','UN','20','120','01:01:02:00','80','0.2','900','','','','']]),'text/csv;charset=utf-8');}
S.ext.wmsImp=S.ext.wmsImp||{errs:[],ok:''};
async function wmsImportRows(rows){
  var R=S.ext.wmsImp=S.ext.wmsImp||{errs:[],ok:''};R.errs=[];R.ok='';
  if(!rows||rows.length<2){R.errs=['El archivo no tiene filas para importar.'];render();return;}
  if(rows.length>15001){R.errs=['El archivo tiene más de 15.000 filas. Dividilo en partes.'];render();return;}
  var al={codigo:'cod',sku:'cod',producto:'pro',descripcion:'pro',nombre:'pro',categoria:'cat',um:'um',unidad:'um',stockminimo:'min',minimo:'min',min:'min',stockmaximo:'max',maximo:'max',max:'max',ubicacion:'ubi',stockactual:'stk',stock:'stk',cantidad:'stk',pesokg:'pes',peso:'pes',costo:'costo',precio:'costo',proveedor:'prov',plazoproveedordias:'lead',plazo:'lead',leadtime:'lead',lote:'lote',vencimiento:'vto',vence:'vto',fechadevencimiento:'vto'};
  var ix={};rows[0].forEach(function(h,i){var k=al[norm11(h)];if(k&&ix[k]==null)ix[k]=i;});
  if(ix.cod==null||ix.pro==null){R.errs=['Faltan las columnas Código y Producto. Descargá la plantilla y usá esos encabezados.'];render();return;}
  var num=function(x){var n=typeof x==='number'?x:parseFloat(String(x==null?'':x).trim().replace(',','.'));return isNaN(n)?null:n;};
  var w=W(),exS={},exU={};w.skus.forEach(function(s){exS[s.codigo]=s;});w.ubic.forEach(function(u){exU[u.codigo]=true;});
  var cur=wStock().m,curL={},errs=[],skus={},ubs={},movs=[],seen={},nIgn=0;wLotes().forEach(function(l){curL[l.sku+'|'+l.ubi+'|'+l.lote]=l.q;});var idb=Date.now().toString(36)+Math.random().toString(36).slice(2,6),idn=0;
  for(var i=1;i<rows.length;i++){
    var r=rows[i]||[],c=function(k){return ix[k]==null?'':r[ix[k]];},lin='Fila '+(i+1),cod=String(c('cod')).trim(),pro=String(c('pro')).trim();
    if(!cod&&!pro){nIgn++;continue;}
    if(!cod||!pro){errs.push(lin+': falta el código o el producto.');continue;}
    var ub=String(c('ubi')).trim(),ubC='';
    if(ub){var pp=locParse(ub);if(!pp){errs.push(lin+': la ubicación "'+ub+'" no tiene el formato 01:01:01:00 (pasillo:rack:ubicación:altura). Si Excel la convirtió en hora, formateá la columna como Texto.');continue;}ubC=locFmt(pp.p,pp.r,pp.u,pp.a);}
    var stk=null;if(String(c('stk')).trim()!==''){stk=num(c('stk'));if(stk==null||stk<0){errs.push(lin+': el stock "'+c('stk')+'" no es un número válido.');continue;}}
    if(stk>0&&!ubC){errs.push(lin+': para cargar stock hace falta la ubicación.');continue;}
    var lot=String(c('lote')).trim().slice(0,30),vto='';
    if(String(c('vto')).trim()!==''){vto=pFecha(c('vto'));if(!/^\d{4}-\d{2}-\d{2}$/.test(vto)){errs.push(lin+': el vencimiento "'+c('vto')+'" no es una fecha válida (usá AAAA-MM-DD).');continue;}}
    if(vto&&!lot){errs.push(lin+': si hay vencimiento, falta el lote.');continue;}
    var key=cod+'|'+ubC+'|'+lot;if(seen[key]){errs.push(lin+': el código '+cod+' está repetido en la misma ubicación'+(lot?' y lote':'')+'.');continue;}seen[key]=1;
    var o=skus[cod]||Object.assign({um:'UN',min:0,max:0,peso:0},exS[cod]||{},{id:cod,codigo:cod});
    o.producto=pro;
    var tx=function(k,f){var v=String(c(k)).trim();if(v)o[f]=v;},nu=function(k,f){var v=String(c(k)).trim()===''?null:num(c(k));if(v!=null&&v>=0)o[f]=v;};
    tx('cat','categoria');tx('um','um');tx('prov','prov');nu('min','min');nu('max','max');nu('pes','peso');nu('costo','costo');nu('lead','lead');
    if(ubC&&!o.ubic)o.ubic=ubC;
    skus[cod]=o;
    if(ubC){
      if(!exU[ubC]&&!ubs[ubC])ubs[ubC]={id:ubC,codigo:ubC,descripcion:'',deposito:'',cap:150};
      if(stk!=null){var dif=stk-(lot?(curL[cod+'|'+ubC+'|'+lot]||0):(cur[ubC+'|'+cod]||0));if(dif!==0){var mv={id:'A'+idb+'-'+(idn++),fecha:HOY,tipo:'AJUSTE',sku:cod,ubicacion:ubC,'in':dif>0?dif:0,out:dif<0?-dif:0,operador:actor(),nota:'Carga por planilla'};if(lot){mv.lote=lot;if(vto)mv.vence=vto;}movs.push(mv);}}}
  }
  if(errs.length){R.errs=errs.slice(0,8).concat(errs.length>8?['…y '+(errs.length-8)+' más. No se importó nada: corregí el archivo y volvé a elegirlo.']:['No se importó nada: corregí el archivo y volvé a elegirlo.']);render();return;}
  var sk=Object.keys(skus).map(function(k){return skus[k];}),ub2=Object.keys(ubs).map(function(k){return ubs[k];});
  if(!sk.length){R.errs=['No encontré filas con datos.'];render();return;}
  try{toast('Cargando '+sk.length+' productos…');await wBulk(['ubic'],{ubic:ub2});await wBulk(['skus'],{skus:sk});await wBulk(['kardex'],{kardex:movs});
    var pl=function(n,a,b){return n+' '+(n===1?a:b);};R.ok=pl(sk.length,'producto actualizado','productos actualizados')+', '+pl(ub2.length,'ubicación nueva','ubicaciones nuevas')+' y '+pl(movs.length,'ajuste de stock','ajustes de stock')+'.';toast(R.ok);}
  catch(e){R.errs=['No se pudo guardar. Revisá la conexión y probá de nuevo.'];}
  render();}
var _iw11=importWms;
async function wmsImportFile(f){
  try{toast('Leyendo el archivo…');var rows;
    if(/\.(csv|txt)$/i.test(f.name))rows=csvParse(await leerTxt(f));
    else{await loadXLSX();var wb=XLSX.read(await f.arrayBuffer(),{type:'array'});
      if(wb.SheetNames.some(function(n){return /maestro sku|kardex/i.test(n);}))return _iw11(f);
      rows=XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]],{header:1,raw:true,defval:''});}
    await wmsImportRows(rows);
  }catch(e){toast('No se pudo leer el archivo.');}}
importWms=wmsImportFile;
function wExport11(kind){
  var w=W(),s=wStock(),rows,nm;
  if(kind==='stock'){nm='stock';rows=[['Código','Producto','Categoría','U.M.','Ubicación','Stock','Mínimo','Máximo','Costo unitario','Valor']];
    var by={};Object.keys(s.m).forEach(function(k){var p=k.indexOf('|'),q=s.m[k];if(q!==0)(by[k.slice(p+1)]=by[k.slice(p+1)]||[]).push([k.slice(0,p),q]);});
    w.skus.forEach(function(k){var l=by[k.codigo]||[['',0]];l.forEach(function(x){rows.push([k.codigo,k.producto,k.categoria||'',k.um||'',x[0],x[1],k.min||0,k.max||0,k.costo==null?'':k.costo,k.costo==null?'':Math.round(x[1]*k.costo*100)/100]);});});}
  else if(kind==='ubic'){nm='ubicaciones';rows=[['Código','Descripción','Depósito','Capacidad (unidades)','Peso máximo (kg)']].concat(w.ubic.map(function(u){return [u.codigo,u.descripcion||'',u.deposito||'',u.cap||0,u.capKg||''];}));}
  else{nm='movimientos';rows=[['Fecha','Tipo','Código','Ubicación','Entrada','Salida','Operador','Lote','Vence','Nota']].concat(w.kardex.slice().sort(function(a,b){return String(a.fecha).localeCompare(String(b.fecha));}).map(function(x){return [x.fecha,x.tipo,x.sku,x.ubicacion,x['in']||0,x.out||0,x.operador||'',x.lote||'',x.vence||'',x.nota||''];}));}
  guardarArchivo(nm+'-'+HOY+'.csv',csvOut(rows),'text/csv;charset=utf-8');}
function wPanel11(){
  var R=S.ext.wmsImp||{errs:[],ok:''};
  return '<div class="panel"><h3>Cargar productos y stock desde una planilla</h3>'+
   '<p class="small muted" style="margin:0">Una fila por producto y ubicación (o por pallet, con las columnas opcionales Lote y Vencimiento). «Stock actual» es lo que hay hoy en esa ubicación: el portal registra solo la diferencia como ajuste, así que podés volver a subir el archivo sin duplicar stock. Si la ubicación no existe, se crea. Acepta CSV o Excel (también el Excel de 3 hojas Maestro SKU / Ubicaciones / Kardex).</p>'+
   '<div class="row"><button class="btn" data-act="x11-wplantilla">Descargar plantilla (CSV)</button><label class="btn pri" style="cursor:pointer">Elegir archivo<input id="w-csv" type="file" accept=".csv,.txt,.xlsx,.xls" hidden></label></div>'+
   (R.ok?'<div class="banner ok" role="status"><div><strong>Listo</strong>'+esc(R.ok)+'</div></div>':'')+
   (R.errs.length?'<div class="banner bad" role="alert">'+ICON.alert+'<div><strong>No se pudo importar</strong>'+R.errs.map(function(e){return esc(e);}).join('<br>')+'</div></div>':'')+
   '<div class="small muted" style="margin-top:10px">Llevate tus datos cuando quieras (se abren en Excel):</div><div class="row"><button class="btn sm" data-act="x11-wexp" data-k="stock">Stock y valor</button><button class="btn sm" data-act="x11-wexp" data-k="ubic">Ubicaciones</button><button class="btn sm" data-act="x11-wexp" data-k="kardex">Movimientos</button></div></div>';}
var _wM11=wMaestros;wMaestros=function(){return wPanel11()+_wM11.apply(this,arguments);};
var _xI11=xImp;xImp=function(){return _xI11.apply(this,arguments)+wPanel11();};
document.addEventListener('click',function(ev){var b=ev.target.closest&&ev.target.closest('[data-act^="x11-"]');if(!b)return;
  if(b.dataset.act==='x11-wplantilla')wPlantillaCsv();else if(b.dataset.act==='x11-wexp')wExport11(b.dataset.k);});
document.addEventListener('change',function(ev){var t=ev.target;if(t&&t.id==='w-csv'&&t.files&&t.files[0]){var f=t.files[0];t.value='';wmsImportFile(f);}});
/* botón de soporte por WhatsApp: se activa cargando el número en comercial.json */
try{fetch('/comercial.json',{credentials:'same-origin'}).then(function(r){return r.ok?r.json():null;}).then(function(c){
  var n=c&&String(c.whatsapp||'').replace(/\D/g,'');if(!n||n.length<8||document.getElementById('wa-soporte'))return;
  var a=document.createElement('a');a.id='wa-soporte';a.className='btn pri';a.target='_blank';a.rel='noopener';a.textContent='Ayuda por WhatsApp';
  a.href='https://wa.me/'+n+'?text='+encodeURIComponent('Hola, necesito ayuda con el Portal Logístico.');
  a.style.cssText='position:fixed;right:14px;bottom:14px;z-index:50;box-shadow:0 4px 14px rgba(0,0,0,.35)';document.body.appendChild(a);}).catch(function(){});}catch(_){}
/* botón de inicio: el nombre del portal lleva a la pantalla principal */
document.addEventListener('click',function(ev){var a=ev.target.closest&&ev.target.closest('[data-act="x12-inicio"]');if(!a)return;
  if(ev.metaKey||ev.ctrlKey||ev.shiftKey||ev.button===1)return;
  ev.preventDefault();S.ui.tab='op';S.ui.formOpen=false;S.ui.edit=null;if(S.ext){S.ext.pod=null;}render();try{window.scrollTo(0,0);}catch(_){}});
/* EXT11 end */
/* ===== EXT13: botones de acción en avisos y paneles ===== */
var DEST13={
  equipos:{l:'Ver equipos',tab:'eq',eqsub:'equipos'},
  fichas:{l:'Ver fichas de choferes',tab:'eq',eqsub:'personal'},
  checks:{l:'Ir a check lists',tab:'eq',eqsub:'historial'},
  lotes:{l:'Ver lotes',tab:'wms',wsub:'lotes'},
  repo:{l:'Ver reposición',tab:'wms',wsub:'x8rep'},
  maestros:{l:'Cargar pesos en productos',tab:'wms',wsub:'maestros'},
  viajes:{l:'Ir a Viajes',tab:'viajes'},
  carga:{l:'Ir a Puesta en marcha',tab:'gest',gsub:'carga'},
  lunes:{l:'Ver lo que falta (Lunes OK)',tab:'gest',gsub:'lunes'}
};
var RULES13=[
  {h:/Consentimiento de ubicación de choferes/,d:'fichas'},
  {b:/service vencido|fuera de servicio|documentaci[oó]n (por vencer|vencida)|Vencimientos para revisar/i,d:'equipos'},
  {b:/check list/i,d:'checks'},
  {b:/para reordenar/i,d:'repo'},
  {b:/lotes? vencid|por vencer en 30/i,d:'lotes'},
  {b:/Faltan pesos de/i,d:'maestros'},
  {b:/Todav[ií]a no hay entregas cargadas/i,d:'viajes'}
];
function aqui13(d){var D=DEST13[d];if(!D)return true;
  if(D.tab==='eq')return S.ui.tab==='eq'&&(S.ui.eqsub||'equipos')===D.eqsub;
  if(D.tab==='wms')return S.ui.wsub===D.wsub&&(rolActual()==='deposito'||S.ui.tab==='wms');
  if(D.tab==='gest')return S.ui.tab==='gest'&&S.ext.sub===D.gsub;
  return S.ui.tab===D.tab;}
function enhance13(){
  var rol=rolActual();if(rol!=='admin'&&rol!=='deposito')return;
  var main=document.querySelector('#app main');if(!main)return;
  var add=function(el,d,inner){var D=DEST13[d];if(!D||aqui13(d))return;if(rol==='deposito'&&D.tab!=='wms')return;
    if(el.querySelector('button,a,[data-act]'))return;
    var box=document.createElement('div');box.className='row';box.style.marginTop='8px';
    box.innerHTML='<button class="btn sm" data-act="x13-go" data-d="'+d+'">'+esc(D.l)+' →</button>';
    (inner&&el.lastElementChild?el.lastElementChild:el).appendChild(box);};
  main.querySelectorAll('.banner').forEach(function(el){var t=el.textContent;for(var i=0;i<RULES13.length;i++){var r=RULES13[i];if(r.b&&r.b.test(t)){add(el,r.d,true);break;}}});
  main.querySelectorAll('.panel').forEach(function(el){var h=el.querySelector('h3');if(!h)return;var t=h.textContent;for(var i=0;i<RULES13.length;i++){var r=RULES13[i];if(r.h&&r.h.test(t)){add(el,r.d,false);break;}}});}
var _render13=render;
render=function(){_render13.apply(this,arguments);try{enhance13();}catch(_){}};
document.addEventListener('click',function(ev){var b=ev.target.closest&&ev.target.closest('[data-act="x13-go"]');if(!b)return;var D=DEST13[b.dataset.d];if(!D)return;
  ev.preventDefault();
  if(D.tab==='eq'){S.ui.tab='eq';S.ui.eqsub=D.eqsub;S.ui.eqf=null;S.ui.fic=null;S.ui.chk=null;}
  else if(D.tab==='wms'){if(rolActual()==='admin')S.ui.tab='wms';S.ui.wsub=D.wsub;}
  else if(D.tab==='gest'){S.ui.tab='gest';S.ext.sub=D.gsub;}
  else S.ui.tab=D.tab;
  render();try{window.scrollTo(0,0);}catch(_){}});
/* EXT13 end */
/* ===== EXT15: viajes de larga distancia — alta manual y planilla CSV ===== */
S.ext.vj=S.ext.vj||{open:false};
var VJ_COLS=['Guía (opcional)','Fecha (AAAA-MM-DD)','Transportista','Ruta','Vehículo','Km','Toneladas','Tarifa pactada por km','Costo real por km','Peaje'];
function vjFecha(x){x=String(x==null?'':x).trim();var m=x.match(/^(\d{4})-(\d{2})-(\d{2})/);if(m)return m[1]+'-'+m[2]+'-'+m[3];m=x.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/);if(m)return m[3]+'-'+('0'+m[2]).slice(-2)+'-'+('0'+m[1]).slice(-2);return '';}
function vjNum(x){var n=typeof x==='number'?x:parseFloat(String(x==null?'':x).trim().replace(/\./g,function(d,i,s){return /,/.test(s)?'':d;}).replace(',','.'));return isNaN(n)?0:n;}
function vjPanel(){
  var o=S.ext.vj||{};
  var h='<div class="row"><button class="btn pri" data-act="x15-vjnew">'+(o.open?'Cerrar formulario':'Nuevo viaje')+'</button><button class="btn" data-act="x15-vjplant">Plantilla de planilla (CSV)</button></div>';
  if(!o.open)return h;
  var VEH=['Camión','Camioneta','Semirremolque','Utilitario'];
  return h+'<form class="panel" id="form-viaje" autocomplete="off"><h3>Nuevo viaje</h3><p class="small muted" style="margin:0">La <strong>tarifa pactada</strong> es lo que acordaste pagar por km. El <strong>costo real</strong> es lo que finalmente se pagó por km. El portal compara los dos y marca los viajes que se pasaron del presupuesto.</p><div class="grid2">'+
   '<label>Guía o número (opcional)<input id="vj-guia" maxlength="30" placeholder="Si lo dejás vacío se arma solo"></label>'+
   '<label>Fecha<input id="vj-fec" type="date" required value="'+HOY+'"></label>'+
   '<label>Transportista<input id="vj-pro" required maxlength="60" placeholder="Ej.: Trans SRL"></label>'+
   '<label>Ruta<input id="vj-rut" required maxlength="80" placeholder="Ej.: Buenos Aires - Rosario"></label>'+
   '<label>Vehículo<input id="vj-veh" list="dl-vjveh" maxlength="40" placeholder="Camión"><datalist id="dl-vjveh">'+VEH.map(function(v){return '<option value="'+v+'">';}).join('')+'</datalist></label>'+
   '<label>Kilómetros<input id="vj-km" type="number" min="1" step="any" required></label>'+
   '<label>Toneladas<input id="vj-ton" type="number" min="0" step="any" placeholder="0"></label>'+
   '<label>Tarifa pactada por km ($)<input id="vj-tar" type="number" min="1" step="any" required></label>'+
   '<label>Costo real por km ($)<input id="vj-cos" type="number" min="1" step="any" required></label>'+
   '<label>Peaje total ($)<input id="vj-pea" type="number" min="0" step="any" placeholder="0"></label></div>'+
   '<div class="row"><button class="btn pri" type="submit">Guardar viaje</button></div></form>';}
async function vjGuardar(v){
  if(S.mode==='demo'){var m={};S.data.demo.viajes.concat([v]).forEach(function(x){m[x.id]=x;});S.data.demo.viajes=Object.keys(m).map(function(k){return m[k];});render();return;}
  await db.doc('viajes/'+v.id).set(clean(v));}
async function vjImportCsv(file){
  try{var rows=csvParse(await leerTxt(file));
    if(rows.length<2){toast('El archivo no tiene filas.');return;}
    var al={guia:'guia',guiaopcional:'guia',fecha:'fec',fechaaaaammdd:'fec',transportista:'pro',proveedor:'pro',ruta:'rut',vehiculo:'veh',km:'km',kilometros:'km',toneladas:'ton',ton:'ton',tarifapactadaporkm:'tar',tarifa:'tar',costorealporkm:'cos',costokm:'cos',costo:'cos',peaje:'pea',peajes:'pea'};
    var ix={};rows[0].forEach(function(h,i){var k=al[norm11(h)];if(k&&ix[k]==null)ix[k]=i;});
    var falt=['fec','pro','rut','km','tar','cos'].filter(function(k){return ix[k]==null;});
    if(falt.length){toast('Faltan columnas. Descargá la plantilla y usá esos encabezados.');return;}
    var out=[],err=[],seen={};
    rows.slice(1).forEach(function(r,i){var c=function(k){return ix[k]==null?'':r[ix[k]];};if(!r||r.every(function(x){return String(x||'').trim()==='';}))return;
      var f=vjFecha(c('fec')),km=vjNum(c('km')),tar=vjNum(c('tar')),cos=vjNum(c('cos')),pro=String(c('pro')).trim(),rut=String(c('rut')).trim();
      var e=!f?'fecha no válida (usá AAAA-MM-DD o DD/MM/AAAA)':!pro?'falta el transportista':!rut?'falta la ruta':!(km>0)?'faltan los km':!(tar>0)?'falta la tarifa pactada':!(cos>0)?'falta el costo real':'';
      if(e){err.push('Fila '+(i+2)+': '+e);return;}
      var id=String(c('guia')).trim()||('V'+Date.now().toString(36)+i);if(!/^[A-Za-z0-9][A-Za-z0-9-]*$/.test(id)){err.push('Fila '+(i+2)+': la guía solo puede tener letras, números y guiones');return;}
      if(seen[id]){err.push('Fila '+(i+2)+': la guía '+id+' está repetida');return;}seen[id]=1;
      out.push({id:id,guia:id,fecha:f,proveedor:pro,ruta:rut,vehiculo:String(c('veh')).trim(),km:km,ton:vjNum(c('ton')),tarifaKm:tar,costoKm:cos,peaje:vjNum(c('pea'))});});
    if(err.length){toast(err.slice(0,3).join(' · ')+(err.length>3?' · y '+(err.length-3)+' más. No se importó nada.':'. No se importó nada.'));return;}
    if(!out.length){toast('No hay viajes para importar.');return;}
    for(var i=0;i<out.length;i+=10)await Promise.all(out.slice(i,i+10).map(vjGuardar));
    toast(out.length+(out.length===1?' viaje importado.':' viajes importados.'));
  }catch(e){toast('No se pudo importar el archivo.');}}
var _iv15=importViajes;importViajes=async function(f){if(/\.(csv|txt)$/i.test(f.name))return vjImportCsv(f);return _iv15(f);};
var _vv15=viewViajes;viewViajes=function(){var out=_vv15.apply(this,arguments),k='</label></div>',i=out.indexOf(k);return i<0?out:out.slice(0,i+k.length)+vjPanel()+out.slice(i+k.length);};
document.addEventListener('click',function(ev){var b=ev.target.closest&&ev.target.closest('[data-act^="x15-"]');if(!b)return;
  if(b.dataset.act==='x15-vjnew'){S.ext.vj.open=!S.ext.vj.open;render();}
  else if(b.dataset.act==='x15-vjplant'){guardarArchivo('plantilla-viajes.csv',csvOut([VJ_COLS,['G-0001',HOY,'Trans SRL','Buenos Aires - Rosario','Camión','300','10.8','1840','1815','17600'],['G-0002',HOY,'Logística Norte','Buenos Aires - Córdoba','Camioneta','700','3.7','950','1035','35200']]),'text/csv;charset=utf-8');}});
document.addEventListener('submit',async function(ev){var f=ev.target;if(!f||f.id!=='form-viaje')return;ev.preventDefault();
  var g=function(i){return (document.getElementById(i)||{}).value||'';};
  var fec=vjFecha(g('vj-fec')),km=vjNum(g('vj-km')),tar=vjNum(g('vj-tar')),cos=vjNum(g('vj-cos')),pro=g('vj-pro').trim(),rut=g('vj-rut').trim(),gu=g('vj-guia').trim();
  if(!fec||!pro||!rut||!(km>0)||!(tar>0)||!(cos>0)){toast('Completá fecha, transportista, ruta, km, tarifa pactada y costo real.');return;}
  if(gu&&!/^[A-Za-z0-9][A-Za-z0-9-]*$/.test(gu)){toast('La guía solo puede tener letras, números y guiones.');return;}
  var id=gu||('V'+Date.now().toString(36));
  try{await vjGuardar({id:id,guia:id,fecha:fec,proveedor:pro,ruta:rut,vehiculo:g('vj-veh').trim(),km:km,ton:vjNum(g('vj-ton')),tarifaKm:tar,costoKm:cos,peaje:vjNum(g('vj-pea'))});S.ext.vj.open=false;toast('Viaje guardado');render();}
  catch(e){toast('No se pudo guardar el viaje.');}});
/* EXT15 end */
/* ===== EXT16: rapidez de uso — inicio del depósito (acciones + buscador) y paradas del chofer más cortas ===== */
WSUBS_ALL.unshift(['inicio','Inicio']);WSUBS_DEP.unshift('inicio');if(WSUBS_DEP.indexOf('mov')<0)WSUBS_DEP.push('mov');
var _vd16=viewDeposito;viewDeposito=function(){if(S.ui.dep==null){S.ui.dep='wms';S.ui.wsub='inicio';}return _vd16.apply(this,arguments);};
var _vw16=viewWms;viewWms=function(){if(S.ui.wsub==='inicio')return '<div class="row sp"><h2>Depósito</h2></div>'+wSub()+wInicio();return _vw16.apply(this,arguments);};
function wInicio(){
  var w=W(),st=wStock(),q=String(S.ui.qdep||'').trim().toLowerCase();
  var pk=(WC('picks')||[]).filter(function(p){return p.estado==='pendiente';}).length,rj=(typeof wRepo==='function'?null:null);
  var A=[['recep','Recibir mercadería','Ingresar lo que llegó'],['picking','Preparar pedido',pk?pk+(pk===1?' pedido pendiente':' pedidos pendientes'):'Picking paso a paso'],['mov','Mover o sacar stock','Entradas, salidas, transferencias'],['conteos','Contar stock','Conteo físico']];
  var h='<div class="panel"><h3>¿Qué hacés ahora?</h3><div class="grid2" style="gap:10px">'+A.map(function(a){return '<button class="btn pri" style="min-height:68px;text-align:left;display:block" data-act="wsub" data-v="'+a[0]+'"><strong>'+a[1]+'</strong><br><span class="small" style="opacity:.85">'+a[2]+'</span></button>';}).join('')+'</div></div>';
  h+='<div class="panel"><h3>Buscar</h3><label>Producto o ubicación<input id="q-dep" type="search" inputmode="search" placeholder="Código, nombre o ubicación (ej. 01:02)" value="'+esc(S.ui.qdep||'')+'" autocomplete="off"></label>';
  if(q){
    var by={};Object.keys(st.m).forEach(function(k){var p=k.indexOf('|'),n=st.m[k];if(n>0)(by[k.slice(p+1)]=by[k.slice(p+1)]||[]).push([k.slice(0,p),n]);});
    var hits=w.skus.filter(function(k){return (k.codigo+' '+k.producto+' '+(k.categoria||'')).toLowerCase().indexOf(q)>=0;});
    var ubs=w.ubic.filter(function(u){return u.codigo.toLowerCase().indexOf(q)>=0;}).slice(0,6);
    var row=function(k){var l=(by[k.codigo]||[]),tot=l.reduce(function(t,x){return t+x[1];},0);
      return '<div class="doc"><span class="k"><strong>'+esc(k.codigo)+'</strong> · '+esc(k.producto)+'</span><span class="v">'+(tot?'Total '+nf(tot)+' · '+l.map(function(x){return '<span class="mono">'+esc(x[0])+'</span> ('+nf(x[1])+')';}).join(' · '):'Sin stock')+'</span>'+
        (l.length?'<span class="v"><button class="btn sm" data-act="x16-mover" data-sku="'+esc(k.codigo)+'" data-ubi="'+esc(l[0][0])+'">Mover o sacar</button></span>':'')+'</div>';};
    h+=hits.slice(0,8).map(row).join('');
    if(hits.length>8)h+='<div class="small muted">Hay '+(hits.length-8)+' más: escribí más letras para acotar.</div>';
    h+=ubs.map(function(u){var ps=Object.keys(st.m).filter(function(k){return k.indexOf(u.codigo+'|')===0&&st.m[k]>0;}).map(function(k){return k.slice(u.codigo.length+1)+' ('+nf(st.m[k])+')';});
      return '<div class="doc"><span class="k"><span class="mono">'+esc(u.codigo)+'</span> · ubicación</span><span class="v">'+(ps.length?esc(ps.join(' · ')):'Libre')+'</span></div>';}).join('');
    if(!hits.length&&!ubs.length)h+='<div class="small muted">No encontré nada con "'+esc(q)+'".</div>';}
  return h+'</div>';}
document.addEventListener('input',function(ev){var t=ev.target;if(t&&t.id==='q-dep'){S.ui.qdep=t.value;render();}});
document.addEventListener('click',function(ev){var b=ev.target.closest&&ev.target.closest('[data-act="x16-mover"],[data-act="x16-obs"]');if(!b)return;
  if(b.dataset.act==='x16-mover'){S.ui.m={tipo:'TRANSFERENCIA',sku:b.dataset.sku,ubi:b.dataset.ubi};S.ui.wsub='mov';render();try{window.scrollTo(0,0);}catch(_){}}
  else{S.ui.obsOpen=S.ui.obsOpen===b.dataset.id?null:b.dataset.id;render();}});
/* EXT16 end */
/* ===== EXT17: el cliente habla con tráfico (botones directos) y envía consultas sobre factura, remito, chofer o producto ===== */
var TEMAS17=[['factura','Factura'],['remito','Remito'],['chofer','Chofer'],['producto','Producto'],['otro','Otra consulta']];
function tema17(t){var r=TEMAS17.filter(function(x){return x[0]===t;})[0];return r?r[1]:'Consulta';}
function cons17(){return (S.mode==='demo'?(S.ext.cons17demo||[]):(S.ext.cons17||[])).slice().sort(function(a,b){return String(b.ts).localeCompare(String(a.ts));});}
function chip17(c){var ab=c.estado==='abierta';return '<span class="chip '+(ab?'warn':'ok')+'" style="font-size:.75rem">'+(ab?'Abierta':'Respondida')+'</span>';}
function consItem17(c,admin){
  return '<div class="doc"><span class="k"><strong>'+esc(tema17(c.tema))+'</strong>'+(c.guia?' · '+esc(c.guia):'')+(admin?' · '+esc(c.cliente||''):'')+' '+chip17(c)+'</span>'+
    '<span class="v">'+esc(c.texto)+'</span><span class="small muted">'+esc(fmtHora(c.ts))+'</span>'+
    (c.respuesta?'<span class="v" style="border-left:3px solid var(--acc,#2a7);padding-left:8px"><strong>Respuesta de '+esc(c.respondidoPor||'Tráfico')+':</strong> '+esc(c.respuesta)+'</span>':'')+'</div>';}
function panelCli17(){
  var f=S.ui.q17,all=D().entregas.filter(function(e){return S.mode==='demo'?e.clienteId==='c2':true;}).sort(function(a,b){return String(b.fecha).localeCompare(String(a.fecha));});
  var h='<div class="panel"><h3>¿Necesitás hablar con tráfico?</h3>';
  var t=traf();h+=t.telefono?'<div class="row" style="margin-bottom:10px">'+trafBtns('Hola, soy cliente del portal y quiero hacer una consulta.',false)+'</div>':'<p class="small muted">Tráfico todavía no cargó su teléfono. Mientras tanto podés dejar tu consulta acá abajo.</p>';
  h+='<div class="small muted" style="margin-bottom:6px">O dejá una consulta escrita sobre:</div><div class="row" style="gap:8px;flex-wrap:wrap">'+TEMAS17.map(function(x){return '<button class="btn sm" data-act="x17-q" data-t="'+x[0]+'" aria-pressed="'+(!!f&&f.tema===x[0])+'">'+x[1]+'</button>';}).join('')+'</div>';
  if(f){
    h+='<div style="margin-top:12px"><label>Entrega<select id="q17-ent"><option value="">— No es de una entrega en particular —</option>'+all.map(function(e){return '<option value="'+esc(e.id)+'"'+(f.entregaId===e.id?' selected':'')+'>'+esc(e.guia)+' · '+esc(fmtFecha(e.fecha))+'</option>';}).join('')+'</select></label>'+
      '<label>Tema<select id="q17-tema">'+TEMAS17.map(function(x){return '<option value="'+x[0]+'"'+(f.tema===x[0]?' selected':'')+'>'+x[1]+'</option>';}).join('')+'</select></label>'+
      '<label>Tu consulta<textarea id="q17-txt" maxlength="600" placeholder="'+esc({factura:'Ej.: la factura no coincide con el pedido',remito:'Ej.: no me llegó el remito firmado',chofer:'Ej.: el chofer llegó fuera del horario',producto:'Ej.: faltó un producto / llegó dañado'}[f.tema]||'Contanos qué necesitás')+'"></textarea></label>'+
      '<div class="row"><button class="btn pri" data-act="x17-send">Enviar consulta</button><button class="btn" data-act="x17-cancel">Cancelar</button></div></div>';}
  var mine=cons17().slice(0,5);
  if(mine.length)h+='<h3 style="margin-top:14px">Mis consultas</h3>'+mine.map(function(c){return consItem17(c,false);}).join('');
  return h+'</div>';}
var _vc17=viewCliente;viewCliente=function(){var h=_vc17.apply(this,arguments),p=panelCli17(),i=h.indexOf('<h2>Mis entregas</h2>');return i<0?h+p:h.slice(0,i)+p+h.slice(i);};
var _ol17=obsList;obsList=function(e){var h=_ol17.apply(this,arguments);var r=(typeof rolActual==='function')?rolActual():'';
  if(r!=='cliente')return h;
  var mine=cons17().filter(function(c){return c.entregaId===e.id;}).slice(0,3);
  return h+(mine.length?'<div class="obs">'+mine.map(function(c){return consItem17(c,false);}).join('')+'</div>':'')+
    '<div class="row" style="gap:6px;flex-wrap:wrap"><span class="small muted">Consultar sobre esta entrega:</span>'+TEMAS17.slice(0,4).map(function(x){return '<button class="btn sm" data-act="x17-q" data-t="'+x[0]+'" data-id="'+esc(e.id)+'">'+x[1]+'</button>';}).join('')+'</div>';};
function panelAdm17(){
  var l=cons17(),ab=l.filter(function(c){return c.estado==='abierta';}),ya=l.filter(function(c){return c.estado!=='abierta';}).slice(0,5);
  if(!l.length)return '';
  var h='<div class="panel" id="consultas-cli"><h3>Consultas de clientes'+(ab.length?' ('+ab.length+' sin responder)':'')+'</h3>';
  h+=ab.length?ab.map(function(c){var p=D().perfiles.find(function(x){return x.id===c.clienteId;}),u=p&&waUrl(p.telefono,'Hola '+(c.cliente||'')+', te respondo tu consulta sobre '+tema17(c.tema).toLowerCase()+(c.guia?' ('+c.guia+')':'')+': ');
    return consItem17(c,true)+'<div class="row"><label style="flex:1;min-width:200px">Respuesta<textarea id="q17r-'+esc(c.id)+'" maxlength="600"></textarea></label></div><div class="row"><button class="btn sm pri" data-act="x17-resp" data-id="'+esc(c.id)+'">Responder</button>'+(u?'<a class="btn sm" href="'+esc(u)+'" target="_blank" rel="noopener">WhatsApp al cliente</a>':'')+'<button class="btn sm" data-act="x17-cerrar" data-id="'+esc(c.id)+'">Marcar como resuelta</button></div>';}).join(''):'<p class="small muted">No hay consultas sin responder.</p>';
  if(ya.length)h+='<h3 style="margin-top:12px">Últimas respondidas</h3>'+ya.map(function(c){return consItem17(c,true);}).join('');
  return h+'</div>';}
var _va17=viewAdmin;viewAdmin=function(){var h=_va17.apply(this,arguments),n=cons17().filter(function(c){return c.estado==='abierta';}).length;
  var add=S.ui.tab==='op'?panelAdm17():(n?'<div class="banner bad" role="status">'+ICON.bell+'<div><strong>'+n+(n===1?' consulta de cliente sin responder':' consultas de clientes sin responder')+'</strong><button class="btn sm" data-act="x17-go">Ver consultas</button></div></div>':'');
  if(!add)return h;var i=h.indexOf('<h2');return i<0?add+h:h.slice(0,i)+add+h.slice(i);};
(function(){var _ex=extLive;extLive=function(rol,onErr){_ex(rol,onErr);
  var mk=function(s){return s.docs.map(function(d){return Object.assign({id:d.id},d.data());});};
  if(rol==='admin')unsubs.push(db.collection('consultas').onSnapshot(function(s){S.ext.cons17=mk(s);render();},onErr));
  else if(rol==='cliente')unsubs.push(db.collection('consultas').where('clienteId','==',S.me.id).onSnapshot(function(s){S.ext.cons17=mk(s);render();},onErr));};})();
async function cons17Save(c){if(S.mode==='demo'){var a=S.ext.cons17demo=S.ext.cons17demo||[],i=a.findIndex(function(x){return x.id===c.id;});if(i<0)a.push(c);else a[i]=c;render();return;}await db.doc('consultas/'+c.id).set(c);}
document.addEventListener('change',function(ev){var t=ev.target;if(!t||!S.ui.q17)return;if(t.id==='q17-tema')S.ui.q17.tema=t.value;else if(t.id==='q17-ent')S.ui.q17.entregaId=t.value;});
document.addEventListener('click',async function(ev){var b=ev.target.closest&&ev.target.closest('[data-act^="x17-"]');if(!b)return;var a=b.dataset.act,id=b.dataset.id;
  if(a==='x17-q'){S.ui.q17={tema:b.dataset.t,entregaId:id||(S.ui.q17&&S.ui.q17.entregaId)||''};render();setTimeout(function(){var t=document.getElementById('q17-txt');if(t){t.scrollIntoView({block:'center'});t.focus();}},60);}
  else if(a==='x17-cancel'){S.ui.q17=null;render();}
  else if(a==='x17-go'){S.ui.tab='op';render();setTimeout(function(){var p=document.getElementById('consultas-cli');if(p)p.scrollIntoView();},60);}
  else if(a==='x17-send'){var f=S.ui.q17;if(!f)return;var tx=(gv('q17-txt')||'').trim();if(tx.length<3){toast('Escribí tu consulta.');return;}
    var ent=D().entregas.find(function(e){return e.id===(gv('q17-ent')||f.entregaId);});var tm=gv('q17-tema')||f.tema;
    var c={id:(S.mode==='demo'?'q-'+Date.now():db.collection('consultas').doc().id),clienteId:miId(),cliente:actor(),entregaId:ent?ent.id:'',guia:ent?ent.guia:'',tema:tm,texto:tx.slice(0,600),ts:new Date().toISOString(),estado:'abierta'};
    try{await cons17Save(c);S.ui.q17=null;render();toast('Consulta enviada. Te responden por acá.');}catch(err){toast('No se pudo enviar. Probá de nuevo.');}}
  else if(a==='x17-resp'||a==='x17-cerrar'){var c0=cons17().filter(function(x){return x.id===id;})[0];if(!c0)return;var tx2=(gv('q17r-'+id)||'').trim();
    if(a==='x17-resp'&&!tx2){toast('Escribí la respuesta.');return;}
    var n=Object.assign({},c0,{estado:'respondida',respondidoPor:actor(),respondidoTs:new Date().toISOString()});if(tx2)n.respuesta=tx2.slice(0,600);
    try{await cons17Save(n);toast('Listo.');}catch(err){toast('No se pudo guardar.');}}});
/* EXT17 end */
/* ===== EXT18: control de vencimientos — FEFO protegido, bajas de vencidos, margen de vida útil por cliente y aviso por mail ===== */
var V18={minVida:0};
function venc18(){var l=wLotes().filter(function(x){return x.q>0&&x.vence;}).map(function(x){return Object.assign({d:dleft(x.vence)},x);}).sort(function(a,b){return a.d-b.d;});
  return {vencidos:l.filter(function(x){return x.d<0;}),s7:l.filter(function(x){return x.d>=0&&x.d<=7;}),s30:l.filter(function(x){return x.d>7&&x.d<=30;}),s60:l.filter(function(x){return x.d>30&&x.d<=60;})};}
/* lo vencido nunca se ofrece para armar pedidos */
var _wd18=wDisp;wDisp=function(){return _wd18.apply(this,arguments).filter(function(x){return !(x.vence&&x.vence<HOY);});};
function vidaCli18(id){var v=(S.ext.vida18||{})[id];return v?(parseInt(v.dias,10)||0):0;}
var _pc18=pedCandidatos;pedCandidatos=function(){var by=_pc18.apply(this,arguments),mn=V18.minVida||0;
  Object.keys(by).forEach(function(s){by[s]=by[s].filter(function(c){if(!c.vence)return true;var d=dleft(c.vence);return d>=0&&d>=mn;});});return by;};
var _pr18=pedReservar;pedReservar=async function(id,parcial){var p=pedGet(id);V18.minVida=p?vidaCli18(p.clienteId):0;try{return await _pr18.apply(this,arguments);}finally{V18.minVida=0;}};
var _pk18=pickConfirmar;pickConfirmar=function(id,ov){var p=WC('picks').find(function(x){return x.id===id;}),v=p&&(p.lineas||[]).filter(function(l){return l.vence&&l.vence<HOY;});
  if(v&&v.length){toast('No se puede confirmar: el lote '+(v[0].lote||'')+' de '+v[0].sku+' venció. Cancelá la orden y generala de nuevo.');return Promise.resolve();}return _pk18.apply(this,arguments);};
/* margen mínimo de vida útil por cliente (en la ficha) */
var _fc18=viewFicCliente;viewFicCliente=function(p){var h=_fc18.apply(this,arguments),i=h.indexOf('<label>Notas');
  var f='<label>Vida útil mínima al despachar (días, 0 = sin mínimo)<input id="fi-vida" type="number" min="0" max="999" inputmode="numeric" value="'+vidaCli18(p.id)+'"></label>';return i<0?h:h.slice(0,i)+f+h.slice(i);};
var _sf18=saveFicha;saveFicha=async function(){var p=S.ui.fic,v=gv('fi-vida'),r=await _sf18.apply(this,arguments);
  if(p&&p.rol==='cliente'&&v!==''){var n=Math.max(0,Math.min(999,parseInt(v,10)||0));try{S.ext.vida18=S.ext.vida18||{};S.ext.vida18[p.id]={id:p.id,dias:n};if(S.mode!=='demo')await db.doc('wms/vidacli/items/'+p.id).set({id:p.id,dias:n});}catch(_){toast('No se pudo guardar la vida útil mínima.');}}return r;};
/* aviso al sacar un lote que no es el que vence primero */
var _wm18=wMov;wMov=function(){var h=_wm18.apply(this,arguments);return S.ui.fefoMsg?'<div class="banner warn" role="alert">'+ICON.alert+'<div><strong>Ojo con el FEFO</strong>'+esc(S.ui.fefoMsg)+'</div></div>'+h:h;};
document.addEventListener('submit',function(ev){var f=ev.target;if(!f||f.id!=='form-mov')return;var g=function(i){var e=document.getElementById(i);return e?e.value:'';};
  var tipo=g('m-tipo'),sku=g('m-sku'),ubi=g('m-ubi'),lot=g('m-lot').trim();if(tipo==='IN'||!lot)return;
  var mio=wLotes().filter(function(l){return l.sku===sku&&l.ubi===ubi&&l.lote===lot;})[0];if(!mio||!mio.vence||mio.vence<HOY)return;
  var otro=wLotes().filter(function(l){return l.q>0&&l.sku===sku&&l.vence&&l.vence<mio.vence&&l.vence>=HOY&&!(l.lote===lot&&l.ubi===ubi);}).sort(fefo)[0];
  if(!otro){S.ui.fefoMsg=null;S.ui.fefoNota=null;return;}
  var key=sku+'|'+ubi+'|'+lot;
  if(S.ui.fefoOk===key){S.ui.fefoOk=null;S.ui.fefoMsg=null;S.ui.fefoNota='Salida fuera de FEFO: había el lote '+otro.lote+' ('+otro.ubi+') que vence antes';setTimeout(function(){S.ui.fefoNota=null;},4000);return;}
  ev.preventDefault();ev.stopImmediatePropagation();S.ui.fefoOk=key;
  S.ui.fefoMsg='El lote '+otro.lote+' ('+otro.ubi+', '+otro.q+' u.) vence el '+otro.vence.split('-').reverse().join('/')+', antes que el '+lot+'. Conviene sacar ese primero. Si igual querés sacar éste, tocá Registrar de nuevo (queda anotado).';render();},true);
/* panel de vencimientos dentro de "Lotes y FEFO" */
function filaV18(l){var k=[l.sku,l.ubi,l.lote].join('|'),ask=S.ui.baja18===k;
  return '<div class="doc"><span class="k"><strong>'+esc(l.sku)+'</strong> · '+esc((W().skus.find(function(s){return s.codigo===l.sku;})||{}).producto||'')+'</span><span class="v">Lote '+esc(l.lote)+' · <span class="mono">'+esc(l.ubi)+'</span> · '+nf(l.q)+' u. · '+venceChip(l.vence)+'</span>'+
    (l.d<0?(ask?'<span class="v"><strong>¿Dar de baja '+nf(l.q)+' u. del lote '+esc(l.lote)+'?</strong> <button class="btn sm bad" data-act="x18-baja-ok" data-k="'+esc(k)+'">Sí, dar de baja</button> <button class="btn sm" data-act="x18-baja-no">No</button></span>':'<span class="v"><button class="btn sm" data-act="x18-baja" data-k="'+esc(k)+'">Dar de baja</button></span>'):'')+'</div>';}
function panelVenc18(){var v=venc18(),n=v.vencidos.length+v.s7.length+v.s30.length+v.s60.length;
  if(!n)return '<div class="panel"><h3>Vencimientos</h3><p class="small muted" style="margin:0">No hay lotes vencidos ni que venzan en los próximos 60 días.</p></div>';
  var sec=function(t,a,cl){return a.length?'<h3 style="margin-top:12px">'+t+' <span class="chip '+cl+'">'+a.length+'</span></h3>'+a.slice(0,S.ui.v18all?60:5).map(filaV18).join('')+(a.length>5&&!S.ui.v18all?'<div class="row"><span class="small muted">Hay '+(a.length-5)+' más.</span><button class="btn sm" data-act="x18-todos">Ver más</button></div>':''):'';};
  return '<div class="panel"><h3>Vencimientos</h3><p class="small muted" style="margin:0">Los lotes vencidos no se ofrecen para armar pedidos ni se pueden confirmar en un picking. Dalos de baja para que salgan del stock.</p>'+
    sec('Vencidos',v.vencidos,'bad')+sec('Vencen en 7 días o menos — sacalos primero',v.s7,'bad')+sec('Vencen en 8 a 30 días',v.s30,'warn')+sec('Vencen en 31 a 60 días',v.s60,'ok')+'</div>';}
function panelMail18(){if(S.mode==='demo'||rolActual()!=='admin')return '';var c=S.ext.vcfg18||{};
  return '<form class="panel" id="form-venc18"><h3>Aviso diario por mail</h3><p class="small muted" style="margin:0 0 8px">Todos los días después de las 7 se manda un resumen si hay lotes vencidos o que vencen en la semana. Los lunes va el resumen completo.</p>'+
    '<label class="row" style="gap:8px"><input id="vc-act" type="checkbox"'+(c.activo!==false?' checked':'')+'> Enviar el aviso automático</label>'+
    '<label>Correos que lo reciben (separados por coma; vacío = todos los administradores)<input id="vc-mail" inputmode="email" value="'+esc(c.emails||'')+'" placeholder="deposito@empresa.com, gerencia@empresa.com"></label>'+
    '<label>Avisar con anticipación de (días, separados por coma)<input id="vc-dias" value="'+esc(c.dias||'60,30,7')+'"></label>'+
    '<div class="row"><button class="btn pri" type="submit">Guardar</button><button class="btn" type="button" data-act="x18-test">Enviar aviso de prueba ahora</button></div></form>';}
var _xl18=xLotes;xLotes=function(){return panelVenc18()+_xl18.apply(this,arguments)+panelMail18();};
/* avisos en el Inicio del operario y en Operación de administración */
function banner18(){var v=venc18(),h='';if(v.vencidos.length)h+='<div class="banner bad" role="status">'+ICON.alert+'<div><strong>'+v.vencidos.length+(v.vencidos.length===1?' lote vencido':' lotes vencidos')+'</strong>No se pueden despachar. <button class="btn sm" data-act="x18-ver">Ver y dar de baja</button></div></div>';
  if(v.s7.length)h+='<div class="banner warn" role="status">'+ICON.bell+'<div><strong>'+v.s7.length+(v.s7.length===1?' lote vence':' lotes vencen')+' en 7 días o menos</strong>Sacalos primero. <button class="btn sm" data-act="x18-ver">Ver cuáles</button></div></div>';return h;}
var _wi18=wInicio;wInicio=function(){return banner18()+_wi18.apply(this,arguments);};
var _va18=viewAdmin;viewAdmin=function(){var h=_va18.apply(this,arguments);if(S.ui.tab!=='op')return h;var b=banner18();if(!b)return h;var i=h.indexOf('<h2');return i<0?b+h:h.slice(0,i)+b+h.slice(i);};
(function(){var _ex=extLive;extLive=function(rol,onErr){_ex(rol,onErr);var mk=function(s){var o={};s.docs.forEach(function(d){o[d.id]=Object.assign({id:d.id},d.data());});return o;};
  if(rol==='admin'||rol==='deposito')unsubs.push(db.collection('wms/vidacli/items').onSnapshot(function(s){S.ext.vida18=mk(s);render();},onErr));
  if(rol==='admin')unsubs.push(db.doc('config/vencimientos').onSnapshot(function(s){if(s.exists)S.ext.vcfg18=s.data();render();},onErr));};})();
document.addEventListener('submit',async function(ev){if(!ev.target||ev.target.id!=='form-venc18')return;ev.preventDefault();
  var d=(gv('vc-dias')||'').split(/[,\s;]+/).map(function(x){return parseInt(x,10);}).filter(function(n){return n>0&&n<=365;});
  var o={activo:document.getElementById('vc-act').checked,emails:(gv('vc-mail')||'').trim().slice(0,300),dias:(d.length?d:[60,30,7]).join(',')};
  try{await db.doc('config/vencimientos').set(o);S.ext.vcfg18=o;toast('Guardado.');render();}catch(_){toast('No se pudo guardar.');}});
document.addEventListener('click',async function(ev){var b=ev.target.closest&&ev.target.closest('[data-act^="x18-"]');if(!b)return;var a=b.dataset.act;
  if(a==='x18-ver'){var adm=rolActual()==='admin';if(adm){S.ui.tab='wms';}S.ui.dep='wms';S.ui.wsub='lotes';render();try{window.scrollTo(0,0);}catch(_){}}
  else if(a==='x18-todos'){S.ui.v18all=true;render();}
  else if(a==='x18-baja'){S.ui.baja18=b.dataset.k;render();}
  else if(a==='x18-baja-no'){S.ui.baja18=null;render();}
  else if(a==='x18-baja-ok'){var p=String(b.dataset.k).split('|'),l=wLotes().filter(function(x){return x.sku===p[0]&&x.ubi===p[1]&&x.lote===p[2];})[0];S.ui.baja18=null;if(!l||l.q<=0){render();return;}
    try{await wPut('kardex',{id:uid('B'),fecha:HOY,tipo:'AJUSTE',sku:l.sku,ubicacion:l.ubi,'in':0,out:l.q,lote:l.lote,vence:l.vence,operador:actor(),nota:'Baja por vencimiento'});toast('Baja registrada: '+nf(l.q)+' u. del lote '+l.lote+'.');}catch(_){toast('No se pudo registrar la baja.');}}
  else if(a==='x18-test'){b.disabled=true;try{var r=await fetch('/api/vencimientos/enviar',{method:'POST',credentials:'same-origin'}),j=await r.json().catch(function(){return {};});
      toast(r.ok&&j.enviado?'Aviso enviado a '+j.destinatarios+(j.destinatarios===1?' correo.':' correos.'):(j.error||'No se pudo enviar.'));}catch(_){toast('No se pudo enviar.');}b.disabled=false;}});
/* plano para depósitos grandes: un rack por vez (bahías en columnas, alturas en filas) */
function plano19(){
  var w=W(),st=wStock(),lots=wLotes(),by={},venc={},P={};
  Object.keys(st.m).forEach(function(k){if(st.m[k]>0){var i=k.indexOf('|'),u=k.slice(0,i);(by[u]=by[u]||[]).push({sku:k.slice(i+1),q:st.m[k]});}});
  lots.forEach(function(l){if(l.q>0&&l.vence){var d=dleft(l.vence);if(venc[l.ubi]==null||d<venc[l.ubi])venc[l.ubi]=d;}});
  w.ubic.forEach(function(u){var m=locParse(u.codigo);if(!m)return;var pp=P[m.p]=P[m.p]||{};(pp[m.r]=pp[m.r]||[]).push({c:u.codigo,u:m.u,a:m.a});});
  var PL=Object.keys(P).map(Number).sort(function(a,b){return a-b;}),F=S.ui.p19=S.ui.p19||{};
  if(!P[F.p])F.p=PL[0];var RL=Object.keys(P[F.p]||{}).map(Number).sort(function(a,b){return a-b;});if(!P[F.p][F.r])F.r=RL[0];
  var cells=(P[F.p]||{})[F.r]||[],bays=[],alts=[];cells.forEach(function(c){if(bays.indexOf(c.u)<0)bays.push(c.u);if(alts.indexOf(c.a)<0)alts.push(c.a);});
  bays.sort(function(a,b){return a-b;});alts.sort(function(a,b){return b-a;});
  var map={};cells.forEach(function(c){map[c.u+'|'+c.a]=c.c;});
  var occ=Object.keys(by).length,tot=w.ubic.length,sel=S.ui.wloc,q=String(F.q||'').trim().toLowerCase();
  var h='<div class="panel"><h3>Plano del depósito</h3><div class="small muted" style="margin-bottom:8px">'+nf(tot)+' ubicaciones, '+nf(occ)+' con stock ('+Math.round(occ*100/Math.max(1,tot))+'%). Elegí pasillo y rack.</div>'+
    '<label>Buscar un producto<input id="p19-q" type="search" value="'+esc(F.q||'')+'" placeholder="Código o nombre" autocomplete="off"></label>';
  if(q){var hits=w.skus.filter(function(k){return (k.codigo+' '+k.producto).toLowerCase().indexOf(q)>=0;}).slice(0,5),n=0;
    h+=hits.map(function(k){var ls=Object.keys(by).filter(function(u){return by[u].some(function(x){return x.sku===k.codigo;});}).sort();
      return '<div class="doc"><span class="k"><strong>'+esc(k.codigo)+'</strong> · '+esc(k.producto)+'</span><span class="v">'+(ls.length?ls.slice(0,12).map(function(u){return '<button class="btn sm" data-act="x19-ir" data-c="'+esc(u)+'">'+esc(u)+'</button>';}).join(' ')+(ls.length>12?' … '+(ls.length-12)+' más':''):'Sin stock')+'</span></div>';}).join('')||'<div class="small muted">No encontré nada.</div>';}
  h+='<div style="margin-top:10px" class="small muted">Pasillo</div><div class="row" style="gap:6px;flex-wrap:wrap">'+PL.map(function(n){return '<button class="btn sm" data-act="x19-pas" data-v="'+n+'" aria-pressed="'+(n===F.p)+'">'+pad(n)+'</button>';}).join('')+'</div>'+
    '<div style="margin-top:8px" class="small muted">Rack del pasillo '+pad(F.p||0)+'</div><div class="row" style="gap:6px;flex-wrap:wrap">'+RL.map(function(n){return '<button class="btn sm" data-act="x19-rack" data-v="'+n+'" aria-pressed="'+(n===F.r)+'">'+pad(n)+'</button>';}).join('')+'</div></div>';
  var colr=function(c){var d=venc[c],hv=by[c];return c===sel?['var(--accent)','var(--accent-ink)']:!hv?['var(--surface2)','inherit']:d!=null&&d<0?['var(--bad-bg)','var(--bad)']:d!=null&&d<=30?['var(--warn-bg)','var(--warn)']:['var(--signal-bg)','inherit'];};
  h+='<div class="panel"><h3>Pasillo '+pad(F.p||0)+' · Rack '+pad(F.r||0)+'</h3><div class="small muted" style="margin-bottom:6px">Columnas: bahías. Filas: alturas (arriba, la más alta). Tocá una ubicación para ver qué tiene.</div>'+
    '<div style="display:grid;grid-template-columns:34px repeat('+bays.length+',minmax(0,1fr));gap:4px;align-items:stretch"><div></div>'+bays.map(function(u){return '<div class="small muted" style="text-align:center">B'+pad(u)+'</div>';}).join('')+
    alts.map(function(a){return '<div class="small muted" style="align-self:center">A'+pad(a)+'</div>'+bays.map(function(u){var c=map[u+'|'+a];if(!c)return '<div></div>';var l=by[c]||[],cl=colr(c),tq=l.reduce(function(t,x){return t+x.q;},0);
      return '<button data-act="x19-cell" data-c="'+esc(c)+'" style="min-height:52px;border:1px solid var(--line);border-radius:8px;padding:2px;background:'+cl[0]+';color:'+cl[1]+';font-size:11px;line-height:1.2;overflow:hidden" aria-label="'+esc(c)+'">'+(l.length?'<strong>'+nf(tq)+'</strong><br>'+esc(l[0].sku)+(l.length>1?' +'+(l.length-1):''):'—')+'</button>';}).join('');}).join('')+'</div>'+
    '<div class="small muted" style="margin-top:8px">Gris: libre · Color claro: con stock · Amarillo: algún lote vence en 30 días o menos · Rojo: lote vencido</div></div>';
  if(sel&&map&&w.ubic.some(function(u){return u.codigo===sel;})){var l=by[sel]||[],ls=lots.filter(function(x){return x.ubi===sel&&x.q>0;});
    h+='<div class="panel"><h3>Ubicación <span class="mono">'+esc(sel)+'</span></h3>'+(l.length?l.map(function(x){var lt=ls.filter(function(y){return y.sku===x.sku;});
      return '<div class="doc"><span class="k">'+skuTxt(x.sku)+'</span><span class="v"><strong>'+nf(x.q)+' u.</strong>'+lt.map(function(y){return ' · Lote '+esc(y.lote)+' '+venceChip(y.vence);}).join('')+'</span><span class="v"><button class="btn sm" data-act="x16-mover" data-sku="'+esc(x.sku)+'" data-ubi="'+esc(sel)+'">Mover o sacar</button></span></div>';}).join(''):'<div class="small muted">Libre. Cabe: '+nf((w.ubic.find(function(u){return u.codigo===sel;})||{}).cap||0)+' u.</div>')+'</div>';}
  return h;}
var _wp19=wPlano;wPlano=function(){return W().ubic.length>400?plano19():_wp19.apply(this,arguments);};
document.addEventListener('input',function(ev){if(ev.target&&ev.target.id==='p19-q'){(S.ui.p19=S.ui.p19||{}).q=ev.target.value;render();}});
document.addEventListener('click',function(ev){var b=ev.target.closest&&ev.target.closest('[data-act="x19-pas"],[data-act="x19-rack"],[data-act="x19-cell"],[data-act="x19-ir"]');if(!b)return;var F=S.ui.p19=S.ui.p19||{},a=b.dataset.act;
  if(a==='x19-pas'){F.p=parseInt(b.dataset.v,10);F.r=null;}else if(a==='x19-rack')F.r=parseInt(b.dataset.v,10);
  else if(a==='x19-cell')S.ui.wloc=S.ui.wloc===b.dataset.c?null:b.dataset.c;
  else{var m=locParse(b.dataset.c);if(m){F.p=m.p;F.r=m.r;S.ui.wloc=b.dataset.c;}}render();});
/* EXT18 end */
/* ===== EXT19: listas largas (miles de pallets): tablas con filtro y "mostrar más", etiquetas en vista previa ===== */
var LIM19=40;
function trim19(){
  var main=document.querySelector('main');if(!main)return;S.ui.tl19=S.ui.tl19||{};S.ui.tq19=S.ui.tq19||{};
  var base=(S.ui.tab||'')+'/'+(S.ui.wsub||S.ext.sub||'')+'/'+(S.ui.dep||'');
  [].slice.call(main.querySelectorAll('table')).forEach(function(t,idx){
    if(t.closest('#etq-sheet'))return;var body=t.tBodies[0];if(!body||body.rows.length<=LIM19+20)return;
    var key=base+'#'+idx,q=(S.ui.tq19[key]||'').trim().toLowerCase(),lim=S.ui.tl19[key]||LIM19,shown=0,match=0,rows=[].slice.call(body.rows);
    rows.forEach(function(r){var ok=!q||r.textContent.toLowerCase().indexOf(q)>=0;if(ok){match++;if(shown<lim){shown++;r.style.display='';return;}}r.style.display='none';});
    var wrap=t.closest('.tablewrap')||t.parentNode,box=document.createElement('div');box.className='x19-box';
    box.innerHTML='<div class="row" style="gap:8px;align-items:end;margin:6px 0"><label style="flex:1;min-width:180px">Filtrar esta lista ('+nf(rows.length)+' filas)<input id="x19-f-'+idx+'" type="search" data-k="'+esc(key)+'" placeholder="Código, producto, ubicación, lote…" value="'+esc(S.ui.tq19[key]||'')+'" autocomplete="off"></label></div>';
    wrap.parentNode.insertBefore(box,wrap);
    if(match>shown){var f=document.createElement('div');f.className='row';f.style.margin='6px 0';f.innerHTML='<span class="small muted">Mostrando '+nf(shown)+' de '+nf(match)+(q?' que coinciden':'')+'.</span><button class="btn sm" data-act="x19-more" data-k="'+esc(key)+'">Mostrar 100 más</button><button class="btn sm" data-act="x19-all" data-k="'+esc(key)+'">Mostrar todas</button>';wrap.parentNode.insertBefore(f,wrap.nextSibling);}
    else if(q&&!match){var f2=document.createElement('div');f2.className='small muted';f2.textContent='Ninguna fila coincide con "'+q+'".';wrap.parentNode.insertBefore(f2,wrap.nextSibling);}
  });}
var _r19=render;render=function(){var ae=document.activeElement,id=ae&&ae.id&&/^x19-f-/.test(ae.id)?ae.id:null,pos=id?ae.selectionStart:0;_r19.apply(this,arguments);try{trim19();}catch(_){}
  if(id){var e=document.getElementById(id);if(e){e.focus();try{e.setSelectionRange(pos,pos);}catch(_){}}}};
document.addEventListener('input',function(ev){var t=ev.target;if(t&&/^x19-f-/.test(t.id||'')){S.ui.tq19=S.ui.tq19||{};S.ui.tq19[t.dataset.k]=t.value;S.ui.tl19=S.ui.tl19||{};S.ui.tl19[t.dataset.k]=LIM19;render();}
  else if(t&&t.id==='et-q'){S.ext.et.q=t.value;render();}});
document.addEventListener('click',function(ev){var b=ev.target.closest&&ev.target.closest('[data-act="x19-more"],[data-act="x19-all"]');if(!b)return;S.ui.tl19=S.ui.tl19||{};var k=b.dataset.k;
  S.ui.tl19[k]=b.dataset.act==='x19-all'?1e9:(S.ui.tl19[k]||LIM19)+100;render();});
/* etiquetas: filtro por código y vista previa corta (imprimir y descargar incluyen todas las filtradas) */
var _ei19=etqItems;etqItems=function(){var it=_ei19.apply(this,arguments),q=String((S.ext.et&&S.ext.et.q)||'').trim().toLowerCase();return q?it.filter(function(x){return (x.code+' '+x.t2).toLowerCase().indexOf(q)>=0;}):it;};
var _eh19=etqHtml,etq19prev=false;etqHtml=function(it){if(etq19prev&&!S.ext.et19full&&it.length>24)return _eh19(it.slice(0,24))+'<div class="small muted" style="width:100%;margin-top:8px">Vista previa de 24 de '+nf(it.length)+' etiquetas. Al imprimir o descargar salen todas. Usá el filtro para acotar (por ejemplo "03:" para el pasillo 3).</div>';return _eh19(it);};
var _xe19=xEtiq;xEtiq=function(){etq19prev=true;var h;try{h=_xe19.apply(this,arguments);}finally{etq19prev=false;}
  var i=h.indexOf('<div class="small muted">Código 128');var f='<div class="row" style="margin-top:8px"><label style="flex:1;min-width:200px">Filtrar etiquetas (código o texto)<input id="et-q" type="search" value="'+esc((S.ext.et&&S.ext.et.q)||'')+'" placeholder="Ej.: 03: o PIN0012" autocomplete="off"></label></div>';return i<0?h:h.slice(0,i)+f+h.slice(i);};
var _ep19=etqPrint;etqPrint=function(){S.ext.et19full=true;render();setTimeout(function(){_ep19();setTimeout(function(){S.ext.et19full=false;render();},1500);},200);};
/* EXT19 end */






/* ===== EXT20: Staging (posición del pedido preparado) y docks de carga ===== */
(function(){
['staging'].forEach(function(k){if(S.data.demo.wms&&!S.data.demo.wms[k])S.data.demo.wms[k]=[];if(S.data.live.wms&&!S.data.live.wms[k])S.data.live.wms[k]=[];});
WSUBS_ALL.splice(WSUBS_ALL.length-1,0,['x20stg','Staging y despacho']);WSUBS_DEP.push('x20stg');
var _ex=extLive;extLive=function(rol,onErr){_ex(rol,onErr);if(rol!=='admin'&&rol!=='deposito')return;var live=S.data.live;
  unsubs.push(db.collection('wms/staging/items').onSnapshot(function(s){live.wms.staging=s.docs.map(function(d){return Object.assign({id:d.id},d.data());});render();},onErr));};
var U=S.ui.s20=S.ui.s20||{f:'ubicar',q:''};
function isAdm(){return rolActual()==='admin';}
function pos20(t){return WC('staging').filter(function(x){return x.activo!==false&&(!t||x.tipo===t);}).sort(function(a,b){return String(a.codigo).localeCompare(String(b.codigo),'es',{numeric:true});});}
function nPal(p){return Math.max(1,parseInt(p.pallets,10)||1);}
function posL(p){return p.stgPosL&&p.stgPosL.length?p.stgPosL:(p.stgPos?[p.stgPos]:[]);}
function palN(P){return P.on?Math.max(2,Math.min(50,parseInt(P.n,10)||2)):1;}
window.stgPick20=function(id){var ps=pos20('posicion');if(!ps.length)return null;var P=(S.ext.pal20||{})[id]||{on:false,n:2},n=palN(P),l=(P.pos||[]).slice(0,n);
  if(l.length<n||l.some(function(c){return !c;}))return {err:n>1?'Elegí la posición de staging de cada pallet ('+n+').':'Elegí la posición de staging.'};
  if(new Set(l).size<l.length)return {err:'Cada pallet va en una posición distinta.'};
  var ok=ps.map(function(x){return x.codigo;});if(l.some(function(c){return ok.indexOf(c)<0;}))return {err:'Alguna posición de staging ya no existe.'};return {list:l};};
function salidaDias(id){var pd=WC('pedidos').find(function(x){return x.pickId===id;}),P0=(S.ext.pal20||{})[id]||{},fe=pd&&pd.entrega?pd.entrega:(P0.sale||(WC('picks').find(function(x){return x.id===id;})||{}).sale||'');if(!fe)return -1;return Math.round((new Date(fe+'T00:00:00')-new Date(HOY+'T00:00:00'))/864e5);}
window.palCtl20=function(id){var M=(S.ext.pal20=S.ext.pal20||{}),P=M[id]=M[id]||{on:false,n:2},n=palN(P),ps=pos20('posicion'),sel='';
  if(ps.length){var oc=ocup20(),pk0=WC('picks').find(function(x){return x.id===id;})||{},used=(P.pos||(pk0.stgPrev&&n===1&&ps.some(function(x){return x.codigo===pk0.stgPrev;})?[pk0.stgPrev]:[])).slice(0,n);var libres=ps.map(function(x){return x.codigo;}).filter(function(c){return !(oc[c]||[]).length&&used.indexOf(c)<0;});var dd=salidaDias(id);while(used.length<n)used.push((dd>=2?libres.pop():libres.shift())||'');P.pos=used;
    for(var k=0;k<n;k++)sel+='<label class="small">'+(n>1?'Pallet '+(k+1)+' → posición':'Posición de staging')+' <select class="pk20-pos" data-id="'+esc(id)+'" data-k="'+k+'"><option value="">Elegí…</option>'+ps.map(function(x){var u=(oc[x.codigo]||[]).length;return '<option value="'+esc(x.codigo)+'"'+(used[k]===x.codigo?' selected':'')+'>'+esc(x.codigo)+(x.nombre?' · '+esc(x.nombre):'')+(u?' ('+u+' en uso)':' (libre)')+'</option>';}).join('')+'</select></label>';}
  var dd2=salidaDias(id),hint=!ps.length?'<span class="chip warn">Sin posiciones de staging: cargalas en Staging y despacho</span>':dd2>=2?'<span class="chip">📅 Sale en '+dd2+' días: te sugiero una posición lejos del andén</span>':dd2===0?'<span class="chip signal">📅 Sale hoy: posición cerca del andén</span>':dd2===1?'<span class="chip">📅 Sale mañana</span>':'';
  var pdx=WC('pedidos').find(function(x){return x.pickId===id;}),pkx=WC('picks').find(function(x){return x.id===id;})||{};if(!pdx&&!pkx.sale)hint+='<label class="small">¿Cuándo sale? <input type="date" class="pk31-sale" data-id="'+esc(id)+'" min="'+HOY+'" value="'+esc(P.sale||'')+'"></label>';
  return hint+'<span class="row" style="gap:8px;align-items:center;flex-wrap:wrap"><label class="chip" style="cursor:pointer"><input type="checkbox" class="pal20-on" data-id="'+esc(id)+'"'+(P.on?' checked':'')+'> Más de un pallet</label>'+(P.on?'<label class="small">¿Cuántos? <input type="number" class="pal20-n" data-id="'+esc(id)+'" min="2" max="50" value="'+esc(P.n||2)+'" style="width:70px"></label>':'')+sel+'</span>';};
function prep20(){return WC('pedidos').filter(function(p){return p.estado==='preparado';});}
function sueltos20(){return WC('picks').filter(function(k){return k.estado==='completado'&&!k.pedidoId&&k.stgPos&&!k.stgFuera;}).map(function(k){return {id:k.id,cliente:(k.ref||'Picking sin pedido'),stgPosL:k.stgPosL&&k.stgPosL.length?k.stgPosL:String(k.stgPos).split(' · '),stgTs:k.cierre||'',stgPos:String(k.stgPos),stgOk:k.stgOk||'',suelto:true,pk:k};});}
window.sueltos20=sueltos20;
function ocup20(){var m={};prep20().concat(sueltos20()).forEach(function(p){posL(p).forEach(function(c){(m[c]=m[c]||[]).push(p);});});return m;}
function ageMin(iso){var t=iso?new Date(iso).getTime():Date.now();return Math.max(0,Math.round((Date.now()-t)/60000));}
function ageTxt(m){return m<60?m+' min':m<1440?Math.floor(m/60)+' h '+(m%60)+' min':Math.floor(m/1440)+' d';}
function ageCls(m){return m>=360?'bad':m>=120?'warn':'ok';}
function fSlug(c){return String(c||'').toUpperCase().replace(/[^A-Z0-9_-]/g,'').slice(0,20);}
function matchQ(p){var q=(U.q||'').trim().toLowerCase();if(!q)return true;return (p.id+' '+(p.cliente||'')+' '+(p.stgPos||'')+' '+(p.dock||'')).toLowerCase().indexOf(q)>=0;}
async function logPed(p,patch,ev){var q=clean(p);Object.assign(q,patch);q.stgLog=(q.stgLog||[]).concat([Object.assign({ts:isoNow(),por:actor()},ev)]).slice(-30);await pedGuardar(q);}
async function ubicar(id,cods){var p=pedGet(id);if(!p||p.estado!=='preparado')return;cods=[].concat(cods).filter(Boolean);var n=nPal(p);
  if(cods.length<n){toast(n>1?'Elegí '+n+' posiciones (una por pallet).':'Elegí una posición.');return;}
  if(new Set(cods).size<cods.length){toast('Cada pallet va en una posición distinta.');return;}
  var ok=pos20('posicion').map(function(x){return x.codigo;});if(cods.some(function(c){return ok.indexOf(c)<0;})){toast('Alguna posición no existe o está desactivada.');return;}
  if(posL(p).join('|')===cods.join('|'))return;
  await logPed(p,{stgPosL:cods,stgPos:cods.join(' · '),stgTs:p.stgPos?p.stgTs:isoNow(),stgPor:actor()},{ev:p.stgPos?'mover':'ubicar',de:p.stgPos||'',a:cods.join(' · ')});toast(id+' → '+cods.join(' · ')+'.');}
async function setPallets(id,n){var p=pedGet(id);if(!p||p.estado!=='preparado')return;n=Math.max(1,Math.min(50,parseInt(n,10)||1));if(n===nPal(p))return;var q=clean(p);q.pallets=n;if(posL(q).length>n){q.stgPosL=posL(q).slice(0,n);q.stgPos=q.stgPosL.join(' · ');}if(posL(q).length<n&&q.stgPos){delete q.stgPos;delete q.stgPosL;}await pedGuardar(q);}
async function asignarDock(id,cod){var p=pedGet(id);if(!p||p.estado!=='preparado')return;
  if(cod&&!pos20('dock').some(function(x){return x.codigo===cod;})){toast('Ese dock no existe o está desactivado.');return;}
  await logPed(p,{dock:cod||''},{ev:'dock',de:p.dock||'',a:cod||''});toast(cod?id+' asignado al dock '+cod+'.':'Dock quitado.');}
async function crear(tipo,cod,nom){cod=fSlug(cod);if(!cod){toast('Escribí un código (letras, números o guiones).');return false;}
  if(WC('staging').some(function(x){return x.codigo===cod;})){toast('Ya existe «'+cod+'». Usá otro código.');return false;}
  await wPut('staging',{id:'stg-'+cod.toLowerCase(),codigo:cod,tipo:tipo,nombre:String(nom||'').trim().slice(0,60),activo:true,creado:isoNow(),por:actor()});return true;}
async function gen(tipo,pre,n,ini){pre=fSlug(pre);n=parseInt(n,10);ini=parseInt(ini,10)||1;if(!pre||!(n>=1&&n<=100)){toast('Indicá un prefijo y una cantidad de 1 a 100.');return;}
  var c=0;for(var i=0;i<n;i++){var cod=pre+'-'+String(ini+i).padStart(2,'0');if(WC('staging').some(function(x){return x.codigo===cod;}))continue;await wPut('staging',{id:'stg-'+cod.toLowerCase(),codigo:cod,tipo:tipo,nombre:'',activo:true,creado:isoNow(),por:actor()});c++;}
  toast(c?c+(tipo==='dock'?' docks creados.':' posiciones creadas.'):'Esos códigos ya existían.');}
function selPos(idp,k,ps,oc,cur,sug){return '<select id="'+idp+'-'+k+'" aria-label="Posición pallet '+(k+1)+'">'+(cur?'':'<option value="">Elegí…</option>')+ps.map(function(x){var n=(oc[x.codigo]||[]).filter(function(o){return true;}).length;return '<option value="'+esc(x.codigo)+'"'+((cur||sug)===x.codigo?' selected':'')+'>'+esc(x.codigo)+(x.nombre?' · '+esc(x.nombre):'')+(n?' ('+n+' en uso)':' (libre)')+'</option>';}).join('')+'</select>';}
function card(p,modo){var m=ageMin(modo==='ubicar'?(p.preparado||p.stgTs):p.stgTs),oc=ocup20(),ps=pos20('posicion'),ds=pos20('dock'),np=nPal(p),cur=posL(p);
  var h='<div class="panel" style="margin-bottom:8px"><div class="row sp"><div><strong>'+esc(p.id)+'</strong> · '+esc(p.cliente)+'<div class="small muted">'+esc(p.direccion||'sin dirección')+' · entrega '+esc(fmtFecha(p.entrega||''))+' · '+(p.nb?p.nb+' bultos':'sin etiquetas')+' · '+np+(np===1?' pallet':' pallets')+'</div></div><span class="chip '+ageCls(m)+'">'+(modo==='ubicar'?'Esperando ':'En staging ')+ageTxt(m)+'</span></div>';
  var libres=ps.filter(function(x){return !(oc[x.codigo]||[]).length;}).map(function(x){return x.codigo;});
  var pallets='<label class="small">Pallets <input type="number" class="x20-np" data-id="'+esc(p.id)+'" min="1" max="50" value="'+np+'" style="width:64px"></label>';
  var sels='';for(var k=0;k<np;k++)sels+='<label>'+(np>1?'Pallet '+(k+1):'Posición')+selPos('x20-sel-'+esc(p.id),k,ps,oc,cur[k]||'',cur[k]?'':(libres[k]||''))+'</label>';
  if(modo==='ubicar')h+=ps.length?'<div class="row" style="margin-top:8px;flex-wrap:wrap">'+pallets+sels+'<button class="btn pri" data-act="x20-ubi" data-id="'+esc(p.id)+'">Dejar acá</button></div>':'<div class="small muted" style="margin-top:8px">No hay posiciones creadas. '+(isAdm()?'Creálas en «Posiciones y docks».':'Pedile a administración que las cree.')+'</div>';
  else{h+='<div class="row" style="margin-top:6px;gap:6px;flex-wrap:wrap">'+cur.map(function(c){return '<span class="chip ok">📍 '+esc(c)+'</span>';}).join('')+(p.dock?'<span class="chip">Dock '+esc(p.dock)+'</span>':'')+'<span class="small muted">dejado por '+esc(p.stgPor||'—')+'</span></div>'+
    '<div class="row" style="margin-top:8px;flex-wrap:wrap">'+pallets+sels+'<button class="btn" data-act="x20-ubi" data-id="'+esc(p.id)+'">Mover</button>'+
    (ds.length?'<label>Dock<select id="x20-dk-'+esc(p.id)+'"><option value="">Sin dock</option>'+ds.map(function(x){return '<option value="'+esc(x.codigo)+'"'+(p.dock===x.codigo?' selected':'')+'>'+esc(x.codigo)+(x.nombre?' · '+esc(x.nombre):'')+'</option>';}).join('')+'</select></label><button class="btn" data-act="x20-dock" data-id="'+esc(p.id)+'">Asignar</button>':'')+
    '<button class="btn ok" data-act="x20-desp" data-id="'+esc(p.id)+'">Ir a despachar</button></div>';}
  return h+'</div>';}
function isOk20(p){var o=p.stgOk;return !!(o&&o.ts);}
function lineasDe(p){if(p.suelto)return (p.pk.lineas||[]).map(function(l){return {ubi:l.ubi,sku:l.sku,lote:l.lote||'',vence:l.vence||'',qty:l.qty,rec:l.rec!=null?l.rec:l.qty};});
  var pk=WC('picks').find(function(x){return x.id===p.pickId;});if(pk&&(pk.lineas||[]).length)return pk.lineas.map(function(l){return {ubi:l.ubi,sku:l.sku,lote:l.lote||'',vence:l.vence||'',qty:l.qty,rec:l.rec!=null?l.rec:l.qty};});
  return (p.reserva||[]).map(function(r){return {ubi:r.ubi,sku:r.sku,lote:r.lote||'',vence:r.vence||'',qty:r.qty,rec:r.qty};});}
function okBtn(p){return '<button class="btn sm '+(isOk20(p)?'':'ok')+'" data-act="x20-ok" data-id="'+esc(p.id)+'">'+(isOk20(p)?'Quitar control':'✔ Marcar controlada para salir')+'</button>';}
function okChip(p){return isOk20(p)?'<span class="chip ok">✔ Controlada · '+esc(p.stgOk.por||'')+' · '+esc(new Date(p.stgOk.ts).toLocaleTimeString('es-AR',{hour:'2-digit',minute:'2-digit'}))+'</span>':'<span class="chip warn">Sin controlar</span>';}
function cardS(o){var m=ageMin(o.stgTs);return '<div class="panel" style="margin-bottom:8px"><div class="row sp"><div><strong>'+esc(o.id)+'</strong> · '+esc(o.cliente)+'<div class="small muted">Picking sin pedido</div></div><span class="chip '+ageCls(m)+'">En staging '+ageTxt(m)+'</span></div><div class="row" style="margin-top:6px;gap:6px;flex-wrap:wrap">'+posL(o).map(function(c){return '<span class="chip ok">📍 '+esc(c)+'</span>';}).join('')+okChip(o)+'</div><div class="row" style="margin-top:8px;flex-wrap:wrap">'+okBtn(o)+'<button class="btn sm" data-act="x20-pos" data-id="'+esc(posL(o)[0]||'')+'">Ver detalle</button><button class="btn sm ok" data-act="x31-stgfuera" data-id="'+esc(o.id)+'">Liberar posición</button></div></div>';}
function posDetalle(){var c=U.pos;if(!c)return '';var l=ocup20()[c]||[];
  if(!l.length)return '<div class="panel"><h3>'+esc(c)+'</h3><div class="small muted">Posición libre.</div></div>';
  return l.map(function(p){var ls=lineasDe(p);return '<div class="panel"><div class="row sp"><h3>'+esc(c)+' · '+esc(p.id)+'</h3>'+okChip(p)+'</div><div class="small muted">'+esc(p.cliente||'')+(p.suelto?' · picking sin pedido':(p.entrega?' · entrega '+esc(fmtFecha(p.entrega)):''))+'</div>'+
    (ls.length?tbl(['Producto','Lote','Vence','Cantidad','Pickeado'],ls.map(function(x){return [skuTxt(x.sku),esc(x.lote||'—'),esc(x.vence||'—'),nf(x.qty),nf(x.rec)];}),420):'<div class="small muted">Sin detalle de productos.</div>')+
    '<div class="row" style="margin-top:10px;flex-wrap:wrap">'+okBtn(p)+(p.suelto?'<button class="btn sm ok" data-act="x31-stgfuera" data-id="'+esc(p.id)+'">Liberar posición</button>':'')+'</div></div>';}).join('');}
function mapa(){var oc=ocup20(),ps=pos20('posicion');if(!ps.length)return '<div class="empty">No hay posiciones creadas.</div>';
  return '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:8px">'+ps.map(function(x){var l=oc[x.codigo]||[];var allOk=l.length&&l.every(isOk20),sel=U.pos===x.codigo;return '<div class="panel" data-act="x20-pos" data-id="'+esc(x.codigo)+'" role="button" tabindex="0" style="padding:8px;margin:0;cursor:pointer;border-color:'+(sel?'var(--accent,#ff6a1a)':allOk?'var(--ok,#2a7)':l.length?'var(--warn,#c80)':'var(--line,#ccc)')+(sel?';border-width:2px':'')+'"><strong>'+esc(x.codigo)+'</strong>'+(allOk?' <span class="chip ok">✔ controlada</span>':'')+(x.nombre?'<div class="small muted">'+esc(x.nombre)+'</div>':'')+(l.length?l.map(function(p){return '<div class="small">'+esc(p.id)+'<br><span class="muted">'+esc(p.cliente)+'</span></div>';}).join(''):'<div class="small muted">Libre</div>')+'</div>';}).join('')+'</div>';}
function conf(){var all=WC('staging').slice().sort(function(a,b){return a.tipo.localeCompare(b.tipo)||String(a.codigo).localeCompare(String(b.codigo),'es',{numeric:true});}),oc=ocup20();
  if(!isAdm())return '<div class="empty">Solo administración crea o desactiva posiciones y docks.</div>';
  var h='<div class="panel"><h3>Crear una posición o un dock</h3><div class="row" style="flex-wrap:wrap"><label>Tipo<select id="x20-tipo"><option value="posicion">Posición de staging</option><option value="dock">Dock de carga</option></select></label><label>Código<input id="x20-cod" maxlength="20" placeholder="Ej: STG-01 o DOCK-1" autocomplete="off"></label><label>Nombre (opcional)<input id="x20-nom" maxlength="60" placeholder="Ej: Zona norte"></label><button class="btn pri" data-act="x20-crear">Crear</button></div></div>'+
   '<div class="panel"><h3>Crear varias de una vez</h3><div class="row" style="flex-wrap:wrap"><label>Tipo<select id="x20-gtipo"><option value="posicion">Posiciones</option><option value="dock">Docks</option></select></label><label>Prefijo<input id="x20-gpre" maxlength="14" value="STG" style="width:110px"></label><label>Cantidad<input id="x20-gn" type="number" min="1" max="100" value="10" style="width:90px"></label><label>Desde el N°<input id="x20-gini" type="number" min="1" value="1" style="width:90px"></label><button class="btn" data-act="x20-gen">Generar</button></div><div class="small muted">Ej: prefijo STG, cantidad 10 → STG-01 … STG-10. Los que ya existen se saltean.</div></div>';
  h+=all.length?'<div class="panel"><h3>Posiciones y docks ('+all.length+')</h3>'+tbl(['Código','Tipo','Nombre','Estado',''],all.map(function(x){var uso=(oc[x.codigo]||[]).length+prep20().filter(function(p){return p.dock===x.codigo;}).length;return ['<span class="guia">'+esc(x.codigo)+'</span>',x.tipo==='dock'?'Dock de carga':'Posición',esc(x.nombre||'—'),x.activo===false?'<span class="chip">Desactivado</span>':'<span class="chip ok">Activo</span>'+(uso?' <span class="small muted">'+uso+' en uso</span>':''),'<button class="btn sm" data-act="x20-tog" data-id="'+esc(x.id)+'">'+(x.activo===false?'Activar':'Desactivar')+'</button>'+(uso?'':' <button class="btn sm bad" data-act="x20-del" data-id="'+esc(x.id)+'">Borrar</button>')];}),640)+'</div>':'<div class="empty">Todavía no hay posiciones ni docks. Creá una arriba o generá varias de una vez.</div>';
  return h;}
window.xStg20=function xStg20(){var pr=prep20(),sin=pr.filter(function(p){return !p.stgPos;}).filter(matchQ),sl0=sueltos20(),con=pr.filter(function(p){return p.stgPos;}).concat(sl0).filter(matchQ).sort(function(a,b){return String(a.stgTs).localeCompare(String(b.stgTs));}),totSt=pr.filter(function(p){return p.stgPos;}).length+sl0.length,okN=pr.filter(function(p){return p.stgPos&&isOk20(p);}).length+sl0.filter(isOk20).length,dem=con.filter(function(p){return ageMin(p.stgTs)>=120;}),f=U.f||'ubicar';
  var h='<div class="kpis">'+KPI(nf(pr.filter(function(p){return !p.stgPos;}).length),'Por ubicar','preparados sin posición',pr.some(function(p){return !p.stgPos;})?'bad':'')+KPI(nf(totSt),'En staging',okN+' controlados de '+totSt+' · listos para cargar',totSt>okN?'warn':'')+KPI(nf(pos20('posicion').filter(function(x){return !(ocup20()[x.codigo]||[]).length;}).length),'Posiciones libres','de '+pos20('posicion').length)+KPI(nf(dem.length),'Demorados','más de 2 horas',dem.length?'warn':'')+'</div>'+
   '<div class="chips" style="margin:10px 0">'+[['ubicar','Por ubicar ('+sin.length+')'],['staging','En staging ('+con.length+')'],['dem','Demorados ('+dem.length+')'],['mapa','Mapa'],['conf','Posiciones y docks']].map(function(k){return '<button class="chip'+(f===k[0]?' ok':'')+'" data-act="x20-f" data-v="'+k[0]+'">'+k[1]+'</button>';}).join('')+'</div>'+
   (f==='ubicar'||f==='staging'||f==='dem'?'<div class="row" style="margin-bottom:8px"><label style="flex:1">Buscar pedido, cliente, posición o dock<input id="x20-q" type="search" value="'+esc(U.q||'')+'" autocomplete="off"></label></div>':'');
  if(f==='ubicar')h+=sin.length?sin.slice(0,60).map(function(p){return card(p,'ubicar');}).join(''):'<div class="empty">No hay pedidos preparados esperando posición.</div>';
  else if(f==='staging')h+=con.length?con.slice(0,60).map(function(p){return p.suelto?cardS(p):card(p,'staging');}).join(''):'<div class="empty">No hay pedidos en staging.</div>';
  else if(f==='dem')h+=dem.length?dem.slice(0,60).map(function(p){return p.suelto?cardS(p):card(p,'staging');}).join(''):'<div class="empty">Nada demorado.</div>';
  else if(f==='mapa')h+='<div class="panel"><h3>Mapa de staging</h3><div class="small muted" style="margin-bottom:8px">Tocá una posición para ver qué hay: pedido, productos, lote y cantidad.</div>'+mapa()+'</div>'+posDetalle();
  else h+=conf();
  var hist=pr.length?'':'';return h+hist;};
var _vw=viewWms;viewWms=function(){if(S.ui.wsub==='x20stg'){S.ext.sub='x20stg';return '<div class="row sp"><h2>Depósito</h2></div>'+wSub()+window.xStg20();}return _vw();};
var _vd=viewDeposito;viewDeposito=function(){if(S.ui.dep==='wms'&&S.ui.wsub==='x20stg'){var sw='<div class="seg lt" role="group" aria-label="Sección" style="margin-bottom:14px"><button data-act="x-dep" data-id="eq" aria-pressed="false">Equipos</button><button data-act="x-dep" data-id="wms" aria-pressed="true">Depósito (recepción, picking, etiquetas)</button></div>';return sw+viewWms();}return _vd();};
/* despacho: exige posición (si ya hay posiciones creadas) */
var _ed=expDespachar;expDespachar=async function(id){var p=pedGet(id);if(p&&p.estado==='preparado'&&!p.stgPos&&pos20('posicion').length){toast('Primero ubicá el pedido en una posición de staging.');S.ui.wsub='x20stg';U.f='ubicar';render();return;}
  var antes=p&&p.estado==='preparado'?p.stgPos:'';await _ed(id);
  if(antes){var n=0,t=setInterval(function(){n++;var q=pedGet(id);if(q&&q.estado==='despachado'){clearInterval(t);if(!q.stgSalida){logPed(q,{stgSalida:isoNow()},{ev:'salida',de:antes,a:''}).then(function(){toast('Posición de staging '+antes+' liberada.');}).catch(function(){});}}else if(n>10)clearInterval(t);},700);}};
/* Expedición: muestra posición y dock de cada pedido */
var _xe=xExp;xExp=function(){var h=_xe();prep20().forEach(function(p){var b='<span style="display:block;font-size:.72rem;margin-bottom:4px">'+(p.stgPos?posL(p).map(function(c){return '<span class="chip ok">📍 '+esc(c)+'</span>';}).join(' ')+(nPal(p)>1?' <span class="chip">'+nPal(p)+' pallets</span>':'')+(p.dock?' <span class="chip">Dock '+esc(p.dock)+'</span>':''):'<span class="chip warn">Sin posición</span>')+'</span>';h=h.split('<h3>'+esc(p.id)+' · ').join('<h3>'+b+esc(p.id)+' · ');});return h;};
/* aviso en el resto de las pantallas del depósito */
var _vw2=viewWms;viewWms=function(){var h=_vw2();if(S.ui.wsub==='x20stg')return h;var n=prep20().filter(function(p){return !p.stgPos;}).length;if(!n||!pos20('posicion').length)return h;
  return '<div class="banner warn" role="status"><div><strong>'+n+(n===1?' pedido preparado sin posición':' pedidos preparados sin posición')+'</strong>Dejalos en staging para poder despacharlos.</div><button class="btn sm" data-act="wsub" data-v="x20stg">Ubicar ahora</button></div>'+h;};
/* búsqueda con foco */
var _r=render;render=function(){var ae=document.activeElement,k=ae&&ae.id==='x20-q',pos=k?ae.selectionStart:0;_r.apply(this,arguments);if(k){var e=document.getElementById('x20-q');if(e){e.focus();try{e.setSelectionRange(pos,pos);}catch(_){}}}};
var _pc20=pickConfirmar;pickConfirmar=async function(id,ov){await _pc20(id,ov);[1500,4000].forEach(function(ms){setTimeout(function(){pedSync().catch(function(){});},ms);});};
var _gh=guiadoHtml;guiadoHtml=function(){var h=_gh();var id=S.ext.gd&&S.ext.gd.id;return id?h.replace('<div id="gd-cam"></div></div>','<div id="gd-cam"></div><div class="row" style="margin-top:8px">'+palCtl20(id)+'</div></div>'):h;};
document.addEventListener('change',async function(ev){var t=ev.target;if(!t||!t.classList)return;var P;
  if(t.classList.contains('pal20-on')){P=(S.ext.pal20=S.ext.pal20||{});P[t.dataset.id]=Object.assign(P[t.dataset.id]||{n:2},{on:t.checked});render();}
  else if(t.classList.contains('pal20-n')){P=(S.ext.pal20=S.ext.pal20||{});P[t.dataset.id]=Object.assign(P[t.dataset.id]||{},{on:true,n:Math.max(2,Math.min(50,parseInt(t.value,10)||2))});render();}
  else if(t.classList.contains('pk20-pos')){P=(S.ext.pal20=S.ext.pal20||{});var Q=P[t.dataset.id]=P[t.dataset.id]||{on:false,n:2};Q.pos=(Q.pos||[]).slice();Q.pos[+t.dataset.k]=t.value;}
  else if(t.classList.contains('x20-np')){try{await setPallets(t.dataset.id,t.value);}catch(e){toast('No se pudo guardar.');}}});
document.addEventListener('input',function(ev){if(ev.target&&ev.target.id==='x20-q'){U.q=ev.target.value;render();}});
document.addEventListener('click',async function(ev){var b=ev.target.closest&&ev.target.closest('[data-act^="x20-"]');if(!b)return;var a=b.dataset.act,id=b.dataset.id;
  try{if(a==='x20-f'){U.f=b.dataset.v;render();}
  else if(a==='x20-pos'){U.pos=(U.pos===id?'':id);U.f='mapa';render();}
  else if(a==='x20-ok'){var pq=pedGet(id);if(pq){await logPed(pq,{stgOk:isOk20(pq)?'':{ts:isoNow(),por:actor()}},{ev:'control'});}else{var kk=WC('picks').find(function(x){return x.id===id;});if(kk){kk=clean(kk);kk.stgOk=(kk.stgOk&&kk.stgOk.ts)?'':{ts:isoNow(),por:actor()};await wPut('picks',kk);}}toast('Listo.');}
  else if(a==='x20-ubi'){var pp=pedGet(id),c=[];for(var k=0;k<(pp?nPal(pp):1);k++)c.push(gv('x20-sel-'+id+'-'+k));await ubicar(id,c);}
  else if(a==='x20-dock')await asignarDock(id,gv('x20-dk-'+id));
  else if(a==='x20-desp'){X8.ui.expSel=id;S.ui.wsub='x8exp';render();}
  else if(a==='x20-crear'){if(await crear(gv('x20-tipo'),gv('x20-cod'),gv('x20-nom')))toast('Creado.');}
  else if(a==='x20-gen')await gen(gv('x20-gtipo'),gv('x20-gpre'),gv('x20-gn'),gv('x20-gini'));
  else if(a==='x20-tog'&&isAdm()){var s=WC('staging').find(function(x){return x.id===id;});if(s)await wPut('staging',Object.assign({},s,{activo:s.activo===false}));}
  else if(a==='x20-del'&&isAdm()){await wDel('staging',id);}}catch(e){if(window.console)console.error(e);toast('No se pudo guardar. Probá de nuevo.');}});
})();
/* ===== EXT20 end ===== */

/* ===== EXT21: conteo cíclico aleatorio ===== */
(function(){
var _xc=xConteos;xConteos=function(){var h=_xc(),n=S.ext.cnR21||10,nsku=(function(){var st=wStock(),m={};Object.keys(st.m).forEach(function(k){if(st.m[k]>0)m[k.split('|')[1]]=1;});return Object.keys(m).length;})();
  var panel='<div class="panel"><h3>Conteo al azar</h3><div class="small muted">El sistema elige SKU al azar entre los que tienen stock y, de cada uno, una ubicación al azar. Elegí cuántos querés contar.</div><div class="row" style="margin-top:8px;flex-wrap:wrap"><label>Cantidad de SKU a contar<input id="cn-rnd-n" type="number" min="1" max="200" value="'+esc(n)+'" style="width:110px"></label><button class="btn pri" data-act="x-cnR">Sortear y armar conteo</button></div><div class="small muted">SKU con stock disponible para sortear: '+nf(nsku)+'.</div></div>';
  var mark='como "AJUSTE".</div></div>';return h.indexOf(mark)>=0?h.replace(mark,mark+panel):panel+h;};
function rnd(n){if(window.crypto&&crypto.getRandomValues){var a=new Uint32Array(1);crypto.getRandomValues(a);return a[0]/4294967296*n;}return Math.random()*n;}
async function sortear(){var n=parseInt(gv('cn-rnd-n'),10);if(!(n>=1&&n<=200)){toast('Indicá una cantidad de 1 a 200.');return;}S.ext.cnR21=n;
  var st=wStock(),por={};Object.keys(st.m).forEach(function(k){if(st.m[k]>0){var q=k.split('|');(por[q[1]]=por[q[1]]||[]).push(q[0]);}});
  var skus=Object.keys(por);if(!skus.length){toast('No hay stock para contar.');return;}
  for(var i=skus.length-1;i>0;i--){var j=Math.floor(rnd(i+1)),t=skus[i];skus[i]=skus[j];skus[j]=t;}
  var pick=skus.slice(0,n),items=pick.map(function(sk){var u=por[sk][Math.floor(rnd(por[sk].length))];return {ubi:u,sku:sk,sistema:st.m[u+'|'+sk]};}).sort(function(a,b){return a.ubi.localeCompare(b.ubi);});
  await wPut('conteos',{id:uid('CN'),fecha:HOY,estado:'abierto',items:items,por:actor(),modo:'azar'});toast('Conteo al azar armado: '+items.length+' SKU'+(items.length<n?' (no había más con stock)':'')+'.');}
document.addEventListener('click',async function(ev){var b=ev.target.closest&&ev.target.closest('[data-act="x-cnR"]');if(!b)return;try{await sortear();}catch(e){if(window.console)console.error(e);toast('No se pudo armar el conteo.');}});
})();
/* ===== EXT21 end ===== */

/* ===== EXT22: reposición masiva con selección ===== */
(function(){
function key(r){return [r.sku,r.hacia,r.desde,r.lote||''].join('~');}
var _xr=xRepo;xRepo=function(){var h=_xr(),sg=repoSug();if(!sg.length)return h;var off=(S.ext.rp22=S.ext.rp22||{}),st=wStock(),ub=x8ubic(),n=sg.filter(function(r){return !off[key(r)];}).length;
  var tot=sg.filter(function(r){return !off[key(r)];}).reduce(function(a,r){return a+r.qty;},0);
  var panel='<div class="panel"><h3>Productos bajo el '+repoPct()+'% ('+sg.length+')</h3><div class="small muted">Tildá los que querés reponer y pedí todo junto. Se crea una tarea por cada uno y le llegan al operario ordenadas.</div><div class="row" style="margin:8px 0;flex-wrap:wrap"><button class="btn" data-act="x22-todo" data-v="1">Tildar todos</button><button class="btn" data-act="x22-todo" data-v="0">Destildar todos</button></div>'+
   tbl(['','SKU','Nivel hoy','Origen → destino','Reponer'],sg.map(function(r){var u=ub[r.hacia],cur=Math.max(0,st.m[r.hacia+'|'+r.sku]||0),pc=u&&u.cap>0?Math.round(cur/u.cap*100):null;
     return ['<input type="checkbox" class="rp22-c" data-k="'+esc(key(r))+'"'+(off[key(r)]?'':' checked')+' aria-label="Reponer '+esc(r.sku)+'">','<span class="guia">'+esc(r.sku)+'</span><div class="small muted">'+esc(r.producto||'')+'</div>',pc==null?nf(cur)+' u':'<span class="chip '+(pc<=10?'bad':'warn')+'">'+pc+'%</span> <span class="small muted">'+nf(cur)+'/'+nf(u.cap)+'</span>','<span class="mono">'+esc(r.desde)+'</span> → <span class="mono">'+esc(r.hacia)+'</span>'+(r.vence?'<div class="small muted">vence '+esc(r.vence)+'</div>':''),nf(r.qty)+' u'];}),560)+
   '<div class="row" style="margin-top:10px"><button class="btn pri" data-act="x22-crear"'+(n?'':' disabled')+'>Solicitar reposición de '+n+(n===1?' producto':' productos')+' ('+nf(tot)+' u)</button></div></div>';
  var m='<div class="panel"><h3>Tareas pendientes';return h.indexOf(m)>=0?h.replace(m,panel+m):h+panel;};
document.addEventListener('change',function(ev){var t=ev.target;if(t&&t.classList&&t.classList.contains('rp22-c')){var o=(S.ext.rp22=S.ext.rp22||{});if(t.checked)delete o[t.dataset.k];else o[t.dataset.k]=1;render();}});
document.addEventListener('click',async function(ev){var b=ev.target.closest&&ev.target.closest('[data-act^="x22-"]');if(!b)return;var o=(S.ext.rp22=S.ext.rp22||{});
  try{if(b.dataset.act==='x22-todo'){repoSug().forEach(function(r){if(b.dataset.v==='1')delete o[key(r)];else o[key(r)]=1;});render();}
  else{var sel=repoSug().filter(function(r){return !o[key(r)];});if(!sel.length){toast('No hay nada tildado.');return;}b.disabled=true;
    for(var i=0;i<sel.length;i++){var r=sel[i];await wPut('repos',{id:uid('RP'),sku:r.sku,producto:r.producto,hacia:r.hacia,desde:r.desde,lote:r.lote,vence:r.vence,qty:r.qty,estado:'pendiente',creada:isoNow(),por:actor(),auto:false});}
    toast(sel.length+(sel.length===1?' tarea de reposición creada.':' tareas de reposición creadas.'));}}catch(e){if(window.console)console.error(e);toast('No se pudieron crear todas. Revisá la lista de pendientes.');}});
})();
/* ===== EXT22 end ===== */

/* ===== EXT23: en todos lados donde hay un SKU, mostrar en qué posiciones está y cuánto hay ===== */
(function(){
var skuTxt0=window.skuTxt0=skuTxt;
var memo={k:null,n:-1,v:null};
function mapa(){var st=wStock();if(memo.k===st&&memo.v)return memo.v;var by={};Object.keys(st.m).forEach(function(k){var q=st.m[k];if(q>0){var i=k.indexOf('|');(by[k.slice(i+1)]=by[k.slice(i+1)]||[]).push([k.slice(0,i),q]);}});
  Object.keys(by).forEach(function(c){by[c].sort(function(a,b){return b[1]-a[1]||String(a[0]).localeCompare(String(b[0]));});});memo={k:st,v:by};return by;}
window.skuPosL23=function(c){return mapa()[c]||[];};
window.skuPos23=function(c,max){var l=mapa()[c]||[],m=max||6;if(!l.length)return '';return l.slice(0,m).map(function(x){return x[0]+' ('+nf(x[1])+')';}).join(' · ')+(l.length>m?' · +'+(l.length-m)+' más':'');};
skuTxt=function(c){var t=skuPos23(c);return skuTxt0(c)+'<span class="small muted" style="display:block;font-weight:400;font-size:.8em">📍 '+(t?esc(t):'sin stock')+'</span>';};
function deco(){var by=mapa(),codes={};(W().skus||[]).forEach(function(k){codes[k.codigo]=1;});
  [].forEach.call(document.querySelectorAll('select'),function(sel){if(sel.dataset.d23)return;var o=[].slice.call(sel.options),hit=o.filter(function(x){return x.value&&codes[x.value];}).length;if(!hit||hit<(o.filter(function(x){return x.value;}).length)*0.7)return;sel.dataset.d23='1';
    o.forEach(function(x){if(!x.value||!codes[x.value])return;var l=by[x.value]||[];x.text=x.text+' — '+(l.length?l.slice(0,3).map(function(y){return y[0]+' ('+nf(y[1])+')';}).join(', ')+(l.length>3?' +'+(l.length-3):''):'sin stock');});});
  var mu=document.getElementById('m-ubi'),m=S.ui.m||{};if(mu&&m.sku&&!mu.dataset.d23){mu.dataset.d23='1';var l=by[m.sku]||[],q={};l.forEach(function(y){q[y[0]]=y[1];});
    if(m.tipo==='IN'){[].forEach.call(mu.options,function(x){if(x.value&&q[x.value])x.text=x.text+' ('+nf(q[x.value])+')';});}
    else{var cur=mu.value,h='<option value="">'+(l.length?'Elegir…':'Sin stock de este SKU')+'</option>'+l.map(function(y){return '<option value="'+esc(y[0])+'">'+esc(y[0])+' ('+nf(y[1])+' u)</option>';}).join('');mu.innerHTML=h;if(q[cur])mu.value=cur;}}}
var _r=render;render=function(){_r.apply(this,arguments);try{deco();}catch(e){if(window.console)console.error(e);}};
})();
/* ===== EXT23 end ===== */

/* ===== EXT24: carga por planilla (CSV o Excel) dentro de Fichas ===== */
(function(){
var _vp=viewPersonal;viewPersonal=function(){var h=_vp(),o='';
  try{var x=xCarga(),i=x.indexOf('<div class="panel"><h3>1. Plantillas'),j=x.indexOf('<div class="panel"><h3>4.');if(i>=0&&j>i)o=x.slice(i,j).replace('1. Plantillas','Cargar por planilla: plantillas').replace('2. Alta masiva de usuarios','Empleados y clientes (CSV o Excel)').replace('3. Vehículos','Máquinas y vehículos (CSV o Excel)');}catch(e){if(window.console)console.error(e);}
  return h+(o?'<h2 style="margin-top:22px">Cargar muchos de una vez</h2><p class="small muted" style="margin:0 0 8px">Empleados y clientes van en el mismo archivo (la columna Rol dice quién es quién). Las máquinas, autoelevadores y camiones van en el de vehículos. Podés subir CSV o Excel (.xlsx).</p>'+o:'');};
})();
/* ===== EXT24 end ===== */

/* ===== EXT25: emojis en títulos, medidores circulares en indicadores y paleta de colores ===== */
(function(){
var EM={'chofer':'🚐','chófer':'🚐','deposito':'🏭','depósito':'🏭','cliente':'🤝','administración':'🧑‍💼','administracion':'🧑‍💼',
'operación':'⚙️','control':'🛡️','dashboard':'📊','viajes':'🗺️','equipos y personal':'👷','equipos':'🚜','check lists':'✅','fichas':'🪪','gestión':'🗂️','simulación':'🧪',
'hoja de ruta':'🧭','stock':'📦','plano':'🏗️','peso y orden':'⚖️','movimiento':'🔄','kardex':'📒','abc-xyz':'🔠','lotes y fefo':'⏳','conteos':'🔢','picking':'🛒',
'logística inversa':'↩️','productos y ubicaciones':'📍','staging':'🚪','expedición':'🚚','reposición':'🔁','mantenimiento':'🔧','hoy':'📅','mañana':'🌅','salir':'👋',
'nueva entrega':'➕','entregas':'🚚','pedidos':'🧾','recepción':'📥','recepciones':'📥','incidencias':'⚠️','facturas de fletes':'🧮','costos':'💰','indicadores':'📈',
'inicio':'🏠','rotación y salida':'📈','etiquetas':'🏷️','valorizado':'💲','staging y despacho':'🚪','efectividad':'🎯','recorrido estimado':'🛣️','combustible estimado':'⛽','importar excel':'📥','exportar':'📤','ver demostración':'🎬','ir al portal en vivo':'🟢','vencimientos para revisar':'📆'};
var KE=[['otif','🎯'],['exactitud','🎯'],['ira','🎯'],['efectividad','🎯'],['recorrido','🛣️'],['combustible','⛽'],['entregas','🚚'],['entregada','✅'],['no entregada','❌'],['costo','💰'],['gasto','💵'],['stock','📦'],['unidades','📦'],['reordenar','🔔'],['quiebre','🚨'],['ocupación','📊'],['devoluc','↩️'],['conteo','🔢'],['incidencia','⚠️'],['órdenes','🔧'],['pedidos','🧾'],['posicion','📍'],['posicion','📍'],['alerta','🚨'],['sku','🏷️'],['flete','🚛'],['margen','💹'],['ahorro','💸'],['staging','🚪'],['ubicar','📍'],['demorad','⏱️'],['programadas','🗓️'],['en camino','🚚'],['reingres','♻️'],['cerrad','🔒'],['abiertos','📂'],['ajustad','⚖️'],['vencid','⛔'],['a tiempo','⏱️'],['completo','✅']];
function emo(t){var k=String(t||'').trim().toLowerCase();if(EM[k])return EM[k];var m=/^(control|alertas|pedidos|clientes|choferes|chóferes)\b/.exec(k);return m?EM[m[1]]||({control:'🛡️',alertas:'🚨',clientes:'🤝',choferes:'🚐',chóferes:'🚐'})[m[1]]||'':'';}
function hasEmo(t){return /^[←-⯿\u{1F000}-\u{1FAFF}]/u.test(t.trim());}
var VEH='🚐🚚🚛🚜🏍🛻',SPIN='🔁🔄♻️',RING='🔔🚨',last={k:'',t:0};
function kind(e){return e==='🏭'?'fab':VEH.indexOf(e)>=0?'veh':SPIN.indexOf(e)>=0?'spin':RING.indexOf(e)>=0?'ring':e==='⏳'?'flip':'pop';}
var didGo=false;
function put(el,node,e,txt){var sp=document.createElement('span');sp.className='emo e-'+kind(e);sp.setAttribute('aria-hidden','true');sp.textContent=e;
  node.nodeValue=' '+txt.trim();el.insertBefore(sp,node);
  var el0=Date.now()-last.t;
  if(!didGo&&el0<900&&last.k===txt.trim().toLowerCase()){didGo=true;sp.style.animationDelay='-'+el0+'ms';sp.classList.add('go');setTimeout(function(){sp.classList.remove('go');},900-el0);}}
function deco(){didGo=false;
  [].forEach.call(document.querySelectorAll('.seg button,h2,h3,.btn'),function(el){
    if(el.dataset.e25||el.childNodes.length!==1||el.firstChild.nodeType!==3)return;el.dataset.e25='1';
    var t=el.textContent,e=emo(t);if(e&&!hasEmo(t))put(el,el.firstChild,e,t);});
  [].forEach.call(document.querySelectorAll('.kpi'),function(k,i){
    if(k.dataset.e25)return;k.dataset.e25='1';k.dataset.c=String(i%6);
    var l=k.querySelector('.l'),b=k.querySelector('b');if(!l||!b)return;
    var lt=l.textContent.toLowerCase();
    if(!hasEmo(lt)&&l.childNodes.length===1){for(var j=0;j<KE.length;j++){if(lt.indexOf(KE[j][0])>=0){put(l,l.firstChild,KE[j][1],l.textContent);break;}}}
    var m=/^\s*(\d+(?:[.,]\d+)?)\s*%\s*$/.exec(b.textContent);
    if(m){var p=Math.max(0,Math.min(100,parseFloat(m[1].replace(',','.'))));
      var st=b.getAttribute('style')||'',col=/var\(--(ok|warn|bad)\)/.exec(st);
      var g=document.createElement('div');g.className='gauge';g.style.setProperty('--p',p);if(col)g.style.setProperty('--gc','var(--'+col[1]+')');
      g.setAttribute('role','img');g.setAttribute('aria-label',b.textContent.trim());g.innerHTML='<b>'+b.textContent.trim()+'</b>';
      k.classList.add('g');k.appendChild(g);}
  });
}
document.addEventListener('pointerdown',function(ev){var t=ev.target&&ev.target.closest&&ev.target.closest('.seg button,h2,h3,.btn,.kpi,.brand');if(!t)return;
  var sp=t.querySelector('.emo');if(!sp)return;var tx=t.textContent.replace(sp.textContent,'').trim().toLowerCase();last={k:tx,t:Date.now()};
  sp.classList.remove('go');sp.style.animationDelay='';void sp.offsetWidth;sp.classList.add('go');setTimeout(function(){sp.classList.remove('go');},900);},true);
var _r=render;render=function(){_r.apply(this,arguments);try{deco();}catch(e){if(window.console)console.error(e);}};
})();
/* ===== EXT25 end ===== */

/* ===== EXT26: misión del día, celebraciones, racha personal y guías (sin rankings ni comparaciones entre personas) ===== */
(function(){
var prev={},G={chofer:['🚐','Tu día en 3 pasos',[['📋','Mirá tu hoja de ruta','Las paradas están en orden. La próxima aparece primero.'],['📍','Llegá y registrá la entrega','Foto, firma y cantidad. Si no pudiste entregar, contá por qué.'],['↩️','Declará lo que devuelve el cliente','Así el depósito lo recibe bien y el stock queda justo.']]],
deposito:['🏭','Tu día en 3 pasos',[['🛒','Picking','Seguí el orden que te muestra la pantalla. Cada línea te dice en qué posición está y cuánto hay.'],['🚪','Dejá el pedido en staging','Elegí la posición de staging al cerrar el picking y tildá si tiene más de un pallet.'],['🔢','Conteos y reposición','Contá lo que te sortea el sistema y avisá lo que está bajo el 30%.']]],
admin:['🧑‍💼','Tu panel en 3 pasos',[['🚨','Primero lo urgente','Las alertas de arriba (vencimientos, quiebres) son lo primero para resolver.'],['📊','Mirá el Dashboard','Los círculos te muestran de un vistazo cómo viene la operación.'],['🗂️','Gestioná en Fichas y Depósito','Altas masivas por planilla, stock por posición y pedidos.']]],
cliente:['🤝','Tus entregas en 3 pasos',[['🚚','Seguí tu pedido','Ves el estado y la ventana horaria de cada entrega.'],['✍️','Confirmá al recibir','El chófer registra la entrega con tu firma.'],['↩️','¿Algo no está bien?','Avisá la diferencia y se gestiona la devolución.']]]};
function esc2(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
function ls(k,v){try{if(v===undefined)return JSON.parse(localStorage.getItem(k)||'null');localStorage.setItem(k,JSON.stringify(v));}catch(_){return null;}}
function racha(){var id=(S.me&&S.me.id)||('demo-'+S.demoRol),k='pl-racha-'+id,r=ls(k)||{d:'',n:0};
  if(r.d!==HOY){r={d:HOY,n:(r.d===addDays(-1)?r.n+1:1)};ls(k,r);}return r.n;}
function bar(p){return '<div class="bar" style="margin:6px 0"><i style="width:'+Math.max(0,Math.min(100,p))+'%"></i></div>';}
function datos(rol){
  if(rol==='chofer'){var yo=miId(),all=D().entregas.filter(function(e){return e.choferId===yo;}),hoy=all.filter(function(e){return e.fecha===HOY;}),
      hechas=hoy.filter(function(e){return e.estado==='entregada'||e.estado==='no_entregada';}).length,tot=hoy.length,ok=all.filter(function(e){return e.estado==='entregada';}).length;
    return {key:'hechas',val:hechas,tot:tot,pct:tot?hechas/tot*100:0,
      txt:!tot?'Hoy no tenés paradas asignadas.':hechas>=tot?'¡Jornada completa! Todo entregado.':'Te faltan '+(tot-hechas)+(tot-hechas===1?' parada':' paradas')+' para cerrar el día.',
      meta:hechas+' de '+tot+' paradas',done:tot>0&&hechas>=tot,msg:'¡Parada lista!',fin:'🎉 ¡Jornada completa!',logros:[[ok>=1,'🥇','Primera entrega'],[ok>=10,'🚚','10 entregas'],[ok>=50,'🏅','50 entregas'],[ok>=100,'🏆','100 entregas']]};}
  if(rol==='deposito'){var ps=WC('pedidos'),pen=ps.filter(function(p){return p.estado==='reservado'||p.estado==='preparacion';}).length,lis=ps.filter(function(p){return p.estado==='preparado';}).length,t=pen+lis;
    return {key:'listos',val:lis,tot:t,pct:t?lis/t*100:0,
      txt:!t?'No hay pedidos para preparar ahora.':!pen?'¡Todo preparado! Quedan pedidos listos para cargar.':'Quedan '+pen+(pen===1?' pedido':' pedidos')+' para preparar.',
      meta:lis+' listos · '+pen+' por preparar',done:t>0&&!pen,msg:'¡Pedido listo!',fin:'🎉 ¡Todo preparado!',logros:[]};}
  if(rol==='admin'){var es=D().entregas.filter(function(e){return e.fecha===HOY;}),h=es.filter(function(e){return e.estado==='entregada'||e.estado==='no_entregada';}).length;
    return {key:'adm',val:h,tot:es.length,pct:es.length?h/es.length*100:0,
      txt:!es.length?'Hoy no hay entregas programadas.':h>=es.length?'¡Día completo! Todas las entregas cerradas.':'Van '+h+' de '+es.length+' entregas de hoy.',
      meta:h+' de '+es.length+' entregas',done:es.length>0&&h>=es.length,msg:'¡Entrega cerrada!',fin:'🎉 ¡Día completo!',logros:[]};}
  if(rol==='cliente'){var c=D().entregas.filter(function(e){return S.mode==='demo'?e.clienteId==='c2':true;}),cam=c.filter(function(e){return e.estado==='en_camino';}).length,pr=c.filter(function(e){return e.estado==='programada';}).length;
    return {key:'cli',val:cam,tot:0,pct:0,txt:cam?'Tenés '+cam+(cam===1?' entrega en camino.':' entregas en camino.'):pr?'Tenés '+pr+' programadas.':'No hay entregas pendientes.',meta:'',done:false,msg:'',fin:'',logros:[],nobar:true};}
  return null;}
function conf(){var host=document.createElement('div');host.className='conf25';host.setAttribute('aria-hidden','true');
  var E=['🎉','✨','🟠','🔵','🟣','🟢','⭐'];for(var i=0;i<26;i++){var s=document.createElement('span');s.textContent=E[i%E.length];s.style.left=(Math.random()*100)+'%';s.style.animationDelay=(Math.random()*.5)+'s';s.style.fontSize=(14+Math.random()*14)+'px';host.appendChild(s);}
  document.body.appendChild(host);setTimeout(function(){host.remove();},2600);}
function card(){var rol=rolActual();if(!rol||S.ui.mision25===false)return '';
  if(rol==='admin'&&S.ui.tab&&S.ui.tab!=='op')return '';
  if(rol==='deposito'&&S.ui.wsub&&S.ui.wsub!=='inicio'&&S.ui.dep==='wms')return '';
  var d=datos(rol),g=G[rol];if(!d||!g)return '';
  var r=racha(),k=rol+'|'+d.key,p=prev[k];
  if(p!==undefined&&d.val>p){if(d.done&&d.tot>0){toast(d.fin);}else toast(d.msg+' Van '+d.meta+'.');conf();}
  prev[k]=d.val;
  var lg=d.logros.filter(function(x){return x[0];}).map(function(x){return '<span class="chip ok" title="'+esc2(x[2])+'">'+x[1]+' '+esc2(x[2])+'</span>';}).join(' ');
  var rb=r>=30?'🏆':r>=7?'🔥':r>=3?'⚡':'🌱';
  var open=S.ui.guia25?' open':'';
  return '<section class="mision" aria-label="Misión del día"><div class="row sp"><div><div class="mi-t">🎯 Misión de hoy</div><div class="mi-x">'+esc2(d.txt)+'</div></div>'+
    '<div class="mi-r" title="Días seguidos usando el portal. Es solo tuyo: nadie más lo ve."><b>'+rb+' '+r+'</b><span>'+(r===1?'día':'días')+' seguidos</span></div></div>'+
    (d.nobar?'':bar(d.pct)+'<div class="small muted">'+esc2(d.meta)+'</div>')+
    (lg?'<div class="chips" style="margin-top:8px">'+lg+'</div>':'')+
    '<details class="guia25"'+open+'><summary>'+g[0]+' ¿Cómo funciona? · '+esc2(g[1])+'</summary><ol class="g-steps">'+g[2].map(function(s){return '<li><span class="g-e">'+s[0]+'</span><div><b>'+esc2(s[1])+'</b><br><span class="muted small">'+esc2(s[2])+'</span></div></li>';}).join('')+'</ol></details></section>';}
var _mh=mainHtml;mainHtml=function(){var c='';try{c=card();}catch(e){if(window.console)console.error(e);}return c+_mh.apply(this,arguments);};
document.addEventListener('toggle',function(ev){var t=ev.target;if(t&&t.classList&&t.classList.contains('guia25'))S.ui.guia25=t.open;},true);
})();
/* ===== EXT26 end ===== */

/* ===== EXT27: ajustes por puesto (gerente, administrativo, depósito, chófer, cliente) ===== */
(function(){
function pct(a,b){return b?Math.round(a/b*100):null;}
function gaugeHtml(v,l,sub,bad){var p=v==null?0:v,col=v==null?'var(--muted)':bad?bad:(p>=90?'var(--ok)':p>=70?'var(--warn)':'var(--bad)');
  return '<div class="t25"><div class="gauge" style="--p:'+p+';--gc:'+col+'" role="img" aria-label="'+l+' '+(v==null?'sin datos':v+'%')+'"><b>'+(v==null?'—':v+'%')+'</b></div><div class="t25-l">'+l+'</div><div class="t25-s">'+sub+'</div></div>';}
function tablero(){
  var hoy=D().entregas.filter(function(e){return e.fecha===HOY;}),hec=hoy.filter(function(e){return e.estado==='entregada'||e.estado==='no_entregada';}).length;
  var sem=D().entregas.filter(function(e){return e.fecha>=addDays(-6)&&e.fecha<=HOY&&e.estado==='entregada';}),ot=sem.filter(onTime).length;
  var w=W(),st=wStock(),capT=(w.ubic||[]).reduce(function(t,u){return t+(u.cap||0);},0),uni=Object.keys(st.tot).reduce(function(t,k){return t+st.tot[k];},0);
  var sk=w.skus||[],rj=sk.filter(function(r){return wAlert((st.tot[r.codigo]||0)-r.min,r.min)==='REORDEN';}).length;
  var al=[],lv=0;try{lv=(WC('lotes')||[]).filter(function(l){return l.vence&&l.vence<HOY&&l.qty>0;}).length;}catch(_){}
  var noent=hoy.filter(function(e){return e.estado==='no_entregada';}).length;
  if(rj)al.push('<span class="chip bad">🔔 '+rj+' SKUs para reordenar</span>');if(noent)al.push('<span class="chip warn">❌ '+noent+' no entregadas hoy</span>');if(lv)al.push('<span class="chip bad">⛔ '+lv+' lotes vencidos</span>');
  return '<section class="panel tablero25"><h3>📈 Cómo viene hoy</h3><div class="t25g">'+gaugeHtml(pct(hec,hoy.length),'Entregas de hoy',hec+' de '+hoy.length)+gaugeHtml(pct(ot,sem.length),'A tiempo (7 días)',ot+' de '+sem.length)+gaugeHtml(capT?pct(uni,capT):null,'Ocupación depósito',nf(uni)+' u',capT&&uni/capT>0.9?'var(--warn)':'var(--c1)')+gaugeHtml(sk.length?100-pct(rj,sk.length):null,'Stock sano',(sk.length-rj)+' de '+sk.length+' SKUs')+'</div>'+(al.length?'<div class="chips" style="margin-top:6px">'+al.join(' ')+'</div>':'')+'</section>';}
var _vo=viewOps;viewOps=function(){var h=_vo.apply(this,arguments),i=h.indexOf('<div class="tiles">'),t='';try{t=tablero();}catch(e){if(window.console)console.error(e);}return i>=0?h.slice(0,i)+t+h.slice(i):t+h;};
document.addEventListener('click',function(ev){var b=ev.target.closest&&ev.target.closest('[data-act="x27-hechas"]');if(!b)return;S.ui.verHechas=!S.ui.verHechas;render();});
var _r=render;render=function(){var rol=null;try{rol=rolActual();}catch(_){}
  document.body.dataset.rol=rol||'';
  try{var h=new Date().getHours(),de=document.documentElement;if(rol==='chofer'){if(h>=19||h<6){if(!de.dataset.theme){de.dataset.theme='dark';de.dataset.auto27='1';}}else if(de.dataset.auto27){delete de.dataset.theme;delete de.dataset.auto27;}}else if(de.dataset.auto27){delete de.dataset.theme;delete de.dataset.auto27;}}catch(_){}
  _r.apply(this,arguments);};
})();
/* ===== EXT27 end ===== */

/* ===== EXT28: filtro y buscador de usuarios ===== */
(function(){
document.addEventListener('click',function(ev){var t=ev.target.closest&&ev.target.closest('[data-act="x28-ufil"],[data-act="x28-umas"]');if(!t)return;
  if(t.dataset.act==='x28-ufil'){S.ui.ufil=t.dataset.v||'';S.ui.ulim=25;}else S.ui.ulim=(S.ui.ulim||25)+25;render();});
document.addEventListener('input',function(ev){var t=ev.target;if(t&&t.id==='x28-uq'){S.ui.uq=t.value;S.ui.ulim=25;render();}});
})();
/* ===== EXT28 end ===== */

/* ===== EXT29: filtro y buscador de fichas ===== */
(function(){
document.addEventListener('click',function(ev){var t=ev.target.closest&&ev.target.closest('[data-act="x29-pfil"],[data-act="x29-pmas"]');if(!t)return;
  if(t.dataset.act==='x29-pfil'){S.ui.pfil=t.dataset.v||'';S.ui.plim=25;}else S.ui.plim=(S.ui.plim||25)+25;render();});
document.addEventListener('input',function(ev){var t=ev.target;if(t&&t.id==='x29-pq'){S.ui.pq=t.value;S.ui.plim=25;render();}});
})();
/* ===== EXT29 end ===== */

/* ===== EXT30: rotación, tiempo de salida del stock, tamaño/peso y ubicación ideal para cuidar el OTIF ===== */
(function(){
WSUBS_ALL.splice(WSUBS_ALL.length-1,0,['x30rot','Rotación y salida']);
var RC={rap:['⚡','Rápida','ok'],med:['🔄','Media','warn'],len:['🐢','Lenta',''],sin:['🧊','Sin salida','bad']};
var PC={liv:'Liviano',med:'Medio',pes:'Pesado'};
function vol30(k){var l=+k.largo||0,a=+k.ancho||0,h=+k.alto||0;return l&&a&&h?l*a*h/1000:0;}
function pesoCl(k){var p=+k.peso||0,v=vol30(k);return (p>10||v>30)?'pes':(p>1||v>5)?'med':'liv';}
function rotCl(dias){return dias==null?'sin':dias<=30?'rap':dias<=90?'med':dias<=180?'len':'len';}
function ideal(abc,rc,pc){var cerca=(abc==='A'&&rc!=='sin')?'alta':(abc==='B'||rc==='med')&&rc!=='sin'?'media':'baja';
  var niv=pc==='pes'?[1,1]:pc==='med'?(cerca==='alta'?[1,2]:[1,2]):(cerca==='alta'?[2,3]:cerca==='media'?[2,4]:[3,9]);
  var t={alta:'cerca del despacho',media:'zona media',baja:'al fondo'}[cerca]+', '+(pc==='pes'?'nivel piso':niv[0]===1&&niv[1]<=2?'nivel 1-2':'nivel '+niv[0]+(niv[1]>niv[0]&&niv[1]<9?'-'+niv[1]:'+'));
  return {cerca:cerca,niv:niv,txt:t};}
function zonaOk(cerca,dq){return cerca==='alta'?dq<=0.34:cerca==='media'?(dq>=0.2&&dq<=0.67):dq>=0.5;}
function A(){return x8c('rot30',function(){
  var ab=abastRows(),st=wStock(),lay=simLayout(SIMD),pa=simPlace(lay,'actual'),by={},list=[];
  var ord=lay.list.slice().sort(function(a,b){return (a.x+a.y)-(b.x+b.y);}),dq={};ord.forEach(function(l,i){dq[l.code]=ord.length>1?i/(ord.length-1):0;});
  var totD=ab.reduce(function(t,r){return t+r.d;},0),totS=ab.reduce(function(t,r){return t+r.stock;},0);
  var rk=ab.slice().sort(function(a,b){return b.d-a.d;}),acc=0;
  rk.forEach(function(r){acc+=totD?r.d/totD:0;r.abc=r.d<=0?'C':acc-(totD?r.d/totD:0)<0.8?'A':acc-(totD?r.d/totD:0)<0.95?'B':'C';});
  ab.forEach(function(r){var k=r.s,dias=r.d>0&&r.stock>0?r.stock/r.d:(r.stock>0?null:0),rc=r.stock<=0?'sin':rotCl(dias),pc=pesoCl(k),id=ideal(r.abc,rc,pc),pos=pa[k.codigo],loc=pos?locParse(pos):null,d=pos&&dq[pos]!=null?dq[pos]:null;
    var okZ=d==null?null:zonaOk(id.cerca,d),okN=loc?(loc.u>=id.niv[0]&&loc.u<=id.niv[1]):null;
    var o={r:r,s:k,dias:dias,rot:r.d>0&&r.stock>0?r.d*365/r.stock:0,rc:rc,pc:pc,abc:r.abc,id:id,pos:pos||'',okZ:okZ,okN:okN,mal:(okZ===false||okN===false),vol:vol30(k),riesgo:r.d>0&&r.cob!=null&&r.cob<r.L};
    by[k.codigo]=o;list.push(o);});
  return {list:list,by:by,totD:totD,totS:totS,dq:dq};});}
function gauge(v,l,sub){var p=v==null?0:Math.round(v),col=v==null?'var(--muted)':p>=85?'var(--ok)':p>=60?'var(--warn)':'var(--bad)';
  return '<div class="t25"><div class="gauge" style="--p:'+p+';--gc:'+col+'" role="img" aria-label="'+l+'"><b>'+(v==null?'—':p+'%')+'</b></div><div class="t25-l">'+l+'</div><div class="t25-s">'+sub+'</div></div>';}
function pct1(n,d){return d?n/d*100:null;}
function xRot(){
  var a=A(),L=a.list,totS=a.totS,totD=a.totD;
  var dTodo=totD>0?totS/totD:null;
  var s30=L.reduce(function(t,o){return t+Math.min(o.r.stock,o.r.d*30);},0),s90=L.reduce(function(t,o){return t+Math.min(o.r.stock,o.r.d*90);},0);
  var conD=L.filter(function(o){return o.r.d>0;}),seg=conD.filter(function(o){return !o.riesgo;}).length;
  var ubi=L.filter(function(o){return o.okZ!==null&&(o.abc!=='C'||o.pc==='pes');}),bien=ubi.filter(function(o){return !o.mal;}).length;
  var cls={};L.forEach(function(o){var c=cls[o.rc]=cls[o.rc]||{n:0,s:0,d:0};c.n++;c.s+=o.r.stock;c.d+=o.r.d;});
  var ries=L.filter(function(o){return o.riesgo;}).sort(function(x,y){return (x.r.cob/x.r.L)-(y.r.cob/y.r.L);});
  var mal=L.filter(function(o){return o.mal&&o.abc!=='C';}).sort(function(x,y){return y.r.d-x.r.d;});
  var h='<div class="panel tablero25"><h3>📈 Rotación y salida del stock</h3><p class="small muted" style="margin:0">Cuánto tarda en salir cada producto, qué tan rápido rota y dónde conviene tenerlo según su peso y medida. La meta: nunca quedarte sin stock (OTIF alto) y preparar cada pedido con el menor recorrido.</p>'+
   '<div class="kpis" style="margin-top:6px">'+KPI(dTodo==null?'—':nf(dTodo,0)+' d','Todo el stock sale en',nf(totS)+' u a '+nf(totD,0)+' u/día')+KPI(nf(conD.length),'SKUs con salida','de '+nf(L.length)+' ('+nf(L.length-conD.length)+' sin salida)')+'</div>'+
   '<div class="t25g" style="margin-top:10px">'+gauge(pct1(s30,totS),'Sale en 30 días',nf(s30)+' u')+gauge(pct1(s90,totS),'Sale en 90 días',nf(s90)+' u')+gauge(pct1(seg,conD.length),'Cobertura segura',seg+' de '+conD.length+' SKUs (OTIF)')+gauge(pct1(bien,ubi.length),'Bien ubicados',bien+' de '+ubi.length+' SKUs A/B/pesados')+'</div></div>';
  h+='<div class="panel"><h3>Por velocidad de rotación</h3>'+tbl(['Rotación','SKUs','% del stock','% de las salidas','Qué hacer'],['rap','med','len','sin'].map(function(k){var c=cls[k]||{n:0,s:0,d:0};return ['<span class="chip '+RC[k][2]+'">'+RC[k][0]+' '+RC[k][1]+'</span>',nf(c.n),nf(pct1(c.s,totS)||0,1)+'%',nf(pct1(c.d,totD)||0,1)+'%',{rap:'Cerca del despacho, nivel de la mano, reponer con anticipación.',med:'Zona media. Revisá el mínimo cada mes.',len:'Al fondo o arriba (si es liviano). No sobrecomprar.',sin:'Revisá: liquidar, devolver o bajar el mínimo.'}[k]];}),560)+
   '<div class="small muted">Rápida: sale en 30 días o menos. Media: 31 a 90. Lenta: más de 90. Sin salida: no tuvo movimiento o no hay stock.</div></div>';
  h+='<div class="panel"><h3>🚨 Riesgo para el OTIF ('+ries.length+')</h3><div class="small muted">Productos que se acabarían antes de que llegue la reposición. Pedilos ya.</div>'+
   (ries.length?tbl(['SKU','Stock','Sale por día','Alcanza','Reposición tarda','Pedir'],ries.slice(0,15).map(function(o){return ['<span class="guia">'+esc(o.s.codigo)+'</span> '+esc(o.s.producto),nf(o.r.stock),nf(o.r.d,1),'<span class="chip bad">'+nf(o.r.cob,1)+' d</span>',nf(o.r.L)+' d','<strong>'+nf(o.r.sug)+'</strong> u'];}),640):'<div class="banner ok" role="status">'+ICON.check+'<div><strong>Ningún producto en riesgo</strong>Todo lo que sale tiene cobertura mayor que el tiempo de reposición.</div></div>')+'</div>';
  h+='<div class="panel"><h3>📍 Conviene reubicar ('+mal.length+')</h3><div class="small muted">Productos de alta y media salida, o pesados, fuera de su zona ideal.</div>'+
   (mal.length?tbl(['SKU','Hoy en','Rotación','Peso y medida','Ideal'],mal.slice(0,15).map(function(o){return ['<span class="guia">'+esc(o.s.codigo)+'</span> '+esc(o.s.producto),'<span class="mono">'+esc(o.pos||'—')+'</span>','<span class="chip '+RC[o.rc][2]+'">'+RC[o.rc][0]+' '+RC[o.rc][1]+' · '+o.abc+'</span>',PC[o.pc]+(o.s.peso?' · '+nf(o.s.peso,1)+' kg':'')+(o.vol?' · '+nf(o.vol,0)+' L':''),esc(o.id.txt)];}),680):'<div class="banner ok" role="status">'+ICON.check+'<div><strong>Todo bien ubicado</strong></div></div>')+'</div>';
  h+='<div class="panel"><h3>Todos los productos</h3>'+tbl(['SKU','Stock','Sale/día','Tarda en salir','Vueltas/año','Clase','Peso y medida','Ubicación ideal'],L.slice().sort(function(x,y){return y.r.d-x.r.d;}).slice(0,300).map(function(o){return ['<span class="guia">'+esc(o.s.codigo)+'</span> '+esc(o.s.producto),nf(o.r.stock),nf(o.r.d,1),o.dias==null?'—':nf(o.dias,0)+' d',nf(o.rot,1),'<span class="chip '+RC[o.rc][2]+'">'+RC[o.rc][0]+' '+RC[o.rc][1]+' · '+o.abc+'</span>',PC[o.pc]+(o.s.peso?' · '+nf(o.s.peso,1)+' kg':'')+(o.vol?' · '+nf(o.vol,0)+' L':''),esc(o.id.txt)];}),980)+'<div class="small muted">Se muestran los 300 de mayor salida.</div></div>';
  h+='<div class="panel"><h3>Cómo se calcula</h3><ul class="small muted" style="margin:0;padding-left:18px;display:grid;gap:4px"><li><strong>Tarda en salir</strong> = stock ÷ unidades que salen por día (promedio del historial).</li><li><strong>Vueltas por año</strong> = salida por día × 365 ÷ stock. Más vueltas, mejor.</li><li><strong>ABC</strong>: A es el 80% de las salidas, B el siguiente 15%, C el resto.</li><li><strong>Peso y medida</strong>: pesado si supera 10 kg o 30 litros; liviano si pesa hasta 1 kg y ocupa menos de 5 litros. Los litros salen de largo × ancho × alto (cm) si el producto los tiene cargados; si no, se usa solo el peso.</li><li><strong>Ubicación ideal</strong>: lo que más sale va cerca del despacho y a la altura de la mano; lo pesado siempre en el piso; lo lento al fondo y arriba.</li><li><strong>Riesgo OTIF</strong>: cuando el stock alcanza para menos días que lo que tarda la reposición.</li></ul></div>';
  return h;}
var _vw=viewWms;viewWms=function(){if(S.ui.wsub==='x30rot'){return '<div class="row sp"><h2>Depósito</h2></div>'+wSub()+xRot();}return _vw.apply(this,arguments);};
/* ubicación sugerida en la recepción: espacio + consolidar + rotación + peso */
putaway=function(sku,qty){var w=W(),st=wStock(),s=w.skus.find(function(x){return x.codigo===sku;}),c=[],oc={},an=null;
  try{an=A().by[sku];}catch(_){}
  Object.keys(st.m).forEach(function(k){var q=st.m[k];if(q>0){var u=k.slice(0,k.indexOf('|'));oc[u]=(oc[u]||0)+q;}});
  var dqm=an?A().dq:null;
  w.ubic.forEach(function(u){var libre=(u.cap||0)-(oc[u.codigo]||0);if(libre<qty)return;
    var mismo=(st.m[u.codigo+'|'+sku]||0)>0,sc=(mismo?0:10)+(s&&u.codigo===s.ubic?-5:0)+(s&&u.deposito===s.deposito?0:5)+(libre-qty)/1000,why=[];
    if(mismo)why.push('ya hay del mismo producto');
    if(an){var lc=locParse(u.codigo);
      if(lc){var lo=an.id.niv[0],hi=an.id.niv[1],out=lc.u<lo?lo-lc.u:lc.u>hi?lc.u-hi:0;sc+=out*3;if(an.pc==='pes'&&lc.u>1)sc+=40;if(!out)why.push(an.pc==='pes'?'nivel piso (pesado)':'nivel adecuado');}
      if(dqm&&dqm[u.codigo]!=null){var d=dqm[u.codigo],c2=an.id.cerca,lo2=c2==='alta'?0:c2==='media'?0.2:0.5,hi2=c2==='alta'?0.34:c2==='media'?0.67:1,o2=d<lo2?lo2-d:d>hi2?d-hi2:0;sc+=o2*8;if(!o2)why.push(c2==='alta'?'cerca del despacho':c2==='baja'?'zona de poca salida':'zona media');}}
    c.push({u:u,libre:libre,mismo:mismo,score:sc,why:why.join(' · ')});});
  c.sort(function(a,b){return a.score-b.score;});return c.slice(0,3);};
})();
/* ===== EXT30 end ===== */

/* ===== EXT31: devoluciones por remito ===== */
(function(){
  function nrm(v){return String(v||'').trim().toLowerCase();}
  function entDe(v){v=nrm(v);if(!v)return null;return (D().entregas||[]).find(function(e){return nrm(e.guia)===v||nrm(e.remito&&e.remito.numero)===v;})||null;}
  function lineas(e){var m={},ord=[];
    (e.items||[]).forEach(function(it){var k=String(it.sku||it.producto||'');if(!k)return;if(!m[k]){m[k]={sku:it.sku||'',desc:it.producto||it.desc||it.sku||'',ent:null,decl:null,est:'ok'};ord.push(k);}var q=it.qty!=null?it.qty:it.cant!=null?it.cant:it.cantidad;if(q!=null)m[k].ent=(m[k].ent||0)+Number(q);});
    (e.devuelve||[]).forEach(function(d){var k=String(d.sku||d.desc||'');if(!k)return;if(!m[k]){m[k]={sku:d.sku||'',desc:d.desc||d.sku||'',ent:null,decl:null,est:'ok'};ord.push(k);}m[k].decl=(m[k].decl||0)+Number(d.qty||0);m[k].est=d.estado==='mal'?'mal':'ok';});
    return ord.map(function(k){return m[k];});}
  var x0=xDevol;
  xDevol=function(){
    var h=x0(),st=S.ext.dvr||{},e=st.id?(D().entregas||[]).find(function(x){return x.id===st.id;}):null;
    var hoy=addDays(-90),ops=(D().entregas||[]).filter(function(x){return x.fecha>=hoy;}).sort(function(a,b){return String(b.fecha).localeCompare(String(a.fecha));}).slice(0,300),dl='';
    ops.forEach(function(x){if(x.remito&&x.remito.numero)dl+='<option value="'+esc(x.remito.numero)+'">'+esc(x.cliente+' · guía '+x.guia)+'</option>';dl+='<option value="'+esc(x.guia)+'">'+esc(x.cliente+(x.remito&&x.remito.numero?' · '+x.remito.numero:''))+'</option>';});
    var p='<div class="panel" id="x-dv-rem"><h3>🧾 Devolución por remito</h3><div class="small muted" style="margin-bottom:8px">Escribí o elegí el remito (o la guía): se trae el cliente y los productos, y cargás lo que realmente devolvió.</div><div class="row"><label>Remito o guía<input id="dv-rem" list="dl-dvrem" autocomplete="off" value="'+esc(st.q||'')+'" placeholder="R-0003-00007712 o G-4818"></label><button class="btn" type="button" data-act="x-dvbus">Buscar</button></div><datalist id="dl-dvrem">'+dl+'</datalist>';
    if(st.q&&!e)p+='<div class="banner warn" role="status"><div>No encontré ese remito. Revisá el número o cargá la devolución a mano abajo.</div></div>';
    if(e){var ls=lineas(e),ya=(WC('devoluciones')||[]).filter(function(d){return d.guia===e.guia;});
      p+='<div style="margin-top:10px"><strong>'+esc(e.cliente)+'</strong><div class="small muted">Guía '+esc(e.guia)+(e.remito&&e.remito.numero?' · remito '+esc(e.remito.numero):'')+' · '+esc(fmtFecha(e.fecha))+'</div></div>';
      if(ya.length)p+='<div class="banner warn" role="status"><div>Ya hay '+ya.length+' devolución(es) registradas con esta guía. Revisá que no la estés cargando dos veces.</div></div>';
      if(!ls.length)p+='<div class="small muted" style="margin-top:8px">Este remito no tiene detalle de productos. Usá el formulario de abajo (ya queda cargado el cliente).</div>';
      else p+=tbl(['Producto','Remito','Declaró el chófer','Devolvió el cliente'],ls.map(function(l,i){return [l.sku?skuTxt(l.sku):esc(l.desc)+' <span class="chip warn">sin SKU</span>',l.ent!=null?nf(l.ent):'—',l.decl!=null?nf(l.decl)+' u '+(l.est==='mal'?'<span class="chip bad">dañada</span>':''):'—','<input id="dvr-q-'+i+'" type="number" min="0"'+(l.ent!=null?' max="'+l.ent+'"':'')+' value="'+(l.decl!=null?l.decl:'')+'" style="width:96px">'];}),420)+
        '<div class="row" style="margin-top:10px"><label>Motivo<select id="dvr-mot">'+DEVOL_MOT.map(function(m){return '<option'+(((st.mot||(e.estado==='no_entregada'?'No entregada (vuelve al depósito)':'Rechazada por el cliente'))===m)?' selected':'')+'>'+esc(m)+'</option>';}).join('')+'</select></label></div><div class="row" style="margin-top:8px"><button class="btn pri" type="button" data-act="x-dvrem">Registrar devolución del remito</button></div><div class="small muted">Lo que cargues queda como recibido y se cuenta/reparte abajo, igual que siempre. La cantidad no puede superar lo del remito.</div>';}
    p+='</div>';
    return p+h;};
  function buscar(){var v=gv('dv-rem').trim();var e=entDe(v);S.ext.dvr={q:v,id:e?e.id:''};if(e){S.ext.dv={guia:e.guia,cliente:e.cliente,motivo:e.estado==='no_entregada'?'No entregada (vuelve al depósito)':'Rechazada por el cliente'};}render();}
  async function registrar(){var st=S.ext.dvr||{},e=st.id?(D().entregas||[]).find(function(x){return x.id===st.id;}):null;if(!e)return;var ls=lineas(e),mot=gv('dvr-mot'),n=0,sin=[],exc=[];
    for(var i=0;i<ls.length;i++){var q=parseInt(gv('dvr-q-'+i),10);if(!(q>0))continue;var l=ls[i];if(!l.sku){sin.push(l.desc);continue;}if(l.ent!=null&&q>l.ent){exc.push(l.sku);continue;}
      await wPut('devoluciones',{id:uid('DV'),fecha:HOY,guia:e.guia,remito:(e.remito&&e.remito.numero)||'',cliente:e.cliente,sku:l.sku,qty:q,qtyDecl:l.decl!=null?l.decl:null,qtyRemito:l.ent!=null?l.ent:null,estadoDecl:l.est,lote:'',vence:'',motivo:mot,nota:'Por remito '+((e.remito&&e.remito.numero)||e.guia),estado:'recibida',por:actor()});n++;}
    if(exc.length){toast('Superan lo del remito: '+exc.join(', ')+'.');return;}
    if(!n){toast(sin.length?'Esos productos no tienen SKU: cargalos a mano abajo.':'Poné cuántas unidades devolvió el cliente.');return;}
    S.ext.dvr=null;toast(n+(n===1?' devolución registrada':' devoluciones registradas')+(sin.length?' · sin SKU (cargar a mano): '+sin.join(', '):'')+'.');render();}
  document.addEventListener('click',function(ev){var b=ev.target.closest&&ev.target.closest('[data-act]');if(!b)return;var a=b.dataset.act;if(a==='x-dvbus'){ev.stopPropagation();buscar();}else if(a==='x-dvrem'){ev.stopPropagation();registrar().catch(function(){toast('No se pudo guardar. Probá de nuevo.');});}},true);
  document.addEventListener('change',function(ev){if(ev.target&&ev.target.id==='dv-rem')buscar();});
})();
/* ===== EXT31 end ===== */

/* ===== EXT31b: expedición con número de picking ===== */
(function(){
  function nrm(v){return String(v||'').trim().toLowerCase();}
  function buscarPk(v){v=nrm(v);if(!v)return null;var ks=WC('picks');
    var k=ks.find(function(x){return nrm(x.id)===v;});if(k)return k;
    var pd=(WC('pedidos')||[]).find(function(x){return nrm(x.id)===v;});if(pd&&pd.pickId){k=ks.find(function(x){return x.id===pd.pickId;});if(k)return k;}
    return ks.find(function(x){return nrm(x.ref)===v;})||ks.find(function(x){return nrm(x.id).slice(-v.length)===v&&v.length>=4;})||null;}
  var e0=xExp;
  xExp=function(){var h=e0(),st=S.ext.expPk||{},k=st.id?WC('picks').find(function(x){return x.id===st.id;}):null;
    var ops=WC('picks').filter(function(x){return !x.ola&&x.estado!=='cancelado';}).sort(function(a,b){return String(b.id).localeCompare(String(a.id));}).slice(0,300);
    var p='<div class="panel" id="x-exp-pk"><h3>🛒 Número de picking (referencia)</h3><div class="small muted" style="margin-bottom:8px">Escribí o elegí el número de picking (o el del pedido): se traen los ítems que se pickearon, para controlar contra lo que cargás.</div><div class="row"><label>Picking o pedido<input id="ex-pk" list="dl-expk" autocomplete="off" value="'+esc(st.q||'')+'" placeholder="PK-… o PED-…"></label><button class="btn" type="button" data-act="x-expk">Traer ítems</button></div><datalist id="dl-expk">'+ops.map(function(x){return '<option value="'+esc(x.id)+'">'+esc((x.ref||'')+' · '+(x.estado||''))+'</option>';}).join('')+'</datalist>';
    if(st.q&&!k)p+='<div class="banner warn" role="status"><div>No encontré ese picking. Revisá el número.</div></div>';
    if(k){var pd=(WC('pedidos')||[]).find(function(x){return x.pickId===k.id||x.id===k.pedidoId;}),done=k.estado==='completado';
      p+='<div style="margin-top:10px"><div class="row sp"><strong>'+esc(k.ref||k.id)+'</strong><span class="chip '+(done?'ok':'warn')+'">'+(done?'Completado':k.estado==='en_ola'?'En ola':'Pendiente')+'</span></div><div class="small muted">'+esc(k.id)+' · '+esc(fmtFecha(k.fecha))+(k.asignadoNombre?' · 👷 '+esc(k.asignadoNombre):'')+(pd?' · pedido '+esc(pd.id):'')+'</div></div>';
      var ls=k.lineas||[];
      p+=ls.length?tbl(['Ubicación','SKU','Lote','Pedido','Pickeado'],ls.map(function(l){var rc=l.rec!=null?l.rec:(done?l.qty:null);return ['<span class="mono">'+esc(l.ubi||'—')+'</span>',skuTxt(l.sku),esc(l.lote||'—'),nf(l.qty),rc==null?'<span class="small muted">sin confirmar</span>':'<strong>'+nf(rc)+'</strong>'+(rc<l.qty?' <span class="chip bad">faltan '+nf(l.qty-rc)+'</span>':'')];}),460):'<div class="small muted">Esta orden no tiene líneas.</div>';
      if(k.faltan&&k.faltan.length)p+='<div class="banner warn" role="status"><div><strong>Faltante</strong>'+k.faltan.map(function(f){return esc(f.sku)+': faltan '+nf(f.qty);}).join(' · ')+'</div></div>';
      if(pd&&pd.estado==='preparado')p+='<div class="row" style="margin-top:8px"><button class="btn" type="button" data-act="x-expsel31" data-id="'+esc(pd.id)+'">Escanear bultos de '+esc(pd.id)+'</button></div>';
      else if(pd)p+='<div class="small muted" style="margin-top:8px">El pedido '+esc(pd.id)+' todavía no está preparado para despacho.</div>';}
    return p+'</div>'+h;};
  function traer(){var v=gv('ex-pk').trim(),k=buscarPk(v);S.ext.expPk={q:v,id:k?k.id:''};render();}
  document.addEventListener('click',function(ev){var b=ev.target.closest&&ev.target.closest('[data-act]');if(!b)return;var a=b.dataset.act;if(a==='x-expk'){ev.stopPropagation();traer();}else if(a==='x-expsel31'){ev.stopPropagation();X8.ui.expSel=b.dataset.id;render();}else if(a==='x31-stgfuera'){ev.stopPropagation();var k=WC('picks').find(function(x){return x.id===b.dataset.id;});if(k){k=clean(k);k.stgFuera=isoNow();k.stgFueraPor=actor();wPut('picks',k).then(function(){toast('Posición liberada.');}).catch(function(){toast('No se pudo guardar. Probá de nuevo.');});}}},true);
  document.addEventListener('change',function(ev){if(ev.target&&ev.target.id==='pk-sale'){pkMetaSave();S.ext.pkMeta.stg=stgSug(ev.target.value);render();var e2=document.getElementById('pk-stg');if(e2)e2.value=S.ext.pkMeta.stg;}if(ev.target&&ev.target.id==='ex-pk')traer();if(ev.target&&ev.target.classList&&ev.target.classList.contains('pk31-sale')){var M=(S.ext.pal20=S.ext.pal20||{}),id=ev.target.dataset.id,P=M[id]=M[id]||{on:false,n:2};P.sale=ev.target.value;P.pos=[];render();}});
  document.addEventListener('keydown',function(ev){if(ev.key==='Enter'&&ev.target&&ev.target.id==='ex-pk'){ev.preventDefault();traer();}});
})();
/* ===== EXT31b end ===== */

/* ===== EXT32: quién usa cada equipo ===== */
(function(){
  S.data.demo.wms.operarios=S.data.demo.wms.operarios||[];S.data.live.wms.operarios=S.data.live.wms.operarios||[];S.data.demo.wms.uso=S.data.demo.wms.uso||[];S.data.live.wms.uso=S.data.live.wms.uso||[];S.data.demo.wms.usolog=S.data.demo.wms.usolog||[];S.data.live.wms.usolog=S.data.live.wms.usolog||[];
  var _el=extLive;extLive=function(rol,onErr){_el(rol,onErr);if(rol!=='admin'&&rol!=='deposito')return;var live=S.data.live;
    ['uso','usolog','operarios'].forEach(function(k){unsubs.push(db.collection('wms/'+k+'/items').onSnapshot(function(s2){live.wms[k]=s2.docs.map(function(d){return Object.assign({id:d.id},d.data());});render();},onErr));});};
  var _rr=render,regK='';render=function(){_rr.apply(this,arguments);try{var rol=rolActual();if(S.mode==='demo'||(rol!=='admin'&&rol!=='deposito'))return;var ro=WC('operarios');
    if(rol==='deposito'&&S.me&&S.me.id&&S.perfil&&S.perfil.nombre&&!ro.some(function(o){return o.id===S.me.id&&o.nombre===S.perfil.nombre;})){var k='d'+S.me.id+S.perfil.nombre;if(regK!==k){regK=k;wPut('operarios',{id:S.me.id,nombre:S.perfil.nombre}).catch(function(){regK='';});}}
    if(rol==='admin'){var faltan=(D().perfiles||[]).filter(function(o){return o.rol==='deposito'&&o.id&&!ro.some(function(x){return x.id===o.id&&x.nombre===o.nombre;});});var k2='a'+faltan.map(function(o){return o.id+o.nombre;}).join('|');if(faltan.length&&regK!==k2){regK=k2;faltan.forEach(function(o){wPut('operarios',{id:o.id,nombre:o.nombre}).catch(function(){regK='';});});}}}catch(_){}};
  function usoDe(id){return WC('uso').find(function(u){return u.id===id&&u.opId;})||null;}
  function hh(iso){try{return new Date(iso).toLocaleTimeString('es-AR',{hour:'2-digit',minute:'2-digit'});}catch(_){return '';}}
  var _ec=eqCard;eqCard=function(eq,admin){
    var h=_ec(eq,admin),u=usoDe(eq.id),rol=rolActual(),mine=u&&u.opId===miId(),blk='';if(rol!=='admin'&&rol!=='deposito')return h;
    if(u){var hoy=String(u.desde||'').slice(0,10)===HOY;
      blk='<div class="banner info" role="status"><div><strong>👷 En uso: '+esc(u.nombre)+(mine?' (vos)':'')+'</strong>desde '+(hoy?'las '+esc(hh(u.desde)):esc(fmtFecha(String(u.desde).slice(0,10)))+' '+esc(hh(u.desde)))+(hoy?'':' · ¿sigue usándolo?')+'</div></div><div class="row"><button class="btn sm" data-act="x-usodejar" data-id="'+esc(eq.id)+'">Dejar de usar</button>'+(!mine&&rol==='deposito'?'<button class="btn sm pri" data-act="x-usotomar" data-id="'+esc(eq.id)+'">Lo uso yo ahora</button>':'')+'</div>';}
    else{var ops=opsList();
      blk='<div class="row" style="flex-wrap:wrap"><span class="chip ok">🟢 Libre</span>'+(rol==='admin'?'<label class="small">Operario <select id="uso-op-'+esc(eq.id)+'"><option value="">Elegí…</option>'+ops.map(function(o){return '<option value="'+esc(o.id)+'">'+esc(o.nombre)+'</option>';}).join('')+'</select></label><button class="btn sm pri" data-act="x-usotomar" data-id="'+esc(eq.id)+'">Asignar</button>':'<button class="btn sm pri" data-act="x-usotomar" data-id="'+esc(eq.id)+'">Lo voy a usar</button>')+'</div>';}
    var k='<div class="row"><button class="btn pri sm" data-act="chkabrir"';var i=h.indexOf(k);return i<0?h:h.slice(0,i)+blk+h.slice(i);};
  async function cerrar(id,u){if(!u)return;await wPut('usolog',{id:uid('US'),eq:id,opId:u.opId,nombre:u.nombre,desde:u.desde,hasta:isoNow(),por:actor()});}
  async function tomar(id){var u=usoDe(id),opId,nombre;
    if(rolActual()==='admin'){opId=gv('uso-op-'+id);if(!opId){toast('Elegí el operario.');return;}var pf=(D().perfiles||[]).find(function(x){return x.id===opId;});nombre=pf?pf.nombre:'Operario';}
    else{opId=miId();var mp=miPerfil();nombre=(mp&&mp.nombre)||actor();}
    if(u)await cerrar(id,u);
    await wPut('uso',{id:id,opId:opId,nombre:nombre,desde:isoNow(),por:actor()});toast(nombre+' usa el equipo.');}
  async function dejar(id){var u=usoDe(id);if(!u)return;await cerrar(id,u);await wPut('uso',{id:id,opId:'',nombre:'',desde:'',por:actor()});toast('Equipo libre.');}
  document.addEventListener('click',function(ev){var b=ev.target.closest&&ev.target.closest('[data-act]');if(!b)return;var a=b.dataset.act;
    if(a==='x-usotomar'){ev.stopPropagation();tomar(b.dataset.id).catch(function(){toast('No se pudo guardar. Probá de nuevo.');});}
    else if(a==='x-usodejar'){ev.stopPropagation();dejar(b.dataset.id).catch(function(){toast('No se pudo guardar. Probá de nuevo.');});}},true);
})();
/* ===== EXT32 end ===== */

window.__render=render;
boot();
})();
