# Política de datos personales y ubicación

> **Modelo de trabajo, no asesoramiento legal.** Antes de usarlo con clientes reales, hacelo revisar por un abogado/a o por quien lleve la protección de datos de tu empresa. En Argentina rige la Ley 25.326 de Protección de Datos Personales; verificá requisitos vigentes (por ejemplo, registro de bases de datos ante la AAIP) y la normativa laboral aplicable.

## Qué datos trata el portal
| Dato | Para qué | Quién lo ve |
|---|---|---|
| Nombre, correo, teléfono de clientes y personal | Identificar y avisar | Administración (el cliente solo ve lo suyo) |
| Licencia y habilitaciones de choferes y operarios | Controlar vencimientos | Administración y la propia persona |
| Dirección y horario de entrega | Hoja de ruta y avisos | Administración, chofer asignado, cliente dueño |
| Firma, nombre de quien recibe y foto | Prueba de entrega | Administración, chofer asignado, cliente dueño |
| **Ubicación del teléfono del chofer** | Probar que la entrega se hizo en la dirección | Administración (y el dato queda en la entrega) |

## Cómo se trata la ubicación
- Se toma **solo en el momento en que el chofer confirma una entrega**, y **solo si el chofer aceptó** el consentimiento dentro de la aplicación.
- **No hay seguimiento continuo** ni en segundo plano.
- El chofer puede entregar sin registrar ubicación ("Continuar sin registrar ubicación"). La empresa decide si eso es aceptable en su operación.
- El consentimiento queda registrado con fecha. Se puede retirar pidiéndolo a administración.

## Texto de consentimiento (el que ve el chofer)
> Para dejar prueba de que la entrega se hizo en la dirección, esta aplicación puede registrar la ubicación de tu teléfono solo en el momento en que confirmás una entrega. No hay seguimiento continuo. La ve la administración de la empresa. Podés retirar tu consentimiento cuando quieras pidiéndolo a administración.

## Reglas internas recomendadas
1. Usar los datos solo para la operación de entregas y depósito.
2. Un usuario por persona; dar de baja a quien deja la empresa el mismo día.
3. Activar la verificación en dos pasos para administración.
4. No cargar datos que no se necesiten (documentos, domicilios particulares, datos de salud).
5. Conservar las pruebas de entrega durante el plazo que la empresa defina ([N] meses) y borrar después.
6. Atender pedidos de acceso, corrección o baja de datos en un plazo razonable ([10] días corridos).

## Dónde están los datos
- [Servidor propio / proveedor X, país Y]. Copia diaria automática, con retención de [N] días.
- Conexión cifrada (HTTPS). Contraseñas guardadas con hash. Registro de actividad de administración.
- Cada empresa cliente tiene su **propia instalación y base de datos**: no se mezclan datos entre empresas.

## Contacto para consultas de datos
[Nombre, correo, teléfono]
