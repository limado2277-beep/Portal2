'use strict';
// Portal logístico: servidor sin dependencias externas (Node >= 22.13).
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { open, setDoc, getDoc, delDoc, listColl, listCollRecent, listCollEq, INDEXED } = require('./lib/db');
const auth = require('./lib/auth');
const rules = require('./lib/rules');
const { createMailer } = require('./lib/mailer');
const totp = require('./lib/totp');
const integ = require('./lib/integracion');
const { createWebhook } = require('./lib/webhook');
const { createVencimientos } = require('./lib/vencimientos');

function loadEnv(file) {
  try {
    for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
      if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
    }
  } catch (_) {}
}

const SEG = /^[A-Za-z0-9_\-.~:@+]{1,200}$/;
const parsePath = p => {
  if (!p) return null;
  const s = String(p).split('/');
  if (s.length > 16 || !s.every(x => SEG.test(x) && x !== '.' && x !== '..')) return null;
  return s;
};
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json', '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' };
const UPLOAD_OK = { 'application/pdf': '.pdf', 'image/png': '.png', 'image/jpeg': '.jpg', 'image/webp': '.webp' };

const MAGIC = {
  'application/pdf': b => b.slice(0, 5).toString('latin1') === '%PDF-',
  'image/png': b => b.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])),
  'image/jpeg': b => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff,
  'image/webp': b => b.slice(0, 4).toString('latin1') === 'RIFF' && b.slice(8, 12).toString('latin1') === 'WEBP',
};
const COMMON_PW = ['1234567890', 'contraseña1', 'password12', 'password123', 'qwertyuiop', '0123456789', 'abcdefghij', 'portal12345', 'bienvenido1'];
function pwProblem(pw, email) {
  pw = String(pw || '');
  if (pw.length < 10) return 'La contraseña debe tener al menos 10 caracteres';
  if (pw.length > 200) return 'La contraseña es demasiado larga';
  if (/^(.)\1+$/.test(pw)) return 'La contraseña es demasiado simple';
  const low = pw.toLowerCase();
  if (COMMON_PW.includes(low) || (email && low.includes(String(email).split('@')[0].toLowerCase()) && String(email).split('@')[0].length >= 4)) return 'Elegí una contraseña menos predecible (no uses el correo ni claves comunes)';
  return null;
}

function createServer(cfg) {
  fs.mkdirSync(cfg.dataDir, { recursive: true });
  fs.mkdirSync(path.join(cfg.dataDir, 'uploads'), { recursive: true });
  const db = open(path.join(cfg.dataDir, 'portal.db'));
  const publicDir = path.join(__dirname, 'public');

  // Primer uso: crear la cuenta de administración.
  if (!db.prepare('SELECT 1 FROM users LIMIT 1').get()) {
    const email = (cfg.adminEmail || 'admin@example.com').toLowerCase();
    const pass = cfg.adminPassword || crypto.randomBytes(9).toString('base64url');
    db.prepare('INSERT INTO users(id,email,name,role,pass,active,created) VALUES(?,?,?,?,?,1,?)')
      .run(auth.newId(), email, 'Administración', 'admin', auth.hashPassword(pass), new Date().toISOString());
    if (!cfg.adminPassword && !cfg.quiet) console.log(`\n>>> Cuenta de administración creada\n    correo: ${email}\n    contraseña: ${pass}\n    (guardala y cambiala; no se vuelve a mostrar)\n`);
  }
  auth.cleanSessions(db);
  const cleaner = setInterval(() => auth.cleanSessions(db), 6 * 3600e3); cleaner.unref();

  const ctx = { db };
  const audit = (user, action, detail, req) => {
    try { db.prepare('INSERT INTO audit(ts,user_id,user_name,action,detail,ip) VALUES(?,?,?,?,?,?)').run(new Date().toISOString(), user ? user.id : null, user ? user.name : null, action, detail ? String(detail).slice(0, 300) : null, req ? clientIp(req) : null); } catch (_) {}
  };
  const mailer = createMailer(cfg.smtp, (ok, mail, e) => audit(null, ok ? 'correo_enviado' : 'correo_fallido', mail.to + ' · ' + mail.subject + (e ? ' · ' + e.message : '')));
  ctx.mailer = mailer;
  const venc = createVencimientos({ db, mailer, cfg, audit });
  { const t = setInterval(() => venc.tick(), 30 * 60e3); t.unref(); const t2 = setTimeout(() => venc.tick(), 30e3); t2.unref(); }
  // Límite general de pedidos por IP (contra abuso): 1500 por minuto.
  const hits = new Map();
  const rateOk = ip => { const now = Date.now(), r = hits.get(ip); if (!r || now - r.t > 60e3) { hits.set(ip, { n: 1, t: now }); return true; } return ++r.n <= (cfg.rateLimit || 6000); };
  const hitsClean = setInterval(() => { const now = Date.now(); for (const [k, v] of hits) if (now - v.t > 60e3) hits.delete(k); }, 60e3); hitsClean.unref();
  const send = (res, code, body, headers = {}) => {
    const isObj = body !== null && typeof body === 'object' && !Buffer.isBuffer(body);
    const payload = isObj ? JSON.stringify(body) : body;
    res.writeHead(code, Object.assign({ 'Cache-Control': 'no-store' }, isObj ? { 'Content-Type': 'application/json; charset=utf-8' } : {}, headers));
    res.end(payload);
  };
  const fail = (res, code, msg) => send(res, code, { error: msg });
  const readBody = (req, limit) => new Promise((resolve, reject) => {
    const chunks = []; let n = 0;
    req.on('data', c => { n += c.length; if (n > limit) { reject(Object.assign(new Error('too large'), { code: 413 })); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
  const readJson = async (req, limit = 256 * 1024) => {
    const b = await readBody(req, limit);
    try { return JSON.parse(b.toString('utf8') || '{}'); } catch (_) { throw Object.assign(new Error('JSON inválido'), { code: 400 }); }
  };
  const cookie = req => {
    const m = String(req.headers.cookie || '').match(/(?:^|;\s*)sid=([a-f0-9]{64})/);
    return m ? m[1] : null;
  };
  const clientIp = req => (cfg.trustProxy && req.headers['x-forwarded-for'] ? String(req.headers['x-forwarded-for']).split(',')[0].trim() : req.socket.remoteAddress) || '';
  const sessionCookie = (token, maxAge) => `sid=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAge}${cfg.cookieSecure ? '; Secure' : ''}`;

  const securityHeaders = {
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'same-origin',
    'Content-Security-Policy': "default-src 'self'; script-src 'self' https://cdnjs.cloudflare.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'",
  };
  if (cfg.cookieSecure) securityHeaders['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains';

  function publicUser(u) {
    return { id: u.id, name: u.name, email: u.email, role: u.role, isOwner: u.role === 'admin', canEdit: u.role === 'admin' };
  }
  function syncPerfil(u) {
    if (u.role === 'admin') { delDoc(db, 'perfiles/' + u.id); return; }
    const ex = getDoc(db, 'perfiles/' + u.id);
    setDoc(db, 'perfiles/' + u.id, Object.assign({}, ex ? ex.data : {}, { rol: u.role, nombre: u.name }));
  }
  // Aviso por correo al cliente cuando cambia el estado de su entrega.
  const AVISOS = {
    programada: ['Tenés una entrega programada', e => `Programamos la entrega ${e.guia} para ${e.fecha}, entre ${e.desde} y ${e.hasta} h.`],
    en_camino: ['Tu pedido está en camino', e => `Tu pedido ${e.guia} salió hacia ${e.direccion}. Ventana de entrega: ${e.desde} a ${e.hasta} h.`],
    entregada: ['Entregamos tu pedido', e => `Tu pedido ${e.guia} fue entregado. Podés ver el remito y la factura en el portal.`],
    no_entregada: ['No pudimos entregar tu pedido', e => `No pudimos entregar el pedido ${e.guia}. Entrá al portal para ver el detalle y coordinar una nueva entrega.`],
  };
  const webhook = createWebhook(cfg, (ok, evento, err) => audit(null, ok ? 'webhook_enviado' : 'webhook_fallido', evento + (err ? ' · ' + err : '')));
  function notifyEntrega(prev, next) {
    if (webhook.enabled && next && next.guia && (!prev || prev.estado !== next.estado)) {
      const p = next.pod;
      webhook.send('entrega.estado', { guia: next.guia, cliente: next.cliente, estado: next.estado, fecha: next.fecha, pod: p ? { receptor: p.receptor, completa: p.completa !== false, ts: p.ts, distM: p.distM == null ? null : p.distM } : null });
    }
    if (!mailer.enabled || !next || !next.clienteId || !AVISOS[next.estado]) return;
    if (prev && prev.estado === next.estado) return;
    const u = db.prepare('SELECT email,name,active FROM users WHERE id=? AND role=?').get(String(next.clienteId), 'cliente');
    if (!u || !u.active) return;
    const [subject, body] = AVISOS[next.estado];
    const link = cfg.baseUrl ? `\n\nIngresá al portal: ${cfg.baseUrl}` : '';
    mailer.send({ to: u.email, subject: `${cfg.companyName}: ${subject}`, text: `Hola ${u.name},\n\n${body(next)}${link}\n\n${cfg.companyName}` });
  }

  async function api(req, res, url) {
    const method = req.method;
    // Protección contra peticiones desde otros sitios.
    if (method !== 'GET' && method !== 'HEAD') {
      const origin = req.headers.origin;
      if (origin) { try { if (new URL(origin).host !== req.headers.host) return fail(res, 403, 'Origen no permitido'); } catch (_) { return fail(res, 403, 'Origen no válido'); } }
    }
    const p = url.pathname;
    if (!rateOk(clientIp(req))) return fail(res, 429, 'Demasiados pedidos. Esperá un momento.');

    if (p === '/api/config' && method === 'GET') return send(res, 200, { name: cfg.companyName });

    if (p === '/api/login' && method === 'POST') {
      const b = await readJson(req, 4096);
      const email = String(b.email || '').trim().toLowerCase(), pass = String(b.password || '');
      const key = clientIp(req) + '|' + email;
      if (auth.tooMany(key)) return fail(res, 429, 'Demasiados intentos. Esperá unos minutos.');
      const u = db.prepare('SELECT * FROM users WHERE email=?').get(email);
      const okPass = auth.verifyPassword(pass, u ? u.pass : auth.DUMMY);
      if (!u || !u.active || !okPass) { auth.fail(key); audit(null, 'ingreso_fallido', email, req); return fail(res, 401, 'Correo o contraseña incorrectos'); }
      if (u.totp_on) {
        if (!b.code) return send(res, 401, { error: 'Ingresá el código de tu aplicación de autenticación', needCode: true });
        const step = totp.verify(u.totp_secret, b.code, u.totp_last || 0);
        if (!step) { auth.fail(key); audit(null, 'ingreso_fallido', '2fa ' + email, req); return fail(res, 401, 'Código incorrecto o ya usado'); }
        db.prepare('UPDATE users SET totp_last=? WHERE id=?').run(step, u.id);
      }
      auth.ok(key);
      audit(u, 'ingreso', null, req);
      const s = auth.createSession(db, u.id);
      return send(res, 200, publicUser(u), { 'Set-Cookie': sessionCookie(s.token, s.maxAge) });
    }
    // ---- recuperación de contraseña por correo (la respuesta es siempre la misma, exista o no la cuenta) ----
    if (p === '/api/forgot' && method === 'POST') {
      const b = await readJson(req, 2048), email = String(b.email || '').trim().toLowerCase(), key = 'forgot|' + clientIp(req);
      if (auth.tooMany(key)) return fail(res, 429, 'Demasiados intentos. Esperá unos minutos.');
      auth.fail(key);
      const u = db.prepare('SELECT * FROM users WHERE email=? AND active=1').get(email);
      if (u && mailer.enabled) {
        const token = crypto.randomBytes(32).toString('hex');
        db.prepare('DELETE FROM resets WHERE user_id=?').run(u.id);
        db.prepare('INSERT INTO resets(token,user_id,expires) VALUES(?,?,?)').run(crypto.createHash('sha256').update(token).digest('hex'), u.id, Date.now() + 3600e3);
        audit(u, 'reset_pedido', null, req);
        mailer.send({ to: u.email, subject: `${cfg.companyName}: restablecer tu contraseña`, text: `Hola ${u.name},\n\nPedimos restablecer la contraseña de tu cuenta. Entrá a este enlace (vale 1 hora):\n\n${cfg.baseUrl || ''}/?reset=${token}\n\nSi no fuiste vos, ignorá este mensaje: tu contraseña no cambia.\n\n${cfg.companyName}` });
      } else if (u) audit(u, 'reset_sin_correo', 'el servidor no tiene correo configurado', req);
      return send(res, 200, { ok: true });
    }
    if (p === '/api/reset' && method === 'POST') {
      const b = await readJson(req, 4096), key = 'reset|' + clientIp(req);
      if (auth.tooMany(key)) return fail(res, 429, 'Demasiados intentos. Esperá unos minutos.');
      const row = db.prepare('SELECT * FROM resets WHERE token=?').get(crypto.createHash('sha256').update(String(b.token || '')).digest('hex'));
      if (!row || row.expires < Date.now()) { auth.fail(key); return fail(res, 400, 'El enlace venció o no es válido. Pedí uno nuevo.'); }
      const u = db.prepare('SELECT * FROM users WHERE id=?').get(row.user_id);
      const pw = pwProblem(b.password, u && u.email); if (pw) return fail(res, 400, pw);
      db.prepare('UPDATE users SET pass=? WHERE id=?').run(auth.hashPassword(String(b.password)), u.id);
      db.prepare('DELETE FROM resets WHERE user_id=?').run(u.id);
      db.prepare('DELETE FROM sessions WHERE user_id=?').run(u.id);
      audit(u, 'reset_hecho', null, req);
      return send(res, 200, { ok: true });
    }

    // ---- integración con otros sistemas (ERP, planillas): clave en el encabezado X-API-Key ----
    if (p === '/api/integracion/entregas' || p === '/api/integracion/pedidos') {
      if (!cfg.integrationKey || cfg.integrationKey.length < 24) return fail(res, 404, 'No encontrado');
      const h = k => crypto.createHash('sha256').update(String(k || '')).digest();
      if (!crypto.timingSafeEqual(h(req.headers['x-api-key']), h(cfg.integrationKey))) { audit(null, 'api_clave_invalida', p, req); return fail(res, 401, 'Clave de integración no válida'); }
      if (p === '/api/integracion/pedidos') {
        if (method === 'POST') {
          const b = await readJson(req, 2 * 1024 * 1024), items = Array.isArray(b) ? b : b.pedidos;
          if (!Array.isArray(items) || !items.length || items.length > 500) return fail(res, 400, 'Enviá {"pedidos":[...]} con entre 1 y 500 elementos');
          const r = integ.upsertPedidos(db, items);
          audit(null, 'integracion_pedidos', `${r.creados} creados, ${r.actualizados} actualizados, ${r.errores.length} con error`, req);
          return send(res, 200, r);
        }
        if (method === 'GET') return send(res, 200, integ.resumenPedidos(db, url.searchParams.get('estado') || ''));
        return fail(res, 405, 'Método no permitido');
      }
      if (method === 'POST') {
        const b = await readJson(req, 2 * 1024 * 1024), items = Array.isArray(b) ? b : b.entregas;
        if (!Array.isArray(items) || !items.length || items.length > 500) return fail(res, 400, 'Enviá {"entregas":[...]} con entre 1 y 500 elementos');
        const r = integ.upsertEntregas(db, items, () => auth.newId());
        audit(null, 'integracion_entregas', `${r.creadas} creadas, ${r.actualizadas} actualizadas, ${r.errores.length} con error`, req);
        return send(res, 200, r);
      }
      if (method === 'GET' && p === '/api/integracion/entregas' && url.searchParams.get('stock') === '1') return send(res, 200, integ.stock(db));
      if (method === 'GET') return send(res, 200, integ.resumen(db, { desde: /^\d{4}-\d{2}-\d{2}$/.test(url.searchParams.get('desde') || '') ? url.searchParams.get('desde') : '', estado: url.searchParams.get('estado') || '' }));
      return fail(res, 405, 'Método no permitido');
    }
    if (p === '/api/logout' && method === 'POST') {
      auth.destroySession(db, cookie(req));
      return send(res, 204, '', { 'Set-Cookie': sessionCookie('', 0) });
    }

    const user = auth.userFromToken(db, cookie(req));
    if (!user) return fail(res, 401, 'No autenticado');

    if (p === '/api/me' && method === 'GET') return send(res, 200, publicUser(user));

    // ---- tiempos y distancias reales por calle (servidor OSRM propio o de un proveedor compatible) ----
    if (p === '/api/ruta/matriz' && method === 'POST') {
      if (user.role !== 'admin') return fail(res, 403, 'Sin permiso');
      if (!cfg.routingUrl) return fail(res, 501, 'El servicio de mapas no está configurado (ROUTING_URL).');
      const b = await readJson(req, 60000), pts = Array.isArray(b.puntos) ? b.puntos : [];
      if (pts.length < 2 || pts.length > 100) return fail(res, 400, 'Se necesitan entre 2 y 100 puntos');
      if (!pts.every(q => q && Math.abs(q.lat) <= 90 && Math.abs(q.lng) <= 180 && Number.isFinite(q.lat) && Number.isFinite(q.lng))) return fail(res, 400, 'Hay coordenadas no válidas');
      const coords = pts.map(q => (+q.lng).toFixed(6) + ',' + (+q.lat).toFixed(6)).join(';');
      try {
        const r = await fetch(cfg.routingUrl.replace(/\/+$/, '') + '/table/v1/driving/' + coords + '?annotations=duration,distance', { signal: AbortSignal.timeout(15000), headers: { 'user-agent': 'portal-logistico' } });
        const j = await r.json();
        if (!r.ok || j.code !== 'Ok' || !Array.isArray(j.durations)) return fail(res, 502, 'El servicio de mapas no pudo calcular esa matriz');
        const clean = m => Array.isArray(m) ? m.map(f => f.map(x => (typeof x === 'number' ? Math.round(x * 10) / 10 : null))) : null;
        return send(res, 200, { durations: clean(j.durations), distances: clean(j.distances), fuente: new URL(cfg.routingUrl).host });
      } catch (e) { return fail(res, 502, 'No se pudo consultar el servicio de mapas'); }
    }

    // ---- estado de la puesta en marcha (solo administración) ----
    if (p === '/api/onboarding' && method === 'GET') {
      if (user.role !== 'admin') return fail(res, 403, 'Sin permiso');
      const roles = {}; for (const r of db.prepare('SELECT role, COUNT(*) c FROM users WHERE active=1 GROUP BY role').all()) roles[r.role] = r.c;
      let ultima = null, n = 0;
      try { const dir = cfg.backupDir || path.join(__dirname, 'backups'), days = fs.readdirSync(dir).map(f => (f.match(/^portal-(\d{4}-\d{2}-\d{2})\.db$/) || [])[1]).filter(Boolean).sort(); n = days.length; ultima = days[days.length - 1] || null; } catch (_) {}
      const ad = db.prepare("SELECT totp_on FROM users WHERE id=?").get(user.id);
      return send(res, 200, { usuarios: roles, totpAdmin: !!(ad && ad.totp_on), correo: !!cfg.smtp, https: String(cfg.baseUrl || '').startsWith('https://'), integracion: !!cfg.integrationKey, backup: { ultima, n } });
    }

    // ---- verificación en dos pasos (solo administración) ----
    if (p === '/api/2fa' || p.startsWith('/api/2fa/')) {
      if (user.role !== 'admin') return fail(res, 403, 'Sin permiso');
      const u = db.prepare('SELECT * FROM users WHERE id=?').get(user.id);
      if (p === '/api/2fa' && method === 'GET') return send(res, 200, { on: !!u.totp_on });
      const b = method === 'POST' ? await readJson(req, 2048) : {};
      if (p === '/api/2fa/setup' && method === 'POST') {
        if (u.totp_on) return fail(res, 400, 'Ya está activada');
        const secret = totp.newSecret(); db.prepare('UPDATE users SET totp_secret=?, totp_last=0 WHERE id=?').run(secret, u.id);
        return send(res, 200, { secret, uri: totp.uri(secret, cfg.companyName, u.email) });
      }
      if (p === '/api/2fa/enable' && method === 'POST') {
        if (u.totp_on || !u.totp_secret) return fail(res, 400, 'Primero generá la clave');
        const step = totp.verify(u.totp_secret, b.code, 0); if (!step) return fail(res, 400, 'El código no coincide. Revisá la hora del teléfono e intentá de nuevo.');
        db.prepare('UPDATE users SET totp_on=1, totp_last=? WHERE id=?').run(step, u.id); audit(user, '2fa_activada', null, req);
        return send(res, 200, { ok: true });
      }
      if (p === '/api/2fa/disable' && method === 'POST') {
        if (!u.totp_on) return fail(res, 400, 'No está activada');
        if (!auth.verifyPassword(String(b.password || ''), u.pass)) return fail(res, 400, 'Contraseña incorrecta');
        if (!totp.verify(u.totp_secret, b.code, u.totp_last || 0)) return fail(res, 400, 'Código incorrecto');
        db.prepare('UPDATE users SET totp_on=0, totp_secret=NULL, totp_last=0 WHERE id=?').run(u.id); audit(user, '2fa_desactivada', null, req);
        return send(res, 200, { ok: true });
      }
      return fail(res, 404, 'No encontrado');
    }
    // ---- copia completa de los datos (administración) ----
    if (p === '/api/export' && method === 'GET') {
      if (user.role !== 'admin') return fail(res, 403, 'Sin permiso');
      const docs = {}; for (const r of db.prepare('SELECT path,data FROM docs ORDER BY path').all()) docs[r.path] = JSON.parse(r.data);
      audit(user, 'exportacion_completa', Object.keys(docs).length + ' documentos', req);
      return send(res, 200, { generado: new Date().toISOString(), empresa: cfg.companyName, usuarios: db.prepare('SELECT id,email,name,role,active,created FROM users ORDER BY role,name').all(), documentos: docs }, { 'Content-Disposition': 'attachment; filename="respaldo-' + new Date().toISOString().slice(0, 10) + '.json"' });
    }

    if (p === '/api/profiles' && method === 'GET') {
      const ids = String(url.searchParams.get('ids') || '').split(',').filter(x => SEG.test(x)).slice(0, 64);
      const out = {};
      for (const id of ids) { const r = db.prepare('SELECT name FROM users WHERE id=?').get(id); if (r) out[id] = { name: r.name }; }
      return send(res, 200, out);
    }

    // ---- documentos y colecciones ----
    if (p === '/api/doc') {
      const segs = parsePath(url.searchParams.get('path'));
      if (!segs || segs.length % 2 !== 0) return fail(res, 400, 'Ruta de documento no válida');
      const dp = segs.join('/'), coll = segs.slice(0, -1).join('/');
      if (method === 'GET') {
        if (!rules.canRead(user, segs)) return fail(res, 403, 'Sin permiso');
        const d = getDoc(db, dp);
        if (!d || !rules.rowReadable(user, coll, d.data)) return send(res, 200, { exists: false });
        return send(res, 200, { exists: true, data: d.data, version: d.version });
      }
      if (method === 'PUT') {
        if (!rules.canWrite(user, segs)) return fail(res, 403, 'Sin permiso');
        const body = await readJson(req);
        if (!body || typeof body !== 'object' || Array.isArray(body)) return fail(res, 400, 'Se esperaba un objeto');
        const ex = getDoc(db, dp);
        if (!rules.rowWritable(user, coll, ex && ex.data, body)) return fail(res, 403, 'Sin permiso sobre este documento');
        if (coll === 'perfiles') {
          // La cuenta manda: el rol real vive en la tabla de usuarios. Solo se permite pasar entre chofer y depósito.
          const target = db.prepare('SELECT * FROM users WHERE id=?').get(segs[1]);
          if (!target || target.role === 'admin') return fail(res, 400, 'Perfil no válido');
          let rol = target.role;
          if (['chofer', 'deposito'].includes(target.role) && ['chofer', 'deposito'].includes(body.rol)) rol = body.rol;
          body.rol = rol; body.nombre = String(body.nombre || target.name).trim().slice(0, 120) || target.name;
          if (rol !== target.role) { db.prepare('UPDATE users SET role=? WHERE id=?').run(rol, target.id); audit(user, 'cambio_rol', target.email + ' → ' + rol, req); }
          if (body.nombre !== target.name) db.prepare('UPDATE users SET name=? WHERE id=?').run(body.nombre, target.id);
        }
        setDoc(db, dp, body);
        if (coll === 'entregas') notifyEntrega(ex && ex.data, body);
        return send(res, 200, { ok: true });
      }
      if (method === 'DELETE') {
        if (!rules.canWrite(user, segs) || !rules.rowDeletable(user, coll)) return fail(res, 403, 'Sin permiso');
        delDoc(db, dp);
        if (['entregas', 'equipos', 'checks', 'viajes'].includes(coll) || coll.startsWith('wms/')) audit(user, 'borrado', dp, req);
        return send(res, 200, { ok: true });
      }
      return fail(res, 405, 'Método no permitido');
    }
    if (p === '/api/col' && method === 'GET') {
      const segs = parsePath(url.searchParams.get('path'));
      if (!segs || segs.length % 2 !== 1) return fail(res, 400, 'Ruta de colección no válida');
      if (!rules.canRead(user, segs)) return fail(res, 403, 'Sin permiso');
      const coll = segs.join('/');
      let where = [];
      try { where = JSON.parse(url.searchParams.get('where') || '[]'); } catch (_) { return fail(res, 400, 'Filtro no válido'); }
      if (!Array.isArray(where) || where.length > 5) return fail(res, 400, 'Filtro no válido');
      const get = (o, f) => String(f).split('.').reduce((a, k) => (a == null ? undefined : a[k]), o);
      const test = (o, [f, op, v]) => {
        const x = get(o, f);
        switch (op) { case '==': return x === v; case '!=': return x !== v; case '<': return x < v; case '<=': return x <= v; case '>': return x > v; case '>=': return x >= v; case 'in': return Array.isArray(v) && v.includes(x); default: return false; }
      };
      const lim = Math.min(parseInt(url.searchParams.get('limit') || '0', 10) || 0, 2000);
      const om = String(url.searchParams.get('order') || '').match(/^([A-Za-z0-9_.]{1,40}):(asc|desc)$/);
      const eq = where.find(w => Array.isArray(w) && w[1] === '==' && INDEXED.includes(w[0]) && typeof w[2] === 'string');
      let rows = (lim && om && om[1] === 'ts' && om[2] === 'desc' && !where.length) ? listCollRecent(db, coll, lim) : eq ? listCollEq(db, coll, eq[0], eq[2]) : listColl(db, coll);
      rows = rows.filter(r => rules.rowReadable(user, coll, r.data) && where.every(w => Array.isArray(w) && test(r.data, w)));
      if (om) { const dir = om[2] === 'desc' ? -1 : 1; rows.sort((a, b) => { const x = get(a.data, om[1]), y = get(b.data, om[1]); return x === y ? 0 : (x == null ? 1 : y == null ? -1 : (x < y ? -dir : dir)); }); }
      if (lim) rows = rows.slice(0, lim);
      return send(res, 200, rows.map(r => ({ id: r.id, data: r.data })));
    }

    // Sincronización por diferencias: solo lo modificado desde `since`, más la cantidad total para detectar borrados.
    // Se usa para las colecciones grandes del depósito (kardex, SKUs, posiciones) y evita bajar todo cada pocos segundos.
    if (p === '/api/col/delta' && method === 'GET') {
      const segs = parsePath(url.searchParams.get('path'));
      if (!segs || segs.length % 2 !== 1 || segs[0] !== 'wms') return fail(res, 400, 'Ruta de colección no válida');
      if (!rules.canRead(user, segs)) return fail(res, 403, 'Sin permiso');
      const coll = segs.join('/');
      const since = String(url.searchParams.get('since') || '');
      if (since && !/^\d{4}-\d{2}-\d{2}T[\d:.]+Z$/.test(since)) return fail(res, 400, 'Marca de tiempo no válida');
      const rows = since
        ? db.prepare('SELECT id, data, version, updated FROM docs WHERE coll=? AND updated>=? ORDER BY updated').all(coll, since)
        : db.prepare('SELECT id, data, version, updated FROM docs WHERE coll=? ORDER BY id').all(coll);
      const count = db.prepare('SELECT COUNT(*) AS n FROM docs WHERE coll=?').get(coll).n;
      let cursor = since;
      for (const r of rows) if (r.updated > cursor) cursor = r.updated;
      return send(res, 200, { count, cursor, rows: rows.map(r => ({ id: r.id, version: r.version, data: JSON.parse(r.data) })) });
    }

    // ---- archivos (PDF de remitos y facturas) ----
    if (p === '/api/upload' && method === 'POST') {
      if (user.role === 'cliente' || user.role === 'deposito') return fail(res, 403, 'Sin permiso');
      const mime = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
      if (!UPLOAD_OK[mime]) return fail(res, 415, 'Solo PDF o imágenes (PNG, JPG, WEBP)');
      const buf = await readBody(req, 15 * 1024 * 1024);
      if (!buf.length) return fail(res, 400, 'Archivo vacío');
      if (!MAGIC[mime](buf)) return fail(res, 415, 'El contenido no coincide con el tipo de archivo');
      const id = crypto.randomBytes(16).toString('hex');
      let name = 'archivo'; try { name = decodeURIComponent(String(req.headers['x-filename'] || 'archivo')).slice(0, 120); } catch (_) {}
      fs.writeFileSync(path.join(cfg.dataDir, 'uploads', id), buf);
      db.prepare('INSERT INTO files(id,name,mime,size,owner,created) VALUES(?,?,?,?,?,?)').run(id, name, mime, buf.length, user.id, new Date().toISOString());
      return send(res, 200, { id, url: '/uploads/' + id, sizeBytes: buf.length, contentType: mime });
    }

    // ---- carga masiva de documentos del depósito (una sola transacción; evita miles de pedidos sueltos) ----
    if (p === '/api/docs/bulk' && method === 'POST') {
      const b = await readJson(req, 8 * 1024 * 1024), coll = String(b.coll || ''), docs = Array.isArray(b.docs) ? b.docs : [];
      if (!/^(wms\/[a-z_]+\/items|entregas|portal\/[A-Za-z0-9_-]+\/entregas)$/.test(coll)) return fail(res, 400, 'Colección no válida');
      if (!docs.length || docs.length > 1000) return fail(res, 400, 'Enviá entre 1 y 1000 documentos por llamada');
      const jobs = [];
      for (const d of docs) {
        const id = d && d.id, data = d && d.data;
        if (typeof id !== 'string' || !SEG.test(id) || id === '.' || id === '..' || !data || typeof data !== 'object' || Array.isArray(data)) return fail(res, 400, 'Documento no válido');
        const segs = parsePath(coll + '/' + id); if (!segs) return fail(res, 400, 'Identificador no válido: ' + String(id).slice(0, 40));
        if (!rules.canWrite(user, segs)) return fail(res, 403, 'Sin permiso');
        const ex = getDoc(db, segs.join('/'));
        if (!rules.rowWritable(user, coll, ex && ex.data, data)) return fail(res, 403, 'Sin permiso sobre este documento');
        jobs.push([segs.join('/'), data, ex && ex.data]);
      }
      db.exec('BEGIN');
      try { for (const [dp, data] of jobs) setDoc(db, dp, data); db.exec('COMMIT'); } catch (e) { db.exec('ROLLBACK'); throw e; }
      if (coll === 'entregas') for (const [, data, prev] of jobs) notifyEntrega(prev, data);
      return send(res, 200, { ok: true, n: jobs.length });
    }
    // ---- control de vencimientos (solo administración) ----
    if (p === '/api/vencimientos/enviar' && method === 'POST') {
      if (user.role !== 'admin') return fail(res, 403, 'Sin permiso');
      const r = await venc.enviar({ prueba: true });
      return r.error && !r.ok ? fail(res, 400, r.error) : send(res, 200, r);
    }
    // ---- usuarios (solo administración) ----
    if (p === '/api/users' || p.startsWith('/api/users/')) {
      if (user.role !== 'admin') return fail(res, 403, 'Sin permiso');
      if (p === '/api/users' && method === 'GET') {
        return send(res, 200, db.prepare('SELECT id,email,name,role,active FROM users ORDER BY role,name').all().map(u => ({ id: u.id, email: u.email, name: u.name, role: u.role, active: !!u.active })));
      }
      if (p === '/api/users' && method === 'POST') {
        const b = await readJson(req, 8192);
        const email = String(b.email || '').trim().toLowerCase(), name = String(b.name || '').trim(), role = String(b.role || ''), pass = String(b.password || '');
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return fail(res, 400, 'Correo no válido');
        if (!name || name.length > 120) return fail(res, 400, 'Falta el nombre');
        if (!['admin', 'chofer', 'deposito', 'cliente'].includes(role)) return fail(res, 400, 'Rol no válido');
        { const pw = pwProblem(pass, email); if (pw) return fail(res, 400, pw); }
        if (db.prepare('SELECT 1 FROM users WHERE email=?').get(email)) return fail(res, 409, 'Ya existe un usuario con ese correo');
        const u = { id: auth.newId(), email, name, role };
        db.prepare('INSERT INTO users(id,email,name,role,pass,active,created) VALUES(?,?,?,?,?,1,?)').run(u.id, email, name, role, auth.hashPassword(pass), new Date().toISOString());
        syncPerfil(u);
        audit(user, 'usuario_creado', email + ' (' + role + ')', req);
        return send(res, 200, { id: u.id, email, name, role, active: true });
      }
      if (p === '/api/users/bulk' && method === 'POST') {
        const b = await readJson(req, 200000), items = Array.isArray(b.users) ? b.users : [];
        if (!items.length) return fail(res, 400, 'No hay filas');
        if (items.length > 200) return fail(res, 400, 'Máximo 200 usuarios por carga');
        const out = { creados: [], errores: [] }, vistos = new Set();
        items.forEach((it, i) => {
          const err = m => out.errores.push({ fila: i + 1, email: String(it && it.email || '').slice(0, 120), error: m });
          if (!it || typeof it !== 'object') return err('Fila no válida');
          const email = String(it.email || '').trim().toLowerCase(), name = String(it.name || it.nombre || '').trim(), role = String(it.role || it.rol || '').trim().toLowerCase();
          if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return err('Correo no válido');
          if (!name || name.length > 120) return err('Falta el nombre');
          if (!['admin', 'chofer', 'deposito', 'cliente'].includes(role)) return err('Rol no válido (admin, chofer, deposito o cliente)');
          if (vistos.has(email)) return err('Correo repetido en la carga'); vistos.add(email);
          if (db.prepare('SELECT 1 FROM users WHERE email=?').get(email)) return err('Ya existe un usuario con ese correo');
          const password = auth.tempPassword(), u = { id: auth.newId(), email, name, role };
          db.prepare('INSERT INTO users(id,email,name,role,pass,active,created) VALUES(?,?,?,?,?,1,?)').run(u.id, email, name, role, auth.hashPassword(password), new Date().toISOString());
          syncPerfil(u);
          const tel = String(it.telefono || it.tel || '').trim().slice(0, 40), ex = getDoc(db, 'perfiles/' + u.id);
          const area = String(it.area || '').trim().slice(0, 80);
          if ((tel || area) && ex) setDoc(db, 'perfiles/' + u.id, Object.assign({}, ex.data, tel ? { telefono: tel } : {}, area ? { area } : {}));
          audit(user, 'usuario_creado', email + ' (' + role + ', carga masiva)', req);
          out.creados.push({ id: u.id, email, name, role, password });
        });
        return send(res, 200, out);
      }
      const m = p.match(/^\/api\/users\/([a-f0-9]{24})$/);
      if (m) {
        const id = m[1], target = db.prepare('SELECT * FROM users WHERE id=?').get(id);
        if (!target) return fail(res, 404, 'No existe');
        if (method === 'PATCH') {
          const b = await readJson(req, 8192);
          if (b.password !== undefined) {
            { const pw = pwProblem(b.password, target.email); if (pw) return fail(res, 400, pw); }
            audit(user, 'clave_cambiada', target.email, req);
            db.prepare('UPDATE users SET pass=? WHERE id=?').run(auth.hashPassword(String(b.password)), id);
            db.prepare('DELETE FROM sessions WHERE user_id=?').run(id);
          }
          if (b.active !== undefined) {
            if (id === user.id && !b.active) return fail(res, 400, 'No podés desactivar tu propia cuenta');
            db.prepare('UPDATE users SET active=? WHERE id=?').run(b.active ? 1 : 0, id);
            audit(user, b.active ? 'usuario_activado' : 'usuario_desactivado', target.email, req);
            if (!b.active) db.prepare('DELETE FROM sessions WHERE user_id=?').run(id);
          }
          if (b.name !== undefined && String(b.name).trim()) {
            db.prepare('UPDATE users SET name=? WHERE id=?').run(String(b.name).trim().slice(0, 120), id);
            syncPerfil(db.prepare('SELECT * FROM users WHERE id=?').get(id));
          }
          return send(res, 200, { ok: true });
        }
        if (method === 'DELETE') {
          if (id === user.id) return fail(res, 400, 'No podés borrar tu propia cuenta');
          db.prepare('DELETE FROM users WHERE id=?').run(id);
          delDoc(db, 'perfiles/' + id);
          audit(user, 'usuario_borrado', target.email, req);
          return send(res, 200, { ok: true });
        }
      }
      return fail(res, 404, 'No encontrado');
    }
    if (p === '/api/audit' && method === 'GET') {
      if (user.role !== 'admin') return fail(res, 403, 'Sin permiso');
      return send(res, 200, db.prepare('SELECT ts,user_name,action,detail,ip FROM audit ORDER BY id DESC LIMIT 200').all());
    }
    return fail(res, 404, 'No encontrado');
  }

  // Un archivo lo ve: quien lo subió, administración, el cliente cuya entrega lo menciona y el chofer asignado a esa entrega.
  function fileAllowed(user, f) {
    if (user.role === 'admin' || f.owner === user.id) return true;
    if (user.role === 'cliente') return !!db.prepare("SELECT 1 FROM docs WHERE coll=? AND data LIKE ? LIMIT 1").get('portal/' + user.id + '/entregas', '%' + f.id + '%');
    if (user.role === 'chofer') {
      return db.prepare("SELECT data FROM docs WHERE coll='entregas' AND data LIKE ?").all('%' + f.id + '%').some(r => { try { return JSON.parse(r.data).choferId === user.id; } catch (_) { return false; } });
    }
    return false;
  }
  function serveFile(res, file, headers = {}) {
    fs.readFile(file, (err, buf) => {
      if (err) return fail(res, 404, 'No encontrado');
      send(res, 200, buf, Object.assign({ 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' }, headers));
    });
  }

  const server = http.createServer(async (req, res) => {
    for (const k in securityHeaders) res.setHeader(k, securityHeaders[k]);
    try {
      const url = new URL(req.url, 'http://x');
      if (url.pathname === '/healthz') return send(res, 200, { ok: true });
      if (url.pathname.startsWith('/api/')) return await api(req, res, url);
      if (url.pathname.startsWith('/uploads/')) {
        const user = auth.userFromToken(db, cookie(req));
        if (!user) return fail(res, 401, 'No autenticado');
        const id = url.pathname.slice(9);
        if (!/^[a-f0-9]{32}$/.test(id)) return fail(res, 404, 'No encontrado');
        const f = db.prepare('SELECT * FROM files WHERE id=?').get(id);
        if (!f || !fileAllowed(user, f)) return fail(res, 404, 'No encontrado');
        return serveFile(res, path.join(cfg.dataDir, 'uploads', id), { 'Content-Type': f.mime, 'Content-Disposition': 'inline; filename="' + f.name.replace(/[^\w.\- ]/g, '_') + '"', 'Cache-Control': 'private, max-age=3600' });
      }
      let rel = url.pathname === '/' ? '/index.html' : decodeURIComponent(url.pathname);
      const file = path.normalize(path.join(publicDir, rel));
      if (!file.startsWith(publicDir + path.sep)) return fail(res, 404, 'No encontrado');
      return serveFile(res, file, { 'Cache-Control': 'no-cache' });
    } catch (e) {
      if (e && e.code === 413) return fail(res, 413, 'Archivo demasiado grande');
      if (e && e.code === 400) return fail(res, 400, e.message);
      console.error(e);
      return fail(res, 500, 'Error interno');
    }
  });
  return { server, db, ctx };
}

function configFromEnv() {
  const base = process.env.BASE_URL || '';
  return {
    port: parseInt(process.env.PORT || '3000', 10),
    dataDir: path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data')),
    companyName: process.env.COMPANY_NAME || 'Portal de entregas',
    adminEmail: process.env.ADMIN_EMAIL,
    adminPassword: process.env.ADMIN_PASSWORD,
    cookieSecure: process.env.COOKIE_SECURE ? process.env.COOKIE_SECURE === '1' : base.startsWith('https://'),
    trustProxy: process.env.TRUST_PROXY === '1',
    baseUrl: base,
    routingUrl: process.env.ROUTING_URL || '',
    backupDir: path.resolve(process.env.BACKUP_DIR || path.join(__dirname, 'backups')),
    integrationKey: process.env.INTEGRATION_KEY || '',
    rateLimit: parseInt(process.env.RATE_LIMIT || '6000', 10),
    webhookUrl: process.env.WEBHOOK_URL || '',
    webhookSecret: process.env.WEBHOOK_SECRET || '',
    smtp: process.env.SMTP_HOST ? { host: process.env.SMTP_HOST, port: parseInt(process.env.SMTP_PORT || '587', 10), secure: process.env.SMTP_SECURE || 'starttls', user: process.env.SMTP_USER, pass: process.env.SMTP_PASS, from: process.env.SMTP_FROM || process.env.SMTP_USER } : null,
  };
}

module.exports = { createServer, configFromEnv };

if (require.main === module) {
  loadEnv(path.join(__dirname, '.env'));
  const cfg = configFromEnv();
  const { server } = createServer(cfg);
  server.listen(cfg.port, () => console.log(`${cfg.companyName} escuchando en http://localhost:${cfg.port}`));
}
