'use strict';
// Copia de seguridad: base de datos (consistente aunque el servidor esté en uso) y archivos subidos.
// Uso: npm run backup  → crea backups/portal-AAAA-MM-DD.db y backups/uploads-AAAA-MM-DD/. Conserva las últimas BACKUP_KEEP (14).
const fs = require('node:fs');
const path = require('node:path');
const { open } = require('../lib/db');
const dataDir = path.resolve(process.env.DATA_DIR || path.join(__dirname, '..', 'data'));
const out = path.resolve(process.env.BACKUP_DIR || path.join(__dirname, '..', 'backups'));
const keep = Math.max(1, parseInt(process.env.BACKUP_KEEP || '14', 10));
fs.mkdirSync(out, { recursive: true });
const day = new Date().toISOString().slice(0, 10);
const file = path.join(out, `portal-${day}.db`);
if (fs.existsSync(file)) fs.unlinkSync(file);
const db = open(path.join(dataDir, 'portal.db'));
db.exec(`VACUUM INTO '${file.replace(/'/g, "''")}'`);
db.close();
const up = path.join(dataDir, 'uploads'), upOut = path.join(out, `uploads-${day}`);
if (fs.existsSync(up)) { fs.rmSync(upOut, { recursive: true, force: true }); fs.cpSync(up, upOut, { recursive: true }); }
// Borra las copias más viejas.
const stamp = f => (f.match(/(\d{4}-\d{2}-\d{2})/) || [])[1];
const days = [...new Set(fs.readdirSync(out).map(stamp).filter(Boolean))].sort();
for (const d of days.slice(0, Math.max(0, days.length - keep))) {
  fs.rmSync(path.join(out, `portal-${d}.db`), { force: true });
  fs.rmSync(path.join(out, `uploads-${d}`), { recursive: true, force: true });
}
console.log('Copia creada:', file, '(conserva las últimas ' + keep + ')');
