'use strict';
// Restaurar una copia: node scripts/restore.js <portal-AAAA-MM-DD.db> [carpeta-de-datos]
// Con el servidor APAGADO. Verifica la copia antes de reemplazar y guarda la base anterior como portal.db.anterior.
const fs = require('node:fs'), path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const src = process.argv[2], dataDir = path.resolve(process.argv[3] || process.env.DATA_DIR || path.join(__dirname, '..', 'data'));
if (!src || !fs.existsSync(src)) { console.error('Uso: node scripts/restore.js <archivo.db> [carpeta-de-datos]'); process.exit(1); }
const chk = new DatabaseSync(path.resolve(src), { readOnly: true });
const ok = chk.prepare('PRAGMA integrity_check').get().integrity_check;
const n = chk.prepare('SELECT COUNT(*) c FROM users').get().c, d = chk.prepare('SELECT COUNT(*) c FROM docs').get().c;
chk.close();
if (ok !== 'ok') { console.error('La copia está dañada:', ok); process.exit(1); }
fs.mkdirSync(dataDir, { recursive: true });
const dest = path.join(dataDir, 'portal.db');
if (fs.existsSync(dest)) fs.copyFileSync(dest, dest + '.anterior');
for (const ext of ['-wal', '-shm']) fs.rmSync(dest + ext, { force: true });
fs.copyFileSync(path.resolve(src), dest);
const day = (path.basename(src).match(/(\d{4}-\d{2}-\d{2})/) || [])[1], up = path.join(path.dirname(path.resolve(src)), 'uploads-' + day);
if (day && fs.existsSync(up)) fs.cpSync(up, path.join(dataDir, 'uploads'), { recursive: true });
console.log(`Restaurada: ${n} usuarios, ${d} documentos.${day && fs.existsSync(up) ? ' Archivos subidos restaurados.' : ' (No se encontró la carpeta de archivos de esa fecha.)'}`);
