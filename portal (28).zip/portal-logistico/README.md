# Portal logístico

Portal web con cuentas de usuario para **entregas de reparto**, **viajes de larga distancia**, **depósito** (stock, plano de racks, kardex, ABC-XYZ, peso, simulación de picking) y **equipos** (autoelevadores y camiones con check list, fichas de personal y vencimientos). Se publica en tu propio dominio y con el nombre de tu empresa.

| Rol | Qué ve y qué hace |
|---|---|
| **Cliente** | Solo sus entregas, remito y factura (con el PDF), y avisos de pendientes. |
| **Chofer** | Solo su hoja de ruta del día, con Waze, estados y observaciones. Check list de su vehículo antes de salir. Funciona aunque se corte la señal. |
| **Depósito (operario)** | Solo los equipos del depósito y sus check lists. No ve entregas ni clientes. |
| **Administración** | Todo: carga, dashboards, depósito, viajes, equipos, fichas, usuarios y registro de actividad. |

No usa paquetes externos: solo Node.js 22.13 o superior (incluye la base de datos SQLite).

## 1. Probarlo en tu computadora

```bash
cp .env.example .env        # editá COMPANY_NAME, ADMIN_EMAIL y ADMIN_PASSWORD
npm run seed                # (opcional) carga los datos de tu Excel: SKUs, ubicaciones, kardex y viajes
npm start                   # abre http://localhost:3000
npm test                    # 74 pruebas automáticas de permisos, archivos, auditoría, correo, integración, 2FA, depósito, mapas y recuperación de clave
npm run test:dr             # prueba de desastre: copia, base destruida, restauración y verificación de que nada se perdió
```

Si no definís `ADMIN_PASSWORD`, la primera vez se genera una contraseña y se muestra en la consola.

## 2. Publicarlo con tu dominio

**Opción recomendada: un servidor virtual con Docker**

1. **Dominio.** Registrá uno (por ejemplo `tuempresa.com.ar` en NIC Argentina) o usá un subdominio, como `portal.tuempresa.com.ar`.
2. **Servidor.** Contratá un servidor virtual con Linux (1 GB de memoria alcanza para empezar) e instalá Docker.
3. **DNS.** En el panel de tu dominio creá un registro `A` que apunte `portal.tuempresa.com.ar` a la IP del servidor.
4. **Subí esta carpeta al servidor** y, dentro de ella:
   ```bash
   cp .env.example .env
   nano .env      # COMPANY_NAME, DOMAIN=portal.tuempresa.com.ar, BASE_URL=https://portal.tuempresa.com.ar,
                  # ADMIN_EMAIL, ADMIN_PASSWORD (larga), TRUST_PROXY=1
   docker compose up -d --build
   docker compose exec app node --disable-warning=ExperimentalWarning scripts/seed.js   # opcional
   ```
5. Abrí `https://portal.tuempresa.com.ar`. Caddy consigue y renueva el certificado HTTPS solo.

**Alternativa (Render, Railway u otro):** cualquier servicio que ejecute Node 22 **y ofrezca un disco persistente**. Configurá las variables de `.env`, montá el disco y apuntá `DATA_DIR` ahí. Sin disco persistente, los datos se pierden en cada reinicio. El modo sin conexión del chofer y la instalación como aplicación requieren HTTPS.

## 3. Uso diario

- **Crear cuentas:** ingresá como administración → Operación → Usuarios → "Crear usuario". Una cuenta por cliente, chofer y operario. La contraseña inicial debe tener 10 caracteres o más y no ser el correo ni una clave común.
- **Fichas:** Equipos y personal → Fichas. Teléfono, contacto de emergencia, turno, licencia y habilitaciones con semáforo de vencimientos. Se puede pasar a una persona de chofer a depósito desde su ficha.
- **Equipos y check lists:** Equipos y personal → Equipos. Cada equipo tiene su lista de control. Una falla en un punto crítico lo deja "fuera de servicio" hasta que se haga un nuevo check list, y administración lo ve en un aviso en todas las pantallas. Los check lists no se pueden editar ni borrar por quien los hizo.
- **Cargar datos:** a mano desde las pantallas, o con "Importar Excel" en Depósito y en Viajes (hojas `WMS 1`, `WMS 2`, `WMS 3`, `TMS 1`, `TMS 2`). Subir dos veces el mismo archivo no duplica nada.
- **Remito y factura:** se cargan los números y, si querés, el PDF. El portal no los emite: eso sigue en ARCA o en tu sistema de facturación.

### Avisos al cliente

- **Correo (automático).** Completá las variables `SMTP_*` del `.env` con los datos de tu servicio de correo. Cada vez que cambia el estado de una entrega (programada, en camino, entregada, no entregada) el cliente recibe un correo con el enlace al portal. Si falla, reintenta dos veces más y deja el resultado en el registro de actividad. Si dejás `SMTP_HOST` vacío, no se envía nada.
- **Tráfico es el único punto de contacto.** Administración carga el contacto de tráfico en Operación › Contacto de tráfico. El chofer ve botones para llamar o escribirle por WhatsApp ante una urgencia (en su pantalla y en cada parada), y el cliente puede consultarle por cada entrega pendiente. El chofer no ve teléfonos de clientes, y el servidor se lo impide.
- **WhatsApp de tráfico al cliente (con un clic).** Cargá el teléfono del cliente en su ficha. En cada entrega de la lista aparece el botón "WhatsApp" (si falta el teléfono, el botón "Cargar WhatsApp" lleva a la ficha del cliente), que abre el chat con el mensaje ya escrito; lo envía una persona. No usa la API oficial de WhatsApp Business, que es de pago y requiere aprobación.

### Sin conexión (choferes)

La aplicación guarda lo último que se vio y los cambios pendientes **en el teléfono (IndexedDB)**, así que sobreviven a cerrar la aplicación o recargar sin señal.
- **Qué se puede hacer sin señal:** cambiar estados, escribir observaciones, hacer el check list y **sacar la foto de entrega** (queda guardada y se sube sola al volver la señal).
- **Si administración editó lo mismo mientras tanto:** se combinan los cambios campo por campo; las observaciones y el historial se suman, no se pisan. Si el mismo campo cambió en los dos lados gana el cambio del chofer, y la aplicación deja un aviso visible ("se pisó lo que otra persona cambió en…").
- **Reintentos:** si el servidor responde con error o está saturado, la aplicación reintenta con esperas crecientes. El banner de arriba muestra cuántos cambios faltan enviar, el último error y un botón **Reintentar**.
- **Cambios rechazados** (por ejemplo, permisos que cambiaron): no se descartan en silencio; quedan en una lista visible hasta que la persona toca "Entendido".
- **Límites:** al salir de la sesión con cambios sin enviar, la aplicación avisa antes de perderlos. No se probó con un celular físico ni con cortes reales de 4G; se probó con un navegador simulando corte de red, errores 500 y rechazos 403.

### Prueba de entrega

Al tocar "Entregado", el chofer anota quién recibió, marca si la entrega está completa (si no, debe contar qué faltó o se dañó), firma con el dedo y, si quiere, saca una foto. Con su **consentimiento** (se pide una vez, dentro de la aplicación) puede registrar la ubicación; el portal calcula a cuántos metros de la dirección se hizo. Sin consentimiento puede entregar igual, sin ubicación. La prueba la ven administración, el cliente dueño y el chofer asignado. Si no hay señal, la entrega se guarda y la foto queda pendiente (se avisa).

### Gestión (solo administración)

Pestaña **Gestión**:
- **Indicadores:** OTIF (a tiempo y completas), entregas en hora, completas, éxito de entrega, causas de no entrega, OTIF por semana y uso de la capacidad de cada camión (hace falta cargar el peso en las entregas y asignar el equipo al chofer).
- **Costos de flota:** combustible, peajes y otros gastos (los choferes cargan los suyos desde su pantalla), consumo real en L/100 km, costo por km y por entrega, e incluye lo gastado en órdenes de mantenimiento.
- **Mantenimiento:** una falla en un check list abre sola una **orden de trabajo** (crítica si el punto lo era). También se pueden definir services por kilómetros u horas: al vencer aparece el aviso y se genera la orden.
- **Check lists:** editá las listas de control de cada tipo de equipo y anotá la fuente (manual del fabricante, normativa, procedimiento interno). Los puntos que no cambian conservan su historial.
- **Importar / exportar:** cargá entregas desde Excel o CSV (hay plantilla descargable, vista previa con errores y actualización por número de guía sin perder estado, historial ni prueba de entrega) y exportá las entregas a CSV.
- **Datos y seguridad:** registro de consentimientos, copia completa de los datos y verificación en dos pasos.

En **Operación**, el panel *Orden con ventanas horarias* calcula la hora estimada de llegada a cada parada (velocidad media y minutos por parada configurables), advierte atrasos y si la carga supera la capacidad del vehículo, y propone un orden que reduce km y atrasos. Es una heurística: no usa tránsito real ni garantiza el óptimo.

En **Depósito** hay tres secciones nuevas: *Lotes y FEFO* (ingreso con lote y vencimiento, sugerencia de ubicación, semáforo de vencimientos), *Conteos* (conteo cíclico ciego, ajuste en el kardex y exactitud de inventario) y *Picking* (órdenes que reservan stock por FEFO, con la lista ordenada por ubicación; al confirmar generan las salidas). Los ingresos hechos por "Movimiento" no tienen lote: para que FEFO sea confiable hay que ingresar con lote.

También en Depósito:
- **Plano con lotes:** en el plano elegí "Lotes y vencimientos" para ver cada posición con su lote y días para vencer (semáforo). Al tocar una posición se listan sus lotes. En *Stock* hay una tabla con el próximo vencimiento de cada SKU.
- **Logística inversa:** registrá la mercadería devuelta (con guía, motivo, lote y vencimiento) y decidí qué hacer: reingresa a stock en la ubicación sugerida, reproceso, devolución al proveedor o baja. Un lote vencido no puede reingresar. Las entregas no entregadas o parciales aparecen para registrar su devolución con un clic. La mercadería devuelta no suma a stock hasta que se resuelve. Solo administración carga devoluciones.
- **Picking por línea:** la lista sale en serpentina por pasillo, se confirma cantidad recogida por línea (el faltante queda registrado) y se puede descargar en CSV.

### Integración con tu ERP

- **Por archivo:** Gestión › Importar / exportar.
- **Por API:** definí `INTEGRATION_KEY` en `.env` (24 caracteres o más, aleatoria) y reiniciá. Es una clave de servidor a servidor: no la pongas en una página web ni en un teléfono.
  ```
  curl -X POST https://TU-DOMINIO/api/integracion/entregas \
    -H "X-API-Key: TU_CLAVE" -H "Content-Type: application/json" \
    -d '{"entregas":[{"guia":"G-9001","cliente":"Ferretería Del Plata","chofer":"Marcos Peralta","fecha":"2026-12-01","desde":"09:00","hasta":"12:00","direccion":"Av. Mitre 1890, Wilde","bultos":6,"pesoKg":420}]}'
  curl -H "X-API-Key: TU_CLAVE" "https://TU-DOMINIO/api/integracion/entregas?desde=2026-12-01"
  ```
  El POST acepta hasta 500 entregas, crea o actualiza por `guia` y devuelve `{creadas, actualizadas, errores:[{fila,guia,error}]}`. El cliente y el chofer deben existir (se buscan por nombre o por `clienteId`/`choferId`). El GET devuelve estado, hora de entrega y prueba (quién recibió, si estuvo completa, distancia, si hay firma y foto).
- **Copia completa:** `GET /api/export` (administración, con sesión) o el botón en Gestión › Datos y seguridad.

### Verificación en dos pasos y recuperación de clave

- Administración puede activar códigos de 6 dígitos (Google Authenticator, Authy, 1Password) en Gestión › Datos y seguridad. Cada código sirve una sola vez. **Guardá la clave en un lugar seguro:** si perdés el teléfono y la clave, hay que desactivar el 2FA desde la base de datos (`UPDATE users SET totp_on=0 WHERE email='...'`).
- "Olvidé mi contraseña" en la pantalla de ingreso manda un enlace de un solo uso (vale 1 hora) al correo de la cuenta; cierra las sesiones abiertas. **Requiere que el correo (SMTP) esté configurado**; sin eso, no se envía nada y administración puede cambiar la contraseña desde Usuarios.

### Depósito: recepción, escaneo, etiquetas y olas

- **Formato de ubicaciones: `pasillo:rack:ubicación:altura`**, cada parte con dos cifras. Ejemplo: `01:01:01:00` es el pasillo 01, rack 01, ubicación 01, altura 00 (el pallet en el **piso**); `01:01:01:03` es la misma ubicación, tres pisos arriba. La ubicación (01, 02…) es cada hueco dentro del rack y la altura va de 00 hasta el último piso (00 a 04 si tiene cinco). Al cargar o importar se aceptan también `-`, `.` o `/` como separador y se guardan con `:`. Un código con menos de cuatro partes (como el formato anterior de tres) no se acepta: el sistema no importa nada y avisa cuál es. El peso del rack completo suma todas sus ubicaciones y alturas. La vista de frente muestra el rack elegido con las ubicaciones en columnas y las alturas en filas, 00 abajo. **Excel puede convertir códigos con `:` en horas si la celda no es de texto:** las columnas de códigos de la plantilla ya vienen en formato Texto; si el importador detecta horas, avisa y no carga nada. Los datos de demostración y la plantilla ya usan este formato; **no hay conversión automática de bases con formatos anteriores** (`01-02-03` o `01:02:03`): se vuelven a importar.

- **Recepción contra orden de compra** (Depósito › Recepción): cargás la OC, y al llegar la mercadería indicás cantidad, lote, vencimiento y ubicación (sugerida por putaway). Entra al kardex; si llega de más queda como sobrante. Se puede escanear el SKU con un lector.
- **Etiquetas Code 128** de ubicaciones y SKUs (Depósito › Etiquetas): se imprimen o se descargan en HTML.
- **Picking guiado**: ubicación → producto → cantidad, con lector USB/Bluetooth (que escribe el código y Enter) o con la cámara si el navegador soporta `BarcodeDetector`.
- **Olas de picking**: juntás dos o más órdenes pendientes en una recorrida; al confirmar se reparte lo recogido entre los pedidos y los faltantes quedan en cada uno.
- **Personal de depósito** (rol `deposito`) opera todo esto con permisos propios, sin ver entregas, clientes ni viajes. En la versión alojada como artefacto de Claude esa parte funciona solo en la demostración.
- **Reparto entre vehículos** (Operación): divide las entregas del día entre los choferes por zona, capacidad en kg y máximo de paradas, y ordena cada ruta con ventanas horarias.

### Rutas con mapas reales

Por defecto las rutas se calculan con distancia en línea recta × 1,3. Si tu servidor tiene un servicio de ruteo compatible con **OSRM** (propio o de un proveedor), definí `ROUTING_URL` en `.env` (por ejemplo `http://localhost:5000`). En Operación aparece el botón **Usar mapa real**: el servidor consulta una matriz de tiempos y distancias por calle (hasta 100 puntos, solo administración) y el optimizador, la simulación y el reparto entre vehículos la usan. Si el servicio no responde, se sigue con la estimación. Sin `ROUTING_URL` el servidor contesta que no hay mapas configurados.
**Qué se probó:** la integración completa contra un OSRM *de prueba* que escribí (devuelve el doble de la distancia recta para comprobar que se usa la matriz). **No se probó contra un OSRM real** ni con tránsito en vivo: antes de prometerlo, levantá uno con el mapa de Buenos Aires y comparalo con una ruta que conozcas.

### Lectores físicos

Los lectores USB/Bluetooth que escriben el código y Enter (modo teclado) se detectan solos por la velocidad de tecleo: en recepción, picking y conteo se pueden usar sin tocar ningún campo. Probado con teclado simulado; **no con un lector real** (ver Límites).

### Reportes y exportación

Gestión › Reportes: entregas, por chofer, por cliente, por zona, gastos, kardex y check lists, por período (7, 30 días, etc.). Se bajan en CSV (separador punto y coma y acentos, para abrir directo en Excel) o se imprimen / guardan en PDF desde el navegador.

### Inteligencia logística

Gestión › Análisis. Es estadística simple y explicable sobre el historial de la propia empresa, no una "IA" opaca:
- **Predicción de atrasos:** tasa histórica de atrasos por zona, cliente, chofer, franja horaria y tamaño, suavizada para que pocos datos no exageren, combinada en una probabilidad por entrega pendiente y confrontada con la simulación de la ruta. Se muestra su acierto histórico (AUC) calculado con datos que el modelo no vio.
- **Costos por cliente y zona:** combustible y gastos cargados de la flota (con km/l tomado del odómetro) y un costo fijo diario del vehículo que se indica en pantalla, repartidos por kilómetros recorridos. Con el ingreso por entrega o factura da el margen.
- **Rentabilidad por vehículo:** costo, km, rendimiento y utilidad.
- **Predicción de stock:** consumo por SKU, punto de reposición y stock de seguridad; muestra el error (WAPE) sobre las últimas semanas retenidas.
- **Alertas de desvíos:** reglas fijas y visibles: entregas con ventana horaria vencida, entregas sin prueba de entrega, confirmadas a más de 300 m de la dirección, choferes con 20 % o más de no entregadas, costo por entrega que sube más de 30 % contra el promedio, equipos sin check list en 7 días o con fallas, quiebre de stock previsto, lotes vencidos o por vencer, actas de conteo con diferencia mayor al 5 % y vehículos con la carga del día por encima de su capacidad.
**Límites honestos:** con poco historial (menos de unas semanas o unas pocas decenas de entregas) los números no valen; el modelo no ve el tránsito ni el clima; el costo por cliente es un reparto por kilómetros, no un costeo contable. En la demostración el historial es **sintético** (generado con patrones plantados): el 0,76 de AUC y el 10 % de error de stock que se ven ahí demuestran que el método recupera esos patrones, **no** que vaya a acertar igual en tu empresa. Se validará con datos reales de cada cliente.

### Puesta en marcha de una empresa nueva

En **Gestión** hay dos pantallas pensadas para implementar rápido:
- **Puesta en marcha:** plantillas descargables (usuarios, vehículos, conteo y un Excel de depósito compatible con el importador), **alta masiva de usuarios** con clave temporal por persona (se muestran una sola vez y se pueden bajar en CSV), importación de **vehículos** con sus vencimientos, y **conteo físico** con vista previa de diferencias contra el sistema, saldo inicial en el kardex y **acta imprimible para firmar**.
- **Lunes OK:** semáforo con lo que falta antes de arrancar (datos, saldo inicial, check lists, consentimientos, entregas, y en tu servidor: verificación en dos pasos, https y copia de seguridad).

Para varias empresas en un mismo servidor: `npm run alta-cliente -- --nombre "Empresa SA" --dominio portal.empresa.com.ar --admin dueno@empresa.com.ar` crea una instancia aislada (puerto, datos y copias propios, administrador con clave generada) y actualiza `clientes/Caddyfile`; `npm run clientes` las levanta todas, las reinicia si se caen y hace una copia diaria de cada una (con `kill -HUP` suma un cliente nuevo sin cortar a los demás). La guía comercial y de trabajo está en `docs/implementacion-llave-en-mano.md`.

### Documentos para ofrecer el servicio

En `docs/`: propuesta de piloto, política de datos y ubicación (con el texto de consentimiento), soporte y continuidad, caso de ahorro, **implementación llave en mano**, **acuerdo de continuidad** (código en custodia, contacto alternativo, salida sin costo), **API de integración**, **runbook de operación** (restaurar) y **autoevaluación de seguridad** (no es auditoría). Son **plantillas**: los números del caso de ahorro son un ejemplo inventado y la política no es asesoramiento legal.

### Control logístico (pedidos, expedición, alertas, fletes)

En el menú de administración aparece **Control**. Sirve igual para una pyme con 4 SKUs que para un depósito de 1.500 SKUs y más de 5.000 posiciones: en *Control › Módulos* se elige el paquete (Mínimo, Pyme, Completo) o se prende y apaga cada módulo. Lo apagado no aparece en los menús ni genera alertas.

- **Pedidos**: borrador → reserva de stock (primero lo que vence antes) → picking → bultos con etiqueta → escaneo en expedición → despacho (crea la guía) → entregado. Muestra bloqueos (falta stock, sin dirección, lote que vence antes de la entrega, atraso). Se cargan a mano, por archivo (columnas pedido, cliente, direccion, fecha, desde, hasta, sku, cantidad) o desde el ERP.
- **Expedición**: se escanea cada bulto (`PED-000123-1`); avisa si es de otro pedido, si ya se escaneó o si no existe. Despachar (crear la guía y asignar chofer) lo hace administración.
- **Control**: alertas con urgencia, responsable y nota (tomar, resolver, ignorar 7 días). Una alerta resuelta vuelve a las 24 horas si el problema sigue.
- **Abastecimiento**: disponible = stock − comprometido, demanda de 90 días, punto de reposición, sugerido de compra y generación de órdenes de compra por proveedor. Parámetros por SKU (proveedor, lead time, costo, volumen) a mano o por archivo.
- **Reposición de picking**: la posición del piso (altura 00) es el picking; cuando baja del mínimo se crea la tarea de traer de las alturas, primero lo que vence antes. Se crean solas al confirmar un picking.
- **Fletes y costos**: tarifas por transportista (fijo + km + bulto), auditoría de facturas (cobro de más, duplicado, guía inexistente, sin tarifa), costo por viaje/km/bulto y margen logístico por cliente. Solo administración.
- **Productividad**: líneas, unidades, reposiciones y bultos por persona. Mide tiempos del picking: el operario toca «Empezar» y el sistema calcula minutos y líneas por hora; en las demás tareas cuenta tareas, no tiempos.
- **5S (orden y limpieza)**: módulo para administración y supervisor. Auditoría de 15 puntos por área (3 por cada S, cada uno No / Parcial / Sí), tablero con semáforo y tendencia, acciones correctivas con responsable y fecha, historial y CSV. Se abre desde la pantalla de módulos o desde la sección «5S» de Administración.
- **Buscador**: administración y supervisión buscan por factura, remito, SKU, posición y picker (con filtros de cliente y fechas). El cliente tiene su propio buscador, solo por factura, remito y producto, y solo sobre sus entregas; no ve posiciones ni pickers.
- **7 KPIs de almacén** (Dashboard, últimos 30 días): rotación de stock, ocupación, exactitud de inventario, errores de picking, entregas a tiempo, costo por pedido y tiempo de preparación. Los errores de picking se marcan desde Staging ("⚠ Error de picking": tipo + nota) y se pueden quitar.
- **Metas y semáforo**: administración define las metas de cada KPI (botón «Cambiar metas»); el semáforo verde/amarillo/rojo se calcula con ellas. Supervisión y gerencia las ven pero no las cambian.
- **Comparación y presupuesto**: cada KPI de entregas a tiempo, errores y costo por pedido muestra si mejoró o empeoró contra los 30 días anteriores, y se puede cargar un presupuesto logístico mensual (en «Cambiar metas») que pinta el costo en amarillo o rojo al acercarse o pasarse.
- **Cliente**: además de factura, remito, chófer y producto, puede dejar reclamos por faltante o mercadería dañada y pedir una devolución.
- **Chófer**: botón de emergencia (llama al 911) y botón para avisar a tráfico de un incidente.
- **Ajustes de stock con aprobación**: un ajuste (por conteo, baja por vencimiento u otra corrección) lo pide administración o depósito y queda pendiente en Depósito → Ajustes. Lo aprueba o rechaza (con motivo) supervisión o gerencia, nunca quien lo pidió. Al aprobarse, el servidor mismo escribe el movimiento en el kardex; ni administración ni depósito pueden escribir ajustes directos, y un ajuste aprobado no se borra. Supervisión ajusta directo, y queda registrado. La carga inicial por planilla de administración no pasa por aprobación. Todo queda en el registro de auditoría.
- **Atención ahora** (Dashboard): pedidos sin ubicar o demorados en staging, pedidos con fecha vencida, errores de picking de la semana y entregas sin cerrar o no entregadas, cada uno con un botón «Ver».
- **Rol Gerente (solo consulta)**: ve todo lo que ve administración, pero el servidor rechaza cualquier escritura, subida de archivos o gestión de usuarios. Se crea en Usuarios → rol «Gerente».
- **Avisos al cliente por correo**: con SMTP configurado, el cliente recibe un mail cuando su entrega se programa, sale, se entrega o no se pudo entregar.
- **Valorizado** (Depósito › Valorizado, solo administración): valor del stock = unidades × costo unitario del SKU, agrupado por pasillo, rack, altura, depósito o categoría, con las 20 posiciones de más valor y los SKUs sin costo. Usa un costo único por SKU (no promedio ponderado ni FIFO).
- **Escenarios**: qué pasa con otra demanda u otro plazo de proveedores, consolidación de pedidos, kilómetros de retorno vacío y flota propia vs. tercerizada (estimaciones).

**Integración de pedidos (ERP)**: `POST /api/integracion/pedidos` con `{"pedidos":[{"ref":"ERP-1","cliente":"...","direccion":"...","fecha":"AAAA-MM-DD","lineas":[{"sku":"P001","cantidad":3}]}]}` y el encabezado `X-API-Key`. Quedan en borrador; reenviar el mismo `ref` los actualiza mientras sigan en borrador. `GET /api/integracion/pedidos?estado=...` devuelve el estado de cada uno.

**Escala**: las colecciones del depósito se sincronizan por diferencias (una consulta de unos 30 bytes cada 5 segundos en lugar de bajar todo), los selectores grandes pasan a búsqueda con lista, las tablas largas se paginan y el plano muestra un pasillo por vez cuando hay más de 400 posiciones. Medido en el navegador con 1.500 SKUs, 5.200 posiciones y 42.000 movimientos: cada pantalla abre en menos de 1 segundo (ABC-XYZ, 1 s).

### Circuito de gestión (Pedido → Entrega → Conciliación)

En **Control → Gestión (OTIF)** ves el cierre del circuito:

- **OTIF**: % de entregas a tiempo y completas, con costo medio por pedido y flete/venta.
- **Registrar resultado** (en pedidos despachados): fecha/hora real, cantidades entregadas y motivo si hubo faltante o demora. Si no se carga resultado, el sistema *asume* cantidad completa y lo marca.
- **Incidencias**: se crean desde el resultado; se toman, se anotan y se cierran; generan alertas.
- **Vehículo y capacidad**: al despachar elegís transportista y vehículo; avisa si el pedido supera el volumen o peso del vehículo (se configura en Control → Configuración).
- **Conciliación automática**: compara el flete facturado contra el esperado por pedido.
- **Costo por pedido**: flete + tiempo de picking real (picking guiado) + costo por km propio (configurable).
- **Completar reserva**: reintenta reservar lo que faltó. Clientes sin ficha bloquean el pedido.

Límites: retorno vacío y flota propia son estimaciones (línea recta × 1,3); el costo unitario es uno por SKU (sin FIFO/promedio).

## 4. Copias de seguridad

Con Docker, el servicio `backup` hace una copia por día en el volumen (`/data/backups`: base de datos y archivos subidos) y conserva las últimas 14 (`BACKUP_KEEP`). **Esa copia está en el mismo servidor**: si el servidor se pierde, se pierde con él. Copiala también fuera, por ejemplo con `scp`, `rclone` o el sistema de copias de tu proveedor, al menos una vez por semana.

Sin Docker: `npm run backup` (o programalo con cron).

Para restaurar: detené el portal, copiá `portal-AAAA-MM-DD.db` como `portal.db` en la carpeta de datos, y la carpeta `uploads-AAAA-MM-DD` como `uploads`. Probá una restauración antes de necesitarla.

## 5. Seguridad: lo que está y lo que falta

**Incluido**
- Contraseñas con scrypt, sesiones con cookie `HttpOnly`, límite de intentos de ingreso y límite general de pedidos por IP.
- Permisos aplicados en el servidor: un cliente no puede leer lo de otro aunque modifique la página; el operario de depósito no puede leer entregas ni clientes; un chofer solo toca sus entregas.
- Los archivos subidos (PDF, imágenes) se validan por su contenido y solo los ve quien subió el archivo, administración, el cliente de esa entrega y el chofer asignado.
- Los check lists son un registro: se crean a nombre propio, no se editan y solo administración puede borrarlos.
- Registro de actividad (ingresos, ingresos fallidos, altas, cambios de rol y de clave, borrados y correos). Se ve en Operación › Usuarios › "Ver registro de actividad".
- Cabeceras de seguridad y HTTPS automático con Caddy.
- **Rol supervisor (jefe de logística):** opera como administración (entregas, depósito, pedidos, tableros, aprobaciones) pero el servidor le niega la gestión de usuarios, la configuración del sistema, las plantillas, los consentimientos y la copia completa de datos. Se crea desde Usuarios con el rol «Supervisor».
- **Rol gerente (solo consulta):** ve indicadores, costos, depósito y entregas como administración, pero el servidor le niega toda escritura (salvo aprobar o rechazar ajustes de stock), la subida de archivos, la gestión de usuarios, la configuración, los consentimientos de ubicación y las fichas del personal. Se crea desde Usuarios (individual o carga masiva) con el rol «Gerente».
- **Portal del cliente:** el cliente pide mercadería desde su celular (código y cantidad por línea, o "repetir mi último pedido"), ve cada pedido avanzar (solicitado → aceptado → en preparación → despachado → entregado) y descarga su historial en CSV. Administración recibe los pedidos en Control › Pedidos, corrige códigos si hace falta y los acepta: se crea el pedido en borrador. El servidor solo deja al cliente ver y crear los suyos.
- **Preparación en lote:** un botón reserva y genera el picking de todos los pedidos pendientes, por fecha de entrega.
- **Tiempos reales de picking:** "▶ Empezar" marca el inicio; el dashboard muestra minutos por picking y líneas por hora por operario.
- **Controles propios:** administración puede controlar un picking que armó ella misma; queda como excepción y el supervisor la marca como revisada.
- **Chofer:** además de "No se pudo entregar" puede reprogramar la entrega para otro día con motivo; queda en el historial y el cliente lo ve.

**Falta (hacelo antes de cargar datos reales de muchos clientes)**
- **Revisión por un especialista en seguridad.** Nadie externo auditó este código.
- Verificación en dos pasos (2FA) y recuperación de contraseña **ya están implementadas** (ver «Verificación en dos pasos y recuperación de clave»). Falta activarlas en tu servidor: el 2FA lo activa cada administrador y la recuperación solo envía correos si configuraste SMTP.
- Copia de seguridad **fuera del servidor** (otro proveedor o tu computadora): la copia diaria vive en el mismo servidor, así que si se pierde el servidor se pierde la copia. Descargá la copia completa cada tanto o sincronizá la carpeta de backups.
- Revisá las obligaciones de protección de datos personales que te apliquen (Ley 25.326).
- Las listas de control de equipos son plantillas genéricas: ajustalas al manual del fabricante y a tu normativa de higiene y seguridad.

## 6. Límites conocidos

- **Carga medida** (script `npm run loadtest -- 150 20 20000`: usuarios, segundos y entregas; sin parámetros usa 40, 20 y 3.000; en una máquina de prueba, no en tu servidor): 150 usuarios simultáneos y 20.000 entregas dieron 261 operaciones/s, lectura mediana 5 ms, p95 48 ms, escritura p95 19 ms, sin errores, base de 28 MB. Antes de agregar índices y filtros en SQL el p95 era de 23,7 s. Es una simulación de acceso a la base, no 150 teléfonos reales por 4G.
- **Control logístico:** probado con datos de demostración y con una carga sintética de 1.500 SKUs; no con un depósito real. El pronóstico es un promedio ponderado de 90 días (no estacionalidad). El retorno vacío y la flota propia vs. tercerizada son estimaciones en línea recta. Las etiquetas de bulto no se leyeron con un lector real. La productividad mide tiempos solo en el picking (desde «Empezar»); en las demás tareas cuenta tareas. Un pedido se reserva por SKU y ubicación: si dos personas reservan a la vez en el mismo instante, el segundo puede ver stock ya comprometido recién en la siguiente actualización (5 segundos).
- **Escáner y cámara:** el escaneo con lector se probó escribiendo códigos con teclado simulado; la cámara solo con simulaciones. Los códigos Code 128 se validaron contra la tabla del estándar pero **no con un lector real**: imprimí una hoja de prueba y leela antes de etiquetar todo.
- **Rutas:** sin `ROUTING_URL` son heurísticas sobre línea recta × 1,3. Con `ROUTING_URL` usan calles reales, pero la integración solo se probó contra un OSRM de prueba, y no hay tránsito en vivo.
- **Cuándo pasar a PostgreSQL:** más de ~200 usuarios activos a la vez, varias sedes escribiendo o requisitos de alta disponibilidad. El acceso a datos está concentrado en `lib/db.js`, así que el cambio se hace ahí.

- Una sola instancia con SQLite: sirve para decenas de usuarios y decenas de miles de registros. Más allá hay que pasar a PostgreSQL.
- Las pantallas se actualizan consultando cada 5 segundos, no en tiempo real.
- El módulo SQLite de Node 22 figura como experimental; funciona, pero conviene fijar la versión de Node.
- La lectura de Excel usa la librería SheetJS desde una CDN (cdnjs). Para que no dependa de internet, descargá `xlsx.full.min.js` a `public/` y cambiá la dirección en `public/app.js` (función `loadXLSX`).
- Los check lists se leen en bloques de los últimos 400 registros; el historial completo queda en la base.
- Las fotos de entrega sacadas sin señal se guardan en el teléfono y se suben solas al volver la conexión (probado con un navegador simulando el corte; el archivo llega idéntico).
- Las pantallas nuevas (prueba de entrega, gestión, lotes, conteos, picking, importación) las probé con datos de ejemplo en el navegador y de punta a punta en un servidor real (chofer con consentimiento, firma, foto y ubicación; API de integración); no se probaron con clientes reales ni con un celular físico.
- Docker y Caddy están escritos pero **no los pude ejecutar** donde armé el proyecto (no había Docker). Si el primer `docker compose up` falla, es un ajuste menor.

## 7. Para ofrecerlo a otras empresas

Cada empresa necesita su **propia instalación** (su servidor, su dominio y su base de datos): no mezcles clientes en una misma. Antes de cada alta: definí quién recibe el soporte y en qué horario, cómo se hacen y verifican las copias, y quién responde si hay un problema con datos de personas. El registro de actividad y la copia diaria te sirven para investigar cualquier consulta.

## Estructura

```
server.js          servidor y API
lib/               base de datos, ingreso, permisos, correo, TOTP e integración
docs/              plantillas: piloto, datos y ubicación, soporte, caso de ahorro
public/            pantallas (app.js es el portal; compat.js lo conecta con la API y guarda la cola sin conexión)
public/sw.js       copia de la aplicación para abrirla sin señal
scripts/           seed (datos iniciales) y backup
test/smoke.js      pruebas automáticas
data/seed/         datos tomados de tu Excel
```
